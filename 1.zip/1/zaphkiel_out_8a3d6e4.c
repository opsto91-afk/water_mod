// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d6e4
// fn_va = 0x8a3d6e4
// return type (guess): unknown (no ret found)
void* fn_0x8a3d6e4(void* this) {
        // stp x29, x30, [sp, #0xd0]  (0x8a3d6e8)
        *(void**)(sp + 0xe0) = r21;
        // stp x20, x19, [sp, #0xf0]  (0x8a3d6f0)
        fp = sp + 0xd0;
        // mrs x21, tpidr_el0  (0x8a3d6f8)
        r19 = r2;
        r20 = r1;
        r8 = *(void**)(r21 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = *(void**)(this + 0x8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xf0);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3d7cc;
        rd0 = *(void**)(r20);
        r8 = *(void**)(this);
        r6 = rzr;
        rs1 = *(void**)(r20 + 0x8);
        rd2 = *(void**)(r19);
        r7 = rzr;
        *(void**)(sp + 0x30) = rd0;
        rs0 = *(void**)(r19 + 0x8);
        r10 = (void*)0x141db670;
        r9 = *(void**)(r8 + 0x198);
        r8 = sp + 0x40;
        r1 = sp + 0x30;
        r2 = sp + 0x20;
        *(void**)(sp + 0x38) = rs1;
        *(void**)(sp + 0x20) = rd2;
        *(void**)(sp + 0x28) = rs0;
        *(uint8_t*)(sp + 0x10) = rzr;
        // stp xzr, x10, [sp]  (0x8a3d774)
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x58);
        // cmp r8 == - <complex operand>
        if (/* cond: b.hi */) goto label_0x8a3d7f4;
        r9 = *(void**)(sp + 0x74);
        r8 = *(void**)(sp + 0x80);
        this = *(void**)(sp + 0x6c);
        // orr x1, x9, #0x100000000  (0x8a3d798)
        if (r8 == 0) goto label_0x8a3d7d0;
        r19 = this;
        this = r8;
        r20 = r1;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
        this = r19;
        r1 = r20;
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0x8a3d7e0;
        goto label_0x8a3d818;
    label_0x8a3d7cc:
        r1 = rzr;
    label_0x8a3d7d0:
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3d818;
    label_0x8a3d7e0:
        // ldp x20, x19, [sp, #0xf0]  (0x8a3d7e0)
        r21 = *(void**)(sp + 0xe0);
        // ldp x29, x30, [sp, #0xd0]  (0x8a3d7e8)
        sp = sp + 0x100;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7b9bb0
// fn_va = 0xb7b9bb0
// return type (guess): unknown (no ret found)
void* fn_0xb7b9bb0(void* this) {
        *(void**)(sp + 0x180) = rd8;
        // stp x29, x30, [sp, #0x190]  (0xb7b9bb8)
        // stp x28, x27, [sp, #0x1a0]  (0xb7b9bbc)
        // stp x26, x25, [sp, #0x1b0]  (0xb7b9bc0)
        // stp x24, x23, [sp, #0x1c0]  (0xb7b9bc4)
        // stp x22, x21, [sp, #0x1d0]  (0xb7b9bc8)
        // stp x20, x19, [sp, #0x1e0]  (0xb7b9bcc)
        fp = sp + 0x190;
        // mrs x25, tpidr_el0  (0xb7b9bd4)
        r19 = this;
        this = this + 0x1c0;
        r8 = *(void**)(r25 + 0x28);
        r21 = r1;
        *(void**)(fp - 0x20) = r8;
        this = fn_0xb7fbf68(this, r1, r2, r3);  // call  [0xb7fbf68]
        r8 = *(void**)(r19 + 0x1d8);
        r9 = *(void**)(r19 + 0x1f0);
        *(void**)(r19 + 0x1e0) = r8;
        r8 = *(void**)(r19 + 0x918);
        *(void**)(r19 + 0x1f8) = r9;
        r9 = *(void**)(r19 + 0x220);
        *(void**)(r19 + 0x920) = r8;
        r8 = *(void**)(r19 + 0x238);
        *(void**)(r19 + 0x228) = r9;
        r9 = *(void**)(r19 + 0x250);
        *(void**)(r19 + 0x240) = r8;
        r8 = *(void**)(r19 + 0x978);
        *(void**)(r19 + 0x258) = r9;
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0xae0);
        r8 = fp - 0xc0;
        this = (*(void**)r8)(this);  // indirect call
        // ldp x9, x8, [x29, #0xffffffffffffff40]  (0xb7b9c38)
        // stp x9, x8, [sp, #0x70]  (0xb7b9c3c)
        if (r8 == 0) goto label_0xb7b9c68;
        r1 = r8 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r20 = *(void**)(fp - 0xb8);
        if (r20 == 0) goto label_0xb7b9c68;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7ba154;
    label_0xb7b9c68:
        r8 = *(void**)(sp + 0x70);
        if (r8 == 0) goto label_0xb7bac14;
    label_0xb7b9c70:
        r8 = *(void**)(r19 + 0x978);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xf8);
        this = (*(void**)r8)(this);  // indirect call
        rs0 = *(void**)(r19 + 0x430);
        r20 = *(void**)(r19 + 0x958);
        // fmov s1, w8  (0xb7b9c90)
        r22 = this;
        // fcmpe s1, s0  (0xb7b9c98)
        // fcsel s8, s1, s0, mi  (0xb7b9c9c)
        // fmov s0, s8  (0xb7b9ca0)
        this = r19 + 0x1c0;
        r2 = r19 + 0x620;
        r1 = r20;
        this = fn_0xb7fba1c(this, r1, r2, r3);  // call  [0xb7fba1c]
        r8 = *(void**)(r19 + 0x978);
        this = *(void**)(r8 + 0x3d8);
        this = fn_0x9c77730(this, r1, r2, r3);  // call  [0x9c77730]
        // tbz w0, #0x0, 0xb7b9cec  (0xb7b9cc0)
        r23 = *(void**)(r19 + 0x950);
        this = r22;
        this = fn_0xfd82818(this, r1, r2, r3);  // call  [0xfd82818]
        *(void**)(fp - 0xc0) = this;
        // fmov s0, s8  (0xb7b9cd4)
        this = r19 + 0x1c0;
        r2 = fp - 0xc0;
        r3 = r19 + 0x620;
        r1 = r23;
        this = fn_0xb7fbc98(this, r1, r2, r3);  // call  [0xb7fbc98]
    label_0xb7b9cec:
        this = r19 + 0x1c0;
        this = fn_0xb7fbdfc(this, r1, r2, r3);  // call  [0xb7fbdfc]
        r8 = *(void**)(r19 + 0x978);
        // stp xzr, xzr, [sp, #0x58]  (0xb7b9cf8)
        *(void**)(sp + 0x68) = rzr;
        this = *(void**)(r8 + 0x3d8);
        *(void**)(fp - 0x30) = rzr;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xcc8);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7b9d54  (0xb7b9d14)
        r8 = (void*)0x13a584b8;
        r9 = sp + 0x58;
        r23 = fp - 0xc0;
        this = fp - 0xc0;
        r1 = fp - 0x50;
        // stp x8, x9, [x29, #0xffffffffffffff40]  (0xb7b9d30)
        *(void**)(fp - 0xa0) = r23;
        this = fn_0xb7f756c(this, r1, r2, r3);  // call  [0xb7f756c]
        this = *(void**)(fp - 0xa0);
        // cmp this == r23
        if (/* cond: b.ne */) goto label_0xb7b9d80;
    label_0xb7b9d48:
        this = fp - 0xc0;
        goto label_0xb7b9d88;
    label_0xb7b9d54:
        r8 = (void*)0x13a58548;
        r23 = fp - 0xc0;
        this = fp - 0xc0;
        r1 = fp - 0x50;
        // stp x8, x19, [x29, #0xffffffffffffff40]  (0xb7b9d68)
        *(void**)(fp - 0xa0) = r23;
        this = fn_0xb7f756c(this, r1, r2, r3);  // call  [0xb7f756c]
        this = *(void**)(fp - 0xa0);
        // cmp this == r23
        if (/* cond: b.eq */) goto label_0xb7b9d48;
    label_0xb7b9d80:
        if (this == 0) goto label_0xb7b9d94;
    label_0xb7b9d88:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7b9d94:
        *(void**)(sp + 0x50) = rzr;
        rd0 = *(void**)(r8 + 0xbf0);
        *(void**)(sp + 0x88) = r22;
        *(void**)(sp + 0x48) = rd0;
        this = r22;
        this = fn_0xfd89a58(this, r1, r2, r3);  // call  [0xfd89a58]
        *(void**)(sp + 0x90) = this;
        this = r22;
        this = fn_0xfd96614(this, r1, r2, r3);  // call  [0xfd96614]
        r8 = *(void**)(r19 + 0x978);
        // and w9, w0, #0x1  (0xb7b9dc0)
        *(uint8_t*)(sp + 0x98) = r9;
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x688);
        this = (*(void**)r8)(this);  // indirect call
        // and w8, w0, #0x1  (0xb7b9dd8)
        *(uint8_t*)(sp + 0x99) = r8;
        this = r22;
        this = fn_0xfd7b6c0(this, r1, r2, r3);  // call  [0xfd7b6c0]
        // and w8, w0, #0x1  (0xb7b9de8)
        *(void**)(fp - 0x60) = rzr;
        *(uint8_t*)(sp + 0x9a) = r8;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r8 = (void*)0x13a585c8;
        r9 = sp + 0x48;
        // stp x8, x21, [x0]  (0xb7b9e08)
        r8 = sp + 0x88;
        // stp x8, x9, [x0, #0x10]  (0xb7b9e10)
        r8 = sp + 0x70;
        // stp x19, x8, [x0, #0x20]  (0xb7b9e18)
        r8 = fp - 0x50;
        *(void**)(this + 0x30) = r8;
        *(void**)(fp - 0x60) = this;
        this = r19 + 0x1c0;
        r1 = fp - 0x80;
        r21 = fp - 0x80;
        *(void**)(sp + 0x10) = r25;
        this = fn_0xb7fbf14(this, r1, r2, r3);  // call  [0xb7fbf14]
        this = *(void**)(fp - 0x60);
        // cmp this == r21
        if (/* cond: b.eq */) goto label_0xb7b9e54;
        if (this == 0) goto label_0xb7b9e68;
        goto label_0xb7b9e5c;
    label_0xb7b9e54:
        this = fp - 0x80;
    label_0xb7b9e5c:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7b9e68:
        rs0 = *(void**)(r19 + 0x620);
        rs1 = *(void**)(r19 + 0x624);
        this = sp + 0xb8;
        rs2 = *(void**)(r19 + 0x628);
        r1 = fp - 0xc0;
        r2 = sp + 0xa0;
        // fsub s3, s0, s8  (0xb7b9e80)
        // fsub s4, s1, s8  (0xb7b9e84)
        // fadd s0, s0, s8  (0xb7b9e88)
        // fsub s5, s2, s8  (0xb7b9e8c)
        // fadd s1, s1, s8  (0xb7b9e90)
        // fadd s2, s2, s8  (0xb7b9e94)
        // stp s3, s4, [x29, #0xffffffffffffff40]  (0xb7b9e98)
        *(void**)(fp - 0xb8) = rs5;
        // stp s0, s1, [sp, #0xa0]  (0xb7b9ea0)
        *(void**)(sp + 0xa8) = rs2;
        this = fn_0x11f0f24c(this, r1, r2, r3);  // call  [0x11f0f24c]
        r8 = *(void**)(r19 + 0x9e8);
        *(void**)(r19 + 0x9f0) = r8;
        r1 = sp + 0xb8;
        r2 = r19 + 0x9e8;
        this = r20;
        this = fn_0x10376000(this, r1, r2, r3);  // call  [0x10376000]
        r8 = *(void**)(r19 + 0xa18);
        if (r8 == 0) goto label_0xb7ba208;
        r22 = *(void**)(r19 + 0xa10);
        r21 = r19 + 0xa00;
        if (r22 == 0) goto label_0xb7ba1e0;
        r27 = rzr;
        r23 = r19 + 0xa28;
        r8 = r19 + 0xa30;
        r26 = r22;
        *(void**)(sp + 0x18) = r8;
        goto label_0xb7b9f04;
    label_0xb7b9ef4:
        // ldp w1, w2, [sp, #0xa0]  (0xb7b9ef4)
        this = r23;
        this = fn_0xb7f80b4(this, r1, r2, r3);  // call  [0xb7f80b4]
        if (r26 == 0) goto label_0xb7ba1bc;
    label_0xb7b9f04:
        // cmp r27 == 0x64
        if (/* cond: b.eq */) goto label_0xb7ba178;
        r8 = *(void**)(r26 + 0x10);
        *(void**)(sp + 0xa0) = r8;
        r8 = *(void**)(r20);
        r26 = *(void**)(r26);
        r8 = *(void**)(r8 + 0x148);
        r1 = sp + 0xa0;
        this = r20;
        this = (*(void**)r8)(this);  // indirect call
        r27 = r27 + 0x1;
        if (this == 0) goto label_0xb7b9ef4;
        // movi v0.2d, #0x0  (0xb7b9f34)
        *(void**)(fp - 0xa0) = r8;
        // stp q0, q0, [x29, #0xffffffffffffff40]  (0xb7b9f40)
        this = fn_0x10bae940(this, r1, r2, r3);  // call  [0x10bae940]
        this = fn_0x10bc10dc(this, r1, r2, r3);  // call  [0x10bc10dc]
        r24 = this + 0x10;
    label_0xb7b9f50:
        r24 = *(void**)(r24);
        if (r24 == 0) goto label_0xb7b9f6c;
        this = fp - 0xc0;
        r1 = r24 + 0x10;
        r2 = r24 + 0x10;
        this = fn_0xa9f5a48(this, r1, r2, r3);  // call  [0xa9f5a48]
        goto label_0xb7b9f50;
    label_0xb7b9f6c:
        r8 = *(void**)(fp - 0xa8);
        if (r8 == 0) goto label_0xb7ba0d8;
        r28 = *(void**)(sp + 0x18);
        r10 = *(void**)(r28);
        r25 = r28;
        if (r10 == 0) goto label_0xb7b9fd8;
        // ldp w8, w9, [sp, #0xa0]  (0xb7b9f84)
        goto label_0xb7b9f98;
    label_0xb7b9f8c:
        r10 = *(void**)(r28);
        r25 = r28;
        if (r10 == 0) goto label_0xb7b9fd8;
    label_0xb7b9f98:
        r28 = r10;
        r10 = *(void**)(r10 + 0x20);
        // cmp r8 == r10
        if (/* cond: b.lt */) goto label_0xb7b9f8c;
        if (/* cond: b.ne */) goto label_0xb7b9fc4;
        r10 = *(void**)(r28 + 0x24);
        // cmp r9 == r10
        if (/* cond: b.lt */) goto label_0xb7b9f8c;
        // cmp r10 == r9
        if (/* cond: b.lt */) goto label_0xb7b9fcc;
        goto label_0xb7ba144;
    label_0xb7b9fc4:
        // cmp r10 == r8
        if (/* cond: b.ge */) goto label_0xb7ba144;
    label_0xb7b9fcc:
        r10 = *(void**)(r28 + 0x8);
        if (r10 != 0) goto label_0xb7b9f98;
        r25 = r28 + 0x8;
    label_0xb7b9fd8:
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // movi v0.2d, #0x0  (0xb7b9fe0)
        r8 = *(void**)(sp + 0xa0);
        // stp xzr, xzr, [x0]  (0xb7b9fe8)
        *(void**)(this + 0x10) = r28;
        r24 = this;
        r1 = this;
        *(void**)(this + 0x20) = r8;
        *(void**)(this + 0x48) = r8;
        *(void**)(this + 0x28) = rq0;
        *(void**)(this + 0x38) = rq0;
        *(void**)(r25) = this;
        r8 = *(void**)(r23);
        r8 = *(void**)(r8);
        if (r8 == 0) goto label_0xb7ba024;
        *(void**)(r23) = r8;
        r1 = *(void**)(r25);
    label_0xb7ba024:
        this = *(void**)(r19 + 0xa30);
        this = fn_0x88fea88(this, r1, r2, r3);  // call  [0x88fea88]
        r8 = *(void**)(r19 + 0xa38);
        r8 = (void*)0x13a585c9;
        *(void**)(r19 + 0xa38) = r8;
        r8 = *(void**)(r24 + 0x40);
        if (r8 == 0) goto label_0xb7ba080;
    label_0xb7ba040:
        this = *(void**)(r24 + 0x38);
        if (this == 0) goto label_0xb7ba058;
    label_0xb7ba048:
        r25 = *(void**)(this);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        this = r25;
        if (r25 != 0) goto label_0xb7ba048;
    label_0xb7ba058:
        r8 = *(void**)(r24 + 0x30);
        *(void**)(r24 + 0x38) = rzr;
        if (r8 == 0) goto label_0xb7ba07c;
        r9 = rzr;
    label_0xb7ba068:
        r10 = *(void**)(r24 + 0x28);
        r9 = r9 + 0x1;
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7ba068;
    label_0xb7ba07c:
        *(void**)(r24 + 0x40) = rzr;
    label_0xb7ba080:
        r8 = *(void**)(fp - 0xc0);
        this = *(void**)(r24 + 0x28);
        *(void**)(fp - 0xc0) = rzr;
        *(void**)(r24 + 0x28) = r8;
        if (this == 0) goto label_0xb7ba098;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ba098:
        // ldp x9, x0, [x29, #0xffffffffffffff48]  (0xb7ba098)
        r8 = r24;
        r10 = *(void**)(fp - 0xa8);
        rs0 = *(void**)(fp - 0xa0);
        *(void**)(fp - 0xb8) = rzr;
        *(void**)(r8 + 0x38) = this;
        *(void**)(r8 - 0x8) = r9;
        *(void**)(r8 + 0x8) = r10;
        *(void**)(r8 + 0x10) = rs0;
        if (r10 == 0) goto label_0xb7ba0e8;
        r11 = r9 - 0x1;
        r10 = *(void**)(this + 0x8);
        // tst x9, x11  (0xb7ba0c8)
        if (/* cond: b.ne */) goto label_0xb7ba114;
        // and x10, x10, x11  (0xb7ba0d0)
        goto label_0xb7ba124;
    label_0xb7ba0d8:
        // ldp w1, w2, [sp, #0xa0]  (0xb7ba0d8)
        this = r23;
        this = fn_0xb7f80b4(this, r1, r2, r3);  // call  [0xb7f80b4]
        this = *(void**)(fp - 0xb0);
    label_0xb7ba0e8:
        if (this == 0) goto label_0xb7ba0fc;
    label_0xb7ba0ec:
        r24 = *(void**)(this);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        this = r24;
        if (r24 != 0) goto label_0xb7ba0ec;
    label_0xb7ba0fc:
        this = *(void**)(fp - 0xc0);
        *(void**)(fp - 0xc0) = rzr;
        if (this == 0) goto label_0xb7ba10c;
    label_0xb7ba108:
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ba10c:
        if (r26 != 0) goto label_0xb7b9f04;
        goto label_0xb7ba1bc;
    label_0xb7ba114:
        // cmp r10 == r9
        if (/* cond: b.lo */) goto label_0xb7ba124;
        // udiv x11, x10, x9  (0xb7ba11c)
        // msub x10, x11, x9, x10  (0xb7ba120)
    label_0xb7ba124:
        r9 = *(void**)(r24 + 0x28);
        r8 = fp - 0xc0;
        // stp xzr, xzr, [x8, #0x10]  (0xb7ba130)
        this = *(void**)(fp - 0xc0);
        *(void**)(fp - 0xc0) = rzr;
        if (this != 0) goto label_0xb7ba108;
        goto label_0xb7ba10c;
    label_0xb7ba144:
        r24 = r28;
        r8 = *(void**)(r28 + 0x40);
        if (r8 != 0) goto label_0xb7ba040;
        goto label_0xb7ba080;
    label_0xb7ba154:
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        r8 = *(void**)(sp + 0x70);
        if (r8 != 0) goto label_0xb7b9c70;
        goto label_0xb7bac14;
    label_0xb7ba178:
        r25 = *(void**)(sp + 0x10);
        // cmp r22 == r26
        if (/* cond: b.ne */) goto label_0xb7ba194;
        goto label_0xb7ba208;
    label_0xb7ba188:
        // cmp r23 == r26
        r22 = r23;
        if (/* cond: b.eq */) goto label_0xb7ba208;
    label_0xb7ba194:
        r23 = *(void**)(r22);
        r8 = fp - 0xc0;
        this = r21;
        r1 = r22;
        this = fn_0x99ebd64(this, r1, r2, r3);  // call  [0x99ebd64]
        this = *(void**)(fp - 0xc0);
        *(void**)(fp - 0xc0) = rzr;
        if (this == 0) goto label_0xb7ba188;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7ba188;
    label_0xb7ba1bc:
        r8 = *(void**)(r19 + 0xa18);
        r25 = *(void**)(sp + 0x10);
        if (r8 == 0) goto label_0xb7ba208;
        this = *(void**)(r19 + 0xa10);
        if (this == 0) goto label_0xb7ba1e0;
    label_0xb7ba1d0:
        r22 = *(void**)(this);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        this = r22;
        if (r22 != 0) goto label_0xb7ba1d0;
    label_0xb7ba1e0:
        r8 = *(void**)(r19 + 0xa08);
        *(void**)(r19 + 0xa10) = rzr;
        if (r8 == 0) goto label_0xb7ba204;
        r9 = rzr;
    label_0xb7ba1f0:
        r10 = *(void**)(r21);
        r9 = r9 + 0x1;
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7ba1f0;
    label_0xb7ba204:
        *(void**)(r19 + 0xa18) = rzr;
    label_0xb7ba208:
        r21 = *(void**)(r19 + 0x9e8);
        r22 = *(void**)(r19 + 0x9f0);
        // cmp r21 == r22
        if (/* cond: b.eq */) goto label_0xb7ba234;
    label_0xb7ba218:
        r1 = *(void**)(r21);
        r2 = r19 + 0xa28;
        this = r19;
        this = fn_0xb7baf4c(this, r1, r2, r3);  // call  [0xb7baf4c]
        r21 = r21 + 0x8;
        // cmp r21 == r22
        if (/* cond: b.ne */) goto label_0xb7ba218;
    label_0xb7ba234:
        r23 = *(void**)(r19 + 0xa28);
        r21 = r19 + 0xa30;
        // cmp r23 == r21
        if (/* cond: b.eq */) goto label_0xb7ba2e0;
        r8 = fp - 0xc0;
        r22 = (void*)0x13a585d1;
        goto label_0xb7ba25c;
    label_0xb7ba250:
        // cmp r8 == r21
        r23 = r8;
        if (/* cond: b.eq */) goto label_0xb7ba2e0;
    label_0xb7ba25c:
        r24 = *(void**)(r23 + 0x38);
        if (r24 != 0) goto label_0xb7ba2a4;
    label_0xb7ba264:
        r9 = *(void**)(r23 + 0x8);
        if (r9 == 0) goto label_0xb7ba27c;
    label_0xb7ba26c:
        r8 = r9;
        r9 = *(void**)(r9);
        if (r9 != 0) goto label_0xb7ba26c;
        goto label_0xb7ba250;
    label_0xb7ba27c:
        r8 = *(void**)(r23 + 0x10);
        r9 = *(void**)(r8);
        // cmp r9 == r23
        r23 = r8;
        if (/* cond: b.ne */) goto label_0xb7ba27c;
        goto label_0xb7ba250;
    label_0xb7ba294:
        this = *(void**)(fp - 0xb8);
        this = fn_0xb7ee690(this, r1, r2, r3);  // call  [0xb7ee690]
    label_0xb7ba29c:
        r24 = *(void**)(r24);
        if (r24 == 0) goto label_0xb7ba264;
    label_0xb7ba2a4:
        r1 = r24 + 0x10;
        this = r20;
        this = fn_0x10371388(this, r1, r2, r3);  // call  [0x10371388]
        if (this == 0) goto label_0xb7ba29c;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xb8);
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        if (r1 == 0) goto label_0xb7ba29c;
        // stp xzr, xzr, [x22]  (0xb7ba2c8)
        *(void**)(fp - 0xc0) = r22;
        r2 = fp - 0xc0;
        this = r19;
        this = fn_0xb7baf4c(this, r1, r2, r3);  // call  [0xb7baf4c]
        goto label_0xb7ba294;
    label_0xb7ba2e0:
        r8 = *(void**)(r19 + 0x9e8);
        this = *(void**)(r19 + 0x950);
        *(void**)(r19 + 0x9f0) = r8;
        r8 = sp + 0x38;
        this = fn_0x10b05aa4(this, r1, r2, r3);  // call  [0x10b05aa4]
        r8 = *(void**)(sp + 0x38);
        // stp xzr, xzr, [x29, #0xffffffffffffff50]  (0xb7ba2f8)
        r22 = (void*)0x1407f9b8;
        // stp x8, xzr, [x29, #0xffffffffffffff40]  (0xb7ba304)
        // ldarb w8, [x22]  (0xb7ba308)
        // tbz w8, #0x0, 0xb7bacb0  (0xb7ba30c)
    label_0xb7ba310:
        r23 = (void*)0x1407f968;
        // stp x23, x8, [x29, #0xffffffffffffff68]  (0xb7ba31c)
        r8 = sp + 0x88;
        r24 = *(void**)(fp - 0xc0);
        // stp x19, x8, [sp, #0x20]  (0xb7ba32c)
        r8 = sp + 0x48;
        *(void**)(fp - 0x88) = r9;
        *(void**)(sp + 0x30) = r8;
        this = r24 + 0x28;
        // movk w1, #0x85b9, lsl #0x10  (0xb7ba344)
        this = fn_0x96b7824(this, r1, r2, r3);  // call  [0x96b7824]
        r20 = this;
        this = r24 + 0x28;
        // movk w1, #0x8dab, lsl #0x10  (0xb7ba358)
        this = fn_0xb7f81f8(this, r1, r2, r3);  // call  [0xb7f81f8]
        r21 = this;
        this = r24 + 0x28;
        // movk w1, #0x3890, lsl #0x10  (0xb7ba36c)
        this = fn_0xb7f83f0(this, r1, r2, r3);  // call  [0xb7f83f0]
        // ldarb w8, [x22]  (0xb7ba374)
        r9 = fp - 0xc0;
        r24 = r9 + 0x8;
        // tbz w8, #0x0, 0xb7bacf8  (0xb7ba380)
    label_0xb7ba384:
        // ldp x11, x10, [x21, #0x20]  (0xb7ba384)
        // ldp x9, x8, [x20, #0x20]  (0xb7ba38c)
        // stp x20, x21, [x29, #0xffffffffffffff48]  (0xb7ba390)
        // ldp x13, x12, [x0, #0x20]  (0xb7ba394)
        *(void**)(fp - 0xa8) = this;
        *(void**)(fp - 0x88) = r22;
        // cmp r11 == r10
        // csel x11, x11, x10, cc  (0xb7ba3b0)
        // cset w13, cc  (0xb7ba3b4)
        // cmp r12 == r11
        // csel x11, x11, x13, cc  (0xb7ba3c0)
        // stp x23, x11, [x29, #0xffffffffffffff68]  (0xb7ba3c4)
        if (r23 == 0) goto label_0xb7ba524;
        // cmp r23 == r20
        if (/* cond: b.ne */) goto label_0xb7ba510;
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0xb7ba510;
        // asr x8, x10, #0x2  (0xb7ba3e0)
        r26 = fp - 0xc0;
        r27 = sp + 0x80;
        r25 = r8 - 0x1;
        goto label_0xb7ba408;
    label_0xb7ba3fc:
        r25 = r25 - 0x1;
        // cmp r25 == - 0x1
        if (/* cond: b.eq */) goto label_0xb7ba50c;
    label_0xb7ba408:
        r8 = *(void**)(r20 + 0x20);
        r9 = *(void**)(fp - 0xb0);
        // ldp x10, x11, [x9, #0x8]  (0xb7ba414)
        // ubfx x9, x8, #0xb, #0x7  (0xb7ba418)
        // cmp r9 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba3fc;
        if (r11 == 0) goto label_0xb7ba3fc;
        // and x10, x8, #0x3ffff  (0xb7ba430)
        // and x10, x10, #0x7ff  (0xb7ba434)
        // and w11, w8, #0xfffc0000  (0xb7ba43c)
        // eor w12, w12, w11  (0xb7ba440)
        // cmp r12 == r24
        if (/* cond: b.hi */) goto label_0xb7ba3fc;
        r12 = *(void**)(fp - 0xa8);
        // ldp x12, x13, [x12, #0x8]  (0xb7ba450)
        // cmp r9 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba3fc;
        if (r9 == 0) goto label_0xb7ba3fc;
        // eor w9, w9, w11  (0xb7ba46c)
        // cmp r9 == r24
        if (/* cond: b.hi */) goto label_0xb7ba3fc;
        // lsr x9, x25, #0x4  (0xb7ba478)
        r1 = *(void**)(fp - 0xc0);
        r10 = *(void**)(r20 + 0x50);
        *(void**)(sp + 0x80) = r8;
        // and x9, x9, #0xffffffffffffff8  (0xb7ba488)
        this = *(void**)(r1 + 0x150);
        *(void**)(fp - 0x88) = r8;
        if (this == 0) goto label_0xb7ba4b8;
        *(void**)(sp + 0xb8) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0xb8;
        this = (*(void**)r8)(this);  // indirect call
        r1 = *(void**)(fp - 0xc0);
        r8 = *(void**)(fp - 0x88);
    label_0xb7ba4b8:
        // and x9, x25, #0x7f  (0xb7ba4b8)
        this = sp + 0xb8;
        r2 = sp + 0x84;
        // stp x26, x27, [sp, #0xa0]  (0xb7ba4c4)
        *(uint8_t*)(sp + 0xb0) = r28;
        *(void**)(sp + 0x84) = r8;
        this = fn_0x134686b8(this, r1, r2, r3);  // call  [0x134686b8]
        this = sp + 0x20;
        r1 = r21;
        this = fn_0xb7f893c(this, r1, r2, r3);  // call  [0xb7f893c]
        r8 = *(void**)(fp - 0xc0);
        this = *(void**)(r8 + 0x180);
        if (this == 0) goto label_0xb7ba3fc;
        r8 = *(void**)(sp + 0x80);
        *(void**)(sp + 0xb8) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0xb8;
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7ba3fc;
    label_0xb7ba50c:
        r21 = *(void**)(fp - 0xb0);
    label_0xb7ba510:
        // cmp r23 == r21
        if (/* cond: b.eq */) goto label_0xb7ba5c8;
    label_0xb7ba518:
        r8 = *(void**)(fp - 0xa8);
        // cmp r23 == r8
        if (/* cond: b.eq */) goto label_0xb7ba700;
    label_0xb7ba524:
        r8 = *(void**)(r19 + 0x978);
        *(void**)(fp - 0x88) = r22;
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xcc8);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7baa7c  (0xb7ba53c)
        r8 = *(void**)(r19 + 0x978);
        this = *(void**)(r8 + 0x3c8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x1e0);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r19 + 0x978);
        r20 = this;
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xcd8);
        this = (*(void**)r8)(this);  // indirect call
        // scvtf s1, w20  (0xb7ba56c)
        // ldp x0, x1, [sp, #0x58]  (0xb7ba570)
        // subs x8, x1, x0  (0xb7ba57c)
        // fmul s0, s1, s0  (0xb7ba580)
        // asr x8, x8, #0x4  (0xb7ba584)
        // cmp r1 == this
        // clz x8, x8  (0xb7ba58c)
        // fcvtzs w10, s0  (0xb7ba594)
        // csel x2, xzr, x8, eq  (0xb7ba598)
        *(void**)(sp + 0x18) = r10;
        this = fn_0xb7e871c(this, r1, r2, r3);  // call  [0xb7e871c]
        // ldp x22, x23, [sp, #0x58]  (0xb7ba5a4)
        // cmp r22 == r23
        if (/* cond: b.eq */) goto label_0xb7baa7c;
        r25 = sp + 0xb8;
        // movk w26, #0x20b9, lsl #0x10  (0xb7ba5bc)
        *(void**)(sp + 0xc) = rzr;
        goto label_0xb7ba858;
    label_0xb7ba5c8:
        // ldp x9, x8, [x23, #0x20]  (0xb7ba5c8)
        // subs x8, x8, x9  (0xb7ba5cc)
        if (/* cond: b.eq */) goto label_0xb7ba518;
        // asr x8, x8, #0x2  (0xb7ba5d4)
        r25 = fp - 0xc0;
        r26 = sp + 0x80;
        r24 = r8 - 0x1;
        goto label_0xb7ba5fc;
    label_0xb7ba5f0:
        r24 = r24 - 0x1;
        // cmp r24 == - 0x1
        if (/* cond: b.eq */) goto label_0xb7ba518;
    label_0xb7ba5fc:
        r8 = *(void**)(r23 + 0x20);
        r9 = *(void**)(fp - 0xb8);
        // ldp x11, x12, [x9, #0x8]  (0xb7ba608)
        // ubfx x10, x8, #0xb, #0x7  (0xb7ba60c)
        // cmp r10 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba5f0;
        if (r12 == 0) goto label_0xb7ba5f0;
        // and x11, x8, #0x3ffff  (0xb7ba624)
        // and x11, x11, #0x7ff  (0xb7ba628)
        // and w12, w8, #0xfffc0000  (0xb7ba630)
        // eor w13, w20, w12  (0xb7ba634)
        // cmp r13 == r21
        if (/* cond: b.hi */) goto label_0xb7ba5f0;
        r13 = *(void**)(fp - 0xa8);
        // ldp x13, x14, [x13, #0x8]  (0xb7ba644)
        // cmp r10 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba5f0;
        if (r10 == 0) goto label_0xb7ba5f0;
        // eor w10, w10, w12  (0xb7ba660)
        // cmp r10 == r21
        if (/* cond: b.hi */) goto label_0xb7ba5f0;
        // and x10, x20, #0x3ff80  (0xb7ba66c)
        r1 = *(void**)(fp - 0xc0);
        r9 = *(void**)(r9 + 0x50);
        // lsr x10, x10, #0x4  (0xb7ba678)
        *(void**)(sp + 0x80) = r8;
        this = *(void**)(r1 + 0x150);
        *(void**)(fp - 0x88) = r8;
        if (this == 0) goto label_0xb7ba6ac;
        *(void**)(sp + 0xb8) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0xb8;
        this = (*(void**)r8)(this);  // indirect call
        r1 = *(void**)(fp - 0xc0);
        r8 = *(void**)(fp - 0x88);
    label_0xb7ba6ac:
        // and x9, x20, #0x7f  (0xb7ba6ac)
        this = sp + 0xb8;
        r2 = sp + 0x84;
        // stp x25, x26, [sp, #0xa0]  (0xb7ba6b8)
        *(uint8_t*)(sp + 0xb0) = r27;
        *(void**)(sp + 0x84) = r8;
        this = fn_0x134686b8(this, r1, r2, r3);  // call  [0x134686b8]
        this = sp + 0x20;
        r1 = r20;
        this = fn_0xb7f893c(this, r1, r2, r3);  // call  [0xb7f893c]
        r8 = *(void**)(fp - 0xc0);
        this = *(void**)(r8 + 0x180);
        if (this == 0) goto label_0xb7ba5f0;
        r8 = *(void**)(sp + 0x80);
        *(void**)(sp + 0xb8) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0xb8;
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7ba5f0;
    label_0xb7ba700:
        // ldp x9, x8, [x23, #0x20]  (0xb7ba700)
        // subs x8, x8, x9  (0xb7ba704)
        if (/* cond: b.eq */) goto label_0xb7ba524;
        // asr x8, x8, #0x2  (0xb7ba70c)
        r25 = fp - 0xc0;
        r26 = sp + 0x80;
        r24 = r8 - 0x1;
        goto label_0xb7ba734;
    label_0xb7ba728:
        r24 = r24 - 0x1;
        // cmp r24 == - 0x1
        if (/* cond: b.eq */) goto label_0xb7ba524;
    label_0xb7ba734:
        r8 = *(void**)(r23 + 0x20);
        r9 = *(void**)(fp - 0xb8);
        // ldp x11, x12, [x9, #0x8]  (0xb7ba740)
        // ubfx x10, x8, #0xb, #0x7  (0xb7ba744)
        // cmp r10 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba728;
        if (r12 == 0) goto label_0xb7ba728;
        // and x11, x8, #0x3ffff  (0xb7ba75c)
        // and x11, x11, #0x7ff  (0xb7ba760)
        // and w12, w8, #0xfffc0000  (0xb7ba768)
        // eor w13, w20, w12  (0xb7ba76c)
        // cmp r13 == r21
        if (/* cond: b.hi */) goto label_0xb7ba728;
        r13 = *(void**)(fp - 0xb0);
        // ldp x13, x14, [x13, #0x8]  (0xb7ba77c)
        // cmp r10 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba728;
        if (r10 == 0) goto label_0xb7ba728;
        // eor w10, w10, w12  (0xb7ba798)
        // cmp r10 == r21
        if (/* cond: b.hi */) goto label_0xb7ba728;
        // and x10, x20, #0x3ff80  (0xb7ba7a4)
        r1 = *(void**)(fp - 0xc0);
        r9 = *(void**)(r9 + 0x50);
        // lsr x10, x10, #0x4  (0xb7ba7b0)
        *(void**)(sp + 0x80) = r8;
        this = *(void**)(r1 + 0x150);
        *(void**)(fp - 0x88) = r8;
        if (this == 0) goto label_0xb7ba7e4;
        *(void**)(sp + 0xb8) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0xb8;
        this = (*(void**)r8)(this);  // indirect call
        r1 = *(void**)(fp - 0xc0);
        r8 = *(void**)(fp - 0x88);
    label_0xb7ba7e4:
        // and x9, x20, #0x7f  (0xb7ba7e4)
        this = sp + 0xb8;
        r2 = sp + 0x84;
        // stp x25, x26, [sp, #0xa0]  (0xb7ba7f0)
        *(uint8_t*)(sp + 0xb0) = r27;
        *(void**)(sp + 0x84) = r8;
        this = fn_0x134686b8(this, r1, r2, r3);  // call  [0x134686b8]
        this = sp + 0x20;
        r1 = r20;
        this = fn_0xb7f893c(this, r1, r2, r3);  // call  [0xb7f893c]
        r8 = *(void**)(fp - 0xc0);
        this = *(void**)(r8 + 0x180);
        if (this == 0) goto label_0xb7ba728;
        r8 = *(void**)(sp + 0x80);
        *(void**)(sp + 0xb8) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0xb8;
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7ba728;
    label_0xb7ba838:
        *(uint16_t*)(r21) = r8;
        r8 = *(void**)(sp + 0xc);
        *(void**)(sp + 0xc) = r8;
    label_0xb7ba84c:
        r22 = (void*)0x1407f9c8;
        // cmp r22 == r23
        if (/* cond: b.eq */) goto label_0xb7baa7c;
    label_0xb7ba858:
        r8 = *(void**)(r22);
        r10 = *(void**)(r8 + 0x10);
        // ldp x11, x9, [x10, #0x38]  (0xb7ba860)
        // lsr x9, x9, #0x3  (0xb7ba868)
        // and x12, x9, x26  (0xb7ba870)
        r9 = *(void**)(r8 + 0x18);
        r12 = *(void**)(r10 + 0x50);
    label_0xb7ba880:
        r11 = *(void**)(r11);
        // cmp r11 == - 0x1
        if (/* cond: b.eq */) goto label_0xb7ba968;
        r13 = *(void**)(r11 + 0x8);
        // cmp r13 == r26
        if (/* cond: b.ne */) goto label_0xb7ba880;
        r10 = *(void**)(r10 + 0x58);
        // cmp r11 == r10
        if (/* cond: b.eq */) goto label_0xb7ba968;
        r10 = *(void**)(r11 + 0x10);
        if (r10 == 0) goto label_0xb7ba968;
        // ldp x11, x13, [x10, #0x8]  (0xb7ba8b0)
        // ubfx x12, x9, #0xb, #0x7  (0xb7ba8b4)
        // cmp r12 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7ba968;
        if (r11 == 0) goto label_0xb7ba968;
        // and x12, x9, #0x3ffff  (0xb7ba8cc)
        // and w9, w9, #0xfffc0000  (0xb7ba8d0)
        // and x12, x12, #0x7ff  (0xb7ba8d4)
        // eor w9, w28, w9  (0xb7ba8e0)
        // cmp r9 == r11
        if (/* cond: b.hi */) goto label_0xb7ba968;
        // and x9, x28, #0x3ff80  (0xb7ba8ec)
        r10 = *(void**)(r10 + 0x50);
        // lsr x9, x9, #0x4  (0xb7ba8f4)
        if (r21 == 0) goto label_0xb7ba968;
        r9 = *(void**)(sp + 0x18);
        r10 = *(void**)(sp + 0xc);
        // cmp r10 == r9
        if (/* cond: b.ge */) goto label_0xb7ba84c;
        if (r8 == 0) goto label_0xb7bac78;
        // ldp x24, x9, [x19, #0x1d8]  (0xb7ba914)
        *(void**)(sp + 0xb8) = r8;
        *(uint8_t*)(sp + 0xc0) = r27;
        // subs x10, x9, x24  (0xb7ba920)
        if (/* cond: b.eq */) goto label_0xb7baa00;
        // asr x10, x10, #0x3  (0xb7ba928)
        r20 = r24;
    label_0xb7ba930:
        // lsr x11, x10, #0x1  (0xb7ba930)
        // mvn x14, x11  (0xb7ba938)
        // cmp r13 == r8
        // csel x10, x10, x11, cc  (0xb7ba948)
        // csel x20, x12, x20, cc  (0xb7ba94c)
        if (r10 != 0) goto label_0xb7ba930;
        r10 = *(void**)(r19 + 0x1f0);
        // cmp r9 == r20
        *(void**)(sp) = r10;
        if (/* cond: b.ne */) goto label_0xb7baa14;
        goto label_0xb7baa20;
    label_0xb7ba968:
        if (r8 == 0) goto label_0xb7bac78;
        // ldp x21, x9, [x19, #0x1d8]  (0xb7ba96c)
        *(void**)(sp + 0xb8) = r8;
        *(uint8_t*)(sp + 0xc0) = r27;
        // subs x10, x9, x21  (0xb7ba978)
        if (/* cond: b.eq */) goto label_0xb7ba9bc;
        // asr x10, x10, #0x3  (0xb7ba980)
        r20 = r21;
    label_0xb7ba988:
        // lsr x11, x10, #0x1  (0xb7ba988)
        // mvn x14, x11  (0xb7ba990)
        // cmp r13 == r8
        // csel x10, x10, x11, cc  (0xb7ba9a0)
        // csel x20, x12, x20, cc  (0xb7ba9a4)
        if (r10 != 0) goto label_0xb7ba988;
        r24 = *(void**)(r19 + 0x1f0);
        // cmp r9 == r20
        if (/* cond: b.ne */) goto label_0xb7ba9cc;
        goto label_0xb7ba9d8;
    label_0xb7ba9bc:
        r20 = r21;
        r24 = *(void**)(r19 + 0x1f0);
        // cmp r9 == r21
        if (/* cond: b.eq */) goto label_0xb7ba9d8;
    label_0xb7ba9cc:
        r9 = *(void**)(r20);
        // cmp r8 == r9
        if (/* cond: b.hs */) goto label_0xb7ba84c;
    label_0xb7ba9d8:
        this = r19 + 0x1d8;
        r2 = sp + 0xb8;
        r1 = r20;
        this = fn_0xb7f7704(this, r1, r2, r3);  // call  [0xb7f7704]
        this = r19 + 0x1f0;
        r2 = r25 + 0x8;
        this = fn_0xb7f7944(this, r1, r2, r3);  // call  [0xb7f7944]
        goto label_0xb7ba84c;
    label_0xb7baa00:
        r20 = r24;
        r10 = *(void**)(r19 + 0x1f0);
        // cmp r9 == r24
        *(void**)(sp) = r10;
        if (/* cond: b.eq */) goto label_0xb7baa20;
    label_0xb7baa14:
        r9 = *(void**)(r20);
        // cmp r8 == r9
        if (/* cond: b.hs */) goto label_0xb7baa48;
    label_0xb7baa20:
        this = r19 + 0x1d8;
        r2 = sp + 0xb8;
        r1 = r20;
        this = fn_0xb7f7704(this, r1, r2, r3);  // call  [0xb7f7704]
        r9 = *(void**)(sp);
        this = r19 + 0x1f0;
        r2 = r25 + 0x8;
        this = fn_0xb7f7944(this, r1, r2, r3);  // call  [0xb7f7944]
    label_0xb7baa48:
        // and x8, x28, #0x7f  (0xb7baa48)
        r8 = *(uint8_t*)(r21 + 0x1);
        // tbnz w8, #0x0, 0xb7ba838  (0xb7baa54)
        this = *(void**)(r22);
        this = fn_0xfd9b168(this, r1, r2, r3);  // call  [0xfd9b168]
        r20 = *(void**)(r22);
        this = r20;
        this = fn_0xfd86998(this, r1, r2, r3);  // call  [0xfd86998]
        r1 = this;
        this = r20;
        this = fn_0xfd8d9c0(this, r1, r2, r3);  // call  [0xfd8d9c0]
        goto label_0xb7ba838;
    label_0xb7baa7c:
        // ldp x8, x24, [x19, #0x1d8]  (0xb7baa7c)
        // ldp x9, x25, [x19, #0x1f0]  (0xb7baa80)
        // cmp r8 == r24
        if (/* cond: b.ne */) goto label_0xb7baa94;
        // cmp r9 == r25
        if (/* cond: b.eq */) goto label_0xb7bab8c;
    label_0xb7baa94:
        r10 = r19 + 0x918;
        r28 = (void*)0x13a585d1;
        r8 = r9 + 0x1;
        *(void**)(sp + 0x18) = r10;
    label_0xb7baaa4:
        this = *(void**)(sp + 0x70);
        r1 = *(void**)(r28 - 0x8);
        r26 = r8;
        this = fn_0xab51614(this, r1, r2, r3);  // call  [0xab51614]
        // tbz w0, #0x0, 0xb7bab6c  (0xb7baab4)
        r27 = *(void**)(r19 + 0x920);
        r8 = *(void**)(r19 + 0x928);
        // cmp r27 == r8
        if (/* cond: b.hs */) goto label_0xb7baad4;
        r8 = *(void**)(r28 - 0x8);
        goto label_0xb7bab68;
    label_0xb7baad4:
        r9 = *(void**)(sp + 0x18);
        r21 = *(void**)(r9);
        // asr x27, x22, #0x3  (0xb7baae0)
        r9 = r27 + 0x1;
        // lsr x10, x9, #0x3d  (0xb7baae8)
        if (r10 != 0) goto label_0xb7bac7c;
        // asr x10, x8, #0x2  (0xb7baaf4)
        // cmp r10 == r9
        // csel x9, x10, x9, hi  (0xb7baafc)
        r10 = 0x7ffffffffffffff8;
        // cmp r8 == r10
        r8 = 0x1fffffffffffffff;
        // csel x20, x9, x8, cc  (0xb7bab0c)
        if (r20 == 0) goto label_0xb7bab2c;
        // lsr x8, x20, #0x3d  (0xb7bab14)
        if (r8 != 0) goto label_0xb7bac98;
        // lsl x0, x20, #0x3  (0xb7bab1c)
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r23 = this;
        goto label_0xb7bab30;
    label_0xb7bab2c:
        r23 = rzr;
    label_0xb7bab30:
        r8 = *(void**)(r28 - 0x8);
        this = r23;
        r1 = r21;
        r2 = r22;
        this = fn_0x135df980(this, r1, r2, r3);  // call  [0x135df980]
        *(void**)(r19 + 0x918) = r23;
        *(void**)(r19 + 0x920) = r27;
        *(void**)(r19 + 0x928) = r20;
        if (r21 == 0) goto label_0xb7bab68;
        this = r21;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bab68:
        *(void**)(r19 + 0x920) = r27;
    label_0xb7bab6c:
        r9 = (void*)0x13a585d9;
        // cmp r28 == r24
        r8 = r26 + 0x1;
        r28 = r9;
        if (/* cond: b.ne */) goto label_0xb7baaa4;
        // cmp r26 == r25
        r28 = r9;
        if (/* cond: b.ne */) goto label_0xb7baaa4;
    label_0xb7bab8c:
        r19 = *(void**)(sp + 0x40);
        if (r19 == 0) goto label_0xb7baba4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7babc4;
    label_0xb7baba4:
        this = *(void**)(fp - 0x30);
        r8 = fp - 0x50;
        r25 = *(void**)(sp + 0x10);
        // cmp this == r8
        if (/* cond: b.eq */) goto label_0xb7babf0;
    label_0xb7babb8:
        if (this == 0) goto label_0xb7bac04;
        goto label_0xb7babf8;
    label_0xb7babc4:
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        this = *(void**)(fp - 0x30);
        r8 = fp - 0x50;
        r25 = *(void**)(sp + 0x10);
        // cmp this == r8
        if (/* cond: b.ne */) goto label_0xb7babb8;
    label_0xb7babf0:
        this = fp - 0x50;
    label_0xb7babf8:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7bac04:
        this = *(void**)(sp + 0x58);
        if (this == 0) goto label_0xb7bac14;
        *(void**)(sp + 0x60) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bac14:
        r19 = *(void**)(sp + 0x78);
        if (r19 == 0) goto label_0xb7bac44;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bac44;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bac44:
        r8 = *(void**)(r25 + 0x28);
        r9 = *(void**)(fp - 0x20);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7baefc;
        // ldp x20, x19, [sp, #0x1e0]  (0xb7bac54)
        rd8 = *(void**)(sp + 0x180);
        // ldp x22, x21, [sp, #0x1d0]  (0xb7bac5c)
        // ldp x24, x23, [sp, #0x1c0]  (0xb7bac60)
        // ldp x26, x25, [sp, #0x1b0]  (0xb7bac64)
        // ldp x28, x27, [sp, #0x1a0]  (0xb7bac68)
        // ldp x29, x30, [sp, #0x190]  (0xb7bac6c)
        sp = sp + 0x1f0;
        return this;
}

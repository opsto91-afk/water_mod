// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7aa584
// fn_va = 0xb7aa584
// return type (guess): unknown (no ret found)
void* fn_0xb7aa584(void* this) {
        // stp x29, x30, [sp, #0x80]  (0xb7aa588)
        // stp x28, x27, [sp, #0x90]  (0xb7aa58c)
        // stp x26, x25, [sp, #0xa0]  (0xb7aa590)
        // stp x24, x23, [sp, #0xb0]  (0xb7aa594)
        // stp x22, x21, [sp, #0xc0]  (0xb7aa598)
        // stp x20, x19, [sp, #0xd0]  (0xb7aa59c)
        fp = sp + 0x80;
        // mrs x8, tpidr_el0  (0xb7aa5a4)
        r20 = r2;
        r19 = r1;
        *(void**)(sp + 0x20) = r8;
        r21 = this;
        r8 = *(void**)(r8 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = fn_0x135d3960(this, r1, r2, r3);  // call  [0x135d3960]
        // tst w20, #0x1  (0xb7aa5c4)
        r22 = this;
        // csel x8, x9, x8, ne  (0xb7aa5d4)
        this = r21 + 0x208;
        this = fn_0xa337fe0(this, r1, r2, r3);  // call  [0xa337fe0]
        // ldp x26, x24, [x23]  (0xb7aa5e4)
        // cmp r26 == r24
        if (/* cond: b.eq */) goto label_0xb7aa794;
        r23 = sp + 0x38;
        r25 = (void*)0x14087e50;
        goto label_0xb7aa614;
    label_0xb7aa600:
        *(void**)(sp + 0x68) = r8;
    label_0xb7aa608:
        r26 = r26 + 0x8;
        // cmp r26 == r24
        if (/* cond: b.eq */) goto label_0xb7aa794;
    label_0xb7aa614:
        this = *(void**)(r26);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x68);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(this);
        r27 = this;
        if (r8 != 0) goto label_0xb7aa650;
        r8 = *(void**)(r27 + 0x8);
        // movk w9, #0x8f0, lsl #0x10  (0xb7aa638)
        // cmp r22 == r8
        if (/* cond: b.le */) goto label_0xb7aa650;
        *(uint8_t*)(r27) = r8;
    label_0xb7aa650:
        this = *(void**)(r26);
        r28 = *(void**)(r21 + 0x958);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r28);
        r1 = this;
        this = r28;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(r27);
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7aa608;
        r27 = this;
        this = *(void**)(r26);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x18);
        this = (*(void**)r8)(this);  // indirect call
        // and w28, w0, #0xff  (0xb7aa698)
        this = r27;
        this = fn_0x109f9050(this, r1, r2, r3);  // call  [0x109f9050]
        // cmp r28 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7aa6c8;
        this = *(void**)(r26);
        r8 = *(void**)(this);
        r8 = *(void**)(r8);
        this = (*(void**)r8)(this);  // indirect call
        r1 = *(void**)(r21 + 0x958);
        this = fn_0x10f2fb58(this, r1, r2, r3);  // call  [0x10f2fb58]
        // tbz w0, #0x0, 0xb7aa608  (0xb7aa6c4)
    label_0xb7aa6c8:
        this = r19;
        this = fn_0xae177d4(this, r1, r2, r3);  // call  [0xae177d4]
        r8 = (void*)0x14087e60;
        r2 = *(void**)(r21 + 0x958);
        r3 = *(void**)(r26);
        // ldarb w8, [x8]  (0xb7aa6e0)
        // tbz w8, #0x0, 0xb7aa740  (0xb7aa6e4)
    label_0xb7aa6e8:
        *(uint8_t*)(sp + 0x38) = rzr;
        *(uint8_t*)(sp + 0x70) = rzr;
        r7 = rzr;
        // and w5, w20, #0x1  (0xb7aa6f4)
        r1 = r19;
        r4 = r27;
        r6 = r25;
        *(void**)(sp + 0x8) = r23;
        *(void**)(sp) = rzr;
        this = fn_0xaa49de0(this, r1, r2, r3);  // call  [0xaa49de0]
        r8 = *(uint8_t*)(sp + 0x70);
        if (r8 == 0) goto label_0xb7aa608;
        r8 = *(void**)(sp + 0x68);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7aa600;
        r9 = (void*)0x13a56488;
        this = sp + 0x28;
        r1 = r23 + 0x18;
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7aa600;
    label_0xb7aa740:
        // stp x2, x0, [sp, #0x10]  (0xb7aa740)
        this = (void*)0x14087e60;
        r28 = r3;
        this = fn_0x135d36e0(this, r1, r2, r3);  // call  [0x135d36e0]
        r8 = this;
        // ldp x2, x0, [sp, #0x10]  (0xb7aa758)
        r3 = r28;
        if (r8 == 0) goto label_0xb7aa6e8;
        this = (void*)0x89569ec;
        r1 = r25;
        r2 = (void*)0x1368a9b0;
        this = fn_0x135d36c0(this, r1, r2, r3);  // call  [0x135d36c0]
        this = (void*)0x14087e60;
        this = fn_0x135d36f0(this, r1, r2, r3);  // call  [0x135d36f0]
        // ldp x2, x0, [sp, #0x10]  (0xb7aa788)
        r3 = r28;
        goto label_0xb7aa6e8;
    label_0xb7aa794:
        this = r19;
        this = fn_0xae04bb0(this, r1, r2, r3);  // call  [0xae04bb0]
        r8 = sp + 0x28;
        r1 = rzr;
        this = fn_0x11a191b8(this, r1, r2, r3);  // call  [0x11a191b8]
        this = sp + 0x28;
        this = fn_0x11a1987c(this, r1, r2, r3);  // call  [0x11a1987c]
        r8 = *(void**)(sp + 0x20);
        r8 = *(void**)(r8 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7aa810;
        // ldp x20, x19, [sp, #0xd0]  (0xb7aa7c4)
        // ldp x22, x21, [sp, #0xc0]  (0xb7aa7c8)
        // ldp x24, x23, [sp, #0xb0]  (0xb7aa7cc)
        // ldp x26, x25, [sp, #0xa0]  (0xb7aa7d0)
        // ldp x28, x27, [sp, #0x90]  (0xb7aa7d4)
        // ldp x29, x30, [sp, #0x80]  (0xb7aa7d8)
        sp = sp + 0xe0;
        return this;
}

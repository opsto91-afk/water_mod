// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bf1f8
// fn_va = 0xb7bf1f8
// return type (guess): unknown (no ret found)
void* fn_0xb7bf1f8(void* this) {
        // stp x29, x30, [sp, #0x30]  (0xb7bf1fc)
        // stp x22, x21, [sp, #0x40]  (0xb7bf200)
        // stp x20, x19, [sp, #0x50]  (0xb7bf204)
        fp = sp + 0x30;
        // mrs x22, tpidr_el0  (0xb7bf20c)
        r20 = r1;
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = fn_0xb7afc3c(this, r1, r2, r3);  // call  [0xb7afc3c]
        this = r20;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0xb7bf23c  (0xb7bf22c)
        r1 = r19 + 0xc60;
        this = r20;
        this = fn_0xaf66c9c(this, r1, r2, r3);  // call  [0xaf66c9c]
    label_0xb7bf23c:
        r8 = *(void**)(r19 + 0x978);
        this = r8 + 0x500;
        this = fn_0xb81cdd4(this, r1, r2, r3);  // call  [0xb81cdd4]
        this = *(void**)(r19 + 0x978);
        this = fn_0xb7a583c(this, r1, r2, r3);  // call  [0xb7a583c]
        this = *(void**)(r19 + 0x968);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7bf278  (0xb7bf260)
        this = *(void**)(r19 + 0x968);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xd0);
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7bf27c;
    label_0xb7bf278:
    label_0xb7bf27c:
        r8 = *(void**)(r19 + 0x11c0);
        *(uint16_t*)(r19 + 0x970) = this;
        *(uint8_t*)(r19 + 0x4cb) = rzr;
        *(void**)(r19 + 0x5f0) = rzr;
        *(void**)(r19 + 0x600) = rzr;
        *(void**)(r19 + 0x5f8) = rzr;
        if (r8 == 0) goto label_0xb7bf2c8;
        r20 = *(void**)(r19 + 0x11b8);
        if (r20 != 0) goto label_0xb7bf424;
    label_0xb7bf2a0:
        r8 = *(void**)(r19 + 0x11b0);
        *(void**)(r19 + 0x11b8) = rzr;
        if (r8 == 0) goto label_0xb7bf2c4;
        r9 = rzr;
    label_0xb7bf2b0:
        r10 = *(void**)(r19 + 0x11a8);
        r9 = r9 + 0x1;
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bf2b0;
    label_0xb7bf2c4:
        *(void**)(r19 + 0x11c0) = rzr;
    label_0xb7bf2c8:
        r8 = *(void**)(r19 + 0x1118);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x350);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp);
        if (r8 == 0) goto label_0xb7bf43c;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7bf454  (0xb7bf2ec)
    label_0xb7bf2f0:
        r21 = *(void**)(sp + 0x10);
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r20 = this;
        this = r21;
        this = fn_0xacbde14(this, r1, r2, r3);  // call  [0xacbde14]
        r9 = *(void**)(this + 0x220);
        r8 = *(void**)(this + 0x228);
        // stp x9, x8, [sp, #0x18]  (0xb7bf310)
        if (r8 == 0) goto label_0xb7bf324;
        r1 = r8 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7bf324:
        r1 = sp + 0x18;
        this = r20;
        this = fn_0xac29d88(this, r1, r2, r3);  // call  [0xac29d88]
        this = *(void**)(sp + 0x20);
        if (this == 0) goto label_0xb7bf33c;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bf33c:
        r21 = *(void**)(r19 + 0xcd0);
        *(void**)(r19 + 0xcd0) = r20;
        if (r21 == 0) goto label_0xb7bf358;
        this = r21;
        this = fn_0xac2a2d8(this, r1, r2, r3);  // call  [0xac2a2d8]
        this = r21;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bf358:
        r20 = *(void**)(sp + 0x8);
        // stp xzr, xzr, [sp]  (0xb7bf35c)
        if (r20 == 0) goto label_0xb7bf3c0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bf38c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bf38c:
        r20 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r20 == 0) goto label_0xb7bf3c0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bf3c0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bf3c0:
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r20 = this;
        this = fn_0xb74ac30(this, r1, r2, r3);  // call  [0xb74ac30]
        this = *(void**)(r19 + 0xcd8);
        *(void**)(r19 + 0xcd8) = r20;
        if (this == 0) goto label_0xb7bf3e0;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bf3e0:
        if (r9 == 0) goto label_0xb7bf3f0;
    label_0xb7bf3f0:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bf4ac;
        // ldp x20, x19, [sp, #0x50]  (0xb7bf400)
        // ldp x22, x21, [sp, #0x40]  (0xb7bf404)
        // ldp x29, x30, [sp, #0x30]  (0xb7bf408)
        sp = sp + 0x60;
        return this;
}

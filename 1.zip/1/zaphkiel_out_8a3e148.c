// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e148
// fn_va = 0x8a3e148
// return type (guess): unknown (no ret found)
void* fn_0x8a3e148(void* this) {
        // stp x29, x30, [sp, #0xfffffffffffffff0]!  (0x8a3e148)
        this = *(void**)(this + 0x8);
        this = fn_0xa429758(this, r1, r2, r3);  // call  [0xa429758]
        if (this == 0) goto label_0x8a3e168;
        // ldp s0, s1, [x0, #0x2c]  (0x8a3e15c)
        // ldp x29, x30, [sp], #0x10  (0x8a3e160)
        return this;
}

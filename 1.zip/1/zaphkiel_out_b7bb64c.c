// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bb64c
// fn_va = 0xb7bb64c
// return type (guess): unknown (no ret found)
void* fn_0xb7bb64c(void* this) {
        // stp x29, x30, [sp, #0xf0]  (0xb7bb650)
        // stp x28, x25, [sp, #0x100]  (0xb7bb654)
        // stp x24, x23, [sp, #0x110]  (0xb7bb658)
        // stp x22, x21, [sp, #0x120]  (0xb7bb65c)
        // stp x20, x19, [sp, #0x130]  (0xb7bb660)
        fp = sp + 0xf0;
        // mrs x24, tpidr_el0  (0xb7bb668)
        // movi v0.2d, #0x0  (0xb7bb66c)
        r25 = sp + 0x10;
        r8 = *(void**)(r24 + 0x28);
        r19 = r25 + 0x40;
        r20 = this;
        r21 = fp - 0x40;
        r1 = r19;
        *(void**)(fp - 0x8) = r8;
        // stp q0, q0, [sp, #0x10]  (0xb7bb690)
        *(void**)(sp + 0x10) = r8;
        // stp q0, q0, [x25, #0x80]  (0xb7bb69c)
        *(uint8_t*)(sp + 0x14) = r8;
        r8 = (void*)0x13a58658;
        // stp x8, x0, [x25, #0xa0]  (0xb7bb6ac)
        this = fp - 0x40;
        // stp q0, q0, [sp, #0x30]  (0xb7bb6b4)
        // stp q0, q0, [sp, #0x50]  (0xb7bb6b8)
        // stp q0, q0, [sp, #0x70]  (0xb7bb6bc)
        *(void**)(r25 + 0x90) = rzr;
        *(void**)(r25 + 0xc0) = r21;
        this = fn_0xb7f0250(this, r1, r2, r3);  // call  [0xb7f0250]
        this = *(void**)(r25 + 0xc0);
        // cmp this == r21
        if (/* cond: b.eq */) goto label_0xb7bb6e4;
        if (this == 0) goto label_0xb7bb6f8;
        goto label_0xb7bb6ec;
    label_0xb7bb6e4:
        this = fp - 0x40;
    label_0xb7bb6ec:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7bb6f8:
        this = *(void**)(r20 + 0x968);
        if (this == 0) goto label_0xb7bb714;
        this = fn_0x10b3eba4(this, r1, r2, r3);  // call  [0x10b3eba4]
        r8 = *(void**)(this);
        // lsr w9, w8, #0x10  (0xb7bb708)
        goto label_0xb7bb71c;
    label_0xb7bb714:
        r8 = rzr;
        r9 = rzr;
    label_0xb7bb71c:
        *(uint16_t*)(sp + 0x10) = r8;
        *(uint16_t*)(sp + 0x12) = r9;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r21 = this;
        r8 = (void*)0x13a58288;
        r23 = this + 0x20;
        // stp xzr, xzr, [x0, #0x8]  (0xb7bb73c)
        *(void**)(this) = r8;
        r1 = sp + 0x10;
        this = r23;
        this = fn_0xb7f91ac(this, r1, r2, r3);  // call  [0xb7f91ac]
        r22 = *(void**)(r20 + 0x5b8);
        *(void**)(r20 + 0x5b0) = r23;
        *(void**)(r20 + 0x5b8) = r21;
        if (r22 == 0) goto label_0xb7bb788;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bb788;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bb788:
        r21 = *(void**)(r20 + 0x5b0);
        this = sp + 0x4;
        r1 = r20 + 0x614;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r8 = *(void**)(r20 + 0x598);
        r11 = *(void**)(sp + 0xc);
        // ldrsh w12, [x21, #0xfa]  (0xb7bb7a0)
        // ldp w9, w10, [sp, #0x4]  (0xb7bb7a4)
        // bic w8, w8, w8, asr #0x1f  (0xb7bb7a8)
        // ldrsh w13, [x21, #0xfc]  (0xb7bb7ac)
        // cmp r15 == r12
        // asr w11, w14, #0x4  (0xb7bb7cc)
        // asr w14, w16, #0x4  (0xb7bb7d0)
        // csel w16, w15, w12, gt  (0xb7bb7d4)
        // cmp r15 == r13
        // asr w8, w8, #0x4  (0xb7bb7dc)
        // asr w9, w9, #0x4  (0xb7bb7e0)
        // csel w15, w13, w16, gt  (0xb7bb7e4)
        // cmp r10 == r12
        // csel w12, w10, w12, gt  (0xb7bb7ec)
        // cmp r10 == r13
        // asr w15, w15, #0x4  (0xb7bb7f4)
        // csel w12, w13, w12, gt  (0xb7bb800)
        // orr x11, x11, x15, lsl #0x20  (0xb7bb80c)
        // asr w12, w12, #0x4  (0xb7bb810)
        *(void**)(fp - 0x2c) = r8;
        // mul w8, w16, w10  (0xb7bb818)
        *(void**)(r25 + 0xa0) = r11;
        // orr x9, x9, x12, lsl #0x20  (0xb7bb824)
        *(void**)(fp - 0x38) = r14;
        // stp w16, w8, [x29, #0xffffffffffffffe0]  (0xb7bb830)
        // mul w8, w11, w8  (0xb7bb834)
        // orr x10, x10, x11, lsl #0x20  (0xb7bb838)
        *(void**)(r25 + 0xac) = r9;
        *(void**)(r25 + 0xb8) = r10;
        // stp w8, w9, [x29, #0xffffffffffffffe8]  (0xb7bb848)
        r1 = fp - 0x40;
        this = r21;
        this = fn_0xb7ee96c(this, r1, r2, r3);  // call  [0xb7ee96c]
        r8 = sp + 0x10;
        this = *(void**)(r25 + 0x90);
        r9 = (void*)0x13a582f8;
        // cmp this == r9
        *(uint8_t*)(r20 + 0x99a) = r8;
        if (/* cond: b.eq */) goto label_0xb7bb880;
        if (this == 0) goto label_0xb7bb894;
        goto label_0xb7bb888;
    label_0xb7bb880:
        this = r9;
    label_0xb7bb888:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7bb894:
        this = *(void**)(sp + 0x70);
        // cmp this == r19
        if (/* cond: b.eq */) goto label_0xb7bb8ac;
        if (this == 0) goto label_0xb7bb8c0;
        goto label_0xb7bb8b4;
    label_0xb7bb8ac:
        this = r19;
    label_0xb7bb8b4:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7bb8c0:
        r8 = sp + 0x10;
        this = *(void**)(sp + 0x40);
        r9 = (void*)0x13a58298;
        // cmp this == r9
        if (/* cond: b.eq */) goto label_0xb7bb8e0;
        if (this == 0) goto label_0xb7bb8f4;
        goto label_0xb7bb8e8;
    label_0xb7bb8e0:
        this = r9;
    label_0xb7bb8e8:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7bb8f4:
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bb960;
        // ldp x20, x19, [sp, #0x130]  (0xb7bb904)
        // ldp x22, x21, [sp, #0x120]  (0xb7bb908)
        // ldp x24, x23, [sp, #0x110]  (0xb7bb90c)
        // ldp x28, x25, [sp, #0x100]  (0xb7bb910)
        // ldp x29, x30, [sp, #0xf0]  (0xb7bb914)
        sp = sp + 0x140;
        return this;
}

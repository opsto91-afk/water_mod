// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x91782cc
// fn_va = 0x91782cc
// return type (guess): unknown (no ret found)
void* fn_0x91782cc(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x91782cc)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = *(void**)(this + 0x8);
        r8 = (void*)0x138054f0;
        *(void**)(r19) = r8;
        if (this == 0) goto label_0x9178300;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xe0);
        r1 = r19;
        this = (*(void**)r8)(this);  // indirect call
    label_0x9178300:
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9178308)
        return fn_0xe803424(/* tail call */);
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        *(void**)(this + 0x8) = rzr;
        return this;
}

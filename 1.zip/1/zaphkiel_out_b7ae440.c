// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7ae440
// fn_va = 0xb7ae440
// return type (guess): unknown (no ret found)
void* fn_0xb7ae440(void* this, void* r1) {
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0xb7ae440)
        *(void**)(sp + 0x10) = r21;
        // stp x20, x19, [sp, #0x20]  (0xb7ae448)
        r9 = *(void**)(r1 + 0x100);
        r19 = r8;
        // ldp x21, x20, [x9]  (0xb7ae458)
        if (r20 == 0) goto label_0xb7ae4b0;
        r1 = r20 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r20 + 0x8;
        // stp xzr, xzr, [x19]  (0xb7ae474)
        // stp xzr, x21, [x19, #0x10]  (0xb7ae478)
        *(void**)(r19 + 0x20) = r20;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7ae4bc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7ae4bc;
    label_0xb7ae4b0:
        // stp xzr, xzr, [x19]  (0xb7ae4b0)
        // stp xzr, x21, [x19, #0x10]  (0xb7ae4b4)
        *(void**)(r19 + 0x20) = rzr;
    label_0xb7ae4bc:
        this = r19 + 0x28;
        this = fn_0x117b5a60(this, r1, r2, r3);  // call  [0x117b5a60]
        // ldp x20, x19, [sp, #0x20]  (0xb7ae4c4)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0xb7ae4cc)
        return this;
}

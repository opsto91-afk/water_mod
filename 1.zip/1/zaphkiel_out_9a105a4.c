// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a105a4
// fn_va = 0x9a105a4
// return type (guess): unknown (no ret found)
void* fn_0x9a105a4(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a105a4)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = fn_0x9a10384(this, r1, r2, r3);  // call  [0x9a10384]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9a105c0)
        return fn_0xe803424(/* tail call */);
        r9 = *(void**)(this + 0x40);
        r8 = *(void**)(r8 + 0x928);
        // cmp r9 == r8
        // cset w0, ne  (0x9a105d8)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d4274
// fn_va = 0xb7d4274
// return type (guess): unknown (no ret found)
void* fn_0xb7d4274(void* this) {
        *(void**)(sp + 0x140) = rd10;
        // stp d9, d8, [sp, #0x150]  (0xb7d427c)
        // stp x29, x30, [sp, #0x160]  (0xb7d4280)
        // stp x28, x25, [sp, #0x170]  (0xb7d4284)
        // stp x24, x23, [sp, #0x180]  (0xb7d4288)
        // stp x22, x21, [sp, #0x190]  (0xb7d428c)
        // stp x20, x19, [sp, #0x1a0]  (0xb7d4290)
        fp = sp + 0x160;
        // mrs x23, tpidr_el0  (0xb7d4298)
        r20 = (void*)0x1407f080;
        r8 = *(void**)(r23 + 0x28);
        r19 = this;
        this = r20;
        r21 = r1;
        *(void**)(fp - 0x28) = r8;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r22 = *(void**)(r8 + 0x160);
        if (r22 == 0) goto label_0xb7d47d0;
        r8 = *(uint8_t*)(r22);
        if (r8 == 0) goto label_0xb7d47d0;
        r24 = *(void**)(r8 + 0x168);
        if (r24 == 0) goto label_0xb7d42f4;
        r1 = r24 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r22);
        goto label_0xb7d42f8;
    label_0xb7d42f4:
    label_0xb7d42f8:
        *(void**)(fp - 0x98) = r20;
        this = *(void**)(r9 + 0x170);
        // sturb w25, [x29, #0xffffffffffffff70]  (0xb7d4304)
        // stp x22, x24, [x29, #0xffffffffffffff78]  (0xb7d4308)
        *(void**)(fp - 0x78) = this;
        if (r8 != 0) goto label_0xb7d4324;
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0xb7d431c)
        *(void**)(r8) = r9;
    label_0xb7d4324:
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x280);
        r8 = sp + 0x8;
        this = (*(void**)r8)(this);  // indirect call
        // ldp x24, x20, [sp, #0x8]  (0xb7d4334)
        if (r20 == 0) goto label_0xb7d4364;
        r1 = (void*)0x1407f088;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d4364;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d4364:
        r22 = *(void**)(r19 + 0x980);
        r20 = *(void**)(r19 + 0x988);
        // stp x22, x20, [sp, #0x68]  (0xb7d436c)
        if (r20 == 0) goto label_0xb7d4380;
        r1 = (void*)0x1407f088;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7d4380:
        if (r22 == 0) goto label_0xb7d43a4;
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0x68);
        this = r22;
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7d43a4;
        r8 = *(void**)(r24 + 0x7ec);
        r9 = this + 0x1a8;
        // stlr w8, [x9]  (0xb7d43a0)
    label_0xb7d43a4:
        rs0 = *(void**)(r24 + 0x7e8);
        rs1 = *(void**)(r19 + 0xd70);
        rs2 = *(void**)(r19 + 0xd74);
        rs3 = *(void**)(r19 + 0xd78);
        rs4 = *(void**)(r19 + 0xd7c);
        rs5 = *(void**)(r19 + 0xd84);
        // fmul s1, s1, s0  (0xb7d43bc)
        // fmul s2, s2, s0  (0xb7d43c0)
        r8 = *(void**)(r19 + 0xd70);
        // fmul s0, s3, s0  (0xb7d43c8)
        rs3 = *(void**)(r19 + 0xd80);
        r22 = *(uint8_t*)(r21 + 0x4e);
        *(void**)(sp + 0x50) = r8;
        r8 = *(void**)(r19 + 0xd78);
        // cmp r22 == <complex operand>
        // fsub s8, s4, s1  (0xb7d43e0)
        // fsub s10, s3, s2  (0xb7d43e4)
        // cset w21, eq  (0xb7d43e8)
        // fsub s9, s5, s0  (0xb7d43ec)
        *(void**)(sp + 0x58) = r8;
        // stp s8, s10, [sp, #0x5c]  (0xb7d43f4)
        *(void**)(sp + 0x64) = rs9;
        if (/* cond: b.eq */) goto label_0xb7d4474;
        this = sp + 0x8;
        r1 = sp + 0x5c;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r8 = *(void**)(r19 + 0x5e4);
        r9 = *(void**)(sp + 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d443c;
        r8 = *(void**)(r19 + 0x5e8);
        r9 = *(void**)(sp + 0xc);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d443c;
        r8 = *(void**)(r19 + 0x5ec);
        r9 = *(void**)(sp + 0x10);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0xb7d4474;
    label_0xb7d443c:
        this = *(void**)(r19 + 0x968);
        r2 = *(void**)(r19 + 0x5b0);
        r1 = sp + 0x5c;
        this = fn_0xb7a9068(this, r1, r2, r3);  // call  [0xb7a9068]
        this = sp + 0x8;
        r1 = sp + 0x5c;
        r24 = r19 + 0x5e4;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        // ldp s8, s10, [sp, #0x5c]  (0xb7d445c)
        r8 = *(void**)(sp + 0x8);
        r9 = *(void**)(sp + 0x10);
        rs9 = *(void**)(sp + 0x64);
        *(void**)(r24) = r8;
        *(void**)(r24 + 0x8) = r9;
    label_0xb7d4474:
        rs0 = *(void**)(r19 + 0x5d8);
        rs1 = *(void**)(r19 + 0x5dc);
        rs2 = *(void**)(r19 + 0x5e0);
        r8 = *(void**)(r19 + 0x598);
        // fsub s0, s8, s0  (0xb7d4484)
        // fsub s1, s10, s1  (0xb7d4488)
        // fsub s2, s9, s2  (0xb7d448c)
        // fmul s0, s0, s0  (0xb7d4490)
        // fmul s1, s1, s1  (0xb7d4494)
        // fadd s0, s0, s1  (0xb7d4498)
        // fmul s1, s2, s2  (0xb7d449c)
        // fadd s0, s0, s1  (0xb7d44a0)
        // scvtf s1, w8  (0xb7d44a4)
        // fmov s2, w8  (0xb7d44ac)
        // fsqrt s0, s0  (0xb7d44b0)
        // fcmpe s1, s2  (0xb7d44b4)
        if (/* cond: b.hi */) goto label_0xb7d44f0;
        // fmov s2, w8  (0xb7d44bc)
        // fdiv s1, s1, s2  (0xb7d44c0)
        // fmov s2, #4  (0xb7d44c4)
        // fmul s1, s2, s1  (0xb7d44c8)
        // fcmpe s0, s1  (0xb7d44cc)
        if (/* cond: b.gt */) goto label_0xb7d4510;
    label_0xb7d44d4:
        // cmp r22 == <complex operand>
        // cset w3, eq  (0xb7d44d8)
        r1 = sp + 0x5c;
        r2 = sp + 0x50;
        this = r19;
        this = fn_0xb7a9370(this, r1, r2, r3);  // call  [0xb7a9370]
        goto label_0xb7d46d0;
    label_0xb7d44f0:
        // fmov s2, w8  (0xb7d44f4)
        // fcmpe s1, s2  (0xb7d44f8)
        // fmov s1, #16  (0xb7d44fc)
        // fmov s2, #8  (0xb7d4500)
        // fcsel s1, s2, s1, ls  (0xb7d4504)
        // fcmpe s0, s1  (0xb7d4508)
        if (/* cond: b.le */) goto label_0xb7d44d4;
    label_0xb7d4510:
        r8 = "moveRenderingArea task";  // 0x24a7788
        // stp x8, x9, [sp, #0x8]  (0xb7d451c)
        rd0 = *(void**)(r9 + 0x700);
        r9 = *(void**)(r19 + 0xdb0);
        r8 = *(void**)(r8 + 0x670);
        // stp xzr, xzr, [sp, #0x18]  (0xb7d4534)
        r22 = fp - 0xa8;
        r10 = *(void**)(sp + 0x64);
        r20 = *(void**)(r9 + 0x3b0);
        *(void**)(sp + 0x28) = rzr;
        *(void**)(sp + 0x30) = r8;
        r8 = *(void**)(sp + 0x5c);
        *(void**)(sp + 0x38) = rd0;
        *(uint8_t*)(sp + 0x40) = rzr;
        *(void**)(sp + 0x48) = rzr;
        r9 = *(void**)(r20);
        *(void**)(r22 + 0x3) = r8;
        *(void**)(r22 + 0xb) = r10;
        r8 = *(void**)(r9 + 0x48);
        this = r20;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(fp - 0xa8);
        r9 = *(void**)(r22 + 0x7);
        r10 = *(void**)(sp + 0x58);
        // sturb w21, [x29, #0xffffffffffffffa0]  (0xb7d4580)
        *(void**)(r22 + 0x49) = r8;
        r8 = *(void**)(sp + 0x50);
        *(void**)(fp - 0x48) = r10;
        // stp x9, x8, [x29, #0xffffffffffffffa8]  (0xb7d4590)
        r8 = (void*)0x13a56830;
        // stp xzr, xzr, [sp, #0x98]  (0xb7d459c)
        // stp xzr, xzr, [sp, #0x78]  (0xb7d45a0)
        // stp x8, x19, [x29, #0xffffffffffffff90]  (0xb7d45a4)
        r8 = sp + 0xa8;
        r1 = sp + 0x8;
        r2 = sp + 0x98;
        // and w3, w0, #0x1  (0xb7d45b4)
        r4 = fp - 0x70;
        this = r20;
        this = fn_0x88a3f34(this, r1, r2, r3);  // call  [0x88a3f34]
        r8 = *(void**)(fp - 0x70);
        if (r8 == 0) goto label_0xb7d45d8;
        r8 = *(void**)(r8 + 0x8);
        this = fp - 0x70;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7d45d8:
        r21 = *(void**)(sp + 0xa0);
        if (r21 == 0) goto label_0xb7d4608;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d4608;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d4608:
        // ldp x8, x21, [sp, #0xa8]  (0xb7d4608)
        // stp x8, x21, [sp, #0x88]  (0xb7d460c)
        if (r21 == 0) goto label_0xb7d4620;
        r1 = r21 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7d4620:
        r1 = sp + 0x88;
        this = r20;
        this = fn_0x134c0a10(this, r1, r2, r3);  // call  [0x134c0a10]
        if (r21 == 0) goto label_0xb7d4658;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d4658;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d4658:
        r21 = *(void**)(sp + 0x80);
        r20 = *(void**)(sp + 0xb0);
        if (r21 == 0) goto label_0xb7d468c;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d468c;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d468c:
        r21 = r19 + 0x5d8;
        if (r20 == 0) goto label_0xb7d46bc;
        r1 = (void*)0x1407f088;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d46bc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d46bc:
        r8 = *(void**)(sp + 0x5c);
        r9 = *(void**)(sp + 0x64);
        r20 = *(void**)(sp + 0x70);
        *(void**)(r21) = r8;
        *(void**)(r21 + 0x8) = r9;
    label_0xb7d46d0:
        r9 = r19 + 0xd7c;
        r8 = *(void**)(sp + 0x64);
        r10 = *(void**)(sp + 0x5c);
        rd0 = *(void**)(r9);
        rs1 = *(void**)(r19 + 0xd84);
        r11 = r19 + 0x614;
        *(void**)(r19 + 0x61c) = r8;
        *(void**)(r11) = r10;
        *(void**)(r19 + 0x620) = rd0;
        *(void**)(r19 + 0x628) = rs1;
        if (r20 == 0) goto label_0xb7d4724;
        r1 = (void*)0x1407f088;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d4724;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d4724:
        r19 = *(void**)(fp - 0x80);
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7d4728)
        if (r19 == 0) goto label_0xb7d478c;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d4758;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d4758:
        r19 = *(void**)(fp - 0x80);
        *(void**)(fp - 0x78) = rzr;
        if (r19 == 0) goto label_0xb7d478c;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d478c;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d478c:
        // ldurb w8, [x29, #0xffffffffffffff70]  (0xb7d478c)
        if (r8 == 0) goto label_0xb7d479c;
        this = *(void**)(fp - 0x98);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7d479c:
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d485c;
        // ldp x20, x19, [sp, #0x1a0]  (0xb7d47ac)
        rd10 = *(void**)(sp + 0x140);
        // ldp x22, x21, [sp, #0x190]  (0xb7d47b4)
        // ldp x24, x23, [sp, #0x180]  (0xb7d47b8)
        // ldp x28, x25, [sp, #0x170]  (0xb7d47bc)
        // ldp x29, x30, [sp, #0x160]  (0xb7d47c0)
        // ldp d9, d8, [sp, #0x150]  (0xb7d47c4)
        sp = sp + 0x1b0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e1a8
// fn_va = 0x8a3e1a8
// return type (guess): unknown (no ret found)
void* fn_0x8a3e1a8(void* this, void* r1) {
        // stp d11, d10, [sp, #0x40]  (0x8a3e1ac)
        // stp d9, d8, [sp, #0x50]  (0x8a3e1b0)
        // stp x29, x30, [sp, #0x60]  (0x8a3e1b4)
        *(void**)(sp + 0x70) = r23;
        // stp x22, x21, [sp, #0x80]  (0x8a3e1bc)
        // stp x20, x19, [sp, #0x90]  (0x8a3e1c0)
        fp = sp + 0x60;
        // mrs x23, tpidr_el0  (0x8a3e1c8)
        r19 = r8;
        // fmov s8, s0  (0x8a3e1d0)
        r8 = *(void**)(r23 + 0x28);
        r22 = r1;
        r20 = this;
        *(void**)(fp - 0x28) = r8;
        // ldp x8, x21, [x1]  (0x8a3e1e4)
        // stp x8, x21, [sp]  (0x8a3e1e8)
        if (r21 == 0) goto label_0x8a3e1fc;
        r1 = r21 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3e1fc:
        r8 = *(void**)(r22 + 0x10);
        *(void**)(sp + 0x10) = r8;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3e248  (0x8a3e218)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0x8a3e248;
        r22 = this;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tst w0, #0x1  (0x8a3e238)
        // csel x22, x22, xzr, ne  (0x8a3e23c)
        if (r21 != 0) goto label_0x8a3e250;
        goto label_0x8a3e258;
    label_0x8a3e248:
        r22 = rzr;
        if (r21 == 0) goto label_0x8a3e258;
    label_0x8a3e250:
        this = r21;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3e258:
        if (r22 == 0) goto label_0x8a3e30c;
        this = r22;
        this = fn_0xfd967dc(this, r1, r2, r3);  // call  [0xfd967dc]
        // movi d9, #0x0  (0x8a3e264)
        // movi d10, #0x0  (0x8a3e268)
        // cmp this == <complex operand>
        if (/* cond: b.gt */) goto label_0x8a3e28c;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x338);
        this = (*(void**)r8)(this);  // indirect call
        // scvtf s0, w0  (0x8a3e284)
        // fadd s10, s0, s8  (0x8a3e288)
    label_0x8a3e28c:
        r8 = *(void**)(r22 + 0x420);
        rs1 = *(void**)(r22 + 0x3a8);
        // movk w9, #0x3c8e, lsl #0x10  (0x8a3e298)
        r8 = *(void**)(r8);
        // fmov s2, w9  (0x8a3e2a0)
        // scvtf s0, w8  (0x8a3e2a4)
        // fmul s11, s1, s2  (0x8a3e2a8)
        // fcmpe s0, #0  (0x8a3e2ac)
        if (/* cond: b.le */) goto label_0x8a3e2c8;
        // scvtf s0, w8  (0x8a3e2b4)
        // scvtf s1, w8  (0x8a3e2bc)
        // fsub s0, s0, s8  (0x8a3e2c0)
        // fdiv s9, s0, s1  (0x8a3e2c4)
    label_0x8a3e2c8:
        this = *(void**)(r20 + 0x8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x578);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        // stp s10, s11, [x19]  (0x8a3e2ec)
        // stp s9, s0, [x19, #0x8]  (0x8a3e2f0)
        *(uint8_t*)(r19 + 0x10) = r8;
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0x8a3e328;
        goto label_0x8a3e370;
    label_0x8a3e30c:
        r8 = rzr;
        *(uint8_t*)(r19) = rzr;
        *(uint8_t*)(r19 + 0x10) = rzr;
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3e370;
    label_0x8a3e328:
        // ldp x20, x19, [sp, #0x90]  (0x8a3e328)
        r23 = *(void**)(sp + 0x70);
        // ldp x22, x21, [sp, #0x80]  (0x8a3e330)
        // ldp x29, x30, [sp, #0x60]  (0x8a3e334)
        // ldp d9, d8, [sp, #0x50]  (0x8a3e338)
        // ldp d11, d10, [sp, #0x40]  (0x8a3e33c)
        sp = sp + 0xa0;
        return this;
}

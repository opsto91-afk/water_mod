// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a2c48
// fn_va = 0xb7a2c48
// return type (guess): unknown (no ret found)
void* fn_0xb7a2c48(void* this) {
        // stp x29, x30, [sp, #0x60]  (0xb7a2c4c)
        // stp x24, x23, [sp, #0x70]  (0xb7a2c50)
        // stp x22, x21, [sp, #0x80]  (0xb7a2c54)
        // stp x20, x19, [sp, #0x90]  (0xb7a2c58)
        fp = sp + 0x60;
        // mrs x23, tpidr_el0  (0xb7a2c60)
        r20 = r2;
        r21 = r1;
        r8 = *(void**)(r23 + 0x28);
        r19 = this;
        *(void**)(fp - 0x8) = r8;
        r8 = (void*)0x140aa630;
        // ldarb w8, [x8]  (0xb7a2c80)
        // tbz w8, #0x0, 0xb7a3024  (0xb7a2c84)
    label_0xb7a2c88:
        r1 = (void*)0x140ac100;
        this = sp;
        this = fn_0x135c7250(this, r1, r2, r3);  // call  [0x135c7250]
        this = r19;
        r1 = r21;
        r2 = r20;
        this = fn_0xb7b1c18(this, r1, r2, r3);  // call  [0xb7b1c18]
        rs0 = *(void**)(r20 + 0x48);
        this = r19;
        this = fn_0xb7bf4b8(this, r1, r2, r3);  // call  [0xb7bf4b8]
        rs0 = *(void**)(r20 + 0x44);
        this = r19;
        r1 = r21;
        this = fn_0xb7bf714(this, r1, r2, r3);  // call  [0xb7bf714]
        this = r19;
        r1 = r20;
        this = fn_0xb7bfe98(this, r1, r2, r3);  // call  [0xb7bfe98]
        r8 = *(void**)(r19 + 0x1118);
        r9 = *(void**)(r8 + 0x380);
        if (r9 == 0) goto label_0xb7a2cf8;
        r9 = *(uint8_t*)(r9);
        // tbz w9, #0x0, 0xb7a2d10  (0xb7a2ce0)
    label_0xb7a2ce4:
        this = *(void**)(r8 + 0x390);
        this = fn_0xb0608b8(this, r1, r2, r3);  // call  [0xb0608b8]
        r8 = *(void**)(this + 0x10);
        if (r8 != 0) goto label_0xb7a2d30;
        goto label_0xb7a2e04;
    label_0xb7a2cf8:
        r10 = rzr;
        // movk w11, #0xdead, lsl #0x10  (0xb7a2d00)
        *(void**)(r10) = r11;
        r9 = *(uint8_t*)(r9);
        // tbnz w9, #0x0, 0xb7a2ce4  (0xb7a2d0c)
    label_0xb7a2d10:
        r9 = rzr;
        // movk w10, #0xdead, lsl #0x10  (0xb7a2d18)
        *(void**)(r9) = r10;
        this = *(void**)(r8 + 0x390);
        this = fn_0xb0608b8(this, r1, r2, r3);  // call  [0xb0608b8]
        r8 = *(void**)(this + 0x10);
        if (r8 == 0) goto label_0xb7a2e04;
    label_0xb7a2d30:
        r21 = *(void**)(this);
        // lsl x22, x8, #0x3  (0xb7a2d34)
    label_0xb7a2d38:
        this = *(void**)(r21);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x60);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7a2d5c  (0xb7a2d48)
    label_0xb7a2d4c:
    label_0xb7a2d50:
        this = *(void**)(r21);
        r9 = *(void**)(this);
        goto label_0xb7a2df0;
    label_0xb7a2d5c:
        this = *(void**)(r21);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x78);
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        this = r19;
        this = fn_0xb7aecb0(this, r1, r2, r3);  // call  [0xb7aecb0]
        r8 = this;
        this = *(void**)(r21);
        r9 = *(void**)(this);
        // tbz w8, #0x0, 0xb7a2dec  (0xb7a2d84)
        r8 = *(void**)(r9 + 0x78);
        this = (*(void**)r8)(this);  // indirect call
        // ldp s1, s2, [x0]  (0xb7a2d90)
        rs0 = *(void**)(r19 + 0x6ec);
        rs3 = *(void**)(r19 + 0x6f0);
        rs4 = *(void**)(r19 + 0x6f4);
        // ldp s5, s6, [x0, #0x8]  (0xb7a2da0)
        // fsub s1, s1, s0  (0xb7a2da4)
        // fsub s2, s2, s3  (0xb7a2da8)
        // fsub s0, s6, s0  (0xb7a2dac)
        // ldp s7, s6, [x0, #0x10]  (0xb7a2db0)
        // fsub s5, s5, s4  (0xb7a2db4)
        // stp s1, s2, [sp, #0x30]  (0xb7a2db8)
        // fsub s3, s7, s3  (0xb7a2dbc)
        // fsub s1, s6, s4  (0xb7a2dc0)
        *(void**)(sp + 0x38) = rs5;
        // stp s0, s3, [sp, #0x24]  (0xb7a2dc8)
        *(void**)(sp + 0x2c) = rs1;
        this = r19 + 0x62c;
        r1 = sp + 0x30;
        r2 = sp + 0x24;
        this = fn_0x1351dda0(this, r1, r2, r3);  // call  [0x1351dda0]
        // tbnz w0, #0x0, 0xb7a2d4c  (0xb7a2de0)
        r1 = rzr;
        goto label_0xb7a2d50;
    label_0xb7a2dec:
        r1 = rzr;
    label_0xb7a2df0:
        r8 = *(void**)(r9 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
        // subs x22, x22, #0x8  (0xb7a2df8)
        r21 = r21 + 0x8;
        if (/* cond: b.ne */) goto label_0xb7a2d38;
    label_0xb7a2e04:
        r21 = (void*)0x1407f080;
        this = r21;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r22 = *(void**)(r8 + 0x160);
        if (r22 == 0) goto label_0xb7a2e50;
        r8 = *(uint8_t*)(r22);
        if (r8 == 0) goto label_0xb7a2e50;
        r24 = *(void**)(r8 + 0x168);
        if (r24 == 0) goto label_0xb7a2e70;
        r1 = r24 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r22);
        // cmp r8 == <complex operand>
        // cset w8, eq  (0xb7a2e48)
        goto label_0xb7a2e74;
    label_0xb7a2e50:
        this = (void*)0x1407f080;
        *(void**)(sp + 0x30) = rzr;
        *(uint8_t*)(sp + 0x38) = rzr;
        // stp xzr, xzr, [sp, #0x48]  (0xb7a2e60)
        *(void**)(sp + 0x40) = rzr;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        goto label_0xb7a2ec0;
    label_0xb7a2e70:
        r8 = rzr;
    label_0xb7a2e74:
        *(void**)(sp + 0x30) = r21;
        this = *(void**)(r10 + 0x170);
        *(uint8_t*)(sp + 0x38) = r9;
        // stp x22, x24, [sp, #0x40]  (0xb7a2e88)
        *(void**)(sp + 0x50) = this;
        // tbnz w8, #0x0, 0xb7a2ec0  (0xb7a2e90)
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7a2ec0  (0xb7a2ea0)
        r21 = *(void**)(r19 + 0x940);
        *(void**)(r19 + 0x940) = rzr;
        if (r21 == 0) goto label_0xb7a2ec0;
        this = r21;
        this = fn_0xb7ea8b8(this, r1, r2, r3);  // call  [0xb7ea8b8]
        this = r21;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a2ec0:
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r1 = *(void**)(r19 + 0x8);
        r21 = this;
        r2 = r19 + 0x10;
        this = fn_0x11813aec(this, r1, r2, r3);  // call  [0x11813aec]
        r22 = *(void**)(r19 + 0x940);
        *(void**)(r19 + 0x940) = r21;
        if (r22 == 0) goto label_0xb7a2ef4;
        this = r22;
        this = fn_0xb7ea8b8(this, r1, r2, r3);  // call  [0xb7ea8b8]
        this = r22;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a2ef4:
        r1 = *(uint8_t*)(r20 + 0x4d);
        this = r19;
        this = fn_0xb7b843c(this, r1, r2, r3);  // call  [0xb7b843c]
        r8 = *(void**)(r19 + 0x10a0);
        r21 = *(void**)(r19 + 0x10a8);
        // cmp r8 == r21
        if (/* cond: b.eq */) goto label_0xb7a2f78;
        r20 = (void*)0x1407f018;
    label_0xb7a2f14:
        // ldp s0, s1, [x20, #0xc]  (0xb7a2f14)
        r1 = r20 - 0x18;
        this = r19;
        r2 = r20;
        r3 = rzr;
        this = fn_0xb7bedc0(this, r1, r2, r3);  // call  [0xb7bedc0]
        r8 = (void*)0x1407f030;
        r20 = (void*)0x1407f048;
        // cmp r8 == r21
        if (/* cond: b.ne */) goto label_0xb7a2f14;
        r8 = *(void**)(r19 + 0x10a8);
        r20 = *(void**)(r19 + 0x10a0);
        // cmp r8 == r20
        if (/* cond: b.eq */) goto label_0xb7a2f78;
        r21 = r8;
        goto label_0xb7a2f60;
    label_0xb7a2f54:
        // cmp r21 == r20
        r8 = r21;
        if (/* cond: b.eq */) goto label_0xb7a2f74;
    label_0xb7a2f60:
        r9 = *(uint8_t*)(r21 - 0x30);
        // tbz w9, #0x0, 0xb7a2f54  (0xb7a2f64)
        this = *(void**)(r8 - 0x20);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7a2f54;
    label_0xb7a2f74:
        r8 = r20;
    label_0xb7a2f78:
        *(void**)(r19 + 0x10a8) = r8;
        r19 = *(void**)(sp + 0x48);
        // stp xzr, xzr, [sp, #0x40]  (0xb7a2f80)
        if (r19 == 0) goto label_0xb7a2fe4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a2fb0;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a2fb0:
        r19 = *(void**)(sp + 0x48);
        *(void**)(sp + 0x50) = rzr;
        if (r19 == 0) goto label_0xb7a2fe4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a2fe4;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a2fe4:
        r8 = *(uint8_t*)(sp + 0x38);
        if (r8 == 0) goto label_0xb7a2ff4;
        this = *(void**)(sp + 0x30);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7a2ff4:
        this = sp;
        this = fn_0x135c7324(this, r1, r2, r3);  // call  [0x135c7324]
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a3108;
        // ldp x20, x19, [sp, #0x90]  (0xb7a300c)
        // ldp x22, x21, [sp, #0x80]  (0xb7a3010)
        // ldp x24, x23, [sp, #0x70]  (0xb7a3014)
        // ldp x29, x30, [sp, #0x60]  (0xb7a3018)
        sp = sp + 0xa0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bea94
// fn_va = 0xb7bea94
// return type (guess): unknown (no ret found)
void* fn_0xb7bea94(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bea94)
        *(void**)(sp + 0x10) = r19;
        r8 = *(void**)(this + 0xcb0);
        if (r8 == 0) goto label_0xb7beac8;
        // movi v0.2d, #0x0  (0xb7beaa8)
        r19 = *(void**)(this + 0xcb8);
        *(void**)(this + 0xcb0) = rq0;
        if (r19 == 0) goto label_0xb7beac8;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7bead4;
    label_0xb7beac8:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7beacc)
        return this;
}

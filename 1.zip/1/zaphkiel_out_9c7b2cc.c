// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9c7b2cc
// fn_va = 0x9c7b2cc
// return type (guess): unknown (no ret found)
void* fn_0x9c7b2cc(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9c7b2cc)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = *(void**)(this + 0x60);
        r8 = (void*)0x1389cf48;
        r9 = r19 + 0x40;
        // cmp this == r9
        *(void**)(r19) = r8;
        if (/* cond: b.eq */) goto label_0x9c7b304;
        if (this == 0) goto label_0x9c7b318;
        goto label_0x9c7b30c;
    label_0x9c7b304:
        this = r9;
    label_0x9c7b30c:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0x9c7b318:
        this = *(void**)(r19 + 0x30);
        r9 = r19 + 0x10;
        // cmp this == r9
        if (/* cond: b.eq */) goto label_0x9c7b334;
        if (this == 0) goto label_0x9c7b348;
        goto label_0x9c7b33c;
    label_0x9c7b334:
        this = r9;
    label_0x9c7b33c:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0x9c7b348:
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9c7b350)
        return fn_0xe803424(/* tail call */);
        return this;
}

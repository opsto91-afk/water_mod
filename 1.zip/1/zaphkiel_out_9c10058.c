// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9c10058
// fn_va = 0x9c10058
// return type (guess): unknown (no ret found)
void* fn_0x9c10058(void* this) {
        // stp x20, x19, [sp, #0x60]  (0x9c10058)
        fp = sp + 0x20;
        // mrs x25, tpidr_el0  (0x9c10060)
        r24 = this;
        this = r3;
        r8 = *(void**)(r25 + 0x28);
        r20 = r6;
        r23 = r5;
        r19 = r4;
        r22 = r2;
        r21 = r1;
        *(void**)(fp - 0x8) = r8;
        this = fn_0x10be11b0(this, r1, r2, r3);  // call  [0x10be11b0]
        // cmp this == <complex operand>
        if (/* cond: b.eq */) goto label_0x9c1013c;
        this = r24;
        r1 = r23;
        r3 = r21;
        this = fn_0xcd0d074(this, r1, r2, r3);  // call  [0xcd0d074]
        // ldp s0, s1, [x21]  (0x9c100a8)
        // fmov s2, w0  (0x9c100ac)
        // lsr x8, x0, #0x20  (0x9c100b0)
        // tst x1, #0xff00000000  (0x9c100b4)
        rs3 = *(void**)(r21 + 0x8);
        this = r22;
        // fcsel s0, s0, s2, eq  (0x9c100c0)
        // fmov s2, w8  (0x9c100c4)
        // fcsel s1, s1, s2, eq  (0x9c100c8)
        // fmov s2, w1  (0x9c100cc)
        // fcsel s2, s3, s2, eq  (0x9c100d0)
        // stp s0, s1, [sp, #0xc]  (0x9c100d4)
        // fmov s0, #1  (0x9c100d8)
        *(void**)(sp + 0x14) = rs2;
        this = fn_0xfd8ea60(this, r1, r2, r3);  // call  [0xfd8ea60]
        r8 = *(void**)(sp + 0xc);
        r9 = *(void**)(sp + 0x14);
        this = sp;
        // stp s0, s1, [x19, #0xc]  (0x9c100f0)
        r1 = sp + 0xc;
        *(void**)(r19) = r8;
        *(void**)(r19 + 0x8) = r9;
        *(void**)(r19 + 0x14) = rs2;
        r8 = *(void**)(r21 + 0x8);
        r9 = *(void**)(r21);
        *(void**)(r19 + 0x20) = r8;
        *(void**)(r19 + 0x18) = r9;
        this = fn_0xe82f8c8(this, r1, r2, r3);  // call  [0xe82f8c8]
        r8 = *(void**)(r20);
        r1 = sp;
        this = r20;
        r8 = *(void**)(r8 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0x109f425c(this, r1, r2, r3);  // call  [0x109f425c]
        this = fn_0x111c98c0(this, r1, r2, r3);  // call  [0x111c98c0]
        // and w8, w0, #0x1  (0x9c10134)
        *(uint8_t*)(r19 + 0x24) = r8;
    label_0x9c1013c:
        r8 = *(void**)(r25 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9c10168;
        // ldp x20, x19, [sp, #0x60]  (0x9c1014c)
        r25 = *(void**)(sp + 0x30);
        // ldp x22, x21, [sp, #0x50]  (0x9c10154)
        // ldp x24, x23, [sp, #0x40]  (0x9c10158)
        // ldp x29, x30, [sp, #0x20]  (0x9c1015c)
        sp = sp + 0x70;
        return this;
}

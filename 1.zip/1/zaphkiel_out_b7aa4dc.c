// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7aa4dc
// fn_va = 0xb7aa4dc
// return type (guess): unknown (no ret found)
void* fn_0xb7aa4dc(void* this, void* r1) {
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0xb7aa4dc)
        *(void**)(sp + 0x10) = r21;
        // stp x20, x19, [sp, #0x20]  (0xb7aa4e4)
        r9 = *(void**)(r1 + 0x100);
        r20 = r8;
        // ldp x21, x19, [x9]  (0xb7aa4f4)
        if (r19 == 0) goto label_0xb7aa540;
        r1 = r19 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r19 + 0x8;
        // stp xzr, xzr, [x20]  (0xb7aa510)
        // stp xzr, x21, [x20, #0x10]  (0xb7aa514)
        *(void**)(r20 + 0x20) = r19;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7aa55c;
        // ldp x20, x19, [sp, #0x20]  (0xb7aa530)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0xb7aa538)
        return this;
}

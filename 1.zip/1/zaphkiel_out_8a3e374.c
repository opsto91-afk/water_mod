// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e374
// fn_va = 0x8a3e374
// return type (guess): unknown (no ret found)
void* fn_0x8a3e374(void* this) {
        *(void**)(sp + 0x40) = rd10;
        // stp d9, d8, [sp, #0x48]  (0x8a3e37c)
        // stp x29, x30, [sp, #0x58]  (0x8a3e380)
        *(void**)(sp + 0x68) = r23;
        // stp x22, x21, [sp, #0x70]  (0x8a3e388)
        // stp x20, x19, [sp, #0x80]  (0x8a3e38c)
        fp = sp + 0x58;
        // mrs x23, tpidr_el0  (0x8a3e394)
        r22 = this;
        // fmov s8, s0  (0x8a3e39c)
        r9 = *(void**)(r23 + 0x28);
        r21 = r1;
        r19 = r8;
        *(void**)(fp - 0x20) = r9;
        this = *(void**)(this + 0x8);
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0x568);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x200);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0x8a3e4c4  (0x8a3e3cc)
        // ldp x8, x20, [x21]  (0x8a3e3d0)
        // stp x8, x20, [sp]  (0x8a3e3d4)
        if (r20 == 0) goto label_0x8a3e3e8;
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3e3e8:
        this = *(void**)(r22 + 0x8);
        r9 = *(void**)(r21 + 0x10);
        r8 = *(void**)(this);
        *(void**)(sp + 0x10) = r9;
        r8 = *(void**)(r8 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3e434;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3e434  (0x8a3e418)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        r21 = this;
        if (r20 != 0) goto label_0x8a3e43c;
        goto label_0x8a3e444;
    label_0x8a3e434:
        r21 = rzr;
        if (r20 == 0) goto label_0x8a3e444;
    label_0x8a3e43c:
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3e444:
        if (r21 == 0) goto label_0x8a3e4c4;
        this = r21;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tbz w0, #0x0, 0x8a3e4c4  (0x8a3e454)
        // fmov s0, s8  (0x8a3e458)
        this = r21 + 0x8;
        this = fn_0x101c1878(this, r1, r2, r3);  // call  [0x101c1878]
        // fneg s0, s0  (0x8a3e468)
        this = r21 + 0x8;
        // movk w8, #0x3f19, lsl #0x10  (0x8a3e470)
        // fmov s1, w8  (0x8a3e474)
        // fmul s10, s0, s1  (0x8a3e478)
        this = fn_0x1019478c(this, r1, r2, r3);  // call  [0x1019478c]
        this = r21 + 0x8;
        // fmov s9, s0  (0x8a3e484)
        this = fn_0x101946bc(this, r1, r2, r3);  // call  [0x101946bc]
        // fsub s0, s0, s9  (0x8a3e48c)
        this = r21;
        // fmul s0, s0, s8  (0x8a3e494)
        // fadd s8, s9, s0  (0x8a3e498)
        this = fn_0xfd869b0(this, r1, r2, r3);  // call  [0xfd869b0]
        // movk w8, #0x3c8e, lsl #0x10  (0x8a3e4a4)
        // fmov s0, w8  (0x8a3e4a8)
        this = fn_0xe82fbfc(this, r1, r2, r3);  // call  [0xe82fbfc]
        // stp s1, s10, [x19, #0x4]  (0x8a3e4b0)
        *(void**)(r19) = rs0;
        *(void**)(r19 + 0xc) = rs8;
        goto label_0x8a3e4cc;
    label_0x8a3e4c4:
        r8 = rzr;
        *(uint8_t*)(r19) = rzr;
    label_0x8a3e4cc:
        *(uint8_t*)(r19 + 0x10) = r8;
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x20);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3e528;
        // ldp x20, x19, [sp, #0x80]  (0x8a3e4e0)
        r23 = *(void**)(sp + 0x68);
        // ldp x22, x21, [sp, #0x70]  (0x8a3e4e8)
        rd10 = *(void**)(sp + 0x40);
        // ldp x29, x30, [sp, #0x58]  (0x8a3e4f0)
        // ldp d9, d8, [sp, #0x48]  (0x8a3e4f4)
        sp = sp + 0x90;
        return this;
}

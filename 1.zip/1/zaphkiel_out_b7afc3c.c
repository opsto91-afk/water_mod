// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7afc3c
// fn_va = 0xb7afc3c
// return type (guess): unknown (no ret found)
void* fn_0xb7afc3c(void* this) {
        // stp x29, x30, [sp, #0x30]  (0xb7afc40)
        // stp x24, x23, [sp, #0x40]  (0xb7afc44)
        // stp x22, x21, [sp, #0x50]  (0xb7afc48)
        // stp x20, x19, [sp, #0x60]  (0xb7afc4c)
        fp = sp + 0x30;
        // mrs x23, tpidr_el0  (0xb7afc54)
        r19 = this;
        r20 = r1;
        r8 = *(void**)(r23 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = *(void**)(this + 0x968);
        r21 = *(void**)(r19 + 0x978);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        r8 = sp + 0x10;
        this = r21;
        this = fn_0xb7a3f38(this, r1, r2, r3);  // call  [0xb7a3f38]
        this = *(void**)(sp + 0x10);
        if (this == 0) goto label_0xb7afc9c;
        r1 = r19;
        this = fn_0xa9cbf54(this, r1, r2, r3);  // call  [0xa9cbf54]
    label_0xb7afc9c:
        r21 = *(void**)(sp + 0x18);
        if (r21 == 0) goto label_0xb7afccc;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7afccc;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7afccc:
        this = r20;
        this = fn_0xfd8d070(this, r1, r2, r3);  // call  [0xfd8d070]
        r1 = this;
        *(void**)(r19 + 0x968) = this;
        this = r19;
        this = fn_0xb7a6aa8(this, r1, r2, r3);  // call  [0xb7a6aa8]
        this = r20;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0xb7afd8c  (0xb7afcec)
        r21 = *(void**)(r19 + 0x950);
        r22 = *(void**)(r19 + 0x968);
        this = r20;
        this = fn_0xaf660c8(this, r1, r2, r3);  // call  [0xaf660c8]
        this = fn_0x10b6929c(this, r1, r2, r3);  // call  [0x10b6929c]
        r3 = this;
        r8 = sp + 0x10;
        this = sp + 0xf;
        r1 = r21;
        r2 = r22;
        this = fn_0xb7ee6f0(this, r1, r2, r3);  // call  [0xb7ee6f0]
        rq0 = *(void**)(sp + 0x10);
        r20 = *(void**)(r19 + 0x960);
        r8 = r19 + 0x958;
        // stp xzr, xzr, [sp, #0x10]  (0xb7afd28)
        *(void**)(r8) = rq0;
        if (r20 == 0) goto label_0xb7afd5c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7afd5c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7afd5c:
        r20 = *(void**)(sp + 0x18);
        if (r20 == 0) goto label_0xb7afd8c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7afd8c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7afd8c:
        this = *(void**)(r19 + 0x968);
        r20 = *(void**)(r19 + 0x978);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        r8 = sp + 0x10;
        this = r20;
        this = fn_0xb7a3f38(this, r1, r2, r3);  // call  [0xb7a3f38]
        this = *(void**)(sp + 0x10);
        if (this == 0) goto label_0xb7afdc0;
        r1 = r19;
        this = fn_0xa9cbe48(this, r1, r2, r3);  // call  [0xa9cbe48]
    label_0xb7afdc0:
        r20 = *(void**)(sp + 0x18);
        if (r20 == 0) goto label_0xb7afdf0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7afdf0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7afdf0:
        this = r19;
        this = fn_0xb7af424(this, r1, r2, r3);  // call  [0xb7af424]
        r20 = this;
        this = *(void**)(this + 0x20);
        if (this == 0) goto label_0xb7afe1c;
        rq0 = *(void**)(r20 + 0xc8);
        r1 = sp + 0x10;
        *(void**)(sp + 0x10) = rq0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7afe1c:
        // ldp x22, x24, [x20, #0xc8]  (0xb7afe1c)
        goto label_0xb7afe28;
    label_0xb7afe24:
        r24 = r24 - 0x10;
    label_0xb7afe28:
        // cmp r24 == r22
        if (/* cond: b.eq */) goto label_0xb7afe64;
        r21 = *(void**)(r24 - 0x8);
        if (r21 == 0) goto label_0xb7afe24;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7afe24;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7afe24;
    label_0xb7afe64:
        // movi v0.2d, #0x0  (0xb7afe64)
        *(void**)(r20 + 0xd0) = r22;
        this = r19;
        *(void**)(r20 + 0x98) = rq0;
        *(void**)(r20 + 0xa8) = rq0;
        *(void**)(r20 + 0xb8) = rq0;
        r8 = *(void**)(r19);
        *(void**)(r19 + 0x594) = rzr;
        r8 = *(void**)(r8 + 0xf0);
        this = (*(void**)r8)(this);  // indirect call
        r8 = r19 + 0x614;
        r9 = *(void**)(r19 + 0x61c);
        r8 = *(void**)(r8);
        *(void**)(r19 + 0x5e0) = r9;
        *(void**)(r19 + 0x5d8) = r8;
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7afeec;
        // ldp x20, x19, [sp, #0x60]  (0xb7afeb0)
        // ldp x22, x21, [sp, #0x50]  (0xb7afeb4)
        // ldp x24, x23, [sp, #0x40]  (0xb7afeb8)
        // ldp x29, x30, [sp, #0x30]  (0xb7afebc)
        sp = sp + 0x70;
        return this;
}

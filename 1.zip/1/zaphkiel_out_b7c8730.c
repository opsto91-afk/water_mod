// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c8730
// fn_va = 0xb7c8730
// return type (guess): unknown (no ret found)
void* fn_0xb7c8730(void* this) {
        // stp x29, x30, [sp, #0x40]  (0xb7c8734)
        // stp x24, x23, [sp, #0x50]  (0xb7c8738)
        // stp x22, x21, [sp, #0x60]  (0xb7c873c)
        // stp x20, x19, [sp, #0x70]  (0xb7c8740)
        fp = sp + 0x40;
        // mrs x22, tpidr_el0  (0xb7c8748)
        r8 = this;
        r21 = r1;
        r9 = *(void**)(r22 + 0x28);
        this = sp + 0x18;
        r20 = r2;
        *(void**)(fp - 0x8) = r9;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x18;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7c88bc  (0xb7c8778)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7c88bc;
        r19 = this;
        r8 = sp + 0x18;
        this = r21;
        r1 = r20;
        this = fn_0xa9d67fc(this, r1, r2, r3);  // call  [0xa9d67fc]
        this = r19;
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        // ldp x23, x24, [sp, #0x18]  (0xb7c87a8)
        r19 = this;
        goto label_0xb7c87bc;
    label_0xb7c87b4:
        *(uint8_t*)(this) = r8;
    label_0xb7c87b8:
        r23 = r23 + 0x10;
    label_0xb7c87bc:
        // cmp r23 == r24
        if (/* cond: b.eq */) goto label_0xb7c8808;
        r8 = *(void**)(r19);
        r8 = *(void**)(r8 + 0x130);
        this = r19;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r1 = *(void**)(r23);
        r8 = *(void**)(r8 + 0x68);
        r2 = rzr;
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7c87b8;
        this = fn_0xfda9560(this, r1, r2, r3);  // call  [0xfda9560]
        r8 = *(void**)(r23 + 0x8);
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c87b4;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c87b4;
        goto label_0xb7c87b8;
    label_0xb7c8808:
        r8 = sp;
        this = r21;
        r1 = r20;
        this = fn_0xa9d6aa8(this, r1, r2, r3);  // call  [0xa9d6aa8]
        // ldp x20, x21, [sp]  (0xb7c8818)
        // cmp r20 == r21
        if (/* cond: b.eq */) goto label_0xb7c889c;
        goto label_0xb7c8840;
    label_0xb7c8830:
        *(uint8_t*)(this) = r24;
    label_0xb7c8834:
        r20 = r20 + 0x10;
        // cmp r20 == r21
        if (/* cond: b.eq */) goto label_0xb7c8898;
    label_0xb7c8840:
        this = r19;
        r1 = r20;
        this = fn_0x10371388(this, r1, r2, r3);  // call  [0x10371388]
        if (this == 0) goto label_0xb7c8834;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xb8);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7c8834;
        r8 = *(void**)(r20 + 0xc);
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c8884;
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7c8834;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x68);
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7c8830;
    label_0xb7c8884:
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x68);
        this = (*(void**)r8)(this);  // indirect call
        *(uint8_t*)(this) = r23;
        goto label_0xb7c8834;
    label_0xb7c8898:
        r20 = *(void**)(sp);
    label_0xb7c889c:
        if (r20 == 0) goto label_0xb7c88ac;
        this = r20;
        *(void**)(sp + 0x8) = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c88ac:
        this = *(void**)(sp + 0x18);
        if (this == 0) goto label_0xb7c88bc;
        *(void**)(sp + 0x20) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c88bc:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c896c;
        // ldp x20, x19, [sp, #0x70]  (0xb7c88cc)
        // ldp x22, x21, [sp, #0x60]  (0xb7c88d0)
        // ldp x24, x23, [sp, #0x50]  (0xb7c88d4)
        // ldp x29, x30, [sp, #0x40]  (0xb7c88d8)
        sp = sp + 0x80;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e0ac
// fn_va = 0x8a3e0ac
// return type (guess): unknown (no ret found)
void* fn_0x8a3e0ac(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x8a3e0ac)
        *(void**)(sp + 0x10) = r19;
        this = *(void**)(this + 0x8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x5d0);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3e0f8;
        this = fn_0xb7a34a4(this, r1, r2, r3);  // call  [0xb7a34a4]
        r19 = this;
        this = fn_0xb7a35d0(this, r1, r2, r3);  // call  [0xb7a35d0]
        // tbz w0, #0x0, 0x8a3e108  (0x8a3e0d8)
        // and w8, w0, #0x1  (0x8a3e0e0)
        // orr w0, w8, w9, lsl #0x8  (0x8a3e0e8)
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3e0f0)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9c147bc
// fn_va = 0x9c147bc
// return type (guess): unknown (no ret found)
void* fn_0x9c147bc(void* this, void* r1) {
        // stp x29, x30, [sp, #0x10]  (0x9c147c0)
        *(void**)(sp + 0x20) = r19;
        fp = sp + 0x10;
        // mrs x19, tpidr_el0  (0x9c147cc)
        r8 = *(void**)(r19 + 0x28);
        *(void**)(sp + 0x8) = r8;
        r8 = *(void**)(this);
        *(void**)(sp) = r1;
        r1 = sp;
        r8 = *(void**)(r8 + 0x38);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r19 + 0x28);
        r9 = *(void**)(sp + 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9c1480c;
        // ldp x29, x30, [sp, #0x10]  (0x9c147fc)
        r19 = *(void**)(sp + 0x20);
        sp = sp + 0x30;
        return this;
}

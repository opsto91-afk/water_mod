// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a28340
// fn_va = 0x9a28340
// return type (guess): unknown (no ret found)
void* fn_0x9a28340(void* this, void* r1) {
        // stp x20, x19, [sp, #0x40]  (0x9a28340)
        fp = sp + 0x18;
        r20 = this;
        *(void**)(this) = rzr;
        this = r4;
        r22 = r3;
        r21 = r2;
        r19 = r1;
        // fmov s8, s1  (0x9a28360)
        // fmov s9, s0  (0x9a28364)
        *(void**)(r1) = rzr;
        this = fn_0x9a714fc(this, r1, r2, r3);  // call  [0x9a714fc]
        r23 = this;
        this = this + 0x8;
        this = fn_0xe82f9f4(this, r1, r2, r3);  // call  [0xe82f9f4]
        // tbnz w0, #0x0, 0x9a284ac  (0x9a2837c)
        this = r23 + 0x8;
        this = fn_0xe82f28c(this, r1, r2, r3);  // call  [0xe82f28c]
        // tbz w0, #0x0, 0x9a284ac  (0x9a28388)
        r1 = "#look_at_cursor";  // 0x2796c6a
        this = r23 + 0x8;
        this = fn_0xe82f9f8(this, r1, r2, r3);  // call  [0xe82f9f8]
        r23 = this;
        this = fn_0xe82fa6c(this, r1, r2, r3);  // call  [0xe82fa6c]
        // tbz w0, #0x0, 0x9a284ac  (0x9a283a4)
        this = r23;
        r1 = rzr;
        this = fn_0xe82f388(this, r1, r2, r3);  // call  [0xe82f388]
        // tbz w0, #0x0, 0x9a284ac  (0x9a283b4)
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x960);
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0xa42cccc(this, r1, r2, r3);  // call  [0xa42cccc]
        // cmp this == <complex operand>
        if (/* cond: b.ne */) goto label_0x9a28448;
        // movk w22, #0xdead, lsl #0x10  (0x9a283d8)
        this = fn_0xe830744(this, r1, r2, r3);  // call  [0xe830744]
        // sxth w8, w0  (0x9a283e0)
        // scvtf s10, w8  (0x9a283e4)
        r8 = *(void**)(r21);
        if (r8 != 0) goto label_0x9a283f8;
        r9 = rzr;
        *(void**)(r9) = r22;
    label_0x9a283f8:
        r23 = *(uint8_t*)(r8);
        if (r23 != 0) goto label_0x9a28408;
        r8 = rzr;
        *(void**)(r8) = r22;
    label_0x9a28408:
        r21 = *(void**)(r21 + 0x10);
        this = r21;
        this = fn_0x99b8f8c(this, r1, r2, r3);  // call  [0x99b8f8c]
        // fmul s0, s10, s0  (0x9a28414)
        // fsub s0, s9, s0  (0x9a28418)
        *(void**)(r20) = rs0;
        this = fn_0xe830748(this, r1, r2, r3);  // call  [0xe830748]
        // sxth w8, w0  (0x9a28424)
        // scvtf s9, w8  (0x9a28428)
        // tbnz w23, #0x0, 0x9a28438  (0x9a2842c)
        r8 = rzr;
        *(void**)(r8) = r22;
    label_0x9a28438:
        this = r21;
        this = fn_0x99b8f8c(this, r1, r2, r3);  // call  [0x99b8f8c]
        // fmul s0, s9, s0  (0x9a28440)
        goto label_0x9a284a4;
    label_0x9a28448:
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x708);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x9a284ac;
        r8 = *(void**)(this);
        r21 = this;
        r8 = *(void**)(r8 + 0x238);
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0x9a28484  (0x9a2846c)
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x240);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0x9a284ac  (0x9a28480)
    label_0x9a28484:
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x248);
        this = (*(void**)r8)(this);  // indirect call
        rs0 = *(void**)(this);
        // fsub s0, s9, s0  (0x9a28498)
        *(void**)(r20) = rs0;
        rs0 = *(void**)(this + 0x4);
    label_0x9a284a4:
        // fsub s0, s8, s0  (0x9a284a4)
        *(void**)(r19) = rs0;
    label_0x9a284ac:
        // ldp x20, x19, [sp, #0x40]  (0x9a284ac)
        r23 = *(void**)(sp + 0x28);
        // ldp x22, x21, [sp, #0x30]  (0x9a284b4)
        // ldp x29, x30, [sp, #0x18]  (0x9a284b8)
        // ldp d9, d8, [sp, #0x8]  (0x9a284bc)
        return this;
}

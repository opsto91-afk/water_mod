// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e964
// fn_va = 0x8a3e964
// return type (guess): unknown (no ret found)
void* fn_0x8a3e964(void* this) {
        // stp x29, x30, [sp, #0xfffffffffffffff0]!  (0x8a3e964)
        this = *(void**)(this + 0x8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xf8);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3e9a0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x150);
        this = (*(void**)r8)(this);  // indirect call
        // and w8, w0, #0x1  (0x8a3e990)
        // orr w0, w8, w9, lsl #0x8  (0x8a3e994)
        // ldp x29, x30, [sp], #0x10  (0x8a3e998)
        return this;
}

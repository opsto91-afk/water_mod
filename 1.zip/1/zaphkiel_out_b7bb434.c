// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bb434
// fn_va = 0xb7bb434
// return type (guess): unknown (no ret found)
void* fn_0xb7bb434(void* this) {
        // stp x29, x30, [sp, #0x40]  (0xb7bb438)
        // stp x20, x19, [sp, #0x50]  (0xb7bb43c)
        fp = sp + 0x40;
        // mrs x20, tpidr_el0  (0xb7bb444)
        r19 = this;
        r8 = *(void**)(r20 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r8 = *(void**)(this + 0x978);
        r8 = *(void**)(r8 + 0x430);
        this = *(void**)(r8 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x158);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        this = sp + 0x18;
        r1 = sp;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x18;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7bb4b4  (0xb7bb484)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0x1020b844(this, r1, r2, r3);  // call  [0x1020b844]
        if (this == 0) goto label_0xb7bb49c;
        this = fn_0xfd7b6c0(this, r1, r2, r3);  // call  [0xfd7b6c0]
    label_0xb7bb49c:
        r8 = *(uint8_t*)(r19 + 0x948);
        if (r8 == 0) goto label_0xb7bb4c0;
    label_0xb7bb4a4:
        this = *(void**)(sp + 0x8);
        if (this != 0) goto label_0xb7bb4f4;
        goto label_0xb7bb4f8;
    label_0xb7bb4b4:
        this = rzr;
        r8 = *(uint8_t*)(r19 + 0x948);
        if (r8 != 0) goto label_0xb7bb4a4;
    label_0xb7bb4c0:
        r8 = *(uint8_t*)(r19 + 0x94b);
        // bic w8, w8, w0  (0xb7bb4c4)
        // tbnz w8, #0x0, 0xb7bb4e8  (0xb7bb4c8)
        this = *(void**)(r19 + 0x968);
        this = fn_0x10b41b0c(this, r1, r2, r3);  // call  [0x10b41b0c]
        // bic w19, w8, w0  (0xb7bb4d8)
        this = *(void**)(sp + 0x8);
        if (this != 0) goto label_0xb7bb4f4;
        goto label_0xb7bb4f8;
    label_0xb7bb4e8:
        this = *(void**)(sp + 0x8);
        if (this == 0) goto label_0xb7bb4f8;
    label_0xb7bb4f4:
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bb4f8:
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bb548;
        this = r19;
        // ldp x20, x19, [sp, #0x50]  (0xb7bb50c)
        // ldp x29, x30, [sp, #0x40]  (0xb7bb510)
        sp = sp + 0x60;
        return this;
}

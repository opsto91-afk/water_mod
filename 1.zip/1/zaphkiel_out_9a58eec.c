// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a58eec
// fn_va = 0x9a58eec
// return type (guess): unknown (no ret found)
void* fn_0x9a58eec(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffa0]!  (0x9a58eec)
        *(void**)(sp + 0x10) = r28;
        // stp x26, x25, [sp, #0x20]  (0x9a58ef4)
        // stp x24, x23, [sp, #0x30]  (0x9a58ef8)
        // stp x22, x21, [sp, #0x40]  (0x9a58efc)
        // stp x20, x19, [sp, #0x50]  (0x9a58f00)
        // mrs x24, tpidr_el0  (0x9a58f0c)
        r19 = this;
        this = r1;
        r8 = *(void**)(r24 + 0x28);
        r21 = r3;
        r22 = r2;
        r20 = r1;
        *(void**)(fp - 0x8) = r8;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0x9a591e0  (0x9a58f30)
        this = r20;
        this = fn_0xaf5d23c(this, r1, r2, r3);  // call  [0xaf5d23c]
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x4a8);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0x9a58f5c  (0x9a58f48)
        r8 = *(uint8_t*)(r19 + 0x60);
        if (r8 != 0) goto label_0x9a58f5c;
        *(void**)(r19 + 0x18) = rzr;
        goto label_0x9a591e0;
    label_0x9a58f5c:
        this = sp + 0x150;
        r25 = sp + 0x150;
        r23 = sp + 0x40;
        this = fn_0xe8307d0(this, r1, r2, r3);  // call  [0xe8307d0]
        this = r20;
        *(void**)(r25 + 0x1f) = rzr;
        rq0 = *(void**)(r8 + 0x240);
        *(void**)(sp + 0x168) = rzr;
        *(void**)(sp + 0x178) = r8;
        *(void**)(sp + 0x44) = rq0;
        // movi v0.2d, #0x0  (0x9a58f90)
        *(uint16_t*)(sp + 0x54) = r8;
        *(uint8_t*)(sp + 0x40) = rzr;
        *(void**)(r23 + 0x61) = r8;
        *(void**)(sp + 0x58) = rq0;
        *(void**)(sp + 0x68) = rq0;
        *(void**)(sp + 0x78) = rq0;
        *(void**)(r23 + 0x48) = rq0;
        *(void**)(r23 + 0x51) = rq0;
        *(uint8_t*)(sp + 0xa5) = rzr;
        // stp xzr, xzr, [sp, #0x100]  (0x9a58fbc)
        *(void**)(sp + 0xf8) = rzr;
        *(void**)(r23 + 0x68) = rq0;
        *(void**)(r23 + 0x78) = rq0;
        *(void**)(r23 + 0x88) = rq0;
        *(void**)(r23 + 0x98) = rq0;
        *(void**)(r23 + 0xa4) = rq0;
        this = fn_0xaf5d23c(this, r1, r2, r3);  // call  [0xaf5d23c]
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x598);
        r8 = sp + 0x1b0;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x1b0);
        if (r8 == 0) goto label_0x9a59018;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0x9a59030  (0x9a59004)
    label_0x9a59008:
        // ldp x23, x26, [sp, #0x1b8]  (0x9a59008)
        // stp xzr, xzr, [sp, #0x1b0]  (0x9a5900c)
        if (r23 != 0) goto label_0x9a5904c;
        goto label_0x9a590a8;
    label_0x9a59018:
        r9 = rzr;
        // movk w10, #0xdead, lsl #0x10  (0x9a59020)
        *(void**)(r9) = r10;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0x9a59008  (0x9a5902c)
    label_0x9a59030:
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0x9a59038)
        *(void**)(r8) = r9;
        // ldp x23, x26, [sp, #0x1b8]  (0x9a59040)
        // stp xzr, xzr, [sp, #0x1b0]  (0x9a59044)
        if (r23 == 0) goto label_0x9a590a8;
    label_0x9a5904c:
        r1 = r23 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a59074;
        r8 = *(void**)(r23);
        this = r23;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r23;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a59074:
        r23 = *(void**)(sp + 0x1b8);
        *(void**)(sp + 0x1c0) = rzr;
        if (r23 == 0) goto label_0x9a590a8;
        r1 = r23 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a590a8;
        r8 = *(void**)(r23);
        this = r23;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r23;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a590a8:
        r8 = *(uint8_t*)(r26 + 0xf0);
        if (r8 == 0) goto label_0x9a59120;
        this = r26;
        r8 = *(uint8_t*)(this + 0x38);
        r9 = *(void**)(this + 0x8);
        // lsr x10, x8, #0x1  (0x9a590bc)
        // tst w8, #0x1  (0x9a590c0)
        // csel x8, x10, x9, eq  (0x9a590c4)
        if (r8 == 0) goto label_0x9a59120;
        this = fn_0xb99bf8c(this, r1, r2, r3);  // call  [0xb99bf8c]
        *(void**)(sp + 0xf0) = this;
        r8 = r26;
        r9 = *(uint8_t*)(r8 + 0x50);
        // tbnz w9, #0x0, 0x9a590f4  (0x9a590dc)
        rq0 = *(void**)(r8);
        r8 = *(void**)(r8 + 0x10);
        *(void**)(sp + 0x1b0) = rq0;
        *(void**)(sp + 0x1c0) = r8;
        goto label_0x9a59100;
    label_0x9a590f4:
        // ldp x2, x1, [x26, #0x58]  (0x9a590f4)
        this = sp + 0x1b0;
        this = fn_0x88a6328(this, r1, r2, r3);  // call  [0x88a6328]
    label_0x9a59100:
        r8 = sp + 0x40;
        r1 = sp + 0x1b0;
        this = (void*)0x28130b8;
        this = fn_0x8959368(this, r1, r2, r3);  // call  [0x8959368]
        r8 = *(uint8_t*)(sp + 0x1b0);
        // tbz w8, #0x0, 0x9a59120  (0x9a59114)
        this = *(void**)(sp + 0x1c0);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a59120:
        this = r20;
        this = fn_0xfd81dec(this, r1, r2, r3);  // call  [0xfd81dec]
        r8 = *(void**)(this);
        *(void**)(sp + 0x1a0) = rzr;
        r8 = *(void**)(r8 + 0xb10);
        r1 = sp + 0x150;
        r4 = sp + 0x40;
        r5 = sp + 0x180;
        r2 = r22;
        r3 = r21;
        r21 = sp + 0x180;
        this = (*(void**)r8)(this);  // indirect call
        this = *(void**)(sp + 0x1a0);
        // cmp this == r21
        if (/* cond: b.eq */) goto label_0x9a59168;
        if (this == 0) goto label_0x9a5917c;
        goto label_0x9a59170;
    label_0x9a59168:
        this = sp + 0x180;
    label_0x9a59170:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0x9a5917c:
        this = sp + 0x150;
        this = fn_0xe8307d4(this, r1, r2, r3);  // call  [0xe8307d4]
        // tbz w0, #0x0, 0x9a59210  (0x9a59184)
        r8 = rzr;
        r9 = *(uint8_t*)(sp + 0xf8);
        // stp wzr, wzr, [x19, #0x18]  (0x9a59190)
        // tbz w9, #0x0, 0x9a591a0  (0x9a59194)
    label_0x9a59198:
        this = *(void**)(sp + 0x108);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a591a0:
        r8 = *(uint8_t*)(sp + 0xd8);
        // tbnz w8, #0x0, 0x9a592f4  (0x9a591a4)
        r8 = *(uint8_t*)(sp + 0xc0);
        // tbnz w8, #0x0, 0x9a59304  (0x9a591ac)
    label_0x9a591b0:
        r8 = *(uint8_t*)(sp + 0xa8);
        // tbnz w8, #0x0, 0x9a59314  (0x9a591b4)
    label_0x9a591b8:
        r8 = *(uint8_t*)(sp + 0x88);
        // tbnz w8, #0x0, 0x9a59324  (0x9a591bc)
    label_0x9a591c0:
        r8 = *(uint8_t*)(sp + 0x70);
        // tbnz w8, #0x0, 0x9a59334  (0x9a591c4)
    label_0x9a591c8:
        r8 = *(uint8_t*)(sp + 0x58);
        // tbz w8, #0x0, 0x9a591d8  (0x9a591cc)
    label_0x9a591d0:
        this = *(void**)(sp + 0x68);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a591d8:
        this = sp + 0x150;
        this = fn_0xe82f6b0(this, r1, r2, r3);  // call  [0xe82f6b0]
    label_0x9a591e0:
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9a593ec;
        sp = sp + 0x5c0;
        // ldp x20, x19, [sp, #0x50]  (0x9a591f4)
        r28 = *(void**)(sp + 0x10);
        // ldp x22, x21, [sp, #0x40]  (0x9a591fc)
        // ldp x24, x23, [sp, #0x30]  (0x9a59200)
        // ldp x26, x25, [sp, #0x20]  (0x9a59204)
        // ldp x29, x30, [sp], #0x60  (0x9a59208)
        return this;
}

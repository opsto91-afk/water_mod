// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a7bc4
// fn_va = 0xb7a7bc4
// return type (guess): unknown (no ret found)
void* fn_0xb7a7bc4(void* this) {
        this = *(void**)(r19 + 0x3b8);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        r8 = *(uint8_t*)(r19 + 0x390);
        // tbz w8, #0x0, 0xb7a78b0  (0xb7a7bd0)
        this = *(void**)(r19 + 0x3a0);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        r8 = *(uint8_t*)(r19 + 0x378);
        // tbz w8, #0x0, 0xb7a78b8  (0xb7a7be0)
        this = *(void**)(r19 + 0x388);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        r8 = *(uint8_t*)(r19 + 0x368);
        if (r8 != 0) goto label_0xb7a78c0;
        goto label_0xb7a78c8;
        this = fn_0x135df9a0(this, r1, r2, r3);  // call  [0x135df9a0]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        // brk #0x1  (0xb7a7c00)
        return this;
}

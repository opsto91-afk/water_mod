// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7b2b1c
// fn_va = 0xb7b2b1c
// return type (guess): unknown (no ret found)
void* fn_0xb7b2b1c(void* this, void* r2) {
        // stp x2, x9, [sp, #0x8]  (0xb7b2b1c)
        r2 = sp + 0x20;
        this = fn_0xb7e6d8c(this, r1, r2, r3);  // call  [0xb7e6d8c]
        r8 = *(void**)(r19 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b2b4c;
        // ldp x29, x30, [sp, #0x40]  (0xb7b2b38)
        r19 = *(void**)(sp + 0x50);
        sp = sp + 0x60;
        return this;
}

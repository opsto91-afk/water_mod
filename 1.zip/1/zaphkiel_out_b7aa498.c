// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7aa498
// fn_va = 0xb7aa498
// return type (guess): unknown (no ret found)
void* fn_0xb7aa498(void* this) {
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7aa4b8;
        r19 = this;
        this = sp + 0x150;
        this = fn_0xb7aea34(this, r1, r2, r3);  // call  [0xb7aea34]
    label_0xb7aa4b8:
        r8 = *(void**)(sp + 0x20);
        r8 = *(void**)(r8 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7aa4d4;
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
    label_0xb7aa4d4:
        this = fn_0x135df9a0(this, r1, r2, r3);  // call  [0x135df9a0]
        return this;
}

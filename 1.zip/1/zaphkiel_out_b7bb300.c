// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bb300
// fn_va = 0xb7bb300
// return type (guess): unknown (no ret found)
void* fn_0xb7bb300(void* this) {
        // stp x29, x30, [sp, #0x40]  (0xb7bb304)
        // stp x20, x19, [sp, #0x50]  (0xb7bb308)
        fp = sp + 0x40;
        // mrs x20, tpidr_el0  (0xb7bb310)
        r19 = this;
        r8 = *(void**)(r20 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r8 = *(void**)(this + 0x978);
        r8 = *(void**)(r8 + 0x430);
        this = *(void**)(r8 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x158);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        this = sp + 0x18;
        r1 = sp;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x18;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7bb380  (0xb7bb350)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0x1020b844(this, r1, r2, r3);  // call  [0x1020b844]
        if (this == 0) goto label_0xb7bb368;
        this = fn_0xfd7b6c0(this, r1, r2, r3);  // call  [0xfd7b6c0]
    label_0xb7bb368:
        r8 = *(uint8_t*)(r19 + 0x948);
        if (r8 == 0) goto label_0xb7bb38c;
    label_0xb7bb370:
        this = *(void**)(sp + 0x8);
        if (this != 0) goto label_0xb7bb3cc;
        goto label_0xb7bb3d0;
    label_0xb7bb380:
        this = rzr;
        r8 = *(uint8_t*)(r19 + 0x948);
        if (r8 != 0) goto label_0xb7bb370;
    label_0xb7bb38c:
        r8 = *(uint8_t*)(r19 + 0x94b);
        // bic w8, w8, w0  (0xb7bb390)
        // tbnz w8, #0x0, 0xb7bb3c0  (0xb7bb394)
        r8 = *(uint8_t*)(r19 + 0x94a);
        // bic w8, w8, w0  (0xb7bb39c)
        // tbnz w8, #0x0, 0xb7bb3f4  (0xb7bb3a0)
        this = *(void**)(r19 + 0x968);
        this = fn_0x10b41b0c(this, r1, r2, r3);  // call  [0x10b41b0c]
        // bic w19, w8, w0  (0xb7bb3b0)
        this = *(void**)(sp + 0x8);
        if (this != 0) goto label_0xb7bb3cc;
        goto label_0xb7bb3d0;
    label_0xb7bb3c0:
        this = *(void**)(sp + 0x8);
        if (this == 0) goto label_0xb7bb3d0;
    label_0xb7bb3cc:
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bb3d0:
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bb430;
        this = r19;
        // ldp x20, x19, [sp, #0x50]  (0xb7bb3e4)
        // ldp x29, x30, [sp, #0x40]  (0xb7bb3e8)
        sp = sp + 0x60;
        return this;
}

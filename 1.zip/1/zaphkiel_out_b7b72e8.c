// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7b72e8
// fn_va = 0xb7b72e8
// return type (guess): unknown (no ret found)
void* fn_0xb7b72e8(void* this) {
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        this = fn_0x88a3e24(this, r1, r2, r3);  // call  [0x88a3e24]
        return this;
}

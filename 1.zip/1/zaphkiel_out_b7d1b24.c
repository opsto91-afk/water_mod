// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d1b24
// fn_va = 0xb7d1b24
// return type (guess): unknown (no ret found)
void* fn_0xb7d1b24(void* this) {
        r19 = this;
        this = fp - 0x50;
        this = fn_0xb7fb7f0(this, r1, r2, r3);  // call  [0xb7fb7f0]
        goto label_0xb7d1b38;
        r19 = this;
    label_0xb7d1b38:
        r8 = *(uint8_t*)(sp + 0x88);
        // tbz w8, #0x0, 0xb7d1b48  (0xb7d1b3c)
        this = *(void**)(sp + 0x98);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d1b48:
        r8 = *(void**)(r25 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1b60;
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
    label_0xb7d1b60:
        this = fn_0x135df9a0(this, r1, r2, r3);  // call  [0x135df9a0]
        this = this - 0xc50;
        goto label_0xb7d118c;
        // stp d13, d12, [sp, #0xa0]  (0xb7d1b70)
        // stp d11, d10, [sp, #0xb0]  (0xb7d1b74)
        // stp d9, d8, [sp, #0xc0]  (0xb7d1b78)
        // stp x29, x30, [sp, #0xd0]  (0xb7d1b7c)
        // stp x28, x23, [sp, #0xe0]  (0xb7d1b80)
        // stp x22, x21, [sp, #0xf0]  (0xb7d1b84)
        // stp x20, x19, [sp, #0x100]  (0xb7d1b88)
        fp = sp + 0xd0;
        // mrs x22, tpidr_el0  (0xb7d1b90)
        // fmov s8, s1  (0xb7d1b94)
        // fmov s9, s2  (0xb7d1b98)
        r8 = *(void**)(r22 + 0x28);
        r21 = r2;
        r20 = r1;
        r19 = this;
        *(void**)(fp - 0x38) = r8;
        r8 = *(void**)(r1);
        rs1 = *(void**)(r8);
        // movk w8, #0x4265, lsl #0x10  (0xb7d1bbc)
        // fmov s2, w8  (0xb7d1bc0)
        // fmul s1, s1, s2  (0xb7d1bc8)
        // fadd s0, s1, s0  (0xb7d1bcc)
        // fmov s1, w8  (0xb7d1bd0)
        this = fn_0x135fa600(this, r1, r2, r3);  // call  [0x135fa600]
        // fmov s11, #2  (0xb7d1bdc)
        // movk w8, #0x3c8e, lsl #0x10  (0xb7d1be0)
        // fmov s1, w8  (0xb7d1be4)
        // fmul s1, s9, s1  (0xb7d1be8)
        // fmov s9, s0  (0xb7d1bec)
        // fdiv s1, s1, s11  (0xb7d1bf0)
        // fmov s0, s1  (0xb7d1bf4)
        this = fn_0x135d4400(this, r1, r2, r3);  // call  [0x135d4400]
        r8 = *(void**)(r20 + 0x8);
        // scvtf s1, wzr  (0xb7d1c00)
        // scvtf s3, wzr  (0xb7d1c08)
        // scvtf s4, w23  (0xb7d1c0c)
        this = sp + 0x10;
        rs2 = *(void**)(r8);
        r1 = sp + 0x4;
        rd10 = *(void**)(r8 + 0x970);
        // stp s1, s1, [sp, #0x14]  (0xb7d1c28)
        // fmul s12, s0, s2  (0xb7d1c2c)
        // stp s1, s1, [sp, #0x1c]  (0xb7d1c30)
        // stp s1, s1, [sp, #0x28]  (0xb7d1c34)
        // stp s1, s1, [sp, #0x30]  (0xb7d1c38)
        // stp s1, s1, [sp, #0x3c]  (0xb7d1c3c)
        // stp s1, s1, [sp, #0x44]  (0xb7d1c40)
        // fcvt s1, d10  (0xb7d1c44)
        *(void**)(sp + 0x10) = r8;
        *(void**)(sp + 0x24) = r8;
        *(void**)(sp + 0x38) = r8;
        // fmul s0, s9, s1  (0xb7d1c54)
        *(void**)(sp + 0x4c) = r8;
        r8 = sp + 0x50;
        // stp s3, s3, [sp, #0x4]  (0xb7d1c60)
        *(void**)(sp + 0xc) = rs4;
        this = fn_0x90969b8(this, r1, r2, r3);  // call  [0x90969b8]
        // ldp q0, q1, [sp, #0x50]  (0xb7d1c6c)
        // fcvt s2, d10  (0xb7d1c70)
        // scvtf s4, w23  (0xb7d1c74)
        r8 = sp + 0x50;
        this = sp + 0x10;
        r1 = sp + 0x4;
        // stp q0, q1, [sp, #0x10]  (0xb7d1c84)
        // ldp q3, q0, [sp, #0x70]  (0xb7d1c88)
        // scvtf s1, wzr  (0xb7d1c8c)
        // stp q3, q0, [sp, #0x30]  (0xb7d1c90)
        // fmul s0, s8, s2  (0xb7d1c94)
        // stp s4, s1, [sp, #0x4]  (0xb7d1c98)
        *(void**)(sp + 0xc) = rs1;
        this = fn_0x90969b8(this, r1, r2, r3);  // call  [0x90969b8]
        // ldp s4, s5, [sp, #0x50]  (0xb7d1ca4)
        // scvtf s24, wzr  (0xb7d1ca8)
        // ldp s17, s6, [sp, #0x58]  (0xb7d1cac)
        this = sp + 0x10;
        // ldp s0, s2, [sp, #0x60]  (0xb7d1cb4)
        r1 = sp + 0x4;
        // ldp s7, s18, [sp, #0x68]  (0xb7d1cbc)
        r8 = *(void**)(r20 + 0x8);
        // ldp s1, s3, [sp, #0x70]  (0xb7d1cc4)
        // fmul s26, s4, s24  (0xb7d1cc8)
        // ldp s16, s19, [sp, #0x78]  (0xb7d1ccc)
        // fmul s28, s5, s24  (0xb7d1cd0)
        // ldp s20, s21, [sp, #0x80]  (0xb7d1cd4)
        // fmul s30, s17, s24  (0xb7d1cd8)
        // ldp s22, s23, [sp, #0x88]  (0xb7d1cdc)
        // fmul s13, s6, s24  (0xb7d1ce0)
        // stp s4, s5, [sp, #0x10]  (0xb7d1ce4)
        // stp s17, s6, [sp, #0x18]  (0xb7d1ce8)
        // stp s0, s2, [sp, #0x20]  (0xb7d1cec)
        // stp s7, s18, [sp, #0x28]  (0xb7d1cf0)
        // stp s1, s3, [sp, #0x30]  (0xb7d1cf4)
        // stp s16, s19, [sp, #0x38]  (0xb7d1cf8)
        // stp s20, s21, [sp, #0x40]  (0xb7d1cfc)
        // stp s22, s23, [sp, #0x48]  (0xb7d1d00)
        rs25 = *(void**)(r8);
        // fmul s27, s0, s25  (0xb7d1d0c)
        // fmul s29, s2, s25  (0xb7d1d10)
        // fmul s31, s7, s25  (0xb7d1d14)
        // fmul s25, s18, s25  (0xb7d1d18)
        // fadd s26, s26, s27  (0xb7d1d1c)
        // fmul s27, s1, s24  (0xb7d1d20)
        // fadd s28, s28, s29  (0xb7d1d24)
        // fmul s29, s3, s24  (0xb7d1d28)
        // fadd s30, s30, s31  (0xb7d1d2c)
        // fmul s31, s16, s24  (0xb7d1d30)
        // fadd s25, s13, s25  (0xb7d1d34)
        // fmul s24, s19, s24  (0xb7d1d38)
        // fadd s26, s26, s27  (0xb7d1d3c)
        // fadd s27, s28, s29  (0xb7d1d40)
        // fadd s28, s30, s31  (0xb7d1d44)
        // fadd s24, s25, s24  (0xb7d1d48)
        // fmul s25, s12, s11  (0xb7d1d4c)
        // fadd s20, s26, s20  (0xb7d1d50)
        // fadd s21, s27, s21  (0xb7d1d54)
        // fadd s22, s28, s22  (0xb7d1d58)
        // fmul s4, s4, s25  (0xb7d1d5c)
        // fmul s5, s5, s25  (0xb7d1d60)
        // fadd s23, s24, s23  (0xb7d1d64)
        // fmul s0, s0, s25  (0xb7d1d68)
        // fmul s2, s2, s25  (0xb7d1d6c)
        // fmul s1, s1, s25  (0xb7d1d70)
        // fmul s17, s17, s25  (0xb7d1d74)
        // fmul s6, s6, s25  (0xb7d1d78)
        // stp s20, s21, [sp, #0x40]  (0xb7d1d7c)
        // stp s4, s5, [sp, #0x10]  (0xb7d1d80)
        // fmul s4, s7, s25  (0xb7d1d84)
        // fmul s5, s18, s25  (0xb7d1d88)
        // stp s0, s2, [sp, #0x20]  (0xb7d1d8c)
        // fmul s0, s3, s25  (0xb7d1d90)
        // fmul s2, s16, s25  (0xb7d1d94)
        // fmul s3, s19, s25  (0xb7d1d98)
        // stp s22, s23, [sp, #0x48]  (0xb7d1d9c)
        // stp s17, s6, [sp, #0x18]  (0xb7d1da0)
        // stp s4, s5, [sp, #0x28]  (0xb7d1da4)
        // fcvt s4, d10  (0xb7d1da8)
        // scvtf s5, wzr  (0xb7d1dac)
        // stp s1, s0, [sp, #0x30]  (0xb7d1db0)
        // fmov s0, w8  (0xb7d1db4)
        // scvtf s1, w23  (0xb7d1db8)
        r8 = sp + 0x50;
        // stp s2, s3, [sp, #0x38]  (0xb7d1dc0)
        // fmul s0, s0, s4  (0xb7d1dc4)
        *(void**)(sp + 0xc) = rs5;
        // stp s5, s1, [sp, #0x4]  (0xb7d1dcc)
        this = fn_0x90969b8(this, r1, r2, r3);  // call  [0x90969b8]
        // ldp s0, s1, [sp, #0x50]  (0xb7d1dd4)
        r8 = *(void**)(r20 + 0x10);
        // ldp s2, s3, [sp, #0x58]  (0xb7d1ddc)
        // ldp s4, s5, [sp, #0x60]  (0xb7d1de0)
        // ldp s6, s7, [sp, #0x68]  (0xb7d1de4)
        // stp s0, s1, [sp, #0x10]  (0xb7d1de8)
        // stp s2, s3, [sp, #0x18]  (0xb7d1dec)
        // ldp s16, s17, [sp, #0x70]  (0xb7d1df0)
        // stp s4, s5, [sp, #0x20]  (0xb7d1df4)
        // ldp s18, s19, [sp, #0x78]  (0xb7d1df8)
        // stp s6, s7, [sp, #0x28]  (0xb7d1dfc)
        // ldp s20, s21, [sp, #0x80]  (0xb7d1e00)
        // stp s16, s17, [sp, #0x30]  (0xb7d1e04)
        // ldp s22, s23, [sp, #0x88]  (0xb7d1e08)
        // stp s18, s19, [sp, #0x38]  (0xb7d1e0c)
        // stp s20, s21, [sp, #0x40]  (0xb7d1e10)
        // stp s22, s23, [sp, #0x48]  (0xb7d1e14)
        r8 = *(uint8_t*)(r8);
        if (r8 == 0) goto label_0xb7d1eb0;
        r8 = *(void**)(r20 + 0x18);
        r9 = *(uint8_t*)(r8 + 0x18);
        if (r9 == 0) goto label_0xb7d1eb8;
        // fcvt s0, d10  (0xb7d1e2c)
        rs2 = *(void**)(r8 + 0x4);
        // scvtf s1, wzr  (0xb7d1e38)
        // scvtf s3, w9  (0xb7d1e3c)
        r8 = sp + 0x50;
        this = sp + 0x10;
        r1 = sp + 0x4;
        // fmul s0, s2, s0  (0xb7d1e4c)
        // stp s1, s3, [sp, #0x4]  (0xb7d1e50)
        *(void**)(sp + 0xc) = rs1;
        this = fn_0x90969b8(this, r1, r2, r3);  // call  [0x90969b8]
        // ldp s0, s1, [sp, #0x50]  (0xb7d1e5c)
        r8 = *(void**)(r20 + 0x10);
        // ldp s2, s3, [sp, #0x58]  (0xb7d1e64)
        // ldp s4, s5, [sp, #0x60]  (0xb7d1e68)
        // ldp s6, s7, [sp, #0x68]  (0xb7d1e6c)
        // stp s0, s1, [sp, #0x10]  (0xb7d1e70)
        // stp s2, s3, [sp, #0x18]  (0xb7d1e74)
        // ldp s16, s17, [sp, #0x70]  (0xb7d1e78)
        // stp s4, s5, [sp, #0x20]  (0xb7d1e7c)
        // ldp s18, s19, [sp, #0x78]  (0xb7d1e80)
        // stp s6, s7, [sp, #0x28]  (0xb7d1e84)
        // ldp s20, s21, [sp, #0x80]  (0xb7d1e88)
        // stp s16, s17, [sp, #0x30]  (0xb7d1e8c)
        // ldp s22, s23, [sp, #0x88]  (0xb7d1e90)
        // stp s18, s19, [sp, #0x38]  (0xb7d1e94)
        // stp s20, s21, [sp, #0x40]  (0xb7d1e98)
        // stp s22, s23, [sp, #0x48]  (0xb7d1e9c)
        r8 = *(uint8_t*)(r8);
        // cmp r8 == <complex operand>
        // cset w8, eq  (0xb7d1ea8)
        goto label_0xb7d1ebc;
    label_0xb7d1eb0:
        goto label_0xb7d1ebc;
    label_0xb7d1eb8:
        r8 = rzr;
    label_0xb7d1ebc:
        // fmul s24, s4, s4  (0xb7d1ebc)
        // fmul s25, s5, s5  (0xb7d1ec0)
        // fmul s26, s6, s6  (0xb7d1ec4)
        // fadd s24, s24, s25  (0xb7d1ec8)
        // scvtf s25, w23  (0xb7d1ecc)
        // fadd s24, s24, s26  (0xb7d1ed0)
        // fsqrt s24, s24  (0xb7d1ed4)
        // fdiv s26, s25, s24  (0xb7d1ed8)
        // fmul s24, s4, s26  (0xb7d1edc)
        // fmul s25, s5, s26  (0xb7d1ee0)
        // fmul s26, s6, s26  (0xb7d1ee4)
        // stp s24, s25, [sp, #0x4]  (0xb7d1ee8)
        *(void**)(sp + 0xc) = rs26;
        // tbnz w8, #0x0, 0xb7d1f38  (0xb7d1ef0)
        r8 = *(void**)(r20 + 0x18);
        r9 = *(uint8_t*)(r8 + 0x18);
        if (r9 == 0) goto label_0xb7d1f38;
        r9 = *(uint8_t*)(r8 + 0x14);
        if (r9 == 0) goto label_0xb7d1f14;
        // ldp s24, s25, [x8, #0x8]  (0xb7d1f08)
        rs26 = *(void**)(r8 + 0x10);
        goto label_0xb7d1f30;
    label_0xb7d1f14:
        // fmov s27, #1  (0xb7d1f14)
        // fmov s28, #-1  (0xb7d1f18)
        // tst w21, #0x1  (0xb7d1f1c)
        // fcsel s27, s28, s27, ne  (0xb7d1f20)
        // fmul s24, s24, s27  (0xb7d1f24)
        // fmul s25, s25, s27  (0xb7d1f28)
        // fmul s26, s26, s27  (0xb7d1f2c)
    label_0xb7d1f30:
        // stp s24, s25, [sp, #0x4]  (0xb7d1f30)
        *(void**)(sp + 0xc) = rs26;
    label_0xb7d1f38:
        r8 = *(void**)(r20 + 0x20);
        r8 = *(uint8_t*)(r8);
        if (r8 == 0) goto label_0xb7d1f94;
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(r8 + 0x10);
        if (r9 == 0) goto label_0xb7d1f94;
        r9 = *(uint8_t*)(r9);
        if (r9 == 0) goto label_0xb7d1f94;
        this = *(void**)(r8 + 0x20);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x280);
        r8 = sp + 0x50;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x50);
        if (r8 == 0) goto label_0xb7d1f9c;
        rs0 = *(void**)(r8 + 0xc0);
        this = fn_0x1193ff30(this, r1, r2, r3);  // call  [0x1193ff30]
        this = sp + 0x4;
        this = fn_0x1193ff54(this, r1, r2, r3);  // call  [0x1193ff54]
        // and w21, w0, #0x1  (0xb7d1f84)
        r20 = *(void**)(sp + 0x58);
        if (r20 != 0) goto label_0xb7d1fa8;
        goto label_0xb7d1fd0;
    label_0xb7d1f94:
        r21 = rzr;
        goto label_0xb7d1ff8;
    label_0xb7d1f9c:
        r21 = rzr;
        r20 = *(void**)(sp + 0x58);
        if (r20 == 0) goto label_0xb7d1fd0;
    label_0xb7d1fa8:
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d1fd0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d1fd0:
        // ldp s24, s25, [sp, #0x4]  (0xb7d1fd0)
        rs23 = *(void**)(sp + 0x4c);
        // ldp s26, s0, [sp, #0xc]  (0xb7d1fd8)
        // ldp s1, s2, [sp, #0x14]  (0xb7d1fdc)
        // ldp s3, s4, [sp, #0x1c]  (0xb7d1fe0)
        // ldp s5, s6, [sp, #0x24]  (0xb7d1fe4)
        // ldp s7, s16, [sp, #0x2c]  (0xb7d1fe8)
        // ldp s17, s18, [sp, #0x34]  (0xb7d1fec)
        // ldp s19, s20, [sp, #0x3c]  (0xb7d1ff0)
        // ldp s21, s22, [sp, #0x44]  (0xb7d1ff4)
    label_0xb7d1ff8:
        // stp s24, s25, [x19]  (0xb7d1ff8)
        // stp s26, s9, [x19, #0x8]  (0xb7d1ffc)
        // stp s8, s0, [x19, #0x10]  (0xb7d2000)
        // stp s1, s2, [x19, #0x18]  (0xb7d2004)
        // stp s3, s4, [x19, #0x20]  (0xb7d2008)
        // stp s5, s6, [x19, #0x28]  (0xb7d200c)
        // stp s7, s16, [x19, #0x30]  (0xb7d2010)
        // stp s17, s18, [x19, #0x38]  (0xb7d2014)
        // stp s19, s20, [x19, #0x40]  (0xb7d2018)
        // stp s21, s22, [x19, #0x48]  (0xb7d201c)
        *(void**)(r19 + 0x50) = rs23;
        *(uint8_t*)(r19 + 0x54) = r21;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x38);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d205c;
        // ldp x20, x19, [sp, #0x100]  (0xb7d2038)
        // ldp x22, x21, [sp, #0xf0]  (0xb7d203c)
        // ldp x28, x23, [sp, #0xe0]  (0xb7d2040)
        // ldp x29, x30, [sp, #0xd0]  (0xb7d2044)
        // ldp d9, d8, [sp, #0xc0]  (0xb7d2048)
        // ldp d11, d10, [sp, #0xb0]  (0xb7d204c)
        // ldp d13, d12, [sp, #0xa0]  (0xb7d2050)
        sp = sp + 0x110;
        return this;
}

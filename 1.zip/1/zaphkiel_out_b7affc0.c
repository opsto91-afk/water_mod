// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7affc0
// fn_va = 0xb7affc0
// return type (guess): unknown (no ret found)
void* fn_0xb7affc0(void* this) {
        // stp x20, x19, [sp, #0x20]  (0xb7affc0)
        this = (void*)0x1407d860;
        r20 = r1;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r21 = *(void**)(r8 + 0x940);
        if (r21 == 0) goto label_0xb7b0030;
        r8 = *(uint8_t*)(r21);
        if (r8 == 0) goto label_0xb7b0030;
        r19 = *(void**)(r8 + 0x948);
        if (r19 == 0) goto label_0xb7b0048;
        r1 = r19 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r21);
        if (r8 == 0) goto label_0xb7b0020;
        // sxtw x1, w20  (0xb7b0010)
        r8 = *(void**)(r8 + 0x950);
        this = (void*)0x1407d108;
        this = fn_0xa999cfc(this, r1, r2, r3);  // call  [0xa999cfc]
    label_0xb7b0020:
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7b0074;
    label_0xb7b0030:
        this = (void*)0x1407d860;
        // ldp x20, x19, [sp, #0x20]  (0xb7b0038)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0xb7b0040)
        return fn_0x135d03c8(/* tail call */);
    label_0xb7b0048:
        // sxtw x1, w20  (0xb7b004c)
        r8 = *(void**)(r8 + 0x950);
        this = (void*)0x1407d108;
        this = fn_0xa999cfc(this, r1, r2, r3);  // call  [0xa999cfc]
        this = (void*)0x1407d860;
        // ldp x20, x19, [sp, #0x20]  (0xb7b0064)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0xb7b006c)
        return fn_0x135d03c8(/* tail call */);
    label_0xb7b0074:
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        this = (void*)0x1407d860;
        // ldp x20, x19, [sp, #0x20]  (0xb7b0094)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0xb7b009c)
        return fn_0x135d03c8(/* tail call */);
        r8 = *(void**)(r1 + 0x2c);
        r9 = *(void**)(this + 0x598);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b00b8;
        return this;
}

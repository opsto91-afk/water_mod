// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bfe98
// fn_va = 0xb7bfe98
// return type (guess): unknown (no ret found)
void* fn_0xb7bfe98(void* this) {
        // stp x29, x30, [sp, #0x30]  (0xb7bfe9c)
        // stp x24, x23, [sp, #0x40]  (0xb7bfea0)
        // stp x22, x21, [sp, #0x50]  (0xb7bfea4)
        // stp x20, x19, [sp, #0x60]  (0xb7bfea8)
        fp = sp + 0x30;
        // mrs x24, tpidr_el0  (0xb7bfeb0)
        r20 = this;
        r19 = r1;
        r8 = *(void**)(r24 + 0x28);
        this = sp + 0x8;
        *(void**)(fp - 0x8) = r8;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x8;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7bfff0  (0xb7bfedc)
        this = sp + 0x8;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7bfff0;
        this = r20;
        r1 = r19;
        this = fn_0xb7b9bb0(this, r1, r2, r3);  // call  [0xb7b9bb0]
        // ldp x21, x8, [x20, #0x1d8]  (0xb7bfefc)
        r22 = *(void**)(r20 + 0x1f0);
        // cmp r21 == r8
        if (/* cond: b.ne */) goto label_0xb7bff18;
        r8 = *(void**)(r20 + 0x1f8);
    label_0xb7bff10:
        // cmp r22 == r8
        if (/* cond: b.eq */) goto label_0xb7bfff0;
    label_0xb7bff18:
        r23 = *(void**)(r21);
        if (r23 == 0) goto label_0xb7c0018;
        r8 = *(void**)(r20 + 0x1118);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x148);
        this = (*(void**)r8)(this);  // indirect call
        // cmp r23 == this
        if (/* cond: b.ne */) goto label_0xb7bffd4;
        this = *(void**)(r20 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x688);
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0xb7bffd4  (0xb7bff4c)
        this = r23;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tbz w0, #0x0, 0xb7bffd4  (0xb7bff5c)
        r8 = *(void**)(r23);
        this = r23;
        r8 = *(void**)(r8 + 0x150);
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0xb7bffd4  (0xb7bff70)
        r8 = *(uint8_t*)(r19 + 0x4c);
        if (r8 != 0) goto label_0xb7bffd4;
        r8 = *(void**)(r20 + 0x1e0);
        r1 = r21 + 0x8;
        // subs x23, x8, x1  (0xb7bff84)
        if (/* cond: b.eq */) goto label_0xb7bff98;
        this = r21;
        r2 = r23;
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7bff98:
        r8 = *(void**)(r20 + 0x1f8);
        r1 = r22 + 0x1;
        *(void**)(r20 + 0x1e0) = r9;
        // subs x23, x8, x1  (0xb7bffa8)
        if (/* cond: b.eq */) goto label_0xb7bffbc;
        this = r22;
        r2 = r23;
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7bffbc:
        *(void**)(r20 + 0x1f8) = r8;
        r9 = *(void**)(r20 + 0x1e0);
        // cmp r21 == r9
        if (/* cond: b.eq */) goto label_0xb7bff10;
        goto label_0xb7bff18;
    label_0xb7bffd4:
        r8 = *(void**)(r20 + 0x1f8);
        r21 = r21 + 0x8;
        r22 = r22 + 0x1;
        r9 = *(void**)(r20 + 0x1e0);
        // cmp r21 == r9
        if (/* cond: b.eq */) goto label_0xb7bff10;
        goto label_0xb7bff18;
    label_0xb7bfff0:
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c001c;
        // ldp x20, x19, [sp, #0x60]  (0xb7c0000)
        // ldp x22, x21, [sp, #0x50]  (0xb7c0004)
        // ldp x24, x23, [sp, #0x40]  (0xb7c0008)
        // ldp x29, x30, [sp, #0x30]  (0xb7c000c)
        sp = sp + 0x70;
        return this;
}

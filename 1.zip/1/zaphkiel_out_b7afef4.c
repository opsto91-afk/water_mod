// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7afef4
// fn_va = 0xb7afef4
// return type (guess): unknown (no ret found)
void* fn_0xb7afef4(void* this) {
        // stp x20, x19, [sp, #0x10]  (0xb7afef4)
        r19 = this;
        this = this - 0xc58;
        r20 = r1;
        this = fn_0xb7afc3c(this, r1, r2, r3);  // call  [0xb7afc3c]
        this = r20;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0xb7aff24  (0xb7aff14)
        r1 = r19 + 0x8;
        this = r20;
        this = fn_0xaf66c9c(this, r1, r2, r3);  // call  [0xaf66c9c]
    label_0xb7aff24:
        r20 = r19 - 0x2e0;
        r8 = *(void**)(r20);
        this = r8 + 0x500;
        this = fn_0xb81cdd4(this, r1, r2, r3);  // call  [0xb81cdd4]
        this = *(void**)(r20);
        this = fn_0xb7a583c(this, r1, r2, r3);  // call  [0xb7a583c]
        r20 = r19 - 0x2f0;
        this = *(void**)(r20);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7aff68  (0xb7aff50)
        this = *(void**)(r20);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xd0);
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7aff6c;
    label_0xb7aff68:
    label_0xb7aff6c:
        r8 = r19 - 0x2e8;
        r9 = r19 - 0x78d;
        *(uint16_t*)(r8) = this;
        r8 = r19 - 0x668;
        *(uint8_t*)(r9) = rzr;
        // stp xzr, xzr, [x8, #0x8]  (0xb7aff80)
        *(void**)(r8) = rzr;
        // ldp x20, x19, [sp, #0x10]  (0xb7aff88)
        // ldp x29, x30, [sp], #0x20  (0xb7aff8c)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a60d90
// fn_va = 0x8a60d90
// return type (guess): unknown (no ret found)
void* fn_0x8a60d90(void* this, void* r2) {
        // stp x0, x0, [sp, #0x8]  (0x8a60d90)
        *(void**)(sp + 0x38) = r8;
        *(uint8_t*)(sp + 0x40) = rzr;
        goto label_0x8a60dd0;
    label_0x8a60da0:
        r8 = *(void**)(r20 + 0x10);
        rq0 = *(void**)(r20);
        *(void**)(r23 + 0x10) = r8;
        r8 = r23;
        *(void**)(r23) = rq0;
    label_0x8a60db4:
        r9 = *(uint8_t*)(r20 + 0x18);
        // subs x22, x22, #0x20  (0x8a60db8)
        r20 = r20 + 0x20;
        *(uint8_t*)(r23 + 0x18) = r9;
        r23 = r8 + 0x20;
        *(void**)(sp + 0x10) = r23;
        if (/* cond: b.eq */) goto label_0x8a60dec;
    label_0x8a60dd0:
        r8 = *(uint8_t*)(r20);
        // tbz w8, #0x0, 0x8a60da0  (0x8a60dd4)
        // ldp x2, x1, [x20, #0x8]  (0x8a60dd8)
        this = r23;
        this = fn_0x88a6328(this, r1, r2, r3);  // call  [0x88a6328]
        r8 = *(void**)(sp + 0x10);
        goto label_0x8a60db4;
    label_0x8a60dec:
        *(void**)(r19 + 0x8) = r23;
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a60e68;
        // ldp x20, x19, [sp, #0x80]  (0x8a60e00)
        // ldp x22, x21, [sp, #0x70]  (0x8a60e04)
        // ldp x24, x23, [sp, #0x60]  (0x8a60e08)
        // ldp x29, x30, [sp, #0x50]  (0x8a60e0c)
        sp = sp + 0x90;
        return this;
}

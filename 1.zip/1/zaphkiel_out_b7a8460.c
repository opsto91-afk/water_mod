// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a8460
// fn_va = 0xb7a8460
// return type (guess): unknown (no ret found)
void* fn_0xb7a8460(void* this) {
        // stp x29, x30, [sp, #0x50]  (0xb7a8464)
        *(void**)(sp + 0x60) = r19;
        fp = sp + 0x50;
        // mrs x19, tpidr_el0  (0xb7a8470)
        r1 = this;
        this = sp;
        r8 = *(void**)(r19 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = fn_0xb7a84e0(this, r1, r2, r3);  // call  [0xb7a84e0]
        this = *(void**)(sp + 0x30);
        if (this == 0) goto label_0xb7a8494;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a8494:
        this = *(void**)(sp + 0x18);
        if (this == 0) goto label_0xb7a84bc;
        r8 = *(void**)(r19 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a84dc;
        // ldp x29, x30, [sp, #0x50]  (0xb7a84ac)
        r19 = *(void**)(sp + 0x60);
        sp = sp + 0x70;
        return fn_0x135d37b0(/* tail call */);
    label_0xb7a84bc:
        r8 = *(void**)(r19 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a84dc;
        // ldp x29, x30, [sp, #0x50]  (0xb7a84cc)
        r19 = *(void**)(sp + 0x60);
        sp = sp + 0x70;
        return this;
}

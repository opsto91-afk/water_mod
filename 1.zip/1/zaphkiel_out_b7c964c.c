// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c964c
// fn_va = 0xb7c964c
// return type (guess): unknown (no ret found)
void* fn_0xb7c964c(void* this) {
        // stp xzr, xzr, [sp, #0x10]  (0xb7c964c)
        // nop   (0xb7c9650)
        // madd x23, x24, x8, x0  (0xb7c9654)
        r8 = *(void**)(sp + 0x30);
        *(void**)(r9) = rq0;
        rq0 = *(void**)(sp + 0x20);
        r24 = r9 + 0x30;
        *(void**)(r9 + 0x10) = r10;
        *(void**)(r9 + 0x18) = rq0;
        *(void**)(r9 + 0x28) = r8;
        if (/* cond: b.eq */) goto label_0xb7c96e0;
        r8 = r22;
        r9 = r25;
    label_0xb7c9684:
        r10 = *(void**)(r8 + 0x10);
        rq0 = *(void**)(r8);
        *(void**)(r9 + 0x10) = r10;
        *(void**)(r9) = rq0;
        r10 = *(void**)(r8 + 0x28);
        rq0 = *(void**)(r8 + 0x18);
        // stp xzr, xzr, [x8, #0x8]  (0xb7c969c)
        // cmp r8 == r20
        *(void**)(r9 + 0x28) = r10;
        *(void**)(r9 + 0x18) = rq0;
        r9 = r9 + 0x30;
        if (/* cond: b.ne */) goto label_0xb7c9684;
        goto label_0xb7c96c8;
    label_0xb7c96bc:
        r22 = r22 + 0x30;
        // cmp r22 == r20
        if (/* cond: b.eq */) goto label_0xb7c96dc;
    label_0xb7c96c8:
        r8 = *(uint8_t*)(r22);
        // tbz w8, #0x0, 0xb7c96bc  (0xb7c96cc)
        this = *(void**)(r22 + 0x10);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7c96bc;
    label_0xb7c96dc:
        r20 = *(void**)(r19 + 0x10a0);
    label_0xb7c96e0:
        *(void**)(r19 + 0x10a0) = r25;
        *(void**)(r19 + 0x10a8) = r24;
        *(void**)(r19 + 0x10b0) = r23;
        if (r20 == 0) goto label_0xb7c96f8;
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c96f8:
        r8 = *(uint8_t*)(sp + 0x8);
        *(void**)(r19 + 0x10a8) = r24;
        // tbz w8, #0x0, 0xb7c970c  (0xb7c9700)
        this = *(void**)(sp + 0x18);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c970c:
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c978c;
        // ldp x20, x19, [sp, #0x80]  (0xb7c971c)
        r25 = *(void**)(sp + 0x50);
        // ldp x22, x21, [sp, #0x70]  (0xb7c9724)
        // ldp x24, x23, [sp, #0x60]  (0xb7c9728)
        // ldp x29, x30, [sp, #0x40]  (0xb7c972c)
        sp = sp + 0x90;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a7d08
// fn_va = 0xb7a7d08
// return type (guess): unknown (no ret found)
void* fn_0xb7a7d08(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffc0]!  (0xb7a7d08)
        *(void**)(sp + 0x10) = r23;
        // stp x22, x21, [sp, #0x20]  (0xb7a7d10)
        // stp x20, x19, [sp, #0x30]  (0xb7a7d14)
        r8 = *(void**)(this + 0x5b0);
        r19 = this;
        // ldp x22, x23, [x8, #0xc8]  (0xb7a7d24)
        // cmp r22 == r23
        if (/* cond: b.eq */) goto label_0xb7a7d78;
        r8 = *(void**)(r19 + 0x978);
        r20 = *(void**)(r8 + 0x350);
        goto label_0xb7a7d50;
    label_0xb7a7d3c:
        this = r21;
        this = fn_0xa9d4da0(this, r1, r2, r3);  // call  [0xa9d4da0]
    label_0xb7a7d44:
        r22 = r22 + 0x10;
        // cmp r22 == r23
        if (/* cond: b.eq */) goto label_0xb7a7d78;
    label_0xb7a7d50:
        r21 = *(void**)(r22);
        if (r21 == 0) goto label_0xb7a7d44;
        this = r21;
        this = fn_0xa9d3b6c(this, r1, r2, r3);  // call  [0xa9d3b6c]
        if (this == 0) goto label_0xb7a7d3c;
        r1 = r20;
        r2 = rzr;
        this = fn_0xa9ce4c0(this, r1, r2, r3);  // call  [0xa9ce4c0]
        r21 = *(void**)(r22);
        goto label_0xb7a7d3c;
    label_0xb7a7d78:
        this = fn_0xab4c360(this, r1, r2, r3);  // call  [0xab4c360]
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0xe8);
        this = (*(void**)r8)(this);  // indirect call
        this = *(void**)(r19 + 0xc48);
        // ldp x20, x19, [sp, #0x30]  (0xb7a7d90)
        r23 = *(void**)(sp + 0x10);
        // ldp x22, x21, [sp, #0x20]  (0xb7a7d98)
        // ldp x29, x30, [sp], #0x40  (0xb7a7d9c)
        goto label_0xaa1a75c;
        // stp x29, x30, [sp, #0x30]  (0xb7a7da8)
        // stp x24, x23, [sp, #0x40]  (0xb7a7dac)
        // stp x22, x21, [sp, #0x50]  (0xb7a7db0)
        // stp x20, x19, [sp, #0x60]  (0xb7a7db4)
        fp = sp + 0x30;
        // mrs x22, tpidr_el0  (0xb7a7dbc)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = fn_0xb7af424(this, r1, r2, r3);  // call  [0xb7af424]
        r20 = this;
        this = *(void**)(this + 0x20);
        if (this == 0) goto label_0xb7a7df4;
        rq0 = *(void**)(r20 + 0xc8);
        r1 = sp;
        *(void**)(sp) = rq0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a7df4:
        // ldp x23, x24, [x20, #0xc8]  (0xb7a7df4)
        goto label_0xb7a7e00;
    label_0xb7a7dfc:
        r24 = r24 - 0x10;
    label_0xb7a7e00:
        // cmp r24 == r23
        if (/* cond: b.eq */) goto label_0xb7a7e3c;
        r21 = *(void**)(r24 - 0x8);
        if (r21 == 0) goto label_0xb7a7dfc;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7dfc;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7a7dfc;
    label_0xb7a7e3c:
        // movi v0.2d, #0x0  (0xb7a7e3c)
        *(void**)(r20 + 0xd0) = r23;
        this = r19;
        *(void**)(r20 + 0x98) = rq0;
        *(void**)(r20 + 0xa8) = rq0;
        *(void**)(r20 + 0xb8) = rq0;
        r8 = *(void**)(r19);
        *(void**)(r19 + 0x594) = rzr;
        r8 = *(void**)(r8 + 0xf0);
        this = (*(void**)r8)(this);  // indirect call
        r8 = r19 + 0x614;
        r9 = *(void**)(r19 + 0x61c);
        r10 = *(void**)(r19 + 0x978);
        r8 = *(void**)(r8);
        *(void**)(r19 + 0x5e0) = r9;
        *(void**)(r19 + 0x5d8) = r8;
        r19 = *(void**)(r19 + 0xc48);
        this = *(void**)(r10 + 0x3d8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x350);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp);
        if (r8 == 0) goto label_0xb7a7f70;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7a7f88  (0xb7a7ea0)
    label_0xb7a7ea4:
        this = *(void**)(sp + 0x10);
        this = fn_0xacbde14(this, r1, r2, r3);  // call  [0xacbde14]
        r8 = *(void**)(this + 0x220);
        r20 = *(void**)(this + 0x228);
        // stp x8, x20, [sp, #0x18]  (0xb7a7eb4)
        if (r20 == 0) goto label_0xb7a7ec8;
    label_0xb7a7ebc:
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7a7ec8:
        r1 = sp + 0x18;
        this = r19;
        this = fn_0xaa1a798(this, r1, r2, r3);  // call  [0xaa1a798]
        if (r20 == 0) goto label_0xb7a7ee0;
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7ee0:
        r19 = *(void**)(sp + 0x8);
        // stp xzr, xzr, [sp]  (0xb7a7ee4)
        if (r19 == 0) goto label_0xb7a7f48;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7f14;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7f14:
        r19 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r19 == 0) goto label_0xb7a7f48;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7f48;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7f48:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a7fe4;
        // ldp x20, x19, [sp, #0x60]  (0xb7a7f58)
        // ldp x22, x21, [sp, #0x50]  (0xb7a7f5c)
        // ldp x24, x23, [sp, #0x40]  (0xb7a7f60)
        // ldp x29, x30, [sp, #0x30]  (0xb7a7f64)
        sp = sp + 0x70;
        return this;
}

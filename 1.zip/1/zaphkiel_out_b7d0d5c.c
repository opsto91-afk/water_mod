// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d0d5c
// fn_va = 0xb7d0d5c
// return type (guess): unknown (no ret found)
void* fn_0xb7d0d5c(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7d0d5c)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = fn_0xb7bb434(this, r1, r2, r3);  // call  [0xb7bb434]
        // cmp this == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7d0dbc;
        this = *(void**)(r19 + 0x10f8);
        this = fn_0x9c773d8(this, r1, r2, r3);  // call  [0x9c773d8]
        // tbz w0, #0x0, 0xb7d0dc8  (0xb7d0d80)
        this = *(void**)(r19 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x130);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7d0dc8;
        r19 = this;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tbz w0, #0x0, 0xb7d0dc8  (0xb7d0da4)
        this = r19;
        this = fn_0xfd98d48(this, r1, r2, r3);  // call  [0xfd98d48]
        // tbz w0, #0x0, 0xb7d0dc8  (0xb7d0db4)
    label_0xb7d0dbc:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7d0dc0)
        return this;
}

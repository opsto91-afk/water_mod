// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d0a30
// fn_va = 0xb7d0a30
// return type (guess): unknown (no ret found)
void* fn_0xb7d0a30(void* this) {
        // stp x20, x19, [sp, #0x40]  (0xb7d0a30)
        fp = sp + 0x18;
        // fmov s8, s2  (0xb7d0a38)
        // fmov s9, s1  (0xb7d0a3c)
        r8 = (void*)0x140aa570;
        // fmov s10, s0  (0xb7d0a48)
        r19 = r3;
        // ldarb w8, [x8]  (0xb7d0a50)
        r20 = r2;
        r21 = r1;
        r22 = this;
        // tbz w8, #0x0, 0xb7d0aa4  (0xb7d0a60)
    label_0xb7d0a64:
        r1 = (void*)0x140aa740;
        this = r22 - 0xc50;
        r2 = r21;
        r3 = r20;
        r4 = r19;
        // fmov s0, s10  (0xb7d0a7c)
        // fmov s1, s9  (0xb7d0a80)
        // fmov s2, s8  (0xb7d0a84)
        // ldp x20, x19, [sp, #0x40]  (0xb7d0a88)
        r23 = *(void**)(sp + 0x28);
        // ldp x22, x21, [sp, #0x30]  (0xb7d0a90)
        // ldp x29, x30, [sp, #0x18]  (0xb7d0a94)
        // ldp d9, d8, [sp, #0x8]  (0xb7d0a98)
        goto label_0xb7d04d8;
    label_0xb7d0aa4:
        r23 = (void*)0x140aa570;
        this = r23;
        this = fn_0x135d36e0(this, r1, r2, r3);  // call  [0x135d36e0]
        if (this == 0) goto label_0xb7d0a64;
        this = (void*)0x140aa740;
        r1 = "minecraft:block_destruct";  // 0x2564632
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        this = (void*)0x88d2364;
        r2 = (void*)0x1368a9b0;
        r1 = (void*)0x140aa740;
        this = fn_0x135d36c0(this, r1, r2, r3);  // call  [0x135d36c0]
        this = r23;
        this = fn_0x135d36f0(this, r1, r2, r3);  // call  [0x135d36f0]
        goto label_0xb7d0a64;
        r19 = this;
        this = (void*)0x140aa570;
        this = fn_0x135d3700(this, r1, r2, r3);  // call  [0x135d3700]
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
        *(void**)(sp - 0x50) = rd10;
        // stp d9, d8, [sp, #0x8]  (0xb7d0b0c)
        // stp x29, x30, [sp, #0x18]  (0xb7d0b10)
        *(void**)(sp + 0x28) = r23;
        // stp x22, x21, [sp, #0x30]  (0xb7d0b18)
        // stp x20, x19, [sp, #0x40]  (0xb7d0b1c)
        fp = sp + 0x18;
        // fmov s8, s2  (0xb7d0b24)
        // fmov s9, s1  (0xb7d0b28)
        r8 = (void*)0x140aa578;
        // fmov s10, s0  (0xb7d0b34)
        r19 = r3;
        // ldarb w8, [x8]  (0xb7d0b3c)
        r20 = r2;
        r21 = r1;
        r22 = this;
        // tbz w8, #0x0, 0xb7d0b90  (0xb7d0b4c)
    label_0xb7d0b50:
        r1 = (void*)0x140aa768;
        this = r22;
        r2 = r21;
        r3 = r20;
        r4 = r19;
        // fmov s0, s10  (0xb7d0b68)
        // fmov s1, s9  (0xb7d0b6c)
        // fmov s2, s8  (0xb7d0b70)
        // ldp x20, x19, [sp, #0x40]  (0xb7d0b74)
        r23 = *(void**)(sp + 0x28);
        // ldp x22, x21, [sp, #0x30]  (0xb7d0b7c)
        // ldp x29, x30, [sp, #0x18]  (0xb7d0b80)
        // ldp d9, d8, [sp, #0x8]  (0xb7d0b84)
        goto label_0xb7d04d8;
    label_0xb7d0b90:
        r23 = (void*)0x140aa578;
        this = r23;
        this = fn_0x135d36e0(this, r1, r2, r3);  // call  [0x135d36e0]
        if (this == 0) goto label_0xb7d0b50;
        this = (void*)0x140aa768;
        r1 = "minecraft:block_slide";  // 0x2545951
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        this = (void*)0x88d2364;
        r2 = (void*)0x1368a9b0;
        r1 = (void*)0x140aa768;
        this = fn_0x135d36c0(this, r1, r2, r3);  // call  [0x135d36c0]
        this = r23;
        this = fn_0x135d36f0(this, r1, r2, r3);  // call  [0x135d36f0]
        goto label_0xb7d0b50;
        r19 = this;
        this = (void*)0x140aa578;
        this = fn_0x135d3700(this, r1, r2, r3);  // call  [0x135d3700]
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
        *(void**)(sp - 0x50) = rd10;
        // stp d9, d8, [sp, #0x8]  (0xb7d0bf8)
        // stp x29, x30, [sp, #0x18]  (0xb7d0bfc)
        *(void**)(sp + 0x28) = r23;
        // stp x22, x21, [sp, #0x30]  (0xb7d0c04)
        // stp x20, x19, [sp, #0x40]  (0xb7d0c08)
        fp = sp + 0x18;
        // fmov s8, s2  (0xb7d0c10)
        // fmov s9, s1  (0xb7d0c14)
        r8 = (void*)0x140aa578;
        // fmov s10, s0  (0xb7d0c20)
        r19 = r3;
        // ldarb w8, [x8]  (0xb7d0c28)
        r20 = r2;
        r21 = r1;
        r22 = this;
        // tbz w8, #0x0, 0xb7d0c7c  (0xb7d0c38)
    label_0xb7d0c3c:
        r1 = (void*)0x140aa768;
        this = r22 - 0xc50;
        r2 = r21;
        r3 = r20;
        r4 = r19;
        // fmov s0, s10  (0xb7d0c54)
        // fmov s1, s9  (0xb7d0c58)
        // fmov s2, s8  (0xb7d0c5c)
        // ldp x20, x19, [sp, #0x40]  (0xb7d0c60)
        r23 = *(void**)(sp + 0x28);
        // ldp x22, x21, [sp, #0x30]  (0xb7d0c68)
        // ldp x29, x30, [sp, #0x18]  (0xb7d0c6c)
        // ldp d9, d8, [sp, #0x8]  (0xb7d0c70)
        goto label_0xb7d04d8;
    label_0xb7d0c7c:
        r23 = (void*)0x140aa578;
        this = r23;
        this = fn_0x135d36e0(this, r1, r2, r3);  // call  [0x135d36e0]
        if (this == 0) goto label_0xb7d0c3c;
        this = (void*)0x140aa768;
        r1 = "minecraft:block_slide";  // 0x2545951
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        this = (void*)0x88d2364;
        r2 = (void*)0x1368a9b0;
        r1 = (void*)0x140aa768;
        this = fn_0x135d36c0(this, r1, r2, r3);  // call  [0x135d36c0]
        this = r23;
        this = fn_0x135d36f0(this, r1, r2, r3);  // call  [0x135d36f0]
        goto label_0xb7d0c3c;
        r19 = this;
        this = (void*)0x140aa578;
        this = fn_0x135d3700(this, r1, r2, r3);  // call  [0x135d3700]
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7d0ce0)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = fn_0xb7bb300(this, r1, r2, r3);  // call  [0xb7bb300]
        // cmp this == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7d0d40;
        this = *(void**)(r19 + 0x10f8);
        this = fn_0x9c773d8(this, r1, r2, r3);  // call  [0x9c773d8]
        // tbz w0, #0x0, 0xb7d0d4c  (0xb7d0d04)
        this = *(void**)(r19 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x130);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7d0d4c;
        r19 = this;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tbz w0, #0x0, 0xb7d0d4c  (0xb7d0d28)
        this = r19;
        this = fn_0xfd98d48(this, r1, r2, r3);  // call  [0xfd98d48]
        // tbz w0, #0x0, 0xb7d0d4c  (0xb7d0d38)
    label_0xb7d0d40:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7d0d44)
        return this;
}

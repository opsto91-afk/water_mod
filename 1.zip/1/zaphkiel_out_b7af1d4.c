// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7af1d4
// fn_va = 0xb7af1d4
// return type (guess): unknown (no ret found)
void* fn_0xb7af1d4(void* this) {
        // stp x29, x30, [sp, #0x40]  (0xb7af1d8)
        // stp x24, x23, [sp, #0x50]  (0xb7af1dc)
        // stp x22, x21, [sp, #0x60]  (0xb7af1e0)
        // stp x20, x19, [sp, #0x70]  (0xb7af1e4)
        fp = sp + 0x40;
        // mrs x22, tpidr_el0  (0xb7af1ec)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(r9 + 0x9f8);
        r21 = sp;
        *(void**)(fp - 0x8) = r8;
        r8 = (void*)0x13f99010;
        r9 = (void*)0x88a38e8;
        r20 = *(void**)(this + 0x978);
        *(void**)(sp + 0x20) = r21;
        // stp x8, x9, [sp]  (0xb7af21c)
        this = *(void**)(r20 + 0x3a8);
        r1 = sp;
        this = fn_0x134c00bc(this, r1, r2, r3);  // call  [0x134c00bc]
        this = *(void**)(sp + 0x20);
        // cmp this == r21
        if (/* cond: b.eq */) goto label_0xb7af244;
        if (this == 0) goto label_0xb7af258;
        goto label_0xb7af24c;
    label_0xb7af244:
        this = sp;
    label_0xb7af24c:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7af258:
        r8 = *(void**)(r20 + 0x368);
        if (r8 == 0) goto label_0xb7af3a8;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7af3c0  (0xb7af264)
    label_0xb7af268:
        this = *(void**)(r20 + 0x378);
        this = fn_0xb0c61d0(this, r1, r2, r3);  // call  [0xb0c61d0]
        this = r20;
        this = fn_0xb79b088(this, r1, r2, r3);  // call  [0xb79b088]
        this = fn_0xaa5ce38(this, r1, r2, r3);  // call  [0xaa5ce38]
        this = *(void**)(r20 + 0x50);
        if (this == 0) goto label_0xb7af288;
        this = fn_0xa9bc89c(this, r1, r2, r3);  // call  [0xa9bc89c]
    label_0xb7af288:
        this = *(void**)(r20 + 0x68);
        if (this == 0) goto label_0xb7af294;
        this = fn_0xa9d9748(this, r1, r2, r3);  // call  [0xa9d9748]
    label_0xb7af294:
        this = *(void**)(r20 + 0x78);
        if (this == 0) goto label_0xb7af2a0;
        this = fn_0xb77301c(this, r1, r2, r3);  // call  [0xb77301c]
    label_0xb7af2a0:
        this = r19;
        this = fn_0xb7af424(this, r1, r2, r3);  // call  [0xb7af424]
        r20 = this;
        this = *(void**)(this + 0x20);
        if (this == 0) goto label_0xb7af2cc;
        rq0 = *(void**)(r20 + 0xc8);
        r1 = sp;
        *(void**)(sp) = rq0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7af2cc:
        // ldp x23, x24, [x20, #0xc8]  (0xb7af2cc)
        goto label_0xb7af2d8;
    label_0xb7af2d4:
        r24 = r24 - 0x10;
    label_0xb7af2d8:
        // cmp r24 == r23
        if (/* cond: b.eq */) goto label_0xb7af314;
        r21 = *(void**)(r24 - 0x8);
        if (r21 == 0) goto label_0xb7af2d4;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7af2d4;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7af2d4;
    label_0xb7af314:
        // movi v0.2d, #0x0  (0xb7af314)
        *(void**)(r20 + 0xd0) = r23;
        *(void**)(r20 + 0x98) = rq0;
        *(void**)(r20 + 0xa8) = rq0;
        *(void**)(r20 + 0xb8) = rq0;
        r10 = *(void**)(r19 + 0x978);
        r8 = *(void**)(r19 + 0x1d8);
        r9 = *(void**)(r19 + 0x1f0);
        this = r10 + 0x500;
        *(void**)(r19 + 0x1e0) = r8;
        *(void**)(r19 + 0x1f8) = r9;
        this = fn_0xb81cd34(this, r1, r2, r3);  // call  [0xb81cd34]
        // movi v0.2d, #0x0  (0xb7af344)
        r20 = *(void**)(r19 + 0x960);
        r8 = r19 + 0x958;
        *(void**)(r8) = rq0;
        if (r20 == 0) goto label_0xb7af380;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7af380;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7af380:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7af420;
        // ldp x20, x19, [sp, #0x70]  (0xb7af390)
        // ldp x22, x21, [sp, #0x60]  (0xb7af394)
        // ldp x24, x23, [sp, #0x50]  (0xb7af398)
        // ldp x29, x30, [sp, #0x40]  (0xb7af39c)
        sp = sp + 0x80;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c71f4
// fn_va = 0xb7c71f4
// return type (guess): unknown (no ret found)
void* fn_0xb7c71f4(void* this) {
        // stp x20, x19, [sp, #0x30]  (0xb7c71f4)
        fp = sp + 0x20;
        // mrs x20, tpidr_el0  (0xb7c71fc)
        r19 = this;
        r2 = r1;
        r8 = *(void**)(r20 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r8 = *(void**)(this + 0xe80);
        this = *(void**)(this + 0xe78);
        r1 = r8;
        this = fn_0xb7fb6b8(this, r1, r2, r3);  // call  [0xb7fb6b8]
        if (this == 0) goto label_0xb7c7240;
        r2 = this;
        this = sp;
        r1 = r19 + 0xe78;
        this = fn_0xb7fb064(this, r1, r2, r3);  // call  [0xb7fb064]
        this = *(void**)(sp);
        if (this == 0) goto label_0xb7c7240;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c7240:
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c7260;
        // ldp x20, x19, [sp, #0x30]  (0xb7c7250)
        // ldp x29, x30, [sp, #0x20]  (0xb7c7254)
        sp = sp + 0x40;
        return this;
}

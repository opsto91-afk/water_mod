// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9c14750
// fn_va = 0x9c14750
// return type (guess): unknown (no ret found)
void* fn_0x9c14750(void* this, void* r1) {
        // stp x29, x30, [sp, #0x20]  (0x9c14754)
        // stp x20, x19, [sp, #0x30]  (0x9c14758)
        fp = sp + 0x20;
        // mrs x20, tpidr_el0  (0x9c14760)
        r19 = this;
        this = sp + 0x8;
        r8 = *(void**)(r20 + 0x28);
        *(void**)(fp - 0x8) = r8;
        *(void**)(sp + 0x10) = r1;
        r1 = r2;
        this = fn_0xe82f820(this, r1, r2, r3);  // call  [0xe82f820]
        r8 = *(void**)(r19);
        r1 = sp + 0x10;
        r2 = sp + 0x8;
        this = r19;
        r8 = *(void**)(r8 + 0x38);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9c147b8;
        // ldp x20, x19, [sp, #0x30]  (0x9c147a8)
        // ldp x29, x30, [sp, #0x20]  (0x9c147ac)
        sp = sp + 0x40;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3dfd8
// fn_va = 0x8a3dfd8
// return type (guess): unknown (no ret found)
void* fn_0x8a3dfd8(void* this) {
        // stp x29, x30, [sp, #0x40]  (0x8a3dfdc)
        // stp x20, x19, [sp, #0x50]  (0x8a3dfe0)
        fp = sp + 0x40;
        // mrs x20, tpidr_el0  (0x8a3dfe8)
        r19 = r8;
        r8 = sp;
        r9 = *(void**)(r20 + 0x28);
        *(void**)(fp - 0x8) = r9;
        this = *(void**)(this + 0x8);
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0x158);
        this = (*(void**)r8)(this);  // indirect call
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = *(void**)(sp + 0x8);
        if (this == 0) goto label_0x8a3e024;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3e024:
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3e050  (0x8a3e02c)
        this = sp;
        r1 = sp + 0x18;
        this = fn_0xe82f820(this, r1, r2, r3);  // call  [0xe82f820]
        r1 = sp;
        this = r19;
        this = fn_0xe82f8e8(this, r1, r2, r3);  // call  [0xe82f8e8]
        goto label_0x8a3e058;
    label_0x8a3e050:
        r8 = rzr;
        *(uint8_t*)(r19) = rzr;
    label_0x8a3e058:
        *(uint8_t*)(r19 + 0x8) = r8;
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3e0a8;
        // ldp x20, x19, [sp, #0x50]  (0x8a3e06c)
        // ldp x29, x30, [sp, #0x40]  (0x8a3e070)
        sp = sp + 0x60;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a57dc0
// fn_va = 0x9a57dc0
// return type (guess): unknown (no ret found)
void* fn_0x9a57dc0(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a57dc0)
        // stp x20, x19, [sp, #0x10]  (0x9a57dc4)
        r8 = (void*)0x13882fe8;
        r20 = *(void**)(this + 0x58);
        r19 = this;
        *(void**)(this) = r8;
        r8 = (void*)0x138830a8;
        *(void**)(this + 0x10) = r8;
        if (r20 == 0) goto label_0x9a57e14;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a57e14;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a57e14:
        r20 = *(void**)(r19 + 0x48);
        if (r20 == 0) goto label_0x9a57e2c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0x9a57e3c;
    label_0x9a57e2c:
        this = r19 + 0x20;
        // ldp x20, x19, [sp, #0x10]  (0x9a57e30)
        // ldp x29, x30, [sp], #0x20  (0x9a57e34)
        return fn_0x117b5dc4(/* tail call */);
    label_0x9a57e3c:
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
        this = r19 + 0x20;
        // ldp x20, x19, [sp, #0x10]  (0x9a57e58)
        // ldp x29, x30, [sp], #0x20  (0x9a57e5c)
        return fn_0x117b5dc4(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a57e64)
        // stp x20, x19, [sp, #0x10]  (0x9a57e68)
        r8 = (void*)0x13882fe8;
        r20 = *(void**)(this + 0x48);
        r19 = this;
        *(void**)(this - 0x10) = r8;
        r8 = (void*)0x138830a8;
        *(void**)(this) = r8;
        if (r20 == 0) goto label_0x9a57eb8;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a57eb8;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a57eb8:
        r20 = *(void**)(r19 + 0x38);
        if (r20 == 0) goto label_0x9a57ed0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0x9a57ee0;
    label_0x9a57ed0:
        this = r19 + 0x10;
        // ldp x20, x19, [sp, #0x10]  (0x9a57ed4)
        // ldp x29, x30, [sp], #0x20  (0x9a57ed8)
        return fn_0x117b5dc4(/* tail call */);
    label_0x9a57ee0:
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
        this = r19 + 0x10;
        // ldp x20, x19, [sp, #0x10]  (0x9a57efc)
        // ldp x29, x30, [sp], #0x20  (0x9a57f00)
        return fn_0x117b5dc4(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a57f08)
        // stp x20, x19, [sp, #0x10]  (0x9a57f0c)
        r8 = (void*)0x13882fe8;
        r20 = *(void**)(this + 0x58);
        r19 = this;
        *(void**)(this) = r8;
        r8 = (void*)0x138830a8;
        *(void**)(this + 0x10) = r8;
        if (r20 == 0) goto label_0x9a57f5c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a57f5c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a57f5c:
        r20 = *(void**)(r19 + 0x48);
        if (r20 == 0) goto label_0x9a57f74;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0x9a57f8c;
    label_0x9a57f74:
        this = r19 + 0x20;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0x9a57f80)
        // ldp x29, x30, [sp], #0x20  (0x9a57f84)
        return fn_0xe803424(/* tail call */);
    label_0x9a57f8c:
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
        this = r19 + 0x20;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0x9a57fb0)
        // ldp x29, x30, [sp], #0x20  (0x9a57fb4)
        return fn_0xe803424(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0x9a57fbc)
        *(void**)(sp + 0x10) = r21;
        // stp x20, x19, [sp, #0x20]  (0x9a57fc4)
        r8 = (void*)0x13882fe8;
        r19 = this;
        r21 = *(void**)(this + 0x48);
        r20 = this;
        *(void**)(r19 - 0x10) = r8;
        r8 = (void*)0x138830a8;
        *(void**)(this) = r8;
        if (r21 == 0) goto label_0x9a58018;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a58018;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a58018:
        r21 = *(void**)(r20 + 0x38);
        if (r21 == 0) goto label_0x9a58048;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a58048;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a58048:
        this = r20 + 0x10;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        this = r19;
        // ldp x20, x19, [sp, #0x20]  (0x9a58054)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0x9a5805c)
        return fn_0xe803424(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0x9a58064)
        *(void**)(sp + 0x10) = r21;
        // stp x20, x19, [sp, #0x20]  (0x9a5806c)
        r20 = r8;
        this = fn_0xe803540(this, r1, r2, r3);  // call  [0xe803540]
        r19 = this;
        r8 = (void*)0x13883af0;
        r21 = this + 0x18;
        // stp xzr, xzr, [x0, #0x8]  (0x9a58090)
        *(void**)(this) = r8;
        this = r21;
        this = fn_0x9a57c44(this, r1, r2, r3);  // call  [0x9a57c44]
        // stp x21, x19, [x20]  (0x9a580a0)
        // ldp x20, x19, [sp, #0x20]  (0x9a580a4)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0x9a580ac)
        return this;
}

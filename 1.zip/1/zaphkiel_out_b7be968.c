// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7be968
// fn_va = 0xb7be968
// return type (guess): unknown (no ret found)
void* fn_0xb7be968(void* this) {
        // ldp x22, x21, [sp, #0x50]  (0xb7be968)
        // ldp x24, x23, [sp, #0x40]  (0xb7be96c)
        // ldp x26, x25, [sp, #0x30]  (0xb7be970)
        // ldp x29, x30, [sp, #0x20]  (0xb7be974)
        sp = sp + 0x70;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bf1ac
// fn_va = 0xb7bf1ac
// return type (guess): unknown (no ret found)
void* fn_0xb7bf1ac(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bf1ac)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = fn_0xb7af1d4(this, r1, r2, r3);  // call  [0xb7af1d4]
        *(uint8_t*)(r19 + 0xce0) = rzr;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bf1c8)
        return this;
}

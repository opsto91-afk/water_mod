// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3df0c
// fn_va = 0x8a3df0c
// return type (guess): unknown (no ret found)
void* fn_0x8a3df0c(void* this) {
        // stp x20, x19, [sp, #0x40]  (0x8a3df0c)
        fp = sp + 0x20;
        // mrs x21, tpidr_el0  (0x8a3df14)
        r19 = r8;
        r9 = *(void**)(r21 + 0x28);
        *(void**)(fp - 0x8) = r9;
        this = *(void**)(this + 0x8);
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        r8 = sp + 0x8;
        this = fn_0xe82f83c(this, r1, r2, r3);  // call  [0xe82f83c]
        r22 = *(void**)(sp + 0x8);
        if (r22 == 0) goto label_0x8a3df60;
        r20 = *(void**)(sp + 0x10);
        // stp x22, x20, [x19]  (0x8a3df48)
        if (r20 == 0) goto label_0x8a3df80;
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        goto label_0x8a3df68;
    label_0x8a3df60:
        r20 = *(void**)(sp + 0x10);
        if (r20 == 0) goto label_0x8a3df7c;
    label_0x8a3df68:
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0x8a3dfa4;
        if (r22 != 0) goto label_0x8a3df80;
    label_0x8a3df7c:
        // stp xzr, xzr, [x19]  (0x8a3df7c)
    label_0x8a3df80:
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3dfc4;
        // ldp x20, x19, [sp, #0x40]  (0x8a3df90)
        // ldp x22, x21, [sp, #0x30]  (0x8a3df94)
        // ldp x29, x30, [sp, #0x20]  (0x8a3df98)
        sp = sp + 0x50;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d6c24
// fn_va = 0xb7d6c24
// return type (guess): unknown (no ret found)
void* fn_0xb7d6c24(void* this) {
        *(void**)(r8 + 0xc8) = rs0;
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x38);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d6c60;
        sp = sp + 0x190;
        // ldp x20, x19, [sp, #0x70]  (0xb7d6c3c)
        // ldp x22, x21, [sp, #0x60]  (0xb7d6c40)
        // ldp x24, x23, [sp, #0x50]  (0xb7d6c44)
        // ldp x28, x25, [sp, #0x40]  (0xb7d6c48)
        // ldp x29, x30, [sp, #0x30]  (0xb7d6c4c)
        // ldp d9, d8, [sp, #0x20]  (0xb7d6c50)
        // ldp d11, d10, [sp, #0x10]  (0xb7d6c54)
        return this;
}

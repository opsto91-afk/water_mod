// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a833c
// fn_va = 0xb7a833c
// return type (guess): unknown (no ret found)
void* fn_0xb7a833c(void* this) {
        *(void**)(sp + 0x30) = rd8;
        // stp x29, x30, [sp, #0x38]  (0xb7a8344)
        *(void**)(sp + 0x48) = r21;
        // stp x20, x19, [sp, #0x50]  (0xb7a834c)
        fp = sp + 0x38;
        // mrs x20, tpidr_el0  (0xb7a8354)
        r19 = this;
        r8 = *(void**)(r20 + 0x28);
        *(void**)(fp - 0x10) = r8;
        this = *(void**)(this + 0x968);
        if (this == 0) goto label_0xb7a8384;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        // cmp this == <complex operand>
        // cset w8, eq  (0xb7a837c)
        goto label_0xb7a8388;
    label_0xb7a8384:
        r8 = rzr;
    label_0xb7a8388:
        r10 = r19 + 0x414;
        r9 = *(uint8_t*)(r19 + 0x949);
        *(uint8_t*)(sp + 0x8) = r8;
        r8 = *(void**)(r10);
        r21 = sp + 0x8;
        r1 = r19 + 0x614;
        this = r21 + 0xc;
        *(uint8_t*)(sp + 0x9) = r9;
        *(void**)(sp + 0xc) = r8;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        // fmov s0, #1  (0xb7a83b0)
        this = *(void**)(r19 + 0x958);
        r8 = *(uint8_t*)(sp + 0x8);
        rs8 = *(void**)(sp + 0xc);
        *(void**)(sp + 0x20) = this;
        // tbnz w8, #0x0, 0xb7a8410  (0xb7a83c4)
        r8 = *(uint8_t*)(sp + 0x9);
        if (r8 == 0) goto label_0xb7a83f8;
        r8 = *(void**)(this);
        // fmov d0, #0.5  (0xb7a83d4)
        r1 = r21 + 0xc;
        r8 = *(void**)(r8 + 0xc8);
        // fcvt s0, d0  (0xb7a83e0)
        this = (*(void**)r8)(this);  // indirect call
        // fmov s1, #0.5  (0xb7a83e8)
        this = *(void**)(r19 + 0x958);
        // fmul s0, s0, s1  (0xb7a83f0)
        // fadd s0, s0, s1  (0xb7a83f4)
    label_0xb7a83f8:
        // fsub s0, s0, s8  (0xb7a83fc)
        // movk w8, #0x3dcc, lsl #0x10  (0xb7a8400)
        // fmov s1, w8  (0xb7a8404)
        // fmul s0, s0, s1  (0xb7a8408)
        // fadd s0, s8, s0  (0xb7a840c)
    label_0xb7a8410:
        r8 = *(void**)(r19 + 0x930);
        *(void**)(r19 + 0x414) = rs0;
        *(void**)(r19 + 0x418) = rs8;
        if (r8 == 0) goto label_0xb7a8434;
        if (this == 0) goto label_0xb7a8434;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x50);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a8434:
        r8 = *(void**)(r20 + 0x28);
        r9 = *(void**)(fp - 0x10);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a845c;
        // ldp x20, x19, [sp, #0x50]  (0xb7a8444)
        r21 = *(void**)(sp + 0x48);
        // ldp x29, x30, [sp, #0x38]  (0xb7a844c)
        rd8 = *(void**)(sp + 0x30);
        sp = sp + 0x60;
        return this;
}

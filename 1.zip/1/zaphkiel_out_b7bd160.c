// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bd160
// fn_va = 0xb7bd160
// return type (guess): unknown (no ret found)
void* fn_0xb7bd160(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bd160)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc50;
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bd180)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bd188)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc58;
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bd1a8)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bd1b0)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc60;
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bd1d0)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0x30]  (0xb7bd1dc)
        *(void**)(sp + 0x40) = r19;
        fp = sp + 0x30;
        // mrs x19, tpidr_el0  (0xb7bd1e8)
        r1 = this;
        this = sp + 0x8;
        r8 = *(void**)(r19 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x8;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7bd2cc  (0xb7bd208)
        r9 = *(void**)(sp + 0x10);
        // movk w10, #0xb84, lsl #0x10  (0xb7bd214)
        r8 = *(void**)(r9 + 0x40);
        r11 = *(void**)(r9 + 0x38);
        // lsr w8, w8, #0x3  (0xb7bd224)
        // and x12, x8, x10  (0xb7bd22c)
        r8 = *(void**)(sp + 0x18);
        r12 = *(void**)(r9 + 0x50);
    label_0xb7bd23c:
        r11 = *(void**)(r11);
        // cmp r11 == - 0x1
        if (/* cond: b.eq */) goto label_0xb7bd2cc;
        r13 = *(void**)(r11 + 0x8);
        // cmp r13 == r10
        if (/* cond: b.ne */) goto label_0xb7bd23c;
        r9 = *(void**)(r9 + 0x58);
        // cmp r11 == r9
        if (/* cond: b.eq */) goto label_0xb7bd2cc;
        r9 = *(void**)(r11 + 0x10);
        if (r9 == 0) goto label_0xb7bd2cc;
        // ldp x10, x12, [x9, #0x8]  (0xb7bd26c)
        // ubfx x11, x8, #0xb, #0x7  (0xb7bd270)
        // cmp r11 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7bd2cc;
        if (r10 == 0) goto label_0xb7bd2cc;
        // and x11, x8, #0x3ffff  (0xb7bd288)
        // and w8, w8, #0xfffc0000  (0xb7bd28c)
        // and x11, x11, #0x7ff  (0xb7bd290)
        // eor w8, w10, w8  (0xb7bd29c)
        // cmp r8 == r11
        if (/* cond: b.hi */) goto label_0xb7bd2cc;
        // and x8, x10, #0x3ff80  (0xb7bd2a8)
        r9 = *(void**)(r9 + 0x50);
        // and x10, x10, #0x7f  (0xb7bd2b0)
        // lsr x8, x8, #0x4  (0xb7bd2b4)
        // nop   (0xb7bd2c0)
        // umaddl x0, w10, w11, x8  (0xb7bd2c4)
        goto label_0xb7bd2d0;
    label_0xb7bd2cc:
        this = rzr;
    label_0xb7bd2d0:
        r8 = *(void**)(r19 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bd2f0;
        // ldp x29, x30, [sp, #0x30]  (0xb7bd2e0)
        r19 = *(void**)(sp + 0x40);
        sp = sp + 0x50;
        return this;
}

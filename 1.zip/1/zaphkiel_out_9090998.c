// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9090998
// fn_va = 0x9090998
// return type (guess): unknown (no ret found)
void* fn_0x9090998(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9090998)
        *(void**)(sp + 0x10) = r19;
        r8 = (void*)0x13e2e270;
        r11 = *(uint8_t*)(this + 0xc8);
        r19 = this;
        r9 = (void*)0x13e2e4b8;
        *(void**)(this) = r8;
        r10 = (void*)0x13e2e5a0;
        r8 = (void*)0x13e2e630;
        // stp x9, x10, [x0, #0x38]  (0x90909c4)
        *(void**)(this + 0x48) = r8;
        // tbz w11, #0x0, 0x90909d8  (0x90909cc)
        this = *(void**)(r19 + 0xd8);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x90909d8:
        this = r19 + 0x90;
        this = fn_0xcefc6ac(this, r1, r2, r3);  // call  [0xcefc6ac]
        this = r19;
        this = fn_0x10f6fc70(this, r1, r2, r3);  // call  [0x10f6fc70]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x90909f0)
        return fn_0xe803424(/* tail call */);
        return this;
}

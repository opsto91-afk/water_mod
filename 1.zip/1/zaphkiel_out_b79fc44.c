// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb79fc44
// fn_va = 0xb79fc44
// return type (guess): unknown (no ret found)
void* fn_0xb79fc44(void* this) {
        // stp x20, x19, [sp, #0x10]  (0xb79fc44)
        r20 = *(void**)(this + 0x8);
        r19 = this;
        // stp xzr, xzr, [x0]  (0xb79fc54)
        if (r20 == 0) goto label_0xb79fc84;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb79fc94;
        r20 = *(void**)(r19 + 0x8);
        *(void**)(r19 + 0x10) = rzr;
        if (r20 != 0) goto label_0xb79fcb8;
    label_0xb79fc78:
        // ldp x20, x19, [sp, #0x10]  (0xb79fc78)
        // ldp x29, x30, [sp], #0x20  (0xb79fc7c)
        return this;
}

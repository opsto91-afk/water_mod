// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d302c
// fn_va = 0xb7d302c
// return type (guess): unknown (no ret found)
void* fn_0xb7d302c(void* this) {
        r9 = *(void**)(fp - 0x48);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d3068;
        sp = sp + 0x290;
        // ldp x20, x19, [sp, #0x90]  (0xb7d303c)
        // ldp x22, x21, [sp, #0x80]  (0xb7d3040)
        // ldp x24, x23, [sp, #0x70]  (0xb7d3044)
        // ldp x26, x25, [sp, #0x60]  (0xb7d3048)
        // ldp x28, x27, [sp, #0x50]  (0xb7d304c)
        // ldp x29, x30, [sp, #0x40]  (0xb7d3050)
        // ldp d9, d8, [sp, #0x30]  (0xb7d3054)
        // ldp d11, d10, [sp, #0x20]  (0xb7d3058)
        // ldp d13, d12, [sp, #0x10]  (0xb7d305c)
        // ldp d15, d14, [sp], #0xa0  (0xb7d3060)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a584b4
// fn_va = 0x9a584b4
// return type (guess): unknown (no ret found)
void* fn_0x9a584b4(void* this, void* r2) {
        *(void**)(sp + 0x30) = rd10;
        // stp d9, d8, [sp, #0x40]  (0x9a584bc)
        // stp x29, x30, [sp, #0x50]  (0x9a584c0)
        // stp x26, x25, [sp, #0x60]  (0x9a584c4)
        // stp x24, x23, [sp, #0x70]  (0x9a584c8)
        // stp x22, x21, [sp, #0x80]  (0x9a584cc)
        // stp x20, x19, [sp, #0x90]  (0x9a584d0)
        fp = sp + 0x50;
        // mrs x26, tpidr_el0  (0x9a584d8)
        r8 = *(void**)(r26 + 0x28);
        *(void**)(sp + 0x28) = r8;
        r8 = *(void**)(this + 0x18);
        if (r8 == 0) goto label_0x9a5896c;
        r8 = *(void**)(r2);
        r19 = this;
        this = r2;
        r24 = r2;
        r20 = r1;
        r8 = *(void**)(r8 + 0x568);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x300);
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0x9a5896c  (0x9a58514)
        r8 = *(void**)(r24);
        this = r24;
        r9 = *(void**)(r8 + 0xc58);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        r1 = (void*)0x141e8880;
        r8 = sp + 0x20;
        this = sp;
        this = fn_0x103a0b5c(this, r1, r2, r3);  // call  [0x103a0b5c]
        this = sp;
        this = fn_0x1039fe14(this, r1, r2, r3);  // call  [0x1039fe14]
        r22 = *(void**)(sp + 0x20);
        if (r22 == 0) goto label_0x9a5896c;
        r8 = *(void**)(r22);
        if (r8 == 0) goto label_0x9a5893c;
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0xf8);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x270);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r21 = this;
        r8 = *(void**)(r8 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0x9a585bc  (0x9a58584)
        this = r21;
        this = fn_0x10773020(this, r1, r2, r3);  // call  [0x10773020]
        r21 = this;
        this = *(void**)(r22);
        if (this == 0) goto label_0x9a589a0;
        this = fn_0x10797f54(this, r1, r2, r3);  // call  [0x10797f54]
        // and w8, w21, #0xffff  (0x9a585a0)
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0x9a585c4;
        r8 = *(uint8_t*)(r19 + 0x60);
        if (r8 != 0) goto label_0x9a585c4;
    label_0x9a585b4:
        *(void**)(r19 + 0x18) = rzr;
        goto label_0x9a58934;
    label_0x9a585bc:
        r8 = *(uint8_t*)(r19 + 0x60);
        // tbz w8, #0x0, 0x9a585b4  (0x9a585c0)
    label_0x9a585c4:
        r8 = *(void**)(r24);
        r9 = *(void**)(r8 + 0x6c0);
        r8 = sp;
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp);
        // movk w25, #0xdead, lsl #0x10  (0x9a585e0)
        if (r8 == 0) goto label_0x9a5860c;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0x9a5861c  (0x9a585ec)
    label_0x9a585f0:
        this = *(void**)(sp + 0x10);
        this = fn_0x99b8f5c(this, r1, r2, r3);  // call  [0x99b8f5c]
        r22 = *(void**)(sp + 0x8);
        r21 = this;
        // stp xzr, xzr, [sp]  (0x9a58600)
        if (r22 != 0) goto label_0x9a5863c;
        goto label_0x9a58698;
    label_0x9a5860c:
        r9 = rzr;
        *(void**)(r9) = r25;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0x9a585f0  (0x9a58618)
    label_0x9a5861c:
        r8 = rzr;
        *(void**)(r8) = r25;
        this = *(void**)(sp + 0x10);
        this = fn_0x99b8f5c(this, r1, r2, r3);  // call  [0x99b8f5c]
        r22 = *(void**)(sp + 0x8);
        r21 = this;
        // stp xzr, xzr, [sp]  (0x9a58634)
        if (r22 == 0) goto label_0x9a58698;
    label_0x9a5863c:
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a58664;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a58664:
        r22 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r22 == 0) goto label_0x9a58698;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a58698;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a58698:
        // ldp s0, s1, [x21, #0x10]  (0x9a58698)
        r8 = *(void**)(sp + 0x20);
        // fcvtzs w22, s0  (0x9a586a0)
        // fcvtzs w21, s1  (0x9a586a4)
        if (r8 == 0) goto label_0x9a589a0;
        this = *(void**)(r8);
        if (this == 0) goto label_0x9a589a0;
        this = fn_0x1079bb70(this, r1, r2, r3);  // call  [0x1079bb70]
        if (this == 0) goto label_0x9a58934;
        r8 = *(void**)(r24);
        r23 = this;
        r9 = *(void**)(r8 + 0x528);
        r8 = sp;
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp);
        if (r8 == 0) goto label_0x9a58700;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0x9a58710  (0x9a586e0)
    label_0x9a586e4:
        this = *(void**)(sp + 0x10);
        this = fn_0xfef899c(this, r1, r2, r3);  // call  [0xfef899c]
        r25 = *(void**)(sp + 0x8);
        r24 = this;
        // stp xzr, xzr, [sp]  (0x9a586f4)
        if (r25 != 0) goto label_0x9a58730;
        goto label_0x9a5878c;
    label_0x9a58700:
        r9 = rzr;
        *(void**)(r9) = r25;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0x9a586e4  (0x9a5870c)
    label_0x9a58710:
        r8 = rzr;
        *(void**)(r8) = r25;
        this = *(void**)(sp + 0x10);
        this = fn_0xfef899c(this, r1, r2, r3);  // call  [0xfef899c]
        r25 = *(void**)(sp + 0x8);
        r24 = this;
        // stp xzr, xzr, [sp]  (0x9a58728)
        if (r25 == 0) goto label_0x9a5878c;
    label_0x9a58730:
        r1 = r25 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a58758;
        r8 = *(void**)(r25);
        this = r25;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r25;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a58758:
        r25 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r25 == 0) goto label_0x9a5878c;
        r1 = r25 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a5878c;
        r8 = *(void**)(r25);
        this = r25;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r25;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a5878c:
        this = r24;
        this = fn_0xff30a90(this, r1, r2, r3);  // call  [0xff30a90]
        rs1 = *(void**)(r19 + 0x1c);
        // fcmp s1, #0  (0x9a58798)
        if (/* cond: b.ne */) goto label_0x9a587a8;
        // fmov s1, s0  (0x9a587a0)
        *(void**)(r19 + 0x1c) = rs0;
    label_0x9a587a8:
        // fsub s9, s0, s1  (0x9a587a8)
        r8 = *(void**)(r19 + 0x18);
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0x9a588b4;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0x9a58820;
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0x9a58934;
        r8 = *(void**)(r23);
        r8 = *(void**)(r8 + 0x10);
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fcmpe s9, s0  (0x9a587d8)
        // fmov s8, #1  (0x9a587dc)
        if (/* cond: b.pl */) goto label_0x9a587e8;
        // fdiv s8, s9, s0  (0x9a587e4)
    label_0x9a587e8:
        this = r20;
        this = fn_0xb725194(this, r1, r2, r3);  // call  [0xb725194]
        r8 = *(void**)(r23);
        r20 = this;
        r8 = *(void**)(r8 + 0x18);
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fmul s0, s0, s8  (0x9a58804)
        this = r19;
        r1 = r20;
        r2 = r22;
        r3 = r21;
        this = fn_0x9a58a04(this, r1, r2, r3);  // call  [0x9a58a04]
        goto label_0x9a58934;
    label_0x9a58820:
        r8 = *(void**)(r23);
        r8 = *(void**)(r8 + 0x28);
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fmov s8, s0  (0x9a58830)
        // movi d10, #0x0  (0x9a58834)
        // fcmpe s9, s0  (0x9a58838)
        if (/* cond: b.pl */) goto label_0x9a5884c;
        // fdiv s0, s9, s8  (0x9a58840)
        // fmov s1, #1  (0x9a58844)
        // fsub s10, s1, s0  (0x9a58848)
    label_0x9a5884c:
        this = r20;
        this = fn_0xb725194(this, r1, r2, r3);  // call  [0xb725194]
        r1 = this;
        // fmov s0, #1  (0x9a58858)
        this = r19;
        r2 = r22;
        r3 = r21;
        this = fn_0x9a58bb4(this, r1, r2, r3);  // call  [0x9a58bb4]
        this = r20;
        this = fn_0xb725194(this, r1, r2, r3);  // call  [0xb725194]
        r8 = *(void**)(r23);
        r20 = this;
        r8 = *(void**)(r8 + 0x20);
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fmul s0, s0, s10  (0x9a58888)
        this = r19;
        r1 = r20;
        r2 = r22;
        r3 = r21;
        this = fn_0x9a58a04(this, r1, r2, r3);  // call  [0x9a58a04]
        // fcmpe s9, s8  (0x9a588a0)
        if (/* cond: b.lt */) goto label_0x9a58934;
        *(void**)(r19 + 0x18) = r8;
        goto label_0x9a58934;
    label_0x9a588b4:
        r8 = *(void**)(r23);
        r8 = *(void**)(r8 + 0x30);
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fsub s0, s0, s9  (0x9a588c4)
        // movi d1, #0x0  (0x9a588c8)
        r8 = *(void**)(r23);
        r8 = *(void**)(r8 + 0x38);
        // fcmpe s0, #0  (0x9a588d4)
        // fcsel s10, s1, s0, mi  (0x9a588d8)
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fcmpe s10, s0  (0x9a588e4)
        // fmov s8, #1  (0x9a588e8)
        if (/* cond: b.pl */) goto label_0x9a588f4;
        // fdiv s8, s10, s0  (0x9a588f0)
    label_0x9a588f4:
        this = r20;
        this = fn_0xb725194(this, r1, r2, r3);  // call  [0xb725194]
        r1 = this;
        // fmov s0, s8  (0x9a58900)
        this = r19;
        r2 = r22;
        r3 = r21;
        this = fn_0x9a58bb4(this, r1, r2, r3);  // call  [0x9a58bb4]
        r8 = *(void**)(r23);
        r8 = *(void**)(r8 + 0x30);
        this = r23;
        this = (*(void**)r8)(this);  // indirect call
        // fcmpe s9, s0  (0x9a58924)
        if (/* cond: b.lt */) goto label_0x9a58934;
        *(void**)(r19 + 0x18) = rzr;
        *(uint8_t*)(r19 + 0x60) = rzr;
    label_0x9a58934:
        r22 = *(void**)(sp + 0x20);
        if (r22 == 0) goto label_0x9a5896c;
    label_0x9a5893c:
        r19 = r22 + 0xc;
        r1 = r19;
        this = fn_0x8897340(this, r1, r2, r3);  // call  [0x8897340]
        // ldar w8, [x19]  (0x9a5894c)
        // cmp r8 == <complex operand>
        if (/* cond: b.gt */) goto label_0x9a5896c;
        r8 = *(void**)(r22);
        if (r8 != 0) goto label_0x9a5896c;
        this = *(void**)(sp + 0x20);
        if (this == 0) goto label_0x9a5896c;
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a5896c:
        r8 = *(void**)(r26 + 0x28);
        r9 = *(void**)(sp + 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9a58a00;
        // ldp x20, x19, [sp, #0x90]  (0x9a5897c)
        rd10 = *(void**)(sp + 0x30);
        // ldp x22, x21, [sp, #0x80]  (0x9a58984)
        // ldp x24, x23, [sp, #0x70]  (0x9a58988)
        // ldp x26, x25, [sp, #0x60]  (0x9a5898c)
        // ldp x29, x30, [sp, #0x50]  (0x9a58990)
        // ldp d9, d8, [sp, #0x40]  (0x9a58994)
        sp = sp + 0xa0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7ae3ec
// fn_va = 0xb7ae3ec
// return type (guess): unknown (no ret found)
void* fn_0xb7ae3ec(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7ae3ec)
        *(void**)(sp + 0x10) = r19;
        if (this == 0) goto label_0xb7ae410;
        r19 = this;
        r1 = this + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7ae41c;
    label_0xb7ae410:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7ae414)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d31c
// fn_va = 0x8a3d31c
// return type (guess): unknown (no ret found)
void* fn_0x8a3d31c(void* this) {
        // stp x29, x30, [sp, #0x30]  (0x8a3d320)
        *(void**)(sp + 0x40) = r19;
        fp = sp + 0x30;
        // mrs x19, tpidr_el0  (0x8a3d32c)
        this = sp + 0x8;
        r8 = *(void**)(r19 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x8;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3d424  (0x8a3d348)
        r9 = *(void**)(sp + 0x10);
        // movk w10, #0x75df, lsl #0x10  (0x8a3d354)
        // ldp x11, x8, [x9, #0x38]  (0x8a3d358)
        // lsr x8, x8, #0x3  (0x8a3d360)
        // and x12, x8, x10  (0x8a3d368)
        r8 = *(void**)(sp + 0x18);
        r12 = *(void**)(r9 + 0x50);
    label_0x8a3d378:
        r11 = *(void**)(r11);
        // cmp r11 == - 0x1
        if (/* cond: b.eq */) goto label_0x8a3d424;
        r13 = *(void**)(r11 + 0x8);
        // cmp r13 == r10
        if (/* cond: b.ne */) goto label_0x8a3d378;
        r9 = *(void**)(r9 + 0x58);
        // cmp r11 == r9
        if (/* cond: b.eq */) goto label_0x8a3d424;
        r9 = *(void**)(r11 + 0x10);
        if (r9 == 0) goto label_0x8a3d454;
        // ldp x10, x12, [x9, #0x8]  (0x8a3d3a8)
        // ubfx x11, x8, #0xb, #0x7  (0x8a3d3ac)
        // cmp r11 == <complex operand>
        if (/* cond: b.hs */) goto label_0x8a3d424;
        if (r10 == 0) goto label_0x8a3d424;
        // and x11, x8, #0x3ffff  (0x8a3d3c4)
        // and w8, w8, #0xfffc0000  (0x8a3d3c8)
        // and x11, x11, #0x7ff  (0x8a3d3cc)
        // eor w8, w10, w8  (0x8a3d3d8)
        // cmp r8 == r11
        if (/* cond: b.hi */) goto label_0x8a3d424;
        // lsr x8, x10, #0x4  (0x8a3d3e4)
        r9 = *(void**)(r9 + 0x50);
        // and x8, x8, #0x3ff8  (0x8a3d3ec)
        if (r8 == 0) goto label_0x8a3d428;
        // and x9, x10, #0x3ffff  (0x8a3d3f8)
        // and x9, x9, #0x7f  (0x8a3d400)
        // ldp w8, w9, [x8]  (0x8a3d408)
        // lsl x9, x9, #0x20  (0x8a3d40c)
        r10 = *(void**)(r19 + 0x28);
        r11 = *(void**)(fp - 0x8);
        // cmp r10 == r11
        if (/* cond: b.eq */) goto label_0x8a3d440;
        goto label_0x8a3d46c;
    label_0x8a3d424:
        r8 = rzr;
    label_0x8a3d428:
        r1 = rzr;
        r9 = rzr;
        r10 = *(void**)(r19 + 0x28);
        r11 = *(void**)(fp - 0x8);
        // cmp r10 == r11
        if (/* cond: b.ne */) goto label_0x8a3d46c;
    label_0x8a3d440:
        // orr x0, x9, x8  (0x8a3d440)
        // ldp x29, x30, [sp, #0x30]  (0x8a3d444)
        r19 = *(void**)(sp + 0x40);
        sp = sp + 0x50;
        return this;
}

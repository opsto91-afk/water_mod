// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xe803100
// fn_va = 0xe803100
// return type (guess): unknown (no ret found)
void* fn_0xe803100(void* this, void* r1) {
        // stp x20, x19, [sp, #0x10]  (0xe803100)
        r19 = this;
        // cmp r1 == this
        if (/* cond: b.eq */) goto label_0xe80317c;
        rq0 = *(void**)(r1 + 0x18);
        // stp xzr, xzr, [x1, #0x18]  (0xe803118)
        r20 = r1;
        this = *(void**)(r19 + 0x20);
        *(void**)(r19 + 0x18) = rq0;
        if (this == 0) goto label_0xe803130;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xe803130:
        this = *(void**)(r20 + 0x20);
        // stp xzr, xzr, [x20, #0x18]  (0xe803134)
        if (this == 0) goto label_0xe803140;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xe803140:
        r8 = *(void**)(r20 + 0x28);
        this = r19 + 0x8;
        r1 = r20 + 0x8;
        *(void**)(r19 + 0x28) = r8;
        this = fn_0x11e4c32c(this, r1, r2, r3);  // call  [0x11e4c32c]
        r8 = *(void**)(r20 + 0x68);
        r9 = *(void**)(r20 + 0x30);
        this = r19 + 0x88;
        r1 = r20 + 0x88;
        *(void**)(r19 + 0x68) = r8;
        *(void**)(r19 + 0x30) = r9;
        this = fn_0x8959368(this, r1, r2, r3);  // call  [0x8959368]
        this = r19 + 0x70;
        r1 = r20 + 0x70;
        this = fn_0x8959368(this, r1, r2, r3);  // call  [0x8959368]
    label_0xe80317c:
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0xe803180)
        // ldp x29, x30, [sp], #0x20  (0xe803184)
        return this;
}

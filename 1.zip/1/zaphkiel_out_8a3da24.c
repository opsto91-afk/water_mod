// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3da24
// fn_va = 0x8a3da24
// return type (guess): unknown (no ret found)
void* fn_0x8a3da24(void* this) {
        // stp d13, d12, [sp, #0x60]  (0x8a3da28)
        // stp d11, d10, [sp, #0x70]  (0x8a3da2c)
        // stp d9, d8, [sp, #0x80]  (0x8a3da30)
        // stp x29, x30, [sp, #0x90]  (0x8a3da34)
        // stp x28, x27, [sp, #0xa0]  (0x8a3da38)
        // stp x26, x25, [sp, #0xb0]  (0x8a3da3c)
        // stp x24, x23, [sp, #0xc0]  (0x8a3da40)
        // stp x22, x21, [sp, #0xd0]  (0x8a3da44)
        // stp x20, x19, [sp, #0xe0]  (0x8a3da48)
        fp = sp + 0x90;
        // mrs x25, tpidr_el0  (0x8a3da50)
        r22 = this;
        // fmov s8, s2  (0x8a3da58)
        r9 = *(void**)(r25 + 0x28);
        // fmov s9, s1  (0x8a3da60)
        // fmov s10, s0  (0x8a3da64)
        r21 = r1;
        r19 = r8;
        *(void**)(fp - 0x38) = r9;
        this = *(void**)(this + 0x8);
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0x578);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0x8a3dc24  (0x8a3da94)
        // ldp x8, x20, [x21]  (0x8a3da98)
        // stp x8, x20, [sp, #0x20]  (0x8a3da9c)
        if (r20 == 0) goto label_0x8a3dab0;
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3dab0:
        this = *(void**)(r22 + 0x8);
        r9 = *(void**)(r21 + 0x10);
        r8 = *(void**)(this);
        *(void**)(sp + 0x30) = r9;
        r8 = *(void**)(r8 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3dafc;
        this = sp + 0x38;
        r1 = sp + 0x20;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x38;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3dafc  (0x8a3dae0)
        this = sp + 0x38;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        r21 = this;
        if (r20 != 0) goto label_0x8a3db04;
        goto label_0x8a3db0c;
    label_0x8a3dafc:
        r21 = rzr;
        if (r20 == 0) goto label_0x8a3db0c;
    label_0x8a3db04:
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3db0c:
        if (r21 == 0) goto label_0x8a3dc24;
        r9 = *(void**)(r21 + 0x10);
        // movk w10, #0x8424, lsl #0x10  (0x8a3db18)
        // ldp x11, x8, [x9, #0x38]  (0x8a3db1c)
        // lsr x8, x8, #0x3  (0x8a3db24)
        // and x12, x8, x10  (0x8a3db2c)
        r8 = *(void**)(r21 + 0x18);
        r12 = *(void**)(r9 + 0x50);
    label_0x8a3db3c:
        r11 = *(void**)(r11);
        // cmp r11 == - 0x1
        if (/* cond: b.eq */) goto label_0x8a3dc24;
        r13 = *(void**)(r11 + 0x8);
        // cmp r13 == r10
        if (/* cond: b.ne */) goto label_0x8a3db3c;
        r9 = *(void**)(r9 + 0x58);
        // cmp r11 == r9
        if (/* cond: b.eq */) goto label_0x8a3dc24;
        r9 = *(void**)(r11 + 0x10);
        if (r9 == 0) goto label_0x8a3dc24;
        // ldp x10, x12, [x9, #0x8]  (0x8a3db6c)
        // ubfx x11, x8, #0xb, #0x7  (0x8a3db70)
        // cmp r11 == <complex operand>
        if (/* cond: b.hs */) goto label_0x8a3dc24;
        if (r10 == 0) goto label_0x8a3dc24;
        // and x11, x8, #0x3ffff  (0x8a3db88)
        // and w8, w8, #0xfffc0000  (0x8a3db8c)
        // and x11, x11, #0x7ff  (0x8a3db90)
        // eor w8, w10, w8  (0x8a3db9c)
        // cmp r8 == r11
        if (/* cond: b.hi */) goto label_0x8a3dc24;
        // and x8, x10, #0x3ff80  (0x8a3dba8)
        r9 = *(void**)(r9 + 0x50);
        // lsr x8, x8, #0x4  (0x8a3dbb0)
        if (r8 == 0) goto label_0x8a3dc24;
        // and x9, x10, #0x7f  (0x8a3dbbc)
        // umaddl x0, w9, w10, x8  (0x8a3dbc4)
        r21 = this;
        this = fn_0xbd95e2c(this, r1, r2, r3);  // call  [0xbd95e2c]
        // tbz w0, #0x0, 0x8a3dc24  (0x8a3dbd0)
        r8 = sp + 0x38;
        this = r21;
        this = fn_0xbd95e6c(this, r1, r2, r3);  // call  [0xbd95e6c]
        // ldp x26, x22, [sp, #0x38]  (0x8a3dbe0)
        // stp xzr, xzr, [x19]  (0x8a3dbe4)
        *(void**)(r19 + 0x10) = rzr;
        // subs x20, x22, x26  (0x8a3dbec)
        if (/* cond: b.eq */) goto label_0x8a3dd8c;
        // lsr x8, x20, #0x3c  (0x8a3dbf4)
        if (r8 != 0) goto label_0x8a3ddf0;
        // lsl x0, x20, #0x4  (0x8a3dbfc)
        this = fn_0xe803540(this, r1, r2, r3);  // call  [0xe803540]
        // stp x0, x0, [x19]  (0x8a3dc08)
        r20 = this;
        *(void**)(sp + 0x8) = r22;
        // stp x0, x8, [sp, #0x10]  (0x8a3dc14)
        this = r21;
        *(void**)(r19 + 0x10) = r8;
        goto label_0x8a3dc8c;
    label_0x8a3dc24:
        r8 = *(void**)(r25 + 0x28);
        r9 = *(void**)(fp - 0x38);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3de74;
        // stp xzr, xzr, [x19]  (0x8a3dc34)
        *(void**)(r19 + 0x10) = rzr;
    label_0x8a3dc3c:
        // ldp x20, x19, [sp, #0xe0]  (0x8a3dc3c)
        // ldp x22, x21, [sp, #0xd0]  (0x8a3dc40)
        // ldp x24, x23, [sp, #0xc0]  (0x8a3dc44)
        // ldp x26, x25, [sp, #0xb0]  (0x8a3dc48)
        // ldp x28, x27, [sp, #0xa0]  (0x8a3dc4c)
        // ldp x29, x30, [sp, #0x90]  (0x8a3dc50)
        // ldp d9, d8, [sp, #0x80]  (0x8a3dc54)
        // ldp d11, d10, [sp, #0x70]  (0x8a3dc58)
        // ldp d13, d12, [sp, #0x60]  (0x8a3dc5c)
        sp = sp + 0xf0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d078
// fn_va = 0x8a3d078
// return type (guess): unknown (no ret found)
void* fn_0x8a3d078(void* this, void* r1) {
        *(void**)(sp + 0x40) = rd10;
        // stp d9, d8, [sp, #0x48]  (0x8a3d080)
        // stp x29, x30, [sp, #0x58]  (0x8a3d084)
        *(void**)(sp + 0x68) = r23;
        // stp x22, x21, [sp, #0x70]  (0x8a3d08c)
        // stp x20, x19, [sp, #0x80]  (0x8a3d090)
        fp = sp + 0x58;
        // mrs x23, tpidr_el0  (0x8a3d098)
        r19 = r2;
        r21 = r1;
        r8 = *(void**)(r23 + 0x28);
        r22 = this;
        *(void**)(fp - 0x20) = r8;
        // ldp x8, x20, [x1]  (0x8a3d0b0)
        // stp x8, x20, [sp]  (0x8a3d0b4)
        if (r20 == 0) goto label_0x8a3d0c8;
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3d0c8:
        this = *(void**)(r22 + 0x8);
        r9 = *(void**)(r21 + 0x10);
        r8 = *(void**)(this);
        *(void**)(sp + 0x10) = r9;
        r8 = *(void**)(r8 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3d114;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3d114  (0x8a3d0f8)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        r21 = this;
        if (r20 != 0) goto label_0x8a3d11c;
        goto label_0x8a3d124;
    label_0x8a3d114:
        r21 = rzr;
        if (r20 == 0) goto label_0x8a3d124;
    label_0x8a3d11c:
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3d124:
        if (r21 == 0) goto label_0x8a3d184;
        this = r21;
        r1 = r19;
        this = fn_0xfd8b544(this, r1, r2, r3);  // call  [0xfd8b544]
        this = r21;
        // fmov s8, s0  (0x8a3d138)
        // fmov s9, s1  (0x8a3d13c)
        // fmov s10, s2  (0x8a3d140)
        this = fn_0xfd86998(this, r1, r2, r3);  // call  [0xfd86998]
        // ldp s0, s2, [x0]  (0x8a3d148)
        rs1 = *(void**)(this + 0x8);
        // fsub s1, s10, s1  (0x8a3d150)
        // fsub s0, s8, s0  (0x8a3d154)
        // fsub s2, s9, s2  (0x8a3d158)
        // fmov w9, s1  (0x8a3d15c)
        // fmov w8, s0  (0x8a3d160)
        // fmov w10, s2  (0x8a3d164)
        // orr x1, x9, #0x100000000  (0x8a3d168)
        // orr x0, x8, x10, lsl #0x20  (0x8a3d16c)
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x20);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0x8a3d19c;
        goto label_0x8a3d1e4;
    label_0x8a3d184:
        this = rzr;
        r1 = rzr;
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x20);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3d1e4;
    label_0x8a3d19c:
        // ldp x20, x19, [sp, #0x80]  (0x8a3d19c)
        r23 = *(void**)(sp + 0x68);
        // ldp x22, x21, [sp, #0x70]  (0x8a3d1a4)
        rd10 = *(void**)(sp + 0x40);
        // ldp x29, x30, [sp, #0x58]  (0x8a3d1ac)
        // ldp d9, d8, [sp, #0x48]  (0x8a3d1b0)
        sp = sp + 0x90;
        return this;
}

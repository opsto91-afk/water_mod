// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7beb4c
// fn_va = 0xb7beb4c
// return type (guess): unknown (no ret found)
void* fn_0xb7beb4c(void* this) {
        // stp d9, d8, [sp, #0x80]  (0xb7beb50)
        // stp x29, x30, [sp, #0x90]  (0xb7beb54)
        // stp x24, x23, [sp, #0xa0]  (0xb7beb58)
        // stp x22, x21, [sp, #0xb0]  (0xb7beb5c)
        // stp x20, x19, [sp, #0xc0]  (0xb7beb60)
        fp = sp + 0x90;
        // mrs x22, tpidr_el0  (0xb7beb68)
        r19 = this;
        this = sp + 0x30;
        r8 = *(void**)(r22 + 0x28);
        r1 = r19;
        *(void**)(fp - 0x18) = r8;
        this = fn_0xb7a84e0(this, r1, r2, r3);  // call  [0xb7a84e0]
        r23 = *(void**)(sp + 0x3c);
        // cmp r23 == <complex operand>
        if (/* cond: b.lt */) goto label_0xb7bed24;
        r20 = *(void**)(r19 + 0x958);
        r8 = *(void**)(r20);
        r8 = *(void**)(r8 + 0x150);
        this = r20;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xa70);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x18);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r19 + 0x1208);
        // cmp this == r8
        *(void**)(r19 + 0x1208) = r9;
        if (/* cond: b.ge */) goto label_0xb7bed24;
        this = sp + 0x8;
        *(void**)(r19 + 0x1208) = rzr;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r8 = *(void**)(r20);
        r8 = *(void**)(r8 + 0x138);
        r1 = sp + 0x8;
        this = r20;
        this = (*(void**)r8)(this);  // indirect call
        r21 = this;
        this = sp + 0x24;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r1 = sp + 0x24;
        this = r21;
        this = fn_0x10aa08a0(this, r1, r2, r3);  // call  [0x10aa08a0]
        // lsr x8, x0, #0x20  (0xb7bec18)
        rs1 = *(void**)(r19 + 0x114c);
        // scvtf s0, w8  (0xb7bec20)
        r8 = *(void**)(r20);
        r8 = *(void**)(r8 + 0x130);
        // fsub s9, s0, s1  (0xb7bec2c)
        this = r20;
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0x10b3eb2c(this, r1, r2, r3);  // call  [0x10b3eb2c]
        // fmov s0, #1  (0xb7bec3c)
        this = fn_0x10aa0678(this, r1, r2, r3);  // call  [0x10aa0678]
        // scvtf s1, w23  (0xb7bec44)
        r8 = *(void**)(sp + 0x40);
        rs2 = *(void**)(sp + 0x30);
        *(void**)(sp + 0x24) = rs2;
        // fmul s0, s0, s1  (0xb7bec54)
        // scvtf s1, w8  (0xb7bec58)
        // fdiv s8, s0, s1  (0xb7bec60)
        // scvtf s0, w8  (0xb7bec64)
        rs1 = *(void**)(r19 + 0x114c);
        // fadd s0, s1, s0  (0xb7bec6c)
        rd1 = *(void**)(sp + 0x34);
        *(void**)(sp + 0x28) = rd1;
        // fcmpe s1, s0  (0xb7bec78)
        if (/* cond: b.le */) goto label_0xb7bece4;
        // fcmpe s9, #0  (0xb7bec80)
        if (/* cond: b.le */) goto label_0xb7bece4;
        // movk w8, #0x3dcc, lsl #0x10  (0xb7bec8c)
        // fmov s0, w8  (0xb7bec90)
        // movk w8, #0x3d4c, lsl #0x10  (0xb7bec98)
        // fmov s1, w8  (0xb7bec9c)
        // fmul s2, s9, s0  (0xb7beca0)
        // fmov s0, #1  (0xb7beca4)
        this = fn_0x1351ee98(this, r1, r2, r3);  // call  [0x1351ee98]
        // fmov s9, s0  (0xb7becac)
        r1 = "ambient.weather.rain";  // 0x26fd958
        this = sp + 0x8;
        this = fn_0x135d40c0(this, r1, r2, r3);  // call  [0x135d40c0]
        // fmul s0, s9, s8  (0xb7becc4)
        // fmov s1, #0.5  (0xb7becc8)
        r1 = sp + 0x8;
        r2 = sp + 0x24;
        this = r19;
        r3 = rzr;
        this = fn_0xb7bedc0(this, r1, r2, r3);  // call  [0xb7bedc0]
        goto label_0xb7bed14;
    label_0xb7bece4:
        r1 = "ambient.weather.rain";  // 0x26fd958
        this = sp + 0x8;
        this = fn_0x135d40c0(this, r1, r2, r3);  // call  [0x135d40c0]
        // fmov s0, s8  (0xb7becf8)
        // fmov s1, #1  (0xb7becfc)
        r1 = sp + 0x8;
        r2 = sp + 0x24;
        this = r19;
        r3 = rzr;
        this = fn_0xb7bedc0(this, r1, r2, r3);  // call  [0xb7bedc0]
    label_0xb7bed14:
        r8 = *(uint8_t*)(sp + 0x8);
        // tbz w8, #0x0, 0xb7bed24  (0xb7bed18)
        this = *(void**)(sp + 0x18);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bed24:
        this = *(void**)(sp + 0x60);
        if (this == 0) goto label_0xb7bed30;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bed30:
        this = *(void**)(sp + 0x48);
        if (this == 0) goto label_0xb7bed3c;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7bed3c:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bedbc;
        // ldp x20, x19, [sp, #0xc0]  (0xb7bed4c)
        // ldp x22, x21, [sp, #0xb0]  (0xb7bed50)
        // ldp x24, x23, [sp, #0xa0]  (0xb7bed54)
        // ldp x29, x30, [sp, #0x90]  (0xb7bed58)
        // ldp d9, d8, [sp, #0x80]  (0xb7bed5c)
        sp = sp + 0xd0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c3b60
// fn_va = 0xb7c3b60
// return type (guess): unknown (no ret found)
void* fn_0xb7c3b60(void* this, void* r1) {
        // stp d11, d10, [sp, #0x140]  (0xb7c3b64)
        // stp d9, d8, [sp, #0x150]  (0xb7c3b68)
        // stp x29, x30, [sp, #0x160]  (0xb7c3b6c)
        // stp x28, x27, [sp, #0x170]  (0xb7c3b70)
        // stp x26, x25, [sp, #0x180]  (0xb7c3b74)
        // stp x24, x23, [sp, #0x190]  (0xb7c3b78)
        // stp x22, x21, [sp, #0x1a0]  (0xb7c3b7c)
        // stp x20, x19, [sp, #0x1b0]  (0xb7c3b80)
        fp = sp + 0x160;
        // mrs x26, tpidr_el0  (0xb7c3b88)
        r23 = r1;
        r21 = this;
        r9 = *(void**)(r26 + 0x28);
        r19 = r8;
        *(void**)(fp - 0x30) = r9;
        r9 = *(void**)(r1 + 0x100);
        // ldp x20, x22, [x9]  (0xb7c3ba4)
        if (r22 == 0) goto label_0xb7c3bfc;
        r1 = r22 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r22 + 0x8;
        // stp xzr, xzr, [x19]  (0xb7c3bc0)
        // stp xzr, x20, [x19, #0x10]  (0xb7c3bc4)
        *(void**)(r19 + 0x20) = r22;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c3c08;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c3c08;
    label_0xb7c3bfc:
        // stp xzr, xzr, [x19]  (0xb7c3bfc)
        // stp xzr, x20, [x19, #0x10]  (0xb7c3c00)
        *(void**)(r19 + 0x20) = rzr;
    label_0xb7c3c08:
        this = *(void**)(r21 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x148);
        this = (*(void**)r8)(this);  // indirect call
        r24 = this;
        this = *(void**)(r21 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x130);
        this = (*(void**)r8)(this);  // indirect call
        r25 = this;
        this = *(void**)(r21 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0xae0);
        r8 = sp + 0x78;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x78);
        if (r8 == 0) goto label_0xb7c4678;
        this = *(void**)(r21 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xad8);
        this = (*(void**)r8)(this);  // indirect call
        r20 = this;
        this = *(void**)(r21 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x2c0);
        r8 = sp + 0xa8;
        this = (*(void**)r8)(this);  // indirect call
        this = sp + 0xa8;
        this = fn_0x9a0e174(this, r1, r2, r3);  // call  [0x9a0e174]
        r22 = this;
        this = *(void**)(r21 + 0x10f8);
        *(void**)(sp + 0x30) = r20;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x568);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x300);
        this = (*(void**)r8)(this);  // indirect call
        // cmp r25 == 0x0
        *(void**)(sp + 0x48) = r23;
        // cset w8, eq  (0xb7c3ca8)
        // orr w8, w8, w0  (0xb7c3cac)
        // tbnz w8, #0x0, 0xb7c445c  (0xb7c3cb0)
        *(void**)(sp + 0x28) = r24;
        // ldp x23, x24, [x21, #0x1d8]  (0xb7c3cb8)
        // stp x26, x22, [sp, #0x38]  (0xb7c3cbc)
        // ldp x22, x8, [x21, #0x1f0]  (0xb7c3cc0)
        // cmp r23 == r24
        *(void**)(sp + 0x50) = r8;
        if (/* cond: b.ne */) goto label_0xb7c3cdc;
        r8 = *(void**)(sp + 0x50);
        // cmp r22 == r8
        if (/* cond: b.eq */) goto label_0xb7c4264;
    label_0xb7c3cdc:
        r8 = sp + 0x88;
        // movk w20, #0x97d9, lsl #0x10  (0xb7c3ce4)
        // orr x9, x8, #0x1  (0xb7c3ce8)
        // orr x8, x8, #0x2  (0xb7c3cec)
        // stp x8, x9, [sp, #0x18]  (0xb7c3cf0)
    label_0xb7c3cf4:
        r26 = *(void**)(r23);
        // cmp r26 == r25
        if (/* cond: b.eq */) goto label_0xb7c4248;
        r8 = *(void**)(r26);
        r8 = *(void**)(r8 + 0x100);
        this = r26;
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0xb7c4248  (0xb7c3d10)
        r9 = *(void**)(r26 + 0x10);
        // ldp x10, x8, [x9, #0x38]  (0xb7c3d18)
        // lsr x8, x8, #0x3  (0xb7c3d20)
        // and x11, x8, x20  (0xb7c3d28)
        r8 = *(void**)(r26 + 0x18);
        r11 = *(void**)(r9 + 0x50);
    label_0xb7c3d38:
        r10 = *(void**)(r10);
        // cmp r10 == - 0x1
        if (/* cond: b.eq */) goto label_0xb7c3dcc;
        r12 = *(void**)(r10 + 0x8);
        // cmp r12 == r20
        if (/* cond: b.ne */) goto label_0xb7c3d38;
        r9 = *(void**)(r9 + 0x58);
        // cmp r10 == r9
        if (/* cond: b.eq */) goto label_0xb7c3dcc;
        r9 = *(void**)(r10 + 0x10);
        if (r9 == 0) goto label_0xb7c3dcc;
        // ldp x10, x12, [x9, #0x8]  (0xb7c3d68)
        // ubfx x11, x8, #0xb, #0x7  (0xb7c3d6c)
        // cmp r11 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7c3dcc;
        if (r10 == 0) goto label_0xb7c3dcc;
        // and x11, x8, #0x3ffff  (0xb7c3d84)
        // and w8, w8, #0xfffc0000  (0xb7c3d88)
        // and x11, x11, #0x7ff  (0xb7c3d8c)
        // eor w8, w10, w8  (0xb7c3d98)
        // cmp r8 == r11
        if (/* cond: b.hi */) goto label_0xb7c3dcc;
        // lsr x8, x10, #0x4  (0xb7c3da4)
        r9 = *(void**)(r9 + 0x50);
        // and x8, x8, #0x3ff8  (0xb7c3dac)
        if (r8 == 0) goto label_0xb7c3dcc;
        // and x9, x10, #0x3ffff  (0xb7c3db8)
        // and x9, x9, #0x7f  (0xb7c3dbc)
        r8 = *(uint8_t*)(r8 + 0x1);
        // tbnz w8, #0x0, 0xb7c3de8  (0xb7c3dc8)
    label_0xb7c3dcc:
        this = *(void**)(r21 + 0x1138);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xa80);
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0x110c25d0(this, r1, r2, r3);  // call  [0x110c25d0]
        // cmp this == r26
        if (/* cond: b.ne */) goto label_0xb7c4248;
    label_0xb7c3de8:
        r8 = fp - 0x68;
        this = r26;
        this = fn_0xfda0200(this, r1, r2, r3);  // call  [0xfda0200]
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7c3df4)
        r9 = *(void**)(fp - 0x60);
        // lsr x10, x8, #0x1  (0xb7c3dfc)
        // tst w8, #0x1  (0xb7c3e00)
        // csel x8, x10, x9, eq  (0xb7c3e04)
        if (r8 == 0) goto label_0xb7c3f60;
        this = r26;
        this = fn_0xfda4e0c(this, r1, r2, r3);  // call  [0xfda4e0c]
        r27 = this;
        this = fp - 0x68;
        this = fn_0xcefc6ac(this, r1, r2, r3);  // call  [0xcefc6ac]
        // tbnz w27, #0x0, 0xb7c3f68  (0xb7c3e20)
        this = *(void**)(r26 + 0x10);
        r28 = *(void**)(r26 + 0x18);
        // movk w1, #0x665, lsl #0x10  (0xb7c3e30)
        this = fn_0x9c6e66c(this, r1, r2, r3);  // call  [0x9c6e66c]
        // ldp x8, x10, [x0, #0x8]  (0xb7c3e38)
        // ubfx x9, x28, #0xb, #0x7  (0xb7c3e3c)
        r27 = this;
        // cmp r9 == <complex operand>
        if (/* cond: b.hs */) goto label_0xb7c3ec8;
        if (r8 == 0) goto label_0xb7c3ec8;
        // and x9, x28, #0x3ffff  (0xb7c3e58)
        // and x9, x9, #0x7ff  (0xb7c3e60)
        // and w9, w28, #0xfffc0000  (0xb7c3e68)
        // eor w9, w8, w9  (0xb7c3e6c)
        // cmp r9 == r10
        if (/* cond: b.hi */) goto label_0xb7c3ec8;
        // and x9, x8, #0x3ff80  (0xb7c3e78)
        r10 = *(void**)(r27 + 0x50);
        // lsr x9, x9, #0x4  (0xb7c3e80)
        // and x8, x8, #0x7f  (0xb7c3e88)
        r8 = *(void**)(sp + 0x48);
        r8 = *(void**)(r8 + 0xd0);
        if (r8 != 0) goto label_0xb7c3f04;
    label_0xb7c3e9c:
        r9 = rzr;
        // movk w10, #0xdead, lsl #0x10  (0xb7c3ea4)
        *(void**)(r9) = r10;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7c3f0c  (0xb7c3eb0)
    label_0xb7c3eb4:
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0xb7c3ebc)
        *(void**)(r8) = r9;
        goto label_0xb7c3f0c;
    label_0xb7c3ec8:
        *(void**)(fp - 0x68) = r28;
        r1 = fp - 0x68;
        this = r27;
        r2 = rzr;
        this = fn_0x9c6f380(this, r1, r2, r3);  // call  [0x9c6f380]
        r8 = r1 - 0x1;
        r10 = *(void**)(r27 + 0x50);
        // lsr x9, x8, #0x4  (0xb7c3ee4)
        // and x9, x9, #0xffffffffffffff8  (0xb7c3ee8)
        // and x8, x8, #0x7f  (0xb7c3ef0)
        r8 = *(void**)(sp + 0x48);
        r8 = *(void**)(r8 + 0xd0);
        if (r8 == 0) goto label_0xb7c3e9c;
    label_0xb7c3f04:
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7c3eb4  (0xb7c3f08)
    label_0xb7c3f0c:
        r8 = *(void**)(sp + 0x48);
        r27 = *(void**)(r8 + 0xe0);
        r8 = fp - 0x68;
        this = r26;
        this = fn_0xfda0200(this, r1, r2, r3);  // call  [0xfda0200]
        r1 = *(uint8_t*)(r28 + 0x1);
        this = fp - 0x68;
        this = fn_0xcefcf70(this, r1, r2, r3);  // call  [0xcefcf70]
        r2 = this;
        r8 = sp + 0x88;
        this = r27;
        r3 = rzr;
        this = fn_0xb9d06dc(this, r1, r2, r3);  // call  [0xb9d06dc]
        r1 = sp + 0x88;
        this = r26;
        this = fn_0xfda5010(this, r1, r2, r3);  // call  [0xfda5010]
        r8 = *(uint8_t*)(sp + 0x88);
        // tbz w8, #0x0, 0xb7c3f60  (0xb7c3f54)
        this = *(void**)(sp + 0x98);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c3f60:
        this = fp - 0x68;
        this = fn_0xcefc6ac(this, r1, r2, r3);  // call  [0xcefc6ac]
    label_0xb7c3f68:
        r8 = fp - 0x68;
        this = r26;
        this = fn_0xfda4f80(this, r1, r2, r3);  // call  [0xfda4f80]
        this = *(void**)(r21 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x810);
        r8 = sp + 0x88;
        r1 = fp - 0x68;
        r2 = rzr;
        this = (*(void**)r8)(this);  // indirect call
        this = fp - 0x68;
        r1 = sp + 0x88;
        this = fn_0x8959368(this, r1, r2, r3);  // call  [0x8959368]
        r8 = *(uint8_t*)(sp + 0x88);
        // tbz w8, #0x0, 0xb7c3fac  (0xb7c3fa0)
        this = *(void**)(sp + 0x98);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c3fac:
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7c3fac)
        r9 = *(void**)(fp - 0x60);
        // lsr x10, x8, #0x1  (0xb7c3fb4)
        // tst w8, #0x1  (0xb7c3fb8)
        // csel x8, x10, x9, eq  (0xb7c3fbc)
        if (r8 == 0) goto label_0xb7c412c;
        this = r26;
        this = fn_0xfd96614(this, r1, r2, r3);  // call  [0xfd96614]
        // tbnz w0, #0x0, 0xb7c412c  (0xb7c3fcc)
        r8 = *(void**)(r26);
        r8 = *(void**)(r8 + 0x100);
        this = r26;
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0xb7c412c  (0xb7c3fe0)
        this = r26;
        this = fn_0xfd86998(this, r1, r2, r3);  // call  [0xfd86998]
        // ldp s1, s2, [x0]  (0xb7c3fec)
        rs0 = *(void**)(r21 + 0x614);
        rs3 = *(void**)(r21 + 0x618);
        // fsub s0, s1, s0  (0xb7c3ffc)
        // fsub s1, s2, s3  (0xb7c4000)
        rs2 = *(void**)(this + 0x8);
        rs3 = *(void**)(r21 + 0x61c);
        // fsub s2, s2, s3  (0xb7c400c)
        // fmul s0, s0, s0  (0xb7c4010)
        // fmul s1, s1, s1  (0xb7c4014)
        // fadd s0, s0, s1  (0xb7c4018)
        // fmul s1, s2, s2  (0xb7c401c)
        // fadd s0, s0, s1  (0xb7c4020)
        // fmov s1, w8  (0xb7c4024)
        // fcmpe s0, s1  (0xb7c4028)
        if (/* cond: b.pl */) goto label_0xb7c412c;
        this = r26;
        this = fn_0xfda528c(this, r1, r2, r3);  // call  [0xfda528c]
        r8 = *(uint8_t*)(this);
        r9 = *(void**)(this + 0x8);
        // lsr x10, x8, #0x1  (0xb7c4040)
        // tst w8, #0x1  (0xb7c4044)
        // csel x12, x10, x9, eq  (0xb7c4048)
        if (r12 == 0) goto label_0xb7c412c;
        r27 = r12 + 0x1;
        // cmp r27 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7c46e0;
        // cmp r27 == 0x16
        if (/* cond: b.hi */) goto label_0xb7c4080;
        // and w9, w27, #0xff  (0xb7c4064)
        r8 = rzr;
        // stp xzr, xzr, [sp, #0x88]  (0xb7c406c)
        // lsl w9, w9, #0x1  (0xb7c4070)
        *(void**)(sp + 0x98) = rzr;
        *(uint8_t*)(sp + 0x88) = r9;
        goto label_0xb7c40bc;
    label_0xb7c4080:
        // and x8, x27, #0xfffffffffffffff8  (0xb7c4080)
        // orr x9, x27, #0x7  (0xb7c4084)
        // stp x12, x0, [sp, #0x8]  (0xb7c4088)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7c4094)
        r28 = r8 + 0x1;
        this = r28;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r8 = this;
        // stp x27, x0, [sp, #0x90]  (0xb7c40a8)
        // orr x9, x28, #0x1  (0xb7c40ac)
        // ldp x12, x0, [sp, #0x8]  (0xb7c40b0)
        *(void**)(sp + 0x88) = r9;
        // and w9, w9, #0xff  (0xb7c40b8)
    label_0xb7c40bc:
        // tst w9, #0x1  (0xb7c40bc)
        // ldp x11, x9, [sp, #0x18]  (0xb7c40c0)
        r2 = r12;
        r27 = r12;
        // csel x9, x9, x8, eq  (0xb7c40d0)
        // csinc x28, x11, x8, eq  (0xb7c40d4)
        *(uint8_t*)(r9) = r10;
        r9 = *(uint8_t*)(this);
        r10 = *(void**)(this + 0x10);
        // tst w9, #0x1  (0xb7c40e4)
        // csinc x1, x10, x0, ne  (0xb7c40e8)
        this = r28;
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
        r8 = *(uint8_t*)(sp + 0x88);
        // ldp x10, x9, [sp, #0x90]  (0xb7c40fc)
        // lsr x11, x8, #0x1  (0xb7c4100)
        // tst w8, #0x1  (0xb7c4104)
        r8 = *(void**)(sp + 0x20);
        // csel x1, x8, x9, eq  (0xb7c410c)
        // csel x2, x11, x10, eq  (0xb7c4110)
        this = fp - 0x68;
        this = fn_0x135d3b40(this, r1, r2, r3);  // call  [0x135d3b40]
        r8 = *(uint8_t*)(sp + 0x88);
        // tbz w8, #0x0, 0xb7c412c  (0xb7c4120)
        this = *(void**)(sp + 0x98);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c412c:
        this = *(void**)(sp + 0x48);
        r28 = *(void**)(sp + 0x78);
        rs8 = *(void**)(r21 + 0x614);
        rs9 = *(void**)(r21 + 0x618);
        rs10 = *(void**)(r21 + 0x61c);
        r27 = *(void**)(this + 0xb0);
        this = fn_0x9e93210(this, r1, r2, r3);  // call  [0x9e93210]
        // fmov s11, s0  (0xb7c4148)
        r8 = *(void**)(r26);
        r8 = *(void**)(r8 + 0x110);
        this = r26;
        this = (*(void**)r8)(this);  // indirect call
        // fmov s4, s0  (0xb7c415c)
        // fmov s5, s1  (0xb7c4160)
        r1 = *(void**)(sp + 0x40);
        // fmov s6, s2  (0xb7c4168)
        // fmov s7, s3  (0xb7c416c)
        r8 = sp + 0x88;
        // fmov s0, s8  (0xb7c4174)
        // fmov s1, s9  (0xb7c4178)
        r4 = fp - 0x68;
        // fmov s2, s10  (0xb7c4180)
        // fmov s3, s11  (0xb7c4184)
        this = r28;
        r2 = r27;
        r3 = r26;
        this = fn_0xab507fc(this, r1, r2, r3);  // call  [0xab507fc]
        // ldp x2, x3, [sp, #0x88]  (0xb7c4198)
        r9 = 0xf0f0f0f0f0f0f0f0;
        r1 = *(void**)(r19 + 0x8);
        // movk x9, #0xf0f1  (0xb7c41a4)
        // asr x8, x8, #0x3  (0xb7c41ac)
        // mul x4, x8, x9  (0xb7c41b0)
        this = r19;
        this = fn_0xb7eab70(this, r1, r2, r3);  // call  [0xb7eab70]
        r27 = *(void**)(sp + 0x88);
        if (r27 == 0) goto label_0xb7c4238;
        r8 = *(void**)(sp + 0x90);
        this = r27;
        // cmp r8 == r27
        if (/* cond: b.eq */) goto label_0xb7c4230;
        r26 = r8 - 0x30;
        goto label_0xb7c41ec;
    label_0xb7c41dc:
        r8 = r26 - 0x58;
        r26 = r26 - 0x88;
        // cmp r8 == r27
        if (/* cond: b.eq */) goto label_0xb7c422c;
    label_0xb7c41ec:
        r8 = *(void**)(r26 + 0x10);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c4210;
        r9 = (void*)0x13a567f8;
        this = sp + 0xa7;
        r1 = r26;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7c4210:
        // ldurb w8, [x26, #0xffffffffffffffa8]  (0xb7c4210)
        *(void**)(r26 + 0x10) = r9;
        // tbz w8, #0x0, 0xb7c41dc  (0xb7c421c)
        this = *(void**)(r26 - 0x48);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7c41dc;
    label_0xb7c422c:
        this = *(void**)(sp + 0x88);
    label_0xb7c4230:
        *(void**)(sp + 0x90) = r27;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c4238:
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7c4238)
        // tbz w8, #0x0, 0xb7c4248  (0xb7c423c)
        this = *(void**)(fp - 0x58);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c4248:
        r23 = r23 + 0x8;
        r22 = r22 + 0x1;
        // cmp r23 == r24
        if (/* cond: b.ne */) goto label_0xb7c3cf4;
        r8 = *(void**)(sp + 0x50);
        // cmp r22 == r8
        if (/* cond: b.ne */) goto label_0xb7c3cf4;
    label_0xb7c4264:
        this = *(void**)(r21 + 0x1138);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xa80);
        this = (*(void**)r8)(this);  // indirect call
        // ldp x26, x22, [sp, #0x38]  (0xb7c4274)
        r25 = this;
        r23 = *(void**)(sp + 0x48);
        this = *(void**)(sp + 0x28);
        if (this == 0) goto label_0xb7c445c;
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r1 = r25 + 0x20;
        this = fn_0x10371388(this, r1, r2, r3);  // call  [0x10371388]
        r24 = this;
        if (this == 0) goto label_0xb7c445c;
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0xd8);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r25 = this;
        if (this == 0) goto label_0xb7c445c;
        r8 = *(void**)(r25);
        r8 = *(void**)(r8 + 0x48);
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(this);
        r9 = *(void**)(this + 0x8);
        // lsr x10, x8, #0x1  (0xb7c42cc)
        // tst w8, #0x1  (0xb7c42d0)
        // csel x8, x10, x9, eq  (0xb7c42d4)
        if (r8 == 0) goto label_0xb7c43a4;
        r8 = *(void**)(r25);
        r8 = *(void**)(r8 + 0x68);
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0xb7c43a4  (0xb7c42ec)
        r8 = *(void**)(r23 + 0xd0);
        // movk w20, #0xdead, lsl #0x10  (0xb7c42f8)
        if (r8 != 0) goto label_0xb7c4308;
        r9 = rzr;
        *(void**)(r9) = r20;
    label_0xb7c4308:
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7c4318  (0xb7c430c)
        r8 = rzr;
        *(void**)(r8) = r20;
    label_0xb7c4318:
        r8 = *(void**)(r25);
        r26 = *(void**)(r23 + 0xe0);
        r8 = *(void**)(r8 + 0x48);
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r23 + 0xd0);
        r27 = this;
        if (r8 != 0) goto label_0xb7c4340;
        r9 = rzr;
        *(void**)(r9) = r20;
    label_0xb7c4340:
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7c4350  (0xb7c4344)
        r8 = rzr;
        *(void**)(r8) = r20;
    label_0xb7c4350:
        this = *(void**)(r23 + 0xe0);
        this = fn_0xb9d0434(this, r1, r2, r3);  // call  [0xb9d0434]
        // and w1, w0, #0x1  (0xb7c4358)
        this = r27;
        this = fn_0xcefcf70(this, r1, r2, r3);  // call  [0xcefcf70]
        r2 = this;
        r8 = fp - 0x68;
        this = r26;
        r3 = rzr;
        this = fn_0xb9d06dc(this, r1, r2, r3);  // call  [0xb9d06dc]
        r8 = *(void**)(r25);
        r8 = *(void**)(r8 + 0x78);
        r1 = fp - 0x68;
        this = r25;
        r26 = *(void**)(sp + 0x38);
        this = (*(void**)r8)(this);  // indirect call
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7c4394)
        // tbz w8, #0x0, 0xb7c43a4  (0xb7c4398)
        this = *(void**)(fp - 0x58);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c43a4:
        r8 = *(void**)(r25);
        r9 = *(void**)(r8 + 0x70);
        r8 = fp - 0x68;
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7c43b8)
        r9 = *(void**)(fp - 0x60);
        // lsr x10, x8, #0x1  (0xb7c43c0)
        // tst w8, #0x1  (0xb7c43c4)
        // csel x8, x10, x9, eq  (0xb7c43c8)
        if (r8 == 0) goto label_0xb7c444c;
        r8 = *(void**)(r25);
        r8 = *(void**)(r8 + 0x38);
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7c444c  (0xb7c43e0)
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0xb8);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r3 = this;
        if (this == 0) goto label_0xb7c444c;
        r2 = *(void**)(r23 + 0xb0);
        rs0 = *(void**)(r21 + 0x620);
        rs1 = *(void**)(r21 + 0x624);
        rs2 = *(void**)(r21 + 0x628);
        this = *(void**)(sp + 0x30);
        r8 = sp + 0x88;
        r4 = fp - 0x68;
        r1 = r22;
        this = fn_0xaa4a010(this, r1, r2, r3);  // call  [0xaa4a010]
        // ldp x2, x3, [sp, #0x88]  (0xb7c4420)
        r9 = 0xf0f0f0f0f0f0f0f0;
        r1 = *(void**)(r19 + 0x8);
        // movk x9, #0xf0f1  (0xb7c442c)
        // asr x8, x8, #0x3  (0xb7c4434)
        // mul x4, x8, x9  (0xb7c4438)
        this = r19;
        this = fn_0xb7eab70(this, r1, r2, r3);  // call  [0xb7eab70]
        this = sp + 0x88;
        this = fn_0xab54264(this, r1, r2, r3);  // call  [0xab54264]
    label_0xb7c444c:
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7c444c)
        // tbz w8, #0x0, 0xb7c445c  (0xb7c4450)
        this = *(void**)(fp - 0x58);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c445c:
        r23 = *(void**)(r23 + 0xb0);
        this = *(void**)(sp + 0x78);
        r1 = (void*)0x141cb900;
        r8 = sp + 0x68;
        this = fn_0xab51520(this, r1, r2, r3);  // call  [0xab51520]
        r8 = fp - 0x68;
        r2 = sp + 0x68;
        this = r22;
        r1 = r23;
        this = fn_0xa99a49c(this, r1, r2, r3);  // call  [0xa99a49c]
        // ldp x23, x24, [x29, #0xffffffffffffff98]  (0xb7c4488)
        r9 = 0xf0f0f0f0f0f0f0f0;
        r1 = *(void**)(r19 + 0x8);
        // movk x9, #0xf0f1  (0xb7c4494)
        // asr x8, x8, #0x3  (0xb7c449c)
        // mul x4, x8, x9  (0xb7c44a0)
        this = r19;
        r2 = r23;
        r3 = r24;
        this = fn_0xb7eab70(this, r1, r2, r3);  // call  [0xb7eab70]
        if (r23 == 0) goto label_0xb7c4530;
        // cmp r24 == r23
        this = r23;
        if (/* cond: b.eq */) goto label_0xb7c4528;
        r25 = r22;
        r24 = r24 - 0x30;
        r22 = (void*)0x13a567f8;
        goto label_0xb7c44ec;
    label_0xb7c44dc:
        r8 = r24 - 0x58;
        r24 = r24 - 0x88;
        // cmp r8 == r23
        if (/* cond: b.eq */) goto label_0xb7c4520;
    label_0xb7c44ec:
        r8 = *(void**)(r24 + 0x10);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c4508;
        this = sp + 0x88;
        r1 = r24;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7c4508:
        // ldurb w8, [x24, #0xffffffffffffffa8]  (0xb7c4508)
        *(void**)(r24 + 0x10) = r20;
        // tbz w8, #0x0, 0xb7c44dc  (0xb7c4510)
        this = *(void**)(r24 - 0x48);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7c44dc;
    label_0xb7c4520:
        this = *(void**)(fp - 0x68);
        r22 = r25;
    label_0xb7c4528:
        *(void**)(fp - 0x60) = r23;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c4530:
        r23 = *(void**)(sp + 0x70);
        if (r23 == 0) goto label_0xb7c4560;
        r1 = r23 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c4560;
        r8 = *(void**)(r23);
        this = r23;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r23;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c4560:
        r8 = *(void**)(sp + 0x48);
        r21 = *(void**)(r21 + 0x1118);
        this = *(void**)(sp + 0x78);
        r20 = *(void**)(r8 + 0xb0);
        r1 = (void*)0x141cb900;
        r8 = sp + 0x58;
        this = fn_0xab51520(this, r1, r2, r3);  // call  [0xab51520]
        r8 = *(void**)(r21 + 0x2b8);
        r9 = *(void**)(r8 + 0x10);
        r8 = fp - 0x68;
        this = r21 + 0x2b8;
        r3 = sp + 0x58;
        r1 = r22;
        r2 = r20;
        this = (*(void**)r8)(this);  // indirect call
        r20 = *(void**)(sp + 0x60);
        if (r20 == 0) goto label_0xb7c45d0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c45d0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c45d0:
        // ldp x2, x3, [x29, #0xffffffffffffff98]  (0xb7c45d0)
        r9 = 0xf0f0f0f0f0f0f0f0;
        r1 = *(void**)(r19 + 0x8);
        // movk x9, #0xf0f1  (0xb7c45dc)
        // asr x8, x8, #0x3  (0xb7c45e4)
        // mul x4, x8, x9  (0xb7c45e8)
        this = r19;
        this = fn_0xb7eab70(this, r1, r2, r3);  // call  [0xb7eab70]
        r20 = *(void**)(fp - 0x68);
        if (r20 == 0) goto label_0xb7c4670;
        r8 = *(void**)(fp - 0x60);
        this = r20;
        // cmp r8 == r20
        if (/* cond: b.eq */) goto label_0xb7c4668;
        r19 = r8 - 0x30;
        r22 = (void*)0x13a567f8;
        goto label_0xb7c4630;
    label_0xb7c4620:
        r8 = r19 - 0x58;
        r19 = r19 - 0x88;
        // cmp r8 == r20
        if (/* cond: b.eq */) goto label_0xb7c4664;
    label_0xb7c4630:
        r8 = *(void**)(r19 + 0x10);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c464c;
        this = sp + 0x88;
        r1 = r19;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7c464c:
        // ldurb w8, [x19, #0xffffffffffffffa8]  (0xb7c464c)
        *(void**)(r19 + 0x10) = r21;
        // tbz w8, #0x0, 0xb7c4620  (0xb7c4654)
        this = *(void**)(r19 - 0x48);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7c4620;
    label_0xb7c4664:
        this = *(void**)(fp - 0x68);
    label_0xb7c4668:
        *(void**)(fp - 0x60) = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7c4670:
        this = sp + 0xa8;
        this = fn_0x9a10384(this, r1, r2, r3);  // call  [0x9a10384]
    label_0xb7c4678:
        r19 = *(void**)(sp + 0x80);
        if (r19 == 0) goto label_0xb7c46a8;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c46a8;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c46a8:
        r8 = *(void**)(r26 + 0x28);
        r9 = *(void**)(fp - 0x30);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c4878;
        // ldp x20, x19, [sp, #0x1b0]  (0xb7c46b8)
        // ldp x22, x21, [sp, #0x1a0]  (0xb7c46bc)
        // ldp x24, x23, [sp, #0x190]  (0xb7c46c0)
        // ldp x26, x25, [sp, #0x180]  (0xb7c46c4)
        // ldp x28, x27, [sp, #0x170]  (0xb7c46c8)
        // ldp x29, x30, [sp, #0x160]  (0xb7c46cc)
        // ldp d9, d8, [sp, #0x150]  (0xb7c46d0)
        // ldp d11, d10, [sp, #0x140]  (0xb7c46d4)
        sp = sp + 0x1c0;
        return this;
}

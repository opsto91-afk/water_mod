// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d1e8
// fn_va = 0x8a3d1e8
// return type (guess): unknown (no ret found)
void* fn_0x8a3d1e8(void* this, void* r1) {
        *(void**)(sp + 0x40) = rd8;
        // stp x29, x30, [sp, #0x50]  (0x8a3d1f0)
        // stp x22, x21, [sp, #0x60]  (0x8a3d1f4)
        // stp x20, x19, [sp, #0x70]  (0x8a3d1f8)
        fp = sp + 0x50;
        // mrs x22, tpidr_el0  (0x8a3d200)
        // fmov s8, s0  (0x8a3d204)
        r20 = r1;
        r8 = *(void**)(r22 + 0x28);
        r21 = this;
        *(void**)(fp - 0x18) = r8;
        // ldp x8, x19, [x1]  (0x8a3d218)
        // stp x8, x19, [sp]  (0x8a3d21c)
        if (r19 == 0) goto label_0x8a3d230;
        r1 = r19 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3d230:
        this = *(void**)(r21 + 0x8);
        r9 = *(void**)(r20 + 0x10);
        r8 = *(void**)(this);
        *(void**)(sp + 0x10) = r9;
        r8 = *(void**)(r8 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3d27c;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3d27c  (0x8a3d260)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        r20 = this;
        if (r19 != 0) goto label_0x8a3d284;
        goto label_0x8a3d28c;
    label_0x8a3d27c:
        r20 = rzr;
        if (r19 == 0) goto label_0x8a3d28c;
    label_0x8a3d284:
        this = r19;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3d28c:
        if (r20 == 0) goto label_0x8a3d2c0;
        // fmov s0, s8  (0x8a3d290)
        r8 = sp + 0x18;
        this = r20;
        this = fn_0x9c7568c(this, r1, r2, r3);  // call  [0x9c7568c]
        r8 = *(void**)(sp + 0x20);
        this = *(void**)(sp + 0x18);
        // orr x1, x8, #0x100000000  (0x8a3d2a8)
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0x8a3d2d8;
        goto label_0x8a3d318;
    label_0x8a3d2c0:
        this = rzr;
        r1 = rzr;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3d318;
    label_0x8a3d2d8:
        // ldp x20, x19, [sp, #0x70]  (0x8a3d2d8)
        rd8 = *(void**)(sp + 0x40);
        // ldp x22, x21, [sp, #0x60]  (0x8a3d2e0)
        // ldp x29, x30, [sp, #0x50]  (0x8a3d2e4)
        sp = sp + 0x80;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a7500
// fn_va = 0xb7a7500
// return type (guess): unknown (no ret found)
void* fn_0xb7a7500(void* this) {
        // stp x29, x30, [sp, #0x20]  (0xb7a7504)
        // stp x24, x23, [sp, #0x30]  (0xb7a7508)
        // stp x22, x21, [sp, #0x40]  (0xb7a750c)
        // stp x20, x19, [sp, #0x50]  (0xb7a7510)
        fp = sp + 0x20;
        // mrs x22, tpidr_el0  (0xb7a7518)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r8 = (void*)0x13a55170;
        this = *(void**)(this + 0x968);
        *(void**)(r19) = r8;
        r20 = *(void**)(r19 + 0x978);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        r8 = sp;
        this = r20;
        this = fn_0xb7a3f38(this, r1, r2, r3);  // call  [0xb7a3f38]
        this = *(void**)(sp);
        if (this == 0) goto label_0xb7a7568;
        r1 = r19;
        this = fn_0xa9cbf54(this, r1, r2, r3);  // call  [0xa9cbf54]
    label_0xb7a7568:
        r20 = *(void**)(sp + 0x8);
        if (r20 == 0) goto label_0xb7a7580;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7a76c8;
    label_0xb7a7580:
        r21 = *(void**)(r19 + 0x5b0);
        this = *(void**)(r21 + 0x20);
        if (this == 0) goto label_0xb7a75a4;
    label_0xb7a758c:
        rq0 = *(void**)(r21 + 0xc8);
        *(void**)(sp) = rq0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a75a4:
        // ldp x23, x24, [x21, #0xc8]  (0xb7a75a4)
        goto label_0xb7a75b0;
    label_0xb7a75ac:
        r24 = r24 - 0x10;
    label_0xb7a75b0:
        // cmp r24 == r23
        if (/* cond: b.eq */) goto label_0xb7a75ec;
        r20 = *(void**)(r24 - 0x8);
        if (r20 == 0) goto label_0xb7a75ac;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a75ac;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7a75ac;
    label_0xb7a75ec:
        // movi v0.2d, #0x0  (0xb7a75ec)
        *(void**)(r21 + 0xd0) = r23;
        *(void**)(r21 + 0x98) = rq0;
        *(void**)(r21 + 0xa8) = rq0;
        *(void**)(r21 + 0xb8) = rq0;
        r20 = *(void**)(r19 + 0x5b8);
        *(void**)(r19 + 0x5b0) = rq0;
        if (r20 == 0) goto label_0xb7a7634;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7634;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7634:
        r20 = *(void**)(r19 + 0xc48);
        *(void**)(r19 + 0xc48) = rzr;
        if (r20 == 0) goto label_0xb7a7674;
        r21 = *(void**)(r20 + 0x40);
        *(void**)(r20 + 0x40) = rzr;
        if (r21 == 0) goto label_0xb7a765c;
        this = r21;
        this = fn_0x117ab030(this, r1, r2, r3);  // call  [0x117ab030]
        this = r21;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a765c:
        this = r20 + 0x20;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        this = r20;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7674:
        r20 = *(void**)(r19 + 0xc40);
        if (r20 == 0) goto label_0xb7a76a4;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a76a4;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a76a4:
        r20 = *(void**)(r19 + 0xa40);
        *(void**)(r19 + 0xa40) = rzr;
        if (r20 == 0) goto label_0xb7a770c;
        this = *(void**)(r20 + 0x20);
        // cmp this == r20
        if (/* cond: b.eq */) goto label_0xb7a76f0;
        if (this == 0) goto label_0xb7a7704;
        goto label_0xb7a76f8;
    label_0xb7a76c8:
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        r21 = *(void**)(r19 + 0x5b0);
        this = *(void**)(r21 + 0x20);
        if (this != 0) goto label_0xb7a758c;
        goto label_0xb7a75a4;
    label_0xb7a76f0:
        this = r20;
    label_0xb7a76f8:
        r9 = *(void**)(this);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a7704:
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a770c:
        this = *(void**)(r19 + 0xa30);
        this = fn_0xb7ee690(this, r1, r2, r3);  // call  [0xb7ee690]
        this = *(void**)(r19 + 0xa10);
        if (this == 0) goto label_0xb7a772c;
    label_0xb7a771c:
        r20 = *(void**)(this);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        this = r20;
        if (r20 != 0) goto label_0xb7a771c;
    label_0xb7a772c:
        this = *(void**)(r19 + 0xa00);
        *(void**)(r19 + 0xa00) = rzr;
        if (this == 0) goto label_0xb7a773c;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a773c:
        this = *(void**)(r19 + 0x9e8);
        if (this == 0) goto label_0xb7a774c;
        *(void**)(r19 + 0x9f0) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a774c:
        r20 = *(void**)(r19 + 0x9e0);
        if (r20 == 0) goto label_0xb7a777c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a777c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a777c:
        r20 = *(void**)(r19 + 0x988);
        if (r20 == 0) goto label_0xb7a77ac;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a77ac;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a77ac:
        r20 = *(void**)(r19 + 0x960);
        if (r20 == 0) goto label_0xb7a77dc;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a77dc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a77dc:
        r20 = *(void**)(r19 + 0x940);
        *(void**)(r19 + 0x940) = rzr;
        if (r20 == 0) goto label_0xb7a77f8;
        this = r20;
        this = fn_0xb7ea8b8(this, r1, r2, r3);  // call  [0xb7ea8b8]
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a77f8:
        this = *(void**)(r19 + 0x938);
        *(void**)(r19 + 0x938) = rzr;
        if (this == 0) goto label_0xb7a7810;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x8);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a7810:
        this = *(void**)(r19 + 0x930);
        *(void**)(r19 + 0x930) = rzr;
        if (this == 0) goto label_0xb7a7828;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x8);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a7828:
        this = *(void**)(r19 + 0x918);
        if (this == 0) goto label_0xb7a7838;
        *(void**)(r19 + 0x920) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7838:
        this = r19 + 0x790;
        this = fn_0x9bad744(this, r1, r2, r3);  // call  [0x9bad744]
        this = r19 + 0x748;
        this = fn_0x9bad744(this, r1, r2, r3);  // call  [0x9bad744]
        this = r19 + 0x700;
        this = fn_0x9bad744(this, r1, r2, r3);  // call  [0x9bad744]
        r20 = *(void**)(r19 + 0x5b8);
        if (r20 == 0) goto label_0xb7a7880;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7880;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7880:
        this = r19 + 0x4d0;
        this = fn_0xb7a7308(this, r1, r2, r3);  // call  [0xb7a7308]
        r1 = *(void**)(r19 + 0x3e0);
        this = r19 + 0x3d8;
        this = fn_0x9a39fac(this, r1, r2, r3);  // call  [0x9a39fac]
        r1 = *(void**)(r19 + 0x3c8);
        this = r19 + 0x3c0;
        this = fn_0x9a3a02c(this, r1, r2, r3);  // call  [0x9a3a02c]
        r8 = *(uint8_t*)(r19 + 0x3a8);
        // tbnz w8, #0x0, 0xb7a7bc4  (0xb7a78a4)
        r8 = *(uint8_t*)(r19 + 0x390);
        // tbnz w8, #0x0, 0xb7a7bd4  (0xb7a78ac)
    label_0xb7a78b0:
        r8 = *(uint8_t*)(r19 + 0x378);
        // tbnz w8, #0x0, 0xb7a7be4  (0xb7a78b4)
    label_0xb7a78b8:
        r8 = *(uint8_t*)(r19 + 0x368);
        if (r8 == 0) goto label_0xb7a78c8;
    label_0xb7a78c0:
        this = r19 + 0x338;
        this = fn_0x135a12f0(this, r1, r2, r3);  // call  [0x135a12f0]
    label_0xb7a78c8:
        r20 = *(void**)(r19 + 0x328);
        if (r20 == 0) goto label_0xb7a78f8;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a78f8;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a78f8:
        r21 = *(void**)(r19 + 0x308);
        if (r21 == 0) goto label_0xb7a7930;
        r20 = *(void**)(r19 + 0x310);
        this = r21;
        // cmp r20 == r21
        if (/* cond: b.eq */) goto label_0xb7a7928;
    label_0xb7a7910:
        r20 = r20 - 0x20;
        this = r20;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        // cmp r20 == r21
        if (/* cond: b.ne */) goto label_0xb7a7910;
        this = *(void**)(r19 + 0x308);
    label_0xb7a7928:
        *(void**)(r19 + 0x310) = r21;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7930:
        r20 = *(void**)(r19 + 0x300);
        if (r20 == 0) goto label_0xb7a7960;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7960;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7960:
        r20 = *(void**)(r19 + 0x2f0);
        if (r20 == 0) goto label_0xb7a7990;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7990;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7990:
        r20 = *(void**)(r19 + 0x2e0);
        if (r20 == 0) goto label_0xb7a79c0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a79c0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a79c0:
        r20 = *(void**)(r19 + 0x2d0);
        if (r20 == 0) goto label_0xb7a79f0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a79f0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a79f0:
        r20 = *(void**)(r19 + 0x2c0);
        if (r20 == 0) goto label_0xb7a7a20;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7a20;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7a20:
        r20 = *(void**)(r19 + 0x2b0);
        if (r20 == 0) goto label_0xb7a7a50;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7a50;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7a50:
        r20 = *(void**)(r19 + 0x2a0);
        if (r20 == 0) goto label_0xb7a7a80;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7a80;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7a80:
        r20 = *(void**)(r19 + 0x290);
        if (r20 == 0) goto label_0xb7a7ab0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7ab0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7ab0:
        r20 = *(void**)(r19 + 0x280);
        if (r20 == 0) goto label_0xb7a7ae0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7ae0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7ae0:
        r20 = *(void**)(r19 + 0x270);
        if (r20 == 0) goto label_0xb7a7b10;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a7b10;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a7b10:
        this = *(void**)(r19 + 0x250);
        if (this == 0) goto label_0xb7a7b20;
        *(void**)(r19 + 0x258) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b20:
        this = *(void**)(r19 + 0x238);
        if (this == 0) goto label_0xb7a7b30;
        *(void**)(r19 + 0x240) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b30:
        this = *(void**)(r19 + 0x220);
        if (this == 0) goto label_0xb7a7b40;
        *(void**)(r19 + 0x228) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b40:
        r1 = *(void**)(r19 + 0x208);
        if (r1 == 0) goto label_0xb7a7b5c;
        r20 = r19 + 0x208;
        this = r20;
        this = fn_0xa3411ac(this, r1, r2, r3);  // call  [0xa3411ac]
        this = *(void**)(r20);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b5c:
        this = *(void**)(r19 + 0x1f0);
        if (this == 0) goto label_0xb7a7b6c;
        *(void**)(r19 + 0x1f8) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b6c:
        this = *(void**)(r19 + 0x1d8);
        if (this == 0) goto label_0xb7a7b7c;
        *(void**)(r19 + 0x1e0) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b7c:
        this = *(void**)(r19 + 0x1c0);
        if (this == 0) goto label_0xb7a7b8c;
        *(void**)(r19 + 0x1c8) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b8c:
        this = *(void**)(r19 + 0x1a8);
        if (this == 0) goto label_0xb7a7b9c;
        *(void**)(r19 + 0x1b0) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a7b9c:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a7bf8;
        // ldp x20, x19, [sp, #0x50]  (0xb7a7bac)
        // ldp x22, x21, [sp, #0x40]  (0xb7a7bb0)
        // ldp x24, x23, [sp, #0x30]  (0xb7a7bb4)
        // ldp x29, x30, [sp, #0x20]  (0xb7a7bb8)
        sp = sp + 0x60;
        return this;
}

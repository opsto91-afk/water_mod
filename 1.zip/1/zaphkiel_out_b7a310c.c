// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a310c
// fn_va = 0xb7a310c
// return type (guess): unknown (no ret found)
void* fn_0xb7a310c(void* this) {
        // stp x29, x30, [sp, #0x50]  (0xb7a3110)
        *(void**)(sp + 0x60) = r25;
        // stp x24, x23, [sp, #0x70]  (0xb7a3118)
        // stp x22, x21, [sp, #0x80]  (0xb7a311c)
        // stp x20, x19, [sp, #0x90]  (0xb7a3120)
        fp = sp + 0x50;
        // mrs x24, tpidr_el0  (0xb7a3128)
        r19 = r2;
        r21 = r1;
        r8 = *(void**)(r24 + 0x28);
        r20 = this;
        *(void**)(fp - 0x8) = r8;
        r8 = (void*)0x140aa638;
        // ldarb w8, [x8]  (0xb7a3148)
        // tbz w8, #0x0, 0xb7a33b4  (0xb7a314c)
    label_0xb7a3150:
        r1 = (void*)0x140ac230;
        this = sp;
        this = fn_0x135c7250(this, r1, r2, r3);  // call  [0x135c7250]
        this = r20;
        r1 = r21;
        r2 = r19;
        this = fn_0xb7b1c18(this, r1, r2, r3);  // call  [0xb7b1c18]
        r8 = *(void**)(r20 + 0x598);
        // scvtf s0, w8  (0xb7a3174)
        // fmov s1, w8  (0xb7a317c)
        // fcmpe s0, s1  (0xb7a3180)
        rs1 = *(void**)(r19 + 0x48);
        if (/* cond: b.hi */) goto label_0xb7a31a0;
        // fmov s2, w8  (0xb7a318c)
        // fmov s3, #4  (0xb7a3190)
        // fdiv s2, s0, s2  (0xb7a3194)
        // fmul s2, s3, s2  (0xb7a3198)
        goto label_0xb7a31b8;
    label_0xb7a31a0:
        // fmov s3, #8  (0xb7a31a4)
        // fmov s2, w8  (0xb7a31a8)
        // fcmpe s0, s2  (0xb7a31ac)
        // fmov s2, #16  (0xb7a31b0)
        // fcsel s2, s3, s2, ls  (0xb7a31b4)
    label_0xb7a31b8:
        // fsub s0, s0, s2  (0xb7a31b8)
        // fmul s0, s0, s1  (0xb7a31bc)
        *(void**)(r20 + 0x5a0) = rs0;
        this = r20;
        this = fn_0xb7aef04(this, r1, r2, r3);  // call  [0xb7aef04]
        r8 = *(void**)(r20);
        rs0 = *(void**)(r19 + 0x44);
        r8 = *(void**)(r8 + 0xa0);
        this = r20;
        r1 = r21;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r20 + 0xd8c);
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7a31fc;
        this = r20;
        r1 = r19;
        this = fn_0xb7d30d4(this, r1, r2, r3);  // call  [0xb7d30d4]
    label_0xb7a31fc:
        r22 = (void*)0x1407f080;
        this = r22;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r23 = *(void**)(r8 + 0x160);
        if (r23 == 0) goto label_0xb7a3260;
        r8 = *(uint8_t*)(r23);
        if (r8 == 0) goto label_0xb7a3260;
        r21 = *(void**)(r8 + 0x168);
        if (r21 == 0) goto label_0xb7a3368;
        r1 = r21 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r9 = *(uint8_t*)(r23);
        *(void**)(sp + 0x20) = r22;
        this = *(void**)(r8 + 0x170);
        *(uint8_t*)(sp + 0x28) = r25;
        // stp x23, x21, [sp, #0x30]  (0xb7a3250)
        *(void**)(sp + 0x40) = this;
        if (r9 != 0) goto label_0xb7a3384;
        goto label_0xb7a3280;
    label_0xb7a3260:
        this = (void*)0x1407f080;
        *(void**)(sp + 0x20) = rzr;
        *(uint8_t*)(sp + 0x28) = rzr;
        // stp xzr, xzr, [sp, #0x38]  (0xb7a3270)
        *(void**)(sp + 0x30) = rzr;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        r21 = rzr;
    label_0xb7a3280:
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r1 = *(void**)(r20 + 0x8);
        r22 = this;
        r2 = r20 + 0x10;
        this = fn_0x11813aec(this, r1, r2, r3);  // call  [0x11813aec]
        r23 = *(void**)(r20 + 0x940);
        *(void**)(r20 + 0x940) = r22;
        if (r23 == 0) goto label_0xb7a32b4;
        this = r23;
        this = fn_0xb7ea8b8(this, r1, r2, r3);  // call  [0xb7ea8b8]
        this = r23;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7a32b4:
        r1 = *(uint8_t*)(r19 + 0x4e);
        this = r20;
        this = fn_0xb7d3ad8(this, r1, r2, r3);  // call  [0xb7d3ad8]
        // stp xzr, xzr, [sp, #0x30]  (0xb7a32c0)
        if (r21 == 0) goto label_0xb7a3324;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a32f0;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a32f0:
        r19 = *(void**)(sp + 0x38);
        *(void**)(sp + 0x40) = rzr;
        if (r19 == 0) goto label_0xb7a3324;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a3324;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a3324:
        r8 = *(uint8_t*)(sp + 0x28);
        if (r8 == 0) goto label_0xb7a3334;
        this = *(void**)(sp + 0x20);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7a3334:
        this = sp;
        this = fn_0x135c7324(this, r1, r2, r3);  // call  [0x135c7324]
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a3490;
        // ldp x20, x19, [sp, #0x90]  (0xb7a334c)
        r25 = *(void**)(sp + 0x60);
        // ldp x22, x21, [sp, #0x80]  (0xb7a3354)
        // ldp x24, x23, [sp, #0x70]  (0xb7a3358)
        // ldp x29, x30, [sp, #0x50]  (0xb7a335c)
        sp = sp + 0xa0;
        return this;
}

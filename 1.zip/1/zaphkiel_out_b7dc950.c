// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7dc950
// fn_va = 0xb7dc950
// return type (guess): unknown (no ret found)
void* fn_0xb7dc950(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dc950)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = *(void**)(this + 0x20);
        r8 = (void*)0x13a560c0;
        *(void**)(r19) = r8;
        if (this == 0) goto label_0xb7dc97c;
        *(void**)(r19 + 0x28) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dc97c:
        this = *(void**)(r19 + 0x10);
        r8 = (void*)0x13a58950;
        *(void**)(r19) = r8;
        if (this == 0) goto label_0xb7dc994;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7dc994:
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7dc99c)
        return fn_0x135d37b0(/* tail call */);
        this = rzr;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a58dd0
// fn_va = 0x9a58dd0
// return type (guess): unknown (no ret found)
void* fn_0x9a58dd0(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0x9a58dd0)
        // stp x22, x21, [sp, #0x10]  (0x9a58dd4)
        // stp x20, x19, [sp, #0x20]  (0x9a58dd8)
        r9 = *(void**)(this);
        r19 = r3;
        *(uint8_t*)(this + 0x60) = r8;
        r20 = r2;
        r21 = this;
        r8 = *(void**)(r9 + 0xa0);
        r22 = r1;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r21);
        this = r21;
        r1 = r22;
        r2 = r20;
        r3 = r19;
        r4 = *(void**)(r8 + 0xa8);
        // ldp x20, x19, [sp, #0x20]  (0x9a58e1c)
        // ldp x22, x21, [sp, #0x10]  (0x9a58e20)
        // ldp x29, x30, [sp], #0x30  (0x9a58e24)
        goto *r_indirect;  // indirect branch/tailcall
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0x9a58e2c)
        // stp x22, x21, [sp, #0x10]  (0x9a58e30)
        // stp x20, x19, [sp, #0x20]  (0x9a58e34)
        r21 = this;
        r19 = r3;
        r8 = *(void**)(r21 - 0x10);
        *(uint8_t*)(r21 + 0x60) = r9;
        this = r21;
        r20 = r2;
        r22 = r1;
        r8 = *(void**)(r8 + 0xa0);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r21);
        this = r21;
        r1 = r22;
        r2 = r20;
        r4 = *(void**)(r8 + 0xa8);
        r3 = r19;
        // ldp x20, x19, [sp, #0x20]  (0x9a58e7c)
        // ldp x22, x21, [sp, #0x10]  (0x9a58e80)
        // ldp x29, x30, [sp], #0x30  (0x9a58e84)
        goto *r_indirect;  // indirect branch/tailcall
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a58e8c)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = r1;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0x9a58eb0  (0x9a58ea4)
        *(void**)(r19 + 0x18) = r8;
    label_0x9a58eb0:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9a58eb4)
        return this;
}

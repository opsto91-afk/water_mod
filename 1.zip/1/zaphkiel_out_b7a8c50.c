// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a8c50
// fn_va = 0xb7a8c50
// return type (guess): unknown (no ret found)
void* fn_0xb7a8c50(void* this, void* r1) {
        *(void**)(sp + 0x100) = rd10;
        // stp d9, d8, [sp, #0x110]  (0xb7a8c58)
        // stp x29, x30, [sp, #0x120]  (0xb7a8c5c)
        // stp x28, x23, [sp, #0x130]  (0xb7a8c60)
        // stp x22, x21, [sp, #0x140]  (0xb7a8c64)
        // stp x20, x19, [sp, #0x150]  (0xb7a8c68)
        fp = sp + 0x120;
        // mrs x22, tpidr_el0  (0xb7a8c70)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x28) = r8;
        // ldp s8, s9, [x1, #0x14]  (0xb7a8c80)
        r8 = *(void**)(this + 0x978);
        // ldp s10, s0, [x1, #0x1c]  (0xb7a8c88)
        r20 = *(uint8_t*)(r1 + 0x4d);
        // ldp s1, s2, [x1, #0x24]  (0xb7a8c90)
        r8 = *(void**)(r8 + 0xa88);
        // fmov w9, s8  (0xb7a8c98)
        // fmov w10, s9  (0xb7a8c9c)
        // stp s8, s9, [sp, #0x54]  (0xb7a8ca0)
        // fmov w11, s10  (0xb7a8ca4)
        *(void**)(sp + 0x5c) = rs10;
        // cmp r20 == <complex operand>
        // stp s0, s1, [sp, #0x48]  (0xb7a8cb0)
        // cset w21, eq  (0xb7a8cb4)
        *(void**)(sp + 0x50) = rs2;
        // stlr w9, [x8]  (0xb7a8cbc)
        r9 = r8 + 0x4;
        r8 = r8 + 0x8;
        // stlr w10, [x9]  (0xb7a8cc8)
        // fmov w9, s0  (0xb7a8ccc)
        // stlr w11, [x8]  (0xb7a8cd0)
        // fmov w11, s1  (0xb7a8cd4)
        r8 = *(void**)(this + 0x978);
        r8 = *(void**)(r8 + 0xa88);
        r10 = r8 + 0xc;
        // stlr w9, [x10]  (0xb7a8ce4)
        // fmov w10, s2  (0xb7a8ce8)
        r9 = r8 + 0x10;
        r8 = r8 + 0x14;
        // stlr w11, [x9]  (0xb7a8cf4)
        // stlr w10, [x8]  (0xb7a8cf8)
        r8 = *(void**)(this + 0x978);
        r8 = *(void**)(r8 + 0xa88);
        r8 = r8 + 0x18;
        // stlrb w21, [x8]  (0xb7a8d08)
        if (/* cond: b.eq */) goto label_0xb7a8d84;
        this = sp;
        r1 = sp + 0x54;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r8 = *(void**)(r19 + 0x5e4);
        r9 = *(void**)(sp);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a8d4c;
        r8 = *(void**)(r19 + 0x5e8);
        r9 = *(void**)(sp + 0x4);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a8d4c;
        r8 = *(void**)(r19 + 0x5ec);
        r9 = *(void**)(sp + 0x8);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0xb7a8d84;
    label_0xb7a8d4c:
        r2 = *(void**)(r19 + 0x5b0);
        this = *(void**)(r19 + 0x968);
        r1 = sp + 0x54;
        r23 = r19 + 0x5e4;
        this = fn_0xb7a9068(this, r1, r2, r3);  // call  [0xb7a9068]
        this = sp;
        r1 = sp + 0x54;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        // ldp s8, s9, [sp, #0x54]  (0xb7a8d6c)
        r8 = *(void**)(sp);
        r9 = *(void**)(sp + 0x8);
        rs10 = *(void**)(sp + 0x5c);
        *(void**)(r23) = r8;
        *(void**)(r23 + 0x8) = r9;
    label_0xb7a8d84:
        rs0 = *(void**)(r19 + 0x5d8);
        rs1 = *(void**)(r19 + 0x5dc);
        rs2 = *(void**)(r19 + 0x5e0);
        r8 = *(void**)(r19 + 0x598);
        // fsub s0, s8, s0  (0xb7a8d94)
        // fsub s1, s9, s1  (0xb7a8d98)
        // fsub s2, s10, s2  (0xb7a8d9c)
        // fmul s0, s0, s0  (0xb7a8da0)
        // fmul s1, s1, s1  (0xb7a8da4)
        // fadd s0, s0, s1  (0xb7a8da8)
        // fmul s1, s2, s2  (0xb7a8dac)
        // fadd s0, s0, s1  (0xb7a8db0)
        // scvtf s1, w8  (0xb7a8db4)
        // fmov s2, w8  (0xb7a8dbc)
        // fsqrt s0, s0  (0xb7a8dc0)
        // fcmpe s1, s2  (0xb7a8dc4)
        if (/* cond: b.hi */) goto label_0xb7a8e00;
        // fmov s2, w8  (0xb7a8dcc)
        // fdiv s1, s1, s2  (0xb7a8dd0)
        // fmov s2, #4  (0xb7a8dd4)
        // fmul s1, s2, s1  (0xb7a8dd8)
        // fcmpe s0, s1  (0xb7a8ddc)
        if (/* cond: b.gt */) goto label_0xb7a8e20;
    label_0xb7a8de4:
        // cmp r20 == <complex operand>
        r1 = sp + 0x54;
        r2 = sp + 0x48;
        // cset w3, eq  (0xb7a8df0)
        this = r19;
        this = fn_0xb7a9370(this, r1, r2, r3);  // call  [0xb7a9370]
        goto label_0xb7a8fdc;
    label_0xb7a8e00:
        // fmov s2, w8  (0xb7a8e04)
        // fcmpe s1, s2  (0xb7a8e08)
        // fmov s1, #16  (0xb7a8e0c)
        // fmov s2, #8  (0xb7a8e10)
        // fcsel s1, s2, s1, ls  (0xb7a8e14)
        // fcmpe s0, s1  (0xb7a8e18)
        if (/* cond: b.le */) goto label_0xb7a8de4;
    label_0xb7a8e20:
        r8 = "moveRenderingArea task";  // 0x24a7788
        // stp x8, x9, [sp]  (0xb7a8e2c)
        rd0 = *(void**)(r9 + 0x700);
        r9 = *(void**)(r19 + 0x978);
        r8 = *(void**)(r8 + 0x670);
        // stp xzr, xzr, [sp, #0x10]  (0xb7a8e44)
        r23 = fp - 0x80;
        r10 = *(void**)(sp + 0x5c);
        r20 = *(void**)(r9 + 0x3b0);
        *(void**)(sp + 0x20) = rzr;
        *(void**)(sp + 0x28) = r8;
        r8 = *(void**)(sp + 0x54);
        *(void**)(sp + 0x30) = rd0;
        this = r20;
        *(uint8_t*)(sp + 0x38) = rzr;
        *(void**)(sp + 0x40) = rzr;
        r9 = *(void**)(r20);
        *(void**)(r23 + 0x3) = r8;
        *(void**)(r23 + 0xb) = r10;
        r8 = *(void**)(r9 + 0x48);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(fp - 0x80);
        r9 = *(void**)(r23 + 0x7);
        r10 = *(void**)(sp + 0x50);
        // sturb w21, [x29, #0xffffffffffffffa0]  (0xb7a8e90)
        *(void**)(r23 + 0x21) = r8;
        r8 = *(void**)(sp + 0x48);
        *(void**)(fp - 0x48) = r10;
        // stp x9, x8, [x29, #0xffffffffffffffa8]  (0xb7a8ea0)
        r8 = (void*)0x13a56470;
        // stp xzr, xzr, [sp, #0x80]  (0xb7a8eac)
        // stp xzr, xzr, [sp, #0x60]  (0xb7a8eb0)
        // stp x8, x19, [x29, #0xffffffffffffff90]  (0xb7a8eb4)
        r8 = sp + 0x90;
        r1 = sp;
        r2 = sp + 0x80;
        // and w3, w0, #0x1  (0xb7a8ec4)
        r4 = fp - 0x70;
        this = r20;
        this = fn_0x88a3f34(this, r1, r2, r3);  // call  [0x88a3f34]
        r8 = *(void**)(fp - 0x70);
        if (r8 == 0) goto label_0xb7a8ee8;
        r8 = *(void**)(r8 + 0x8);
        this = fp - 0x70;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a8ee8:
        r21 = *(void**)(sp + 0x88);
        if (r21 == 0) goto label_0xb7a8f18;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a8f18;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a8f18:
        // ldp x8, x21, [sp, #0x90]  (0xb7a8f18)
        // stp x8, x21, [sp, #0x70]  (0xb7a8f1c)
        if (r21 == 0) goto label_0xb7a8f30;
        r1 = r21 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7a8f30:
        r1 = sp + 0x70;
        this = r20;
        this = fn_0x134c0a10(this, r1, r2, r3);  // call  [0x134c0a10]
        if (r21 == 0) goto label_0xb7a8f68;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a8f68;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a8f68:
        r21 = *(void**)(sp + 0x68);
        r20 = *(void**)(sp + 0x98);
        if (r21 == 0) goto label_0xb7a8f9c;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a8f9c;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a8f9c:
        r19 = r19 + 0x5d8;
        if (r20 == 0) goto label_0xb7a8fcc;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a8fcc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a8fcc:
        r8 = *(void**)(sp + 0x54);
        r9 = *(void**)(sp + 0x5c);
        *(void**)(r19) = r8;
        *(void**)(r19 + 0x8) = r9;
    label_0xb7a8fdc:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a9064;
        // ldp x20, x19, [sp, #0x150]  (0xb7a8fec)
        rd10 = *(void**)(sp + 0x100);
        // ldp x22, x21, [sp, #0x140]  (0xb7a8ff4)
        // ldp x28, x23, [sp, #0x130]  (0xb7a8ff8)
        // ldp x29, x30, [sp, #0x120]  (0xb7a8ffc)
        // ldp d9, d8, [sp, #0x110]  (0xb7a9000)
        sp = sp + 0x160;
        return this;
}

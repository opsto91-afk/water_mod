// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d3c0c
// fn_va = 0xb7d3c0c
// return type (guess): unknown (no ret found)
void* fn_0xb7d3c0c(void* this) {
        // stp xzr, xzr, [sp]  (0xb7d3c0c)
        *(void**)(r19 + 0x980) = rq0;
        if (r22 == 0) goto label_0xb7d3c40;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d3c40;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d3c40:
        r22 = *(void**)(sp + 0x8);
        if (r22 == 0) goto label_0xb7d3c70;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d3c70;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d3c70:
        if (r21 == 0) goto label_0xb7d3c7c;
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d3c7c:
        *(uint8_t*)(r19 + 0x990) = r20;
        this = r19;
        this = fn_0xb7b8e44(this, r1, r2, r3);  // call  [0xb7b8e44]
        r21 = *(void**)(sp + 0x20);
        *(uint8_t*)(r19 + 0x991) = r8;
        if (r21 == 0) goto label_0xb7d3ca8;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7d3cd0;
    label_0xb7d3ca8:
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d3d44;
        // ldp x20, x19, [sp, #0x60]  (0xb7d3cb8)
        r23 = *(void**)(sp + 0x40);
        // ldp x22, x21, [sp, #0x50]  (0xb7d3cc0)
        // ldp x29, x30, [sp, #0x30]  (0xb7d3cc4)
        sp = sp + 0x70;
        return this;
}

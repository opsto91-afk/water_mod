// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c72b0
// fn_va = 0xb7c72b0
// return type (guess): unknown (no ret found)
void* fn_0xb7c72b0(void* this, void* r2, void* r4) {
        // stp x29, x30, [sp, #0xffffffffffffffc0]!  (0xb7c72b0)
        // stp x24, x23, [sp, #0x10]  (0xb7c72b4)
        // stp x22, x21, [sp, #0x20]  (0xb7c72b8)
        // stp x20, x19, [sp, #0x30]  (0xb7c72bc)
        r22 = *(void**)(r2 + 0x32b8);
        r24 = *(void**)(r2 + 0x32c0);
        // cmp r22 == r24
        if (/* cond: b.eq */) goto label_0xb7c730c;
        r19 = r3;
        r20 = r2;
        r21 = r1;
        r23 = this;
    label_0xb7c72e4:
        r8 = *(void**)(r23 + 0x1118);
        this = r21;
        r1 = r20;
        r2 = r22;
        r3 = r19;
        r4 = *(void**)(r8 + 0x1a8);
        this = fn_0xacad41c(this, r1, r2, r3);  // call  [0xacad41c]
        r22 = r22 + 0x88;
        // cmp r22 == r24
        if (/* cond: b.ne */) goto label_0xb7c72e4;
    label_0xb7c730c:
        // ldp x20, x19, [sp, #0x30]  (0xb7c730c)
        // ldp x22, x21, [sp, #0x20]  (0xb7c7310)
        // ldp x24, x23, [sp, #0x10]  (0xb7c7314)
        // ldp x29, x30, [sp], #0x40  (0xb7c7318)
        return this;
}

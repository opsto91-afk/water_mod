// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7be24c
// fn_va = 0xb7be24c
// return type (guess): unknown (no ret found)
void* fn_0xb7be24c(void* this) {
        // stp x29, x30, [sp, #0x20]  (0xb7be250)
        // stp x26, x25, [sp, #0x30]  (0xb7be254)
        // stp x24, x23, [sp, #0x40]  (0xb7be258)
        // stp x22, x21, [sp, #0x50]  (0xb7be25c)
        // stp x20, x19, [sp, #0x60]  (0xb7be260)
        fp = sp + 0x20;
        // mrs x21, tpidr_el0  (0xb7be268)
        r9 = (void*)0x13a557d0;
        r8 = *(void**)(r21 + 0x28);
        r19 = this;
        *(void**)(fp - 0x8) = r8;
        r8 = (void*)0x13a55940;
        *(void**)(this + 0xc50) = r8;
        r8 = (void*)0x13a55a50;
        *(void**)(this + 0xc58) = r8;
        r8 = (void*)0x13a55a88;
        *(void**)(this) = r9;
        *(void**)(this + 0xc60) = r8;
        r8 = (void*)0x13a55ab0;
        this = *(void**)(this + 0x10f8);
        *(void**)(r19 + 0xc78) = r8;
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x9c8);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp);
        // movk w22, #0xdead, lsl #0x10  (0xb7be2c0)
        if (r8 == 0) goto label_0xb7be584;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7be594  (0xb7be2cc)
    label_0xb7be2d0:
        this = *(void**)(sp + 0x10);
        this = fn_0xbce16e8(this, r1, r2, r3);  // call  [0xbce16e8]
        r20 = *(void**)(sp + 0x8);
        // stp xzr, xzr, [sp]  (0xb7be2dc)
        if (r20 == 0) goto label_0xb7be340;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be30c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be30c:
        r20 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r20 == 0) goto label_0xb7be340;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be340;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be340:
        this = *(void**)(r19 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x9c8);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp);
        if (r8 == 0) goto label_0xb7be5a0;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7be5b0  (0xb7be360)
    label_0xb7be364:
        this = *(void**)(sp + 0x10);
        this = fn_0xbce17f0(this, r1, r2, r3);  // call  [0xbce17f0]
        r20 = *(void**)(sp + 0x8);
        // stp xzr, xzr, [sp]  (0xb7be370)
        if (r20 == 0) goto label_0xb7be3d4;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be3a0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be3a0:
        r20 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r20 == 0) goto label_0xb7be3d4;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be3d4;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be3d4:
        this = fn_0xb7bd4a4(this, r1, r2, r3);  // call  [0xb7bd4a4]
        this = fn_0x134acc2c(this, r1, r2, r3);  // call  [0x134acc2c]
        this = *(void**)(r19 + 0x1298);
        *(void**)(r19 + 0x1298) = rzr;
        if (this == 0) goto label_0xb7be3fc;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be3fc:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1288);
        if (this == 0) goto label_0xb7be414;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be414:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1278);
        if (this == 0) goto label_0xb7be42c;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be42c:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1268);
        if (this == 0) goto label_0xb7be444;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be444:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1258);
        if (this == 0) goto label_0xb7be45c;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be45c:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1248);
        if (this == 0) goto label_0xb7be474;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be474:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1238);
        if (this == 0) goto label_0xb7be48c;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be48c:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1228);
        if (this == 0) goto label_0xb7be4a4;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be4a4:
        this = fn_0x134a8f58(this, r1, r2, r3);  // call  [0x134a8f58]
        this = *(void**)(r19 + 0x1218);
        if (this == 0) goto label_0xb7be4bc;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be4bc:
        r20 = *(void**)(r19 + 0x11b8);
        if (r20 != 0) goto label_0xb7be56c;
    label_0xb7be4c4:
        this = *(void**)(r19 + 0x11a8);
        *(void**)(r19 + 0x11a8) = rzr;
        if (this == 0) goto label_0xb7be4d4;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be4d4:
        this = *(void**)(r19 + 0x1140);
        *(void**)(r19 + 0x1140) = rzr;
        if (this == 0) goto label_0xb7be4ec;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x8);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7be4ec:
        // movi v0.2d, #0x0  (0xb7be4ec)
        r20 = *(void**)(r19 + 0x1128);
        *(void**)(r19 + 0x1120) = rq0;
        if (r20 == 0) goto label_0xb7be5bc;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be524;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be524:
        r20 = *(void**)(r19 + 0x1128);
        *(void**)(r19 + 0x1130) = rzr;
        if (r20 == 0) goto label_0xb7be5c0;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be5c0;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7be5c0;
    label_0xb7be55c:
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        r20 = r22;
        if (r22 == 0) goto label_0xb7be4c4;
    label_0xb7be56c:
        r8 = *(uint8_t*)(r20 + 0x18);
        r22 = *(void**)(r20);
        // tbz w8, #0x0, 0xb7be55c  (0xb7be574)
        this = *(void**)(r20 + 0x28);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7be55c;
    label_0xb7be584:
        r9 = rzr;
        *(void**)(r9) = r22;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7be2d0  (0xb7be590)
    label_0xb7be594:
        r8 = rzr;
        *(void**)(r8) = r22;
        goto label_0xb7be2d0;
    label_0xb7be5a0:
        r9 = rzr;
        *(void**)(r9) = r22;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7be364  (0xb7be5ac)
    label_0xb7be5b0:
        r8 = rzr;
        *(void**)(r8) = r22;
        goto label_0xb7be364;
    label_0xb7be5bc:
        *(void**)(r19 + 0x1130) = rzr;
    label_0xb7be5c0:
        this = *(void**)(r19 + 0x1108);
        if (this == 0) goto label_0xb7be5cc;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be5cc:
        r22 = *(void**)(r19 + 0x10d8);
        if (r22 == 0) goto label_0xb7be650;
        r24 = *(void**)(r19 + 0x10e0);
        this = r22;
        // cmp r24 == r22
        if (/* cond: b.eq */) goto label_0xb7be648;
        r23 = r24;
        goto label_0xb7be608;
    label_0xb7be5f0:
        this = *(void**)(r23);
    label_0xb7be5f4:
        *(void**)(r24 - 0x10) = r25;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be5fc:
        // cmp r23 == r22
        r24 = r23;
        if (/* cond: b.eq */) goto label_0xb7be644;
    label_0xb7be608:
        r25 = *(void**)(r23 - 0x18);
        if (r25 == 0) goto label_0xb7be5fc;
        r26 = *(void**)(r24 - 0x10);
        this = r25;
        // cmp r26 == r25
        if (/* cond: b.ne */) goto label_0xb7be630;
        goto label_0xb7be5f4;
    label_0xb7be624:
        r26 = r26 - 0x58;
        // cmp r26 == r25
        if (/* cond: b.eq */) goto label_0xb7be5f0;
    label_0xb7be630:
        // ldurb w8, [x26, #0xffffffffffffffd0]  (0xb7be630)
        // tbz w8, #0x0, 0xb7be624  (0xb7be634)
        this = *(void**)(r26 - 0x20);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7be624;
    label_0xb7be644:
        this = *(void**)(r19 + 0x10d8);
    label_0xb7be648:
        *(void**)(r19 + 0x10e0) = r22;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be650:
        // tbz w8, #0x0, 0xb7be660  (0xb7be654)
        this = *(void**)(r19 + 0x10c8);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be660:
        r20 = *(void**)(r19 + 0x10a0);
        if (r20 == 0) goto label_0xb7be6ac;
        r8 = *(void**)(r19 + 0x10a8);
        this = r20;
        // cmp r8 == r20
        if (/* cond: b.eq */) goto label_0xb7be6a4;
        r22 = r8;
        goto label_0xb7be68c;
    label_0xb7be680:
        // cmp r22 == r20
        r8 = r22;
        if (/* cond: b.eq */) goto label_0xb7be6a0;
    label_0xb7be68c:
        r9 = *(uint8_t*)(r22 - 0x30);
        // tbz w9, #0x0, 0xb7be680  (0xb7be690)
        this = *(void**)(r8 - 0x20);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7be680;
    label_0xb7be6a0:
        this = *(void**)(r19 + 0x10a0);
    label_0xb7be6a4:
        *(void**)(r19 + 0x10a8) = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be6ac:
        r20 = *(void**)(r19 + 0x1090);
        if (r20 == 0) goto label_0xb7be6dc;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be6dc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be6dc:
        r20 = *(void**)(r19 + 0x1080);
        if (r20 == 0) goto label_0xb7be70c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be70c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be70c:
        r20 = *(void**)(r19 + 0x1070);
        if (r20 == 0) goto label_0xb7be73c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be73c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be73c:
        r20 = *(void**)(r19 + 0x1060);
        if (r20 == 0) goto label_0xb7be76c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be76c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be76c:
        r20 = *(void**)(r19 + 0x1050);
        if (r20 == 0) goto label_0xb7be79c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be79c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be79c:
        r20 = *(void**)(r19 + 0x1040);
        if (r20 == 0) goto label_0xb7be7cc;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be7cc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be7cc:
        r20 = *(void**)(r19 + 0x1030);
        if (r20 == 0) goto label_0xb7be7fc;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be7fc;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be7fc:
        r20 = *(void**)(r19 + 0x1020);
        if (r20 == 0) goto label_0xb7be82c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be82c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be82c:
        r20 = *(void**)(r19 + 0x1010);
        if (r20 == 0) goto label_0xb7be85c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be85c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be85c:
        this = *(void**)(r19 + 0xe88);
        if (this == 0) goto label_0xb7be874;
    label_0xb7be864:
        r20 = *(void**)(this);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        this = r20;
        if (r20 != 0) goto label_0xb7be864;
    label_0xb7be874:
        this = *(void**)(r19 + 0xe78);
        *(void**)(r19 + 0xe78) = rzr;
        if (this == 0) goto label_0xb7be884;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be884:
        this = *(void**)(r19 + 0xe60);
        if (this == 0) goto label_0xb7be89c;
    label_0xb7be88c:
        r20 = *(void**)(this);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        this = r20;
        if (r20 != 0) goto label_0xb7be88c;
    label_0xb7be89c:
        this = *(void**)(r19 + 0xe50);
        *(void**)(r19 + 0xe50) = rzr;
        if (this == 0) goto label_0xb7be8ac;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be8ac:
        this = *(void**)(r19 + 0xcd8);
        *(void**)(r19 + 0xcd8) = rzr;
        if (this == 0) goto label_0xb7be8bc;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be8bc:
        r20 = *(void**)(r19 + 0xcd0);
        *(void**)(r19 + 0xcd0) = rzr;
        if (r20 == 0) goto label_0xb7be8d8;
        this = r20;
        this = fn_0xac2a2d8(this, r1, r2, r3);  // call  [0xac2a2d8]
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7be8d8:
        r20 = *(void**)(r19 + 0xcc8);
        if (r20 == 0) goto label_0xb7be908;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be908;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be908:
        r20 = *(void**)(r19 + 0xcb8);
        if (r20 == 0) goto label_0xb7be938;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7be938;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be938:
        this = *(void**)(r19 + 0xca8);
        if (this == 0) goto label_0xb7be944;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7be944:
        this = r19 + 0xc78;
        this = fn_0x134c242c(this, r1, r2, r3);  // call  [0x134c242c]
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7be980;
        // ldp x20, x19, [sp, #0x60]  (0xb7be964)
        // ldp x22, x21, [sp, #0x50]  (0xb7be968)
        // ldp x24, x23, [sp, #0x40]  (0xb7be96c)
        // ldp x26, x25, [sp, #0x30]  (0xb7be970)
        // ldp x29, x30, [sp, #0x20]  (0xb7be974)
        sp = sp + 0x70;
        return this;
}

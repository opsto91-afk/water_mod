// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c3504
// fn_va = 0xb7c3504
// return type (guess): unknown (no ret found)
void* fn_0xb7c3504(void* this, void* r1) {
        // stp x29, x30, [sp, #0x60]  (0xb7c3508)
        // stp x28, x27, [sp, #0x70]  (0xb7c350c)
        // stp x26, x25, [sp, #0x80]  (0xb7c3510)
        // stp x24, x23, [sp, #0x90]  (0xb7c3514)
        // stp x22, x21, [sp, #0xa0]  (0xb7c3518)
        // stp x20, x19, [sp, #0xb0]  (0xb7c351c)
        fp = sp + 0x60;
        // mrs x9, tpidr_el0  (0xb7c3524)
        r27 = r1;
        r28 = this;
        *(void**)(sp + 0x10) = r9;
        r19 = r8;
        r9 = *(void**)(r9 + 0x28);
        *(void**)(fp - 0x8) = r9;
        r9 = *(void**)(r1 + 0x100);
        // ldp x20, x22, [x9]  (0xb7c3544)
        if (r22 == 0) goto label_0xb7c359c;
        r1 = r22 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r22 + 0x8;
        // stp xzr, xzr, [x19]  (0xb7c3560)
        // stp xzr, x20, [x19, #0x10]  (0xb7c3564)
        *(void**)(r19 + 0x20) = r22;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c35a8;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c35a8;
    label_0xb7c359c:
        // stp xzr, xzr, [x19]  (0xb7c359c)
        // stp xzr, x20, [x19, #0x10]  (0xb7c35a0)
        *(void**)(r19 + 0x20) = rzr;
    label_0xb7c35a8:
        this = r19 + 0x28;
        this = fn_0x117b5a60(this, r1, r2, r3);  // call  [0x117b5a60]
        r8 = *(void**)(r28 + 0x1118);
        this = r19 + 0x28;
        r1 = r8 + 0x1b8;
        this = fn_0x117b5e54(this, r1, r2, r3);  // call  [0x117b5e54]
        r8 = *(void**)(r28 + 0x958);
        if (r8 == 0) goto label_0xb7c3a80;
        r9 = *(void**)(r19 + 0x10);
        r8 = *(void**)(r19);
        r22 = *(void**)(r28 + 0xe90);
        // cmp r22 == <complex operand>
        if (/* cond: b.ls */) goto label_0xb7c3690;
        // lsr x9, x22, #0x3b  (0xb7c35e0)
        if (r9 != 0) goto label_0xb7c3ae4;
        r9 = *(void**)(r19 + 0x8);
        this = *(void**)(r19 + 0x18);
        r1 = r22;
        this = fn_0xb7eb52c(this, r1, r2, r3);  // call  [0xb7eb52c]
        // ldp x20, x25, [x19]  (0xb7c35fc)
        // subs x8, x20, x25  (0xb7c3608)
        if (/* cond: b.eq */) goto label_0xb7c3688;
        r8 = r21;
        r9 = r20;
    label_0xb7c361c:
        rq0 = *(void**)(r9);
        *(void**)(r8) = rq0;
        r10 = *(uint8_t*)(r9 + 0x18);
        r11 = *(void**)(r9 + 0x10);
        // stp xzr, xzr, [x9], #0x20  (0xb7c362c)
        // cmp r9 == r25
        *(uint8_t*)(r8 + 0x18) = r10;
        *(void**)(r8 + 0x10) = r11;
        r8 = r8 + 0x20;
        if (/* cond: b.ne */) goto label_0xb7c361c;
        goto label_0xb7c3654;
    label_0xb7c3648:
        r20 = r20 + 0x20;
        // cmp r20 == r25
        if (/* cond: b.eq */) goto label_0xb7c3688;
    label_0xb7c3654:
        r22 = *(void**)(r20 + 0x8);
        if (r22 == 0) goto label_0xb7c3648;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c3648;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c3648;
    label_0xb7c3688:
        // stp x21, x23, [x19]  (0xb7c3688)
        *(void**)(r19 + 0x10) = r24;
    label_0xb7c3690:
        r26 = *(void**)(r28 + 0xe88);
        if (r26 == 0) goto label_0xb7c3a80;
        r21 = sp + 0x30;
        *(void**)(sp + 0x8) = r27;
        *(void**)(sp + 0x18) = r28;
        goto label_0xb7c36d4;
    label_0xb7c36a8:
        rq0 = *(void**)(sp + 0x30);
        r9 = *(void**)(r21 + 0x10);
        // ldurb w10, [x21, #0x18]  (0xb7c36b0)
        // stp xzr, xzr, [sp, #0x30]  (0xb7c36b4)
        *(void**)(r8) = rq0;
        *(void**)(r8 + 0x10) = r9;
        *(uint8_t*)(r8 + 0x18) = r10;
        r8 = r8 + 0x20;
        *(void**)(r19 + 0x8) = r8;
    label_0xb7c36cc:
        r26 = *(void**)(r26);
        if (r26 == 0) goto label_0xb7c3a80;
    label_0xb7c36d4:
        // scvtf s0, wzr  (0xb7c36d4)
        rs1 = *(void**)(r26 + 0x20);
        // fcmpe s1, s0  (0xb7c36dc)
        if (/* cond: b.le */) goto label_0xb7c36cc;
        r22 = *(void**)(r28 + 0x958);
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0x10);
        r1 = r26 + 0x10;
        this = r22;
        this = (*(void**)r8)(this);  // indirect call
        r23 = this;
        this = r28;
        r1 = r23;
        this = fn_0xb7c0020(this, r1, r2, r3);  // call  [0xb7c0020]
        // tbz w0, #0x0, 0xb7c36cc  (0xb7c370c)
        rs0 = *(void**)(r26 + 0x20);
        this = sp + 0x30;
        r5 = r26 + 0x10;
        r1 = r28;
        r2 = r27;
        r3 = r22;
        r4 = r23;
        this = fn_0xb7c7320(this, r1, r2, r3);  // call  [0xb7c7320]
        // ldp x8, x9, [x19, #0x8]  (0xb7c3730)
        // cmp r8 == r9
        if (/* cond: b.hs */) goto label_0xb7c3764;
        rq0 = *(void**)(sp + 0x30);
        r9 = *(void**)(r21 + 0x10);
        // ldurb w10, [x21, #0x18]  (0xb7c3744)
        // stp xzr, xzr, [sp, #0x30]  (0xb7c3748)
        *(void**)(r8) = rq0;
        *(void**)(r8 + 0x10) = r9;
        *(uint8_t*)(r8 + 0x18) = r10;
        r8 = r8 + 0x20;
        *(void**)(r19 + 0x8) = r8;
        goto label_0xb7c38c0;
    label_0xb7c3764:
        r10 = *(void**)(r19);
        // asr x20, x8, #0x5  (0xb7c376c)
        r8 = r20 + 0x1;
        // lsr x11, x8, #0x3b  (0xb7c3774)
        if (r11 != 0) goto label_0xb7c3ab4;
        // asr x10, x9, #0x4  (0xb7c3780)
        // cmp r10 == r8
        // csel x8, x10, x8, hi  (0xb7c3788)
        r10 = 0x7fffffffffffffe0;
        // cmp r9 == r10
        r9 = 0x7ffffffffffffff;
        // csel x24, x8, x9, cc  (0xb7c3798)
        if (r24 == 0) goto label_0xb7c37b0;
        this = *(void**)(r19 + 0x18);
        r1 = r24;
        this = fn_0xb7eb52c(this, r1, r2, r3);  // call  [0xb7eb52c]
        goto label_0xb7c37b4;
    label_0xb7c37b0:
        this = rzr;
    label_0xb7c37b4:
        rq0 = *(void**)(sp + 0x30);
        r8 = *(void**)(r21 + 0x10);
        // ldurb w9, [x21, #0x18]  (0xb7c37c0)
        // stp xzr, xzr, [sp, #0x30]  (0xb7c37c8)
        *(void**)(r28) = rq0;
        *(void**)(r28 + 0x10) = r8;
        *(uint8_t*)(r28 + 0x18) = r9;
        // ldp x21, x20, [x19]  (0xb7c37d8)
        // subs x8, x21, x20  (0xb7c37dc)
        r9 = r21;
        r8 = r25;
        if (/* cond: b.eq */) goto label_0xb7c38a8;
    label_0xb7c37f0:
        rq0 = *(void**)(r9);
        *(void**)(r8) = rq0;
        r10 = *(uint8_t*)(r9 + 0x18);
        r11 = *(void**)(r9 + 0x10);
        // stp xzr, xzr, [x9], #0x20  (0xb7c3800)
        // cmp r9 == r20
        *(uint8_t*)(r8 + 0x18) = r10;
        *(void**)(r8 + 0x10) = r11;
        r8 = r8 + 0x20;
        if (/* cond: b.ne */) goto label_0xb7c37f0;
        goto label_0xb7c3828;
    label_0xb7c381c:
        r21 = r21 + 0x20;
        // cmp r21 == r20
        if (/* cond: b.eq */) goto label_0xb7c385c;
    label_0xb7c3828:
        r24 = *(void**)(r21 + 0x8);
        if (r24 == 0) goto label_0xb7c381c;
        r1 = r24 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c381c;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c381c;
    label_0xb7c385c:
        r8 = r28 + 0x20;
        r24 = *(void**)(sp + 0x38);
        r28 = *(void**)(sp + 0x18);
        // stp x8, x27, [x19, #0x8]  (0xb7c3868)
        r27 = *(void**)(sp + 0x8);
        r21 = sp + 0x30;
        *(void**)(r19) = r25;
        if (r24 == 0) goto label_0xb7c38c0;
        r1 = r24 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c38c0;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c38c0;
    label_0xb7c38a8:
        r8 = r28 + 0x20;
        r28 = *(void**)(sp + 0x18);
        *(void**)(r19) = r25;
        // stp x8, x27, [x19, #0x8]  (0xb7c38b4)
        r27 = *(void**)(sp + 0x8);
        r21 = sp + 0x30;
    label_0xb7c38c0:
        *(void**)(sp + 0x20) = rzr;
        *(void**)(sp + 0x28) = rzr;
        r2 = r26 + 0x10;
        r3 = sp + 0x20;
        this = r23;
        r1 = r22;
        this = fn_0x109f8234(this, r1, r2, r3);  // call  [0x109f8234]
        // tbz w0, #0x0, 0xb7c36cc  (0xb7c38dc)
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0x10);
        r1 = sp + 0x20;
        this = r22;
        this = (*(void**)r8)(this);  // indirect call
        rs0 = *(void**)(r26 + 0x20);
        r4 = this;
        this = sp + 0x30;
        r5 = sp + 0x20;
        r1 = r28;
        r2 = r27;
        r3 = r22;
        this = fn_0xb7c7320(this, r1, r2, r3);  // call  [0xb7c7320]
        // ldp x8, x9, [x19, #0x8]  (0xb7c3914)
        // cmp r8 == r9
        if (/* cond: b.lo */) goto label_0xb7c36a8;
        r10 = *(void**)(r19);
        // asr x20, x8, #0x5  (0xb7c3928)
        r8 = r20 + 0x1;
        // lsr x11, x8, #0x3b  (0xb7c3930)
        if (r11 != 0) goto label_0xb7c3acc;
        // asr x10, x9, #0x4  (0xb7c393c)
        // cmp r10 == r8
        // csel x8, x10, x8, hi  (0xb7c3944)
        r10 = 0x7fffffffffffffe0;
        // cmp r9 == r10
        r9 = 0x7ffffffffffffff;
        // csel x22, x8, x9, cc  (0xb7c3954)
        if (r22 == 0) goto label_0xb7c3970;
        this = *(void**)(r19 + 0x18);
        r1 = r22;
        this = fn_0xb7eb52c(this, r1, r2, r3);  // call  [0xb7eb52c]
        r23 = this;
        goto label_0xb7c3974;
    label_0xb7c3970:
        r23 = rzr;
    label_0xb7c3974:
        rq0 = *(void**)(sp + 0x30);
        r8 = *(void**)(r21 + 0x10);
        // ldurb w9, [x21, #0x18]  (0xb7c3980)
        // stp xzr, xzr, [sp, #0x30]  (0xb7c3984)
        *(void**)(r28) = rq0;
        *(void**)(r28 + 0x10) = r8;
        *(uint8_t*)(r28 + 0x18) = r9;
        // ldp x21, x20, [x19]  (0xb7c3994)
        // subs x8, x21, x20  (0xb7c3998)
        r9 = r21;
        r8 = r25;
        if (/* cond: b.eq */) goto label_0xb7c3a64;
    label_0xb7c39ac:
        rq0 = *(void**)(r9);
        *(void**)(r8) = rq0;
        r10 = *(uint8_t*)(r9 + 0x18);
        r11 = *(void**)(r9 + 0x10);
        // stp xzr, xzr, [x9], #0x20  (0xb7c39bc)
        // cmp r9 == r20
        *(uint8_t*)(r8 + 0x18) = r10;
        *(void**)(r8 + 0x10) = r11;
        r8 = r8 + 0x20;
        if (/* cond: b.ne */) goto label_0xb7c39ac;
        goto label_0xb7c39e4;
    label_0xb7c39d8:
        r21 = r21 + 0x20;
        // cmp r21 == r20
        if (/* cond: b.eq */) goto label_0xb7c3a18;
    label_0xb7c39e4:
        r24 = *(void**)(r21 + 0x8);
        if (r24 == 0) goto label_0xb7c39d8;
        r1 = r24 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c39d8;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c39d8;
    label_0xb7c3a18:
        r22 = *(void**)(sp + 0x38);
        r8 = r28 + 0x20;
        r28 = *(void**)(sp + 0x18);
        r21 = sp + 0x30;
        *(void**)(r19) = r25;
        // stp x8, x9, [x19, #0x8]  (0xb7c3a30)
        if (r22 == 0) goto label_0xb7c36cc;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c36cc;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c36cc;
    label_0xb7c3a64:
        r8 = r28 + 0x20;
        r28 = *(void**)(sp + 0x18);
        *(void**)(r19) = r25;
        r21 = sp + 0x30;
        // stp x8, x9, [x19, #0x8]  (0xb7c3a78)
        goto label_0xb7c36cc;
    label_0xb7c3a80:
        r8 = *(void**)(sp + 0x10);
        r8 = *(void**)(r8 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c3b5c;
        // ldp x20, x19, [sp, #0xb0]  (0xb7c3a94)
        // ldp x22, x21, [sp, #0xa0]  (0xb7c3a98)
        // ldp x24, x23, [sp, #0x90]  (0xb7c3a9c)
        // ldp x26, x25, [sp, #0x80]  (0xb7c3aa0)
        // ldp x28, x27, [sp, #0x70]  (0xb7c3aa4)
        // ldp x29, x30, [sp, #0x60]  (0xb7c3aa8)
        sp = sp + 0xc0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a7c0c
// fn_va = 0xb7a7c0c
// return type (guess): unknown (no ret found)
void* fn_0xb7a7c0c(void* this) {
        // stp x29, x30, [sp, #0x20]  (0xb7a7c10)
        *(void**)(sp + 0x30) = r21;
        // stp x20, x19, [sp, #0x40]  (0xb7a7c18)
        fp = sp + 0x20;
        // mrs x21, tpidr_el0  (0xb7a7c20)
        r19 = this;
        r8 = *(void**)(r21 + 0x28);
        *(void**)(fp - 0x8) = r8;
        this = *(void**)(this + 0x968);
        r20 = *(void**)(r19 + 0x978);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        r8 = sp + 0x8;
        this = r20;
        this = fn_0xb7a3f38(this, r1, r2, r3);  // call  [0xb7a3f38]
        this = *(void**)(sp + 0x8);
        if (this == 0) goto label_0xb7a7c64;
        r1 = r19;
        this = fn_0xa9cbe48(this, r1, r2, r3);  // call  [0xa9cbe48]
    label_0xb7a7c64:
        r19 = *(void**)(sp + 0x10);
        if (r19 == 0) goto label_0xb7a7c7c;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7a7ca0;
    label_0xb7a7c7c:
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a7cfc;
        // ldp x20, x19, [sp, #0x40]  (0xb7a7c8c)
        r21 = *(void**)(sp + 0x30);
        // ldp x29, x30, [sp, #0x20]  (0xb7a7c94)
        sp = sp + 0x50;
        return this;
}

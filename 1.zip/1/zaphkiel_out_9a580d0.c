// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a580d0
// fn_va = 0x9a580d0
// return type (guess): unknown (no ret found)
void* fn_0x9a580d0(void* this, void* r1) {
        // stp x29, x30, [sp, #0xffffffffffffffb0]!  (0x9a580d0)
        // stp x28, x25, [sp, #0x10]  (0x9a580d4)
        // stp x24, x23, [sp, #0x20]  (0x9a580d8)
        // stp x22, x21, [sp, #0x30]  (0x9a580dc)
        // stp x20, x19, [sp, #0x40]  (0x9a580e0)
        // mrs x21, tpidr_el0  (0x9a580ec)
        r8 = *(void**)(r21 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r8 = *(void**)(this + 0x18);
        if (r8 == 0) goto label_0x9a583e4;
        r8 = *(void**)(r1);
        r19 = this;
        this = r1;
        r20 = r1;
        r8 = *(void**)(r8 + 0x568);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x300);
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0x9a583e4  (0x9a58124)
        this = r19 + 0x20;
        this = fn_0x117b6098(this, r1, r2, r3);  // call  [0x117b6098]
        // tbnz w0, #0x0, 0x9a58274  (0x9a58130)
        r8 = *(void**)(r20);
        this = r20;
        r9 = *(void**)(r8 + 0x340);
        r8 = sp + 0x80;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x80);
        if (r8 == 0) goto label_0x9a5825c;
        r20 = sp + 0xa0;
        r1 = rzr;
        this = r20 + 0xe;
        r22 = sp + 0xa0;
        this = fn_0xe8034ac(this, r1, r2, r3);  // call  [0xe8034ac]
        r8 = "cameraOverlay";  // 0x2464e03
        r23 = *(void**)(r8);
        r24 = *(void**)(r8 + 0x5);
        *(void**)(sp + 0x4a0) = r9;
        *(uint8_t*)(sp + 0xad) = rzr;
        *(void**)(sp + 0xa0) = r23;
        *(void**)(r22 + 0x5) = r24;
        // stp x20, x9, [sp]  (0x9a5818c)
        this = sp + 0x50;
        r1 = sp;
        this = fn_0xe830740(this, r1, r2, r3);  // call  [0xe830740]
        this = *(void**)(sp + 0x80);
        r1 = sp + 0x50;
        r3 = rzr;
        this = fn_0xac2fa04(this, r1, r2, r3);  // call  [0xac2fa04]
        // tbnz w0, #0x0, 0x9a581cc  (0x9a581b4)
        this = *(void**)(sp + 0x80);
        r1 = sp + 0x50;
        this = fn_0xac33bf4(this, r1, r2, r3);  // call  [0xac33bf4]
    label_0x9a581cc:
        r25 = sp + 0xa0;
        r20 = *(void**)(sp + 0x80);
        r1 = rzr;
        this = r25 + 0xe;
        this = fn_0xe8034ac(this, r1, r2, r3);  // call  [0xe8034ac]
        *(void**)(sp + 0xa0) = r23;
        *(void**)(r22 + 0x5) = r24;
        *(void**)(sp + 0x4a0) = r8;
        *(uint8_t*)(sp + 0xad) = rzr;
        // stp x25, x8, [sp, #0x90]  (0x9a581f8)
        this = sp;
        r1 = sp + 0x90;
        this = fn_0xe830740(this, r1, r2, r3);  // call  [0xe830740]
        r8 = sp + 0x30;
        r1 = sp;
        this = r20;
        r2 = rzr;
        r3 = rzr;
        r4 = rzr;
        this = fn_0xac31db8(this, r1, r2, r3);  // call  [0xac31db8]
        this = r19 + 0x20;
        r1 = sp + 0x30;
        this = fn_0x117b5f38(this, r1, r2, r3);  // call  [0x117b5f38]
        this = sp + 0x30;
        this = fn_0x117b5dc4(this, r1, r2, r3);  // call  [0x117b5dc4]
        r8 = *(uint8_t*)(sp + 0x8);
        // tbz w8, #0x0, 0x9a5824c  (0x9a58240)
        this = *(void**)(sp + 0x18);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a5824c:
        r8 = *(uint8_t*)(sp + 0x58);
        // tbz w8, #0x0, 0x9a5825c  (0x9a58250)
        this = *(void**)(sp + 0x68);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a5825c:
        r20 = *(void**)(sp + 0x88);
        if (r20 == 0) goto label_0x9a58274;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0x9a58414;
    label_0x9a58274:
        this = r19 + 0x40;
        this = fn_0x117a8930(this, r1, r2, r3);  // call  [0x117a8930]
        // tbz w0, #0x0, 0x9a5832c  (0x9a5827c)
    label_0x9a58280:
        r1 = "ui_fill_gradient";  // 0x2541906
        this = sp + 0xa0;
        this = fn_0xe82f7a0(this, r1, r2, r3);  // call  [0xe82f7a0]
        r1 = (void*)0x14098800;
        this = sp + 0x50;
        r2 = sp + 0xa0;
        this = fn_0x117a878c(this, r1, r2, r3);  // call  [0x117a878c]
        // ldp x23, x22, [sp, #0x50]  (0x9a582a4)
        if (r22 == 0) goto label_0x9a582b8;
        r1 = r22 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x9a582b8:
        r20 = *(void**)(r19 + 0x48);
        // stp x23, x22, [x19, #0x40]  (0x9a582bc)
        if (r20 == 0) goto label_0x9a582ec;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a582ec;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a582ec:
        r20 = *(void**)(sp + 0x58);
        if (r20 == 0) goto label_0x9a5831c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a5831c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a5831c:
        r8 = *(uint8_t*)(sp + 0xa8);
        // tbz w8, #0x0, 0x9a5832c  (0x9a58320)
        this = *(void**)(sp + 0xb8);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a5832c:
        this = r19 + 0x50;
        this = fn_0x117a8930(this, r1, r2, r3);  // call  [0x117a8930]
        // tbz w0, #0x0, 0x9a583e4  (0x9a58334)
        r1 = "ui_texture_and_color";  // 0x2737dbf
        this = sp + 0xa0;
        this = fn_0xe82f7a0(this, r1, r2, r3);  // call  [0xe82f7a0]
        r1 = (void*)0x14098800;
        this = sp + 0x50;
        r2 = sp + 0xa0;
        this = fn_0x117a878c(this, r1, r2, r3);  // call  [0x117a878c]
        // ldp x23, x22, [sp, #0x50]  (0x9a5835c)
        if (r22 == 0) goto label_0x9a58370;
        r1 = r22 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x9a58370:
        r20 = *(void**)(r19 + 0x58);
        // stp x23, x22, [x19, #0x50]  (0x9a58374)
        if (r20 == 0) goto label_0x9a583a4;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a583a4;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a583a4:
        r19 = *(void**)(sp + 0x58);
        if (r19 == 0) goto label_0x9a583d4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0x9a583d4;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x9a583d4:
        r8 = *(uint8_t*)(sp + 0xa8);
        // tbz w8, #0x0, 0x9a583e4  (0x9a583d8)
        this = *(void**)(sp + 0xb8);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a583e4:
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9a584b0;
        sp = sp + 0x4b0;
        // ldp x20, x19, [sp, #0x40]  (0x9a583fc)
        // ldp x22, x21, [sp, #0x30]  (0x9a58400)
        // ldp x24, x23, [sp, #0x20]  (0x9a58404)
        // ldp x28, x25, [sp, #0x10]  (0x9a58408)
        // ldp x29, x30, [sp], #0x50  (0x9a5840c)
        return this;
}

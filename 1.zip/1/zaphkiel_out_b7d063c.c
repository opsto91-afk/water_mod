// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d063c
// fn_va = 0xb7d063c
// return type (guess): unknown (no ret found)
void* fn_0xb7d063c(void* this) {
        // stp x9, x8, [sp, #0x60]  (0xb7d063c)
        r3 = sp + 0x60;
        this = r22;
        r1 = r25;
        r2 = r24;
        this = fn_0xb846c78(this, r1, r2, r3);  // call  [0xb846c78]
        r24 = *(void**)(fp - 0x88);
        // stp s0, s1, [sp, #0x18]  (0xb7d0658)
        // stp s2, s3, [sp, #0x20]  (0xb7d065c)
        // stp xzr, xzr, [x29, #0xffffffffffffff70]  (0xb7d0660)
        if (r24 == 0) goto label_0xb7d06c4;
        r1 = r24 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d0690;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d0690:
        r24 = *(void**)(fp - 0x88);
        *(void**)(fp - 0x80) = rzr;
        if (r24 == 0) goto label_0xb7d06c4;
        r1 = r24 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d06c4;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d06c4:
        this = *(void**)(r23 + 0x950);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xa70);
        this = (*(void**)r8)(this);  // indirect call
        r8 = fp - 0x90;
        r1 = r22;
        this = fn_0xb7d0220(this, r1, r2, r3);  // call  [0xb7d0220]
        this = sp + 0xb8;
        this = fn_0xffb4dc0(this, r1, r2, r3);  // call  [0xffb4dc0]
        r1 = 0xdd83;
        // fmov s0, s11  (0xb7d06ec)
        r2 = "variable.emitter_intensity";  // 0x24e623e
        // movk x1, #0xbae, lsl #0x10  (0xb7d06f8)
        this = sp + 0xb8;
        // movk x1, #0xfaf7, lsl #0x20  (0xb7d0700)
        // movk x1, #0x3b78, lsl #0x30  (0xb7d0704)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        r1 = 0x6b79;
        // fmov s0, s10  (0xb7d0710)
        r2 = "variable.emitter_particles_count";  // 0x2583653
        // movk x1, #0x9a8e, lsl #0x10  (0xb7d071c)
        this = sp + 0xb8;
        // movk x1, #0x6925, lsl #0x20  (0xb7d0724)
        // movk x1, #0xc2f4, lsl #0x30  (0xb7d0728)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        // ldp s0, s1, [x29, #0xffffffffffffff74]  (0xb7d0730)
        this = sp;
        r1 = rzr;
        this = fn_0xff99778(this, r1, r2, r3);  // call  [0xff99778]
        // movi v0.2d, #0x0  (0xb7d0740)
        r22 = sp + 0x60;
        *(void**)(sp + 0x60) = r8;
        r8 = sp + 0x60;
        r1 = sp;
        this = r8 + 0x10;
        *(void**)(sp + 0xa8) = rzr;
        *(void**)(sp + 0x68) = rq0;
        *(void**)(sp + 0x78) = rq0;
        *(void**)(r22 + 0x28) = rq0;
        *(void**)(r22 + 0x38) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x60;
        *(void**)(sp + 0xb0) = r8;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        r1 = 0xaade;
        r2 = "variable.emitter_texture_coordinate";  // 0x2486d9d
        // movk x1, #0xadb5, lsl #0x10  (0xb7d0794)
        this = sp + 0xb8;
        r3 = sp + 0x60;
        // movk x1, #0xa57c, lsl #0x20  (0xb7d07a0)
        // movk x1, #0x67f, lsl #0x30  (0xb7d07a4)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x60;
        r23 = sp + 0x60;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        // ldp s0, s1, [x29, #0xffffffffffffff7c]  (0xb7d07c0)
        // ldp s2, s3, [x29, #0xffffffffffffff74]  (0xb7d07c4)
        // fsub s0, s0, s2  (0xb7d07c8)
        // fsub s1, s1, s3  (0xb7d07cc)
        this = sp;
        r1 = rzr;
        this = fn_0xff99778(this, r1, r2, r3);  // call  [0xff99778]
        // movi v0.2d, #0x0  (0xb7d07dc)
        this = r23 + 0x10;
        r1 = sp;
        *(void**)(sp + 0x60) = r8;
        *(void**)(sp + 0xa8) = rzr;
        *(void**)(sp + 0x68) = rq0;
        *(void**)(sp + 0x78) = rq0;
        *(void**)(r22 + 0x28) = rq0;
        *(void**)(r22 + 0x38) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x60;
        *(void**)(sp + 0xb0) = r8;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        r1 = 0x6e6f;
        r2 = "variable.emitter_texture_size";  // 0x27fb599
        // movk x1, #0xb505, lsl #0x10  (0xb7d0828)
        this = sp + 0xb8;
        r3 = sp + 0x60;
        // movk x1, #0x75a4, lsl #0x20  (0xb7d0834)
        // movk x1, #0xe587, lsl #0x30  (0xb7d0838)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x60;
        r23 = sp + 0x60;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        this = sp;
        r2 = sp + 0x18;
        r1 = rzr;
        this = fn_0xff97ec4(this, r1, r2, r3);  // call  [0xff97ec4]
        // movi v0.2d, #0x0  (0xb7d0864)
        this = r23 + 0x10;
        r1 = sp;
        *(void**)(sp + 0x60) = r8;
        *(void**)(sp + 0xa8) = rzr;
        *(void**)(sp + 0x68) = rq0;
        *(void**)(sp + 0x78) = rq0;
        *(void**)(r22 + 0x28) = rq0;
        *(void**)(r22 + 0x38) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x60;
        *(void**)(sp + 0xb0) = r8;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        r1 = 0x75d2;
        r2 = "variable.color";  // 0x26bd9eb
        // movk x1, #0x1b2c, lsl #0x10  (0xb7d08b0)
        this = sp + 0xb8;
        r3 = sp + 0x60;
        // movk x1, #0x1473, lsl #0x20  (0xb7d08bc)
        // movk x1, #0x2603, lsl #0x30  (0xb7d08c0)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x60;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        r1 = 0xe1f7;
        // fmov s0, s9  (0xb7d08dc)
        r2 = "variable.velocity_scalar";  // 0x2545967
        // movk x1, #0xcad0, lsl #0x10  (0xb7d08e8)
        this = sp + 0xb8;
        // movk x1, #0xf9b4, lsl #0x20  (0xb7d08f0)
        // movk x1, #0x8edd, lsl #0x30  (0xb7d08f4)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        r1 = 0x20fa;
        // fmov s0, s8  (0xb7d0900)
        r2 = "variable.emitter_radius";  // 0x26802d2
        // movk x1, #0x45, lsl #0x10  (0xb7d090c)
        this = sp + 0xb8;
        // movk x1, #0x8087, lsl #0x20  (0xb7d0914)
        // movk x1, #0x93fd, lsl #0x30  (0xb7d0918)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        this = sp + 0x28;
        r1 = sp + 0xb8;
        this = fn_0xffb53d8(this, r1, r2, r3);  // call  [0xffb53d8]
        r3 = sp + 0x28;
        this = r21;
        r1 = r20;
        r2 = r19;
        this = fn_0xb05f824(this, r1, r2, r3);  // call  [0xb05f824]
        this = sp + 0x28;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        this = sp + 0xb8;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        // ldurb w8, [x29, #0xffffffffffffff98]  (0xb7d0950)
        // tbz w8, #0x0, 0xb7d0960  (0xb7d0954)
        this = *(void**)(fp - 0x58);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d0960:
        r8 = *(void**)(r27 + 0x28);
        r9 = *(void**)(fp - 0x38);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d0a18;
        // ldp x20, x19, [sp, #0x1d0]  (0xb7d0970)
        // ldp x22, x21, [sp, #0x1c0]  (0xb7d0974)
        // ldp x24, x23, [sp, #0x1b0]  (0xb7d0978)
        // ldp x26, x25, [sp, #0x1a0]  (0xb7d097c)
        // ldp x28, x27, [sp, #0x190]  (0xb7d0980)
        // ldp x29, x30, [sp, #0x180]  (0xb7d0984)
        // ldp d9, d8, [sp, #0x170]  (0xb7d0988)
        // ldp d11, d10, [sp, #0x160]  (0xb7d098c)
        sp = sp + 0x1e0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e650
// fn_va = 0x8a3e650
// return type (guess): unknown (no ret found)
void* fn_0x8a3e650(void* this, void* r1) {
        *(void**)(sp + 0x40) = rd10;
        // stp d9, d8, [sp, #0x48]  (0x8a3e658)
        // stp x29, x30, [sp, #0x58]  (0x8a3e65c)
        *(void**)(sp + 0x68) = r21;
        // stp x20, x19, [sp, #0x70]  (0x8a3e664)
        fp = sp + 0x58;
        // mrs x21, tpidr_el0  (0x8a3e66c)
        r20 = r1;
        r8 = *(void**)(r21 + 0x28);
        *(void**)(fp - 0x20) = r8;
        // ldp x8, x19, [x1]  (0x8a3e67c)
        // stp x8, x19, [sp]  (0x8a3e680)
        if (r19 == 0) goto label_0x8a3e694;
        r1 = r19 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3e694:
        r8 = *(void**)(r20 + 0x10);
        *(void**)(sp + 0x10) = r8;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3e6e0  (0x8a3e6b0)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0x8a3e6e0;
        r20 = this;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tst w0, #0x1  (0x8a3e6d0)
        // csel x20, x20, xzr, ne  (0x8a3e6d4)
        if (r19 != 0) goto label_0x8a3e6e8;
        goto label_0x8a3e6f0;
    label_0x8a3e6e0:
        r20 = rzr;
        if (r19 == 0) goto label_0x8a3e6f0;
    label_0x8a3e6e8:
        this = r19;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3e6f0:
        if (r20 == 0) goto label_0x8a3e768;
        this = r20;
        this = fn_0xfd89a58(this, r1, r2, r3);  // call  [0xfd89a58]
        if (this == 0) goto label_0x8a3e768;
        r19 = this;
        this = r20;
        this = fn_0xfd7fec4(this, r1, r2, r3);  // call  [0xfd7fec4]
        this = fn_0xfa4dba8(this, r1, r2, r3);  // call  [0xfa4dba8]
        // tst w0, #0xff  (0x8a3e714)
        if (/* cond: b.eq */) goto label_0x8a3e768;
        this = r19 + 0x8;
        this = fn_0x101c3bc8(this, r1, r2, r3);  // call  [0x101c3bc8]
        rs0 = *(void**)(this + 0x4);
        this = r20;
        // movk w8, #0x3c8e, lsl #0x10  (0x8a3e730)
        // fmov s8, w8  (0x8a3e734)
        // fmul s9, s0, s8  (0x8a3e738)
        this = fn_0xfa87ae0(this, r1, r2, r3);  // call  [0xfa87ae0]
        this = r20;
        // fmul s10, s0, s8  (0x8a3e744)
        this = fn_0xfa87bb0(this, r1, r2, r3);  // call  [0xfa87bb0]
        // fmul s0, s0, s8  (0x8a3e74c)
        // fmov w9, s10  (0x8a3e750)
        // fmov w10, s9  (0x8a3e754)
        r11 = 0x100000000;
        // fmov w8, s0  (0x8a3e75c)
        // lsl x8, x8, #0x20  (0x8a3e760)
        goto label_0x8a3e778;
    label_0x8a3e768:
        r8 = rzr;
        r10 = rzr;
        r11 = rzr;
        r9 = rzr;
    label_0x8a3e778:
        r12 = *(void**)(r21 + 0x28);
        r13 = *(void**)(fp - 0x20);
        // cmp r12 == r13
        if (/* cond: b.ne */) goto label_0x8a3e7d4;
        // orr x0, x9, x8  (0x8a3e788)
        // orr x1, x11, x10  (0x8a3e78c)
        // ldp x20, x19, [sp, #0x70]  (0x8a3e790)
        r21 = *(void**)(sp + 0x68);
        // ldp x29, x30, [sp, #0x58]  (0x8a3e798)
        rd10 = *(void**)(sp + 0x40);
        // ldp d9, d8, [sp, #0x48]  (0x8a3e7a0)
        sp = sp + 0x80;
        return this;
}

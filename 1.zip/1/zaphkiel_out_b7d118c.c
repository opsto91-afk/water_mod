// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d118c
// fn_va = 0xb7d118c
// return type (guess): unknown (no ret found)
void* fn_0xb7d118c(void* this) {
        // stp x29, x30, [sp, #0x130]  (0xb7d1190)
        // stp x28, x27, [sp, #0x140]  (0xb7d1194)
        // stp x26, x25, [sp, #0x150]  (0xb7d1198)
        // stp x24, x23, [sp, #0x160]  (0xb7d119c)
        // stp x22, x21, [sp, #0x170]  (0xb7d11a0)
        // stp x20, x19, [sp, #0x180]  (0xb7d11a4)
        fp = sp + 0x130;
        // mrs x25, tpidr_el0  (0xb7d11ac)
        r21 = this;
        r20 = r1;
        r8 = *(void**)(r25 + 0x28);
        this = sp + 0x80;
        r23 = r4;
        r22 = r3;
        r26 = r2;
        *(void**)(fp - 0x18) = r8;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x80;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7d1a40  (0xb7d11e4)
        this = sp + 0x80;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7d1a40;
        r8 = *(uint8_t*)(r23 + 0x10);
        // movk w24, #0xdead, lsl #0x10  (0xb7d1200)
        if (r8 == 0) goto label_0xb7d12ac;
        rq0 = *(void**)(r23);
        *(void**)(sp + 0x30) = rq0;
    label_0xb7d1210:
        r8 = *(void**)(r21 + 0x1118);
        r9 = *(void**)(r8 + 0x380);
        if (r9 == 0) goto label_0xb7d1394;
        r9 = *(uint8_t*)(r9);
        r22 = sp + 0x80;
        // tbz w9, #0x0, 0xb7d13a8  (0xb7d1224)
    label_0xb7d1228:
        r24 = *(void**)(r8 + 0x390);
        this = sp + 0x80;
        r1 = r20;
        r19 = sp + 0x80;
        this = fn_0x134ee4d8(this, r1, r2, r3);  // call  [0x134ee4d8]
        rq0 = *(void**)(sp + 0x30);
        this = r19 + 0x28;
        *(void**)(r22 + 0x28) = rq0;
        this = fn_0x13538ed8(this, r1, r2, r3);  // call  [0x13538ed8]
        r23 = this;
        this = sp + 0x80;
        this = fn_0x134eea4c(this, r1, r2, r3);  // call  [0x134eea4c]
        r28 = *(void**)(r21 + 0x11b0);
        r19 = sp + 0x80;
        // movk w8, #0x9e37, lsl #0x10  (0xb7d1264)
        // stp x26, x24, [sp, #0x8]  (0xb7d1268)
        // lsl x10, x9, #0x6  (0xb7d1270)
        // eor x22, x8, x9  (0xb7d1280)
        if (r28 == 0) goto label_0xb7d13b4;
        // fmov d0, x28  (0xb7d1288)
        // cnt v0.8b, v0.8b  (0xb7d128c)
        // uaddlv h0, v0.8b  (0xb7d1290)
        // fmov w8, s0  (0xb7d1294)
        // cmp r8 == 0x1
        if (/* cond: b.hi */) goto label_0xb7d13b8;
        r9 = r28 - 0x1;
        // and x27, x22, x9  (0xb7d12a4)
        goto label_0xb7d13cc;
    label_0xb7d12ac:
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r8 = *(void**)(r21 + 0x1118);
        r23 = this;
        r8 = *(void**)(r8 + 0x3d8);
        r9 = *(void**)(r8);
        this = r8;
        r9 = *(void**)(r9 + 0x278);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x6a8);
        r8 = sp + 0x80;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x80);
        if (r8 != 0) goto label_0xb7d12ec;
        r9 = rzr;
        *(void**)(r9) = r24;
    label_0xb7d12ec:
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7d12fc  (0xb7d12f0)
        r8 = rzr;
        *(void**)(r8) = r24;
    label_0xb7d12fc:
        r8 = *(void**)(sp + 0x90);
        r9 = (void*)0x13a55e20;
        // stp x9, x8, [x29, #0xffffffffffffffb0]  (0xb7d1308)
        r3 = fp - 0x50;
        this = r22;
        r1 = r23;
        r2 = r26;
        this = fn_0xb846c78(this, r1, r2, r3);  // call  [0xb846c78]
        r22 = *(void**)(sp + 0x88);
        // stp s0, s1, [sp, #0x30]  (0xb7d1324)
        // stp s2, s3, [sp, #0x38]  (0xb7d1328)
        // stp xzr, xzr, [sp, #0x80]  (0xb7d132c)
        if (r22 == 0) goto label_0xb7d1210;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d135c;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d135c:
        r22 = *(void**)(sp + 0x88);
        *(void**)(sp + 0x90) = rzr;
        if (r22 == 0) goto label_0xb7d1210;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d1210;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7d1210;
    label_0xb7d1394:
        r10 = rzr;
        *(void**)(r10) = r24;
        r9 = *(uint8_t*)(r9);
        r22 = sp + 0x80;
        // tbnz w9, #0x0, 0xb7d1228  (0xb7d13a4)
    label_0xb7d13a8:
        r9 = rzr;
        *(void**)(r9) = r24;
        goto label_0xb7d1228;
    label_0xb7d13b4:
        goto label_0xb7d159c;
    label_0xb7d13b8:
        // cmp r22 == r28
        r27 = r22;
        if (/* cond: b.lo */) goto label_0xb7d13cc;
        // udiv x9, x22, x28  (0xb7d13c4)
        // msub x27, x9, x28, x22  (0xb7d13c8)
    label_0xb7d13cc:
        r9 = *(void**)(r21 + 0x11a8);
        if (r9 == 0) goto label_0xb7d159c;
        r23 = *(void**)(r9);
        if (r23 == 0) goto label_0xb7d159c;
        // cmp r8 == 0x2
        if (/* cond: b.hs */) goto label_0xb7d14bc;
        r24 = r20;
        r26 = r28 - 0x1;
        goto label_0xb7d140c;
    label_0xb7d13f8:
        // and x8, x8, x26  (0xb7d13f8)
        // cmp r8 == r27
        if (/* cond: b.ne */) goto label_0xb7d1598;
    label_0xb7d1404:
        r23 = *(void**)(r23);
        if (r23 == 0) goto label_0xb7d1598;
    label_0xb7d140c:
        r8 = *(void**)(r23 + 0x8);
        // cmp r8 == r22
        if (/* cond: b.ne */) goto label_0xb7d13f8;
        this = r23 + 0x10;
        r1 = sp + 0x80;
        this = fn_0x134ee2b4(this, r1, r2, r3);  // call  [0x134ee2b4]
        // tbz w0, #0x0, 0xb7d1404  (0xb7d1424)
        // fmov s2, w20  (0xb7d1428)
        rs0 = *(void**)(r23 + 0x38);
        rs1 = *(void**)(sp + 0xa8);
        // fmul s0, s0, s2  (0xb7d1434)
        // fmul s1, s1, s2  (0xb7d1438)
        // fcvtzs w8, s0  (0xb7d143c)
        // fcvtzs w9, s1  (0xb7d1440)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1404;
        // fmov s2, w20  (0xb7d144c)
        rs0 = *(void**)(r23 + 0x3c);
        rs1 = *(void**)(sp + 0xac);
        // fmul s0, s0, s2  (0xb7d1458)
        // fmul s1, s1, s2  (0xb7d145c)
        // fcvtzs w8, s0  (0xb7d1460)
        // fcvtzs w9, s1  (0xb7d1464)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1404;
        // fmov s2, w20  (0xb7d1470)
        rs0 = *(void**)(r23 + 0x40);
        rs1 = *(void**)(sp + 0xb0);
        // fmul s0, s0, s2  (0xb7d147c)
        // fmul s1, s1, s2  (0xb7d1480)
        // fcvtzs w8, s0  (0xb7d1484)
        // fcvtzs w9, s1  (0xb7d1488)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1404;
        // fmov s2, w20  (0xb7d1494)
        rs0 = *(void**)(r23 + 0x44);
        rs1 = *(void**)(sp + 0xb4);
        // fmul s0, s0, s2  (0xb7d14a0)
        // fmul s1, s1, s2  (0xb7d14a4)
        // fcvtzs w8, s0  (0xb7d14a8)
        // fcvtzs w9, s1  (0xb7d14ac)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1404;
        goto label_0xb7d1ab0;
    label_0xb7d14bc:
        goto label_0xb7d14d4;
    label_0xb7d14c4:
        // cmp r8 == r27
        if (/* cond: b.ne */) goto label_0xb7d159c;
    label_0xb7d14cc:
        r23 = *(void**)(r23);
        if (r23 == 0) goto label_0xb7d159c;
    label_0xb7d14d4:
        r8 = *(void**)(r23 + 0x8);
        // cmp r8 == r22
        if (/* cond: b.ne */) goto label_0xb7d1584;
        this = r23 + 0x10;
        r1 = sp + 0x80;
        this = fn_0x134ee2b4(this, r1, r2, r3);  // call  [0x134ee2b4]
        // tbz w0, #0x0, 0xb7d14cc  (0xb7d14ec)
        // fmov s2, w26  (0xb7d14f0)
        rs0 = *(void**)(r23 + 0x38);
        rs1 = *(void**)(sp + 0xa8);
        // fmul s0, s0, s2  (0xb7d14fc)
        // fmul s1, s1, s2  (0xb7d1500)
        // fcvtzs w8, s0  (0xb7d1504)
        // fcvtzs w9, s1  (0xb7d1508)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d14cc;
        // fmov s2, w26  (0xb7d1514)
        rs0 = *(void**)(r23 + 0x3c);
        rs1 = *(void**)(sp + 0xac);
        // fmul s0, s0, s2  (0xb7d1520)
        // fmul s1, s1, s2  (0xb7d1524)
        // fcvtzs w8, s0  (0xb7d1528)
        // fcvtzs w9, s1  (0xb7d152c)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d14cc;
        // fmov s2, w26  (0xb7d1538)
        rs0 = *(void**)(r23 + 0x40);
        rs1 = *(void**)(sp + 0xb0);
        // fmul s0, s0, s2  (0xb7d1544)
        // fmul s1, s1, s2  (0xb7d1548)
        // fcvtzs w8, s0  (0xb7d154c)
        // fcvtzs w9, s1  (0xb7d1550)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d14cc;
        // fmov s2, w26  (0xb7d155c)
        rs0 = *(void**)(r23 + 0x44);
        rs1 = *(void**)(sp + 0xb4);
        // fmul s0, s0, s2  (0xb7d1568)
        // fmul s1, s1, s2  (0xb7d156c)
        // fcvtzs w8, s0  (0xb7d1570)
        // fcvtzs w9, s1  (0xb7d1574)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d14cc;
        goto label_0xb7d1aac;
    label_0xb7d1584:
        // cmp r8 == r28
        if (/* cond: b.lo */) goto label_0xb7d14c4;
        // udiv x9, x8, x28  (0xb7d158c)
        // msub x8, x9, x28, x8  (0xb7d1590)
        goto label_0xb7d14c4;
    label_0xb7d1598:
        r20 = r24;
    label_0xb7d159c:
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r1 = sp + 0x80;
        r23 = this;
        // stp x0, x26, [x29, #0xffffffffffffffb0]  (0xb7d15b4)
        // stp xzr, x22, [x0], #0x10  (0xb7d15b8)
        this = fn_0x134ee534(this, r1, r2, r3);  // call  [0x134ee534]
        // ucvtf s1, x28  (0xb7d15c0)
        r8 = *(void**)(r21 + 0x11c0);
        rs0 = *(void**)(r21 + 0x11c8);
        r9 = 0xffffffffffffffff;
        rq3 = *(void**)(r19 + 0x28);
        r8 = r8 + 0x1;
        *(void**)(r23 + 0x48) = r9;
        // ucvtf s2, x8  (0xb7d15e0)
        // sturb w9, [x29, #0xffffffffffffffc0]  (0xb7d15e4)
        // fmul s1, s1, s0  (0xb7d15e8)
        *(void**)(r23 + 0x38) = rq3;
        // fcmpe s2, s1  (0xb7d15f0)
        // cset w9, gt  (0xb7d15f4)
        if (r28 == 0) goto label_0xb7d161c;
        if (r9 != 0) goto label_0xb7d161c;
        r9 = *(void**)(r21 + 0x11a8);
        if (r8 == 0) goto label_0xb7d1874;
    label_0xb7d160c:
        // ldp x19, x22, [sp, #0x8]  (0xb7d160c)
        r9 = *(void**)(r8);
        *(void**)(r23) = r9;
        goto label_0xb7d18f4;
    label_0xb7d161c:
        // lsl x9, x28, #0x1  (0xb7d161c)
        // cmp r28 == 0x3
        if (/* cond: b.lo */) goto label_0xb7d1638;
        r10 = r28 - 0x1;
        // tst x28, x10  (0xb7d162c)
        // cset w10, ne  (0xb7d1630)
        goto label_0xb7d163c;
    label_0xb7d1638:
    label_0xb7d163c:
        // ucvtf s1, x8  (0xb7d163c)
        // orr x9, x10, x9  (0xb7d1640)
        // fdiv s0, s1, s0  (0xb7d1644)
        // frintp s0, s0  (0xb7d1648)
        // fcvtzu x8, s0  (0xb7d164c)
        // cmp r9 == r8
        // csel x24, x9, x8, hi  (0xb7d1654)
        // subs x8, x24, #0x1  (0xb7d1658)
        if (/* cond: b.ne */) goto label_0xb7d1668;
        goto label_0xb7d167c;
    label_0xb7d1668:
        // tst x24, x8  (0xb7d1668)
        if (/* cond: b.eq */) goto label_0xb7d167c;
        this = r24;
        this = fn_0x135d3a40(this, r1, r2, r3);  // call  [0x135d3a40]
        r24 = this;
    label_0xb7d167c:
        r28 = *(void**)(r21 + 0x11b0);
        // cmp r24 == r28
        if (/* cond: b.ls */) goto label_0xb7d175c;
    label_0xb7d1688:
        // lsr x8, x24, #0x3d  (0xb7d1688)
        if (r8 != 0) goto label_0xb7d1ac4;
        // lsl x0, x24, #0x3  (0xb7d1690)
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r8 = this;
        this = *(void**)(r21 + 0x11a8);
        *(void**)(r21 + 0x11a8) = r8;
        if (this == 0) goto label_0xb7d16ac;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d16ac:
        r8 = rzr;
        *(void**)(r21 + 0x11b0) = r24;
    label_0xb7d16b4:
        r9 = *(void**)(r21 + 0x11a8);
        r8 = r8 + 0x1;
        // cmp r24 == r8
        if (/* cond: b.ne */) goto label_0xb7d16b4;
        r8 = *(void**)(r26);
        if (r8 == 0) goto label_0xb7d1854;
        r10 = r24 - 0x1;
        r9 = *(void**)(r8 + 0x8);
        // tst x24, x10  (0xb7d16d8)
        if (/* cond: b.ne */) goto label_0xb7d17b8;
        r11 = *(void**)(r21 + 0x11a8);
        // and x9, x9, x10  (0xb7d16e4)
        r11 = *(void**)(r8);
        if (r11 != 0) goto label_0xb7d1704;
        goto label_0xb7d1854;
    label_0xb7d16f8:
        r8 = r11;
    label_0xb7d16fc:
        r11 = *(void**)(r8);
        if (r11 == 0) goto label_0xb7d1854;
    label_0xb7d1704:
        r12 = *(void**)(r11 + 0x8);
        // and x12, x12, x10  (0xb7d1708)
        // cmp r12 == r9
        if (/* cond: b.eq */) goto label_0xb7d16f8;
        r13 = *(void**)(r21 + 0x11a8);
        if (r14 == 0) goto label_0xb7d174c;
        r13 = *(void**)(r11);
        // lsl x12, x12, #0x3  (0xb7d1724)
        *(void**)(r8) = r13;
        r13 = *(void**)(r21 + 0x11a8);
        r13 = *(void**)(r13);
        *(void**)(r11) = r13;
        r13 = *(void**)(r21 + 0x11a8);
        *(void**)(r12) = r11;
        goto label_0xb7d16fc;
    label_0xb7d174c:
        r8 = r11;
        r9 = r12;
        goto label_0xb7d16fc;
    label_0xb7d175c:
        if (/* cond: b.hs */) goto label_0xb7d1858;
        r8 = *(void**)(r21 + 0x11c0);
        rs1 = *(void**)(r21 + 0x11c8);
        // cmp r28 == 0x3
        // ucvtf s0, x8  (0xb7d176c)
        // fdiv s0, s0, s1  (0xb7d1770)
        // frintp s0, s0  (0xb7d1774)
        // fcvtzu x0, s0  (0xb7d1778)
        if (/* cond: b.lo */) goto label_0xb7d1a70;
        // fmov d0, x28  (0xb7d1780)
        // cnt v0.8b, v0.8b  (0xb7d1784)
        // uaddlv h0, v0.8b  (0xb7d1788)
        // fmov w8, s0  (0xb7d178c)
        // cmp r8 == 0x1
        if (/* cond: b.hi */) goto label_0xb7d1a70;
        r8 = this - 0x1;
        // cmp this == 0x2
        // clz x8, x8  (0xb7d17a4)
        // neg x8, x8  (0xb7d17a8)
        // lsl x8, x9, x8  (0xb7d17ac)
        // csel x0, x0, x8, cc  (0xb7d17b0)
        goto label_0xb7d1a74;
    label_0xb7d17b8:
        // cmp r9 == r24
        if (/* cond: b.lo */) goto label_0xb7d17c8;
        // udiv x10, x9, x24  (0xb7d17c0)
        // msub x9, x10, x24, x9  (0xb7d17c4)
    label_0xb7d17c8:
        r10 = *(void**)(r21 + 0x11a8);
        r10 = *(void**)(r8);
        if (r10 != 0) goto label_0xb7d1818;
        goto label_0xb7d1854;
    label_0xb7d17dc:
        r12 = *(void**)(r10);
        // lsl x11, x11, #0x3  (0xb7d17e0)
        *(void**)(r8) = r12;
        r12 = *(void**)(r21 + 0x11a8);
        r12 = *(void**)(r12);
        *(void**)(r10) = r12;
        r12 = *(void**)(r21 + 0x11a8);
        *(void**)(r11) = r10;
        r10 = r8;
    label_0xb7d1808:
        r11 = r9;
        r8 = r10;
        r10 = *(void**)(r10);
        if (r10 == 0) goto label_0xb7d1854;
    label_0xb7d1818:
        r11 = *(void**)(r10 + 0x8);
        // cmp r11 == r24
        if (/* cond: b.lo */) goto label_0xb7d182c;
        // udiv x12, x11, x24  (0xb7d1824)
        // msub x11, x12, x24, x11  (0xb7d1828)
    label_0xb7d182c:
        // cmp r11 == r9
        if (/* cond: b.eq */) goto label_0xb7d1808;
        r12 = *(void**)(r21 + 0x11a8);
        if (r13 != 0) goto label_0xb7d17dc;
        r8 = r10;
        r10 = *(void**)(r10);
        r9 = r11;
        if (r10 != 0) goto label_0xb7d1818;
    label_0xb7d1854:
        r28 = r24;
    label_0xb7d1858:
        r8 = r28 - 0x1;
        // tst x28, x8  (0xb7d185c)
        if (/* cond: b.ne */) goto label_0xb7d18a8;
        // and x27, x8, x22  (0xb7d1864)
        r9 = *(void**)(r21 + 0x11a8);
        if (r8 != 0) goto label_0xb7d160c;
    label_0xb7d1874:
        r8 = *(void**)(r26);
        *(void**)(r26) = r23;
        // ldp x19, x22, [sp, #0x8]  (0xb7d187c)
        *(void**)(r23) = r8;
        r8 = *(void**)(r23);
        if (r8 == 0) goto label_0xb7d18f8;
        r9 = r28 - 0x1;
        r8 = *(void**)(r8 + 0x8);
        // tst x28, x9  (0xb7d1898)
        if (/* cond: b.ne */) goto label_0xb7d18dc;
        // and x8, x8, x9  (0xb7d18a0)
        goto label_0xb7d18ec;
    label_0xb7d18a8:
        // cmp r22 == r28
        if (/* cond: b.hs */) goto label_0xb7d18c4;
        r27 = r22;
        r9 = *(void**)(r21 + 0x11a8);
        if (r8 != 0) goto label_0xb7d160c;
        goto label_0xb7d1874;
    label_0xb7d18c4:
        // udiv x8, x22, x28  (0xb7d18c4)
        // msub x27, x8, x28, x22  (0xb7d18c8)
        r9 = *(void**)(r21 + 0x11a8);
        if (r8 != 0) goto label_0xb7d160c;
        goto label_0xb7d1874;
    label_0xb7d18dc:
        // cmp r8 == r28
        if (/* cond: b.lo */) goto label_0xb7d18ec;
        // udiv x9, x8, x28  (0xb7d18e4)
        // msub x8, x9, x28, x8  (0xb7d18e8)
    label_0xb7d18ec:
        r9 = *(void**)(r21 + 0x11a8);
    label_0xb7d18f4:
        *(void**)(r8) = r23;
    label_0xb7d18f8:
        r8 = *(void**)(r21 + 0x11c0);
        r24 = r20;
        r20 = rzr;
        r8 = r8 + 0x1;
        *(void**)(r21 + 0x11c0) = r8;
        r8 = *(uint8_t*)(sp + 0x88);
        // tbz w8, #0x0, 0xb7d191c  (0xb7d1910)
    label_0xb7d1914:
        this = *(void**)(sp + 0x98);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d191c:
        // tbnz w20, #0x0, 0xb7d19f8  (0xb7d191c)
        this = fp - 0x50;
        this = fn_0xffb4dc0(this, r1, r2, r3);  // call  [0xffb4dc0]
        this = sp + 0x18;
        r2 = sp + 0x30;
        r1 = rzr;
        this = fn_0xff97ec4(this, r1, r2, r3);  // call  [0xff97ec4]
        // movi v0.2d, #0x0  (0xb7d1938)
        r1 = sp + 0x18;
        *(void**)(sp + 0x80) = r8;
        r8 = sp + 0x80;
        *(void**)(sp + 0xc8) = rzr;
        *(void**)(r8 + 0x18) = rq0;
        *(void**)(r8 + 0x28) = rq0;
        *(void**)(r8 + 0x38) = rq0;
        r8 = sp + 0x80;
        this = r8 + 0x10;
        *(void**)(sp + 0x88) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x80;
        *(void**)(sp + 0xd0) = r8;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        r1 = 0x75d2;
        r2 = "variable.color";  // 0x26bd9eb
        // movk x1, #0x1b2c, lsl #0x10  (0xb7d198c)
        this = fp - 0x50;
        r3 = sp + 0x80;
        // movk x1, #0x1473, lsl #0x20  (0xb7d1998)
        // movk x1, #0x2603, lsl #0x30  (0xb7d199c)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x80;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp + 0x18;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        this = sp + 0x48;
        r1 = fp - 0x50;
        this = fn_0xffb53d8(this, r1, r2, r3);  // call  [0xffb53d8]
        r2 = (void*)0x3780428;
        r3 = sp + 0x48;
        this = r22;
        r1 = r24;
        this = fn_0xb05f824(this, r1, r2, r3);  // call  [0xb05f824]
        *(void**)(r23 + 0x48) = this;
        this = sp + 0x48;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        r1 = *(void**)(r23 + 0x48);
        this = r22;
        this = fn_0xb0608c0(this, r1, r2, r3);  // call  [0xb0608c0]
        this = fp - 0x50;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
    label_0xb7d19f8:
        // ldp w8, w9, [x19]  (0xb7d19f8)
        r10 = *(void**)(r19 + 0x8);
        // fmov s1, #0.5  (0xb7d1a00)
        r1 = *(void**)(r23 + 0x48);
        r3 = (void*)0x3780428;
        r2 = sp + 0x80;
        // scvtf s0, w8  (0xb7d1a14)
        // scvtf s2, w9  (0xb7d1a18)
        // scvtf s3, w10  (0xb7d1a1c)
        this = r22;
        // fadd s0, s0, s1  (0xb7d1a24)
        // fadd s2, s2, s1  (0xb7d1a28)
        // fadd s1, s3, s1  (0xb7d1a2c)
        // stp s0, s2, [sp, #0x80]  (0xb7d1a30)
        // fmov s0, #1  (0xb7d1a34)
        *(void**)(sp + 0x88) = rs1;
        this = fn_0xb060908(this, r1, r2, r3);  // call  [0xb060908]
    label_0xb7d1a40:
        r8 = *(void**)(r25 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1b60;
        // ldp x20, x19, [sp, #0x180]  (0xb7d1a50)
        // ldp x22, x21, [sp, #0x170]  (0xb7d1a54)
        // ldp x24, x23, [sp, #0x160]  (0xb7d1a58)
        // ldp x26, x25, [sp, #0x150]  (0xb7d1a5c)
        // ldp x28, x27, [sp, #0x140]  (0xb7d1a60)
        // ldp x29, x30, [sp, #0x130]  (0xb7d1a64)
        sp = sp + 0x190;
        return this;
}

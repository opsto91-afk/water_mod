// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7dcafc
// fn_va = 0xb7dcafc
// return type (guess): unknown (no ret found)
void* fn_0xb7dcafc(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dcafc)
        // stp x20, x19, [sp, #0x10]  (0xb7dcb00)
        r20 = this;
        r8 = (void*)0x13a55af0;
        r19 = this - 0xc50;
        this = *(void**)(this + 0x140);
        r9 = (void*)0x13a55c28;
        *(void**)(r19) = r8;
        r10 = (void*)0x13a55d38;
        r8 = (void*)0x13a55d70;
        // stp x9, x10, [x20]  (0xb7dcb2c)
        *(void**)(r20 + 0x10) = r8;
        if (this == 0) goto label_0xb7dcb40;
        *(void**)(r20 + 0x148) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcb40:
        this = *(void**)(r20 + 0x30);
        if (this == 0) goto label_0xb7dcb50;
        *(void**)(r20 + 0x38) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcb50:
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0xb7dcb5c)
        // ldp x29, x30, [sp], #0x20  (0xb7dcb60)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dcb68)
        // stp x20, x19, [sp, #0x10]  (0xb7dcb6c)
        r20 = this;
        r8 = (void*)0x13a55af0;
        r19 = this - 0xc58;
        this = *(void**)(this + 0x138);
        r9 = (void*)0x13a55c28;
        *(void**)(r19) = r8;
        r10 = (void*)0x13a55d38;
        r8 = (void*)0x13a55d70;
        // stp x9, x10, [x20, #0xfffffffffffffff8]  (0xb7dcb98)
        *(void**)(r20 + 0x8) = r8;
        if (this == 0) goto label_0xb7dcbac;
        *(void**)(r20 + 0x140) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcbac:
        this = *(void**)(r20 + 0x28);
        if (this == 0) goto label_0xb7dcbbc;
        *(void**)(r20 + 0x30) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcbbc:
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0xb7dcbc0)
        // ldp x29, x30, [sp], #0x20  (0xb7dcbc4)
        goto label_0xb7bd080;
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dcbcc)
        // stp x20, x19, [sp, #0x10]  (0xb7dcbd0)
        r20 = this;
        r8 = (void*)0x13a55af0;
        r19 = this - 0xc58;
        this = *(void**)(this + 0x138);
        r9 = (void*)0x13a55c28;
        *(void**)(r19) = r8;
        r10 = (void*)0x13a55d38;
        r8 = (void*)0x13a55d70;
        // stp x9, x10, [x20, #0xfffffffffffffff8]  (0xb7dcbfc)
        *(void**)(r20 + 0x8) = r8;
        if (this == 0) goto label_0xb7dcc10;
        *(void**)(r20 + 0x140) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcc10:
        this = *(void**)(r20 + 0x28);
        if (this == 0) goto label_0xb7dcc20;
        *(void**)(r20 + 0x30) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcc20:
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0xb7dcc2c)
        // ldp x29, x30, [sp], #0x20  (0xb7dcc30)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dcc38)
        // stp x20, x19, [sp, #0x10]  (0xb7dcc3c)
        r20 = this;
        r8 = (void*)0x13a55af0;
        r19 = this - 0xc60;
        this = *(void**)(this + 0x130);
        r9 = (void*)0x13a55c28;
        *(void**)(r19) = r8;
        r10 = (void*)0x13a55d38;
        r8 = (void*)0x13a55d70;
        // stp x9, x10, [x20, #0xfffffffffffffff0]  (0xb7dcc68)
        *(void**)(r20) = r8;
        if (this == 0) goto label_0xb7dcc7c;
        *(void**)(r20 + 0x138) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcc7c:
        this = *(void**)(r20 + 0x20);
        if (this == 0) goto label_0xb7dcc8c;
        *(void**)(r20 + 0x28) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcc8c:
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0xb7dcc90)
        // ldp x29, x30, [sp], #0x20  (0xb7dcc94)
        goto label_0xb7bd080;
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dcc9c)
        // stp x20, x19, [sp, #0x10]  (0xb7dcca0)
        r20 = this;
        r8 = (void*)0x13a55af0;
        r19 = this - 0xc60;
        this = *(void**)(this + 0x130);
        r9 = (void*)0x13a55c28;
        *(void**)(r19) = r8;
        r10 = (void*)0x13a55d38;
        r8 = (void*)0x13a55d70;
        // stp x9, x10, [x20, #0xfffffffffffffff0]  (0xb7dcccc)
        *(void**)(r20) = r8;
        if (this == 0) goto label_0xb7dcce0;
        *(void**)(r20 + 0x138) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcce0:
        this = *(void**)(r20 + 0x20);
        if (this == 0) goto label_0xb7dccf0;
        *(void**)(r20 + 0x28) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dccf0:
        this = r19;
        this = fn_0xb7bd080(this, r1, r2, r3);  // call  [0xb7bd080]
        this = r19;
        // ldp x20, x19, [sp, #0x10]  (0xb7dccfc)
        // ldp x29, x30, [sp], #0x20  (0xb7dcd00)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7dcd08)
        *(void**)(sp + 0x10) = r19;
        r8 = (void*)0x139dd0e8;
        r19 = this;
        *(void**)(this) = r8;
        this = this + 0x118;
        this = fn_0x11a1aac8(this, r1, r2, r3);  // call  [0x11a1aac8]
        this = r19 + 0x98;
        this = fn_0x11a1aac8(this, r1, r2, r3);  // call  [0x11a1aac8]
        this = r19 + 0x30;
        this = fn_0x11a1b920(this, r1, r2, r3);  // call  [0x11a1b920]
        this = *(void**)(r19 + 0x8);
        r8 = (void*)0x139dd150;
        *(void**)(r19) = r8;
        if (this == 0) goto label_0xb7dcd58;
        *(void**)(r19 + 0x10) = this;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7dcd58:
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7dcd60)
        return fn_0x135d37b0(/* tail call */);
        rq0 = *(void**)(this + 0x8);
        *(void**)(r1 + 0x8) = rq0;
        rq0 = *(void**)(this + 0x18);
        // stp xzr, xzr, [x0, #0x8]  (0xb7dcd74)
        *(void**)(r1 + 0x18) = rq0;
        // stp xzr, xzr, [x0, #0x18]  (0xb7dcd7c)
        return this;
}

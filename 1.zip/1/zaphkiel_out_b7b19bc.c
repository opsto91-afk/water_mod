// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7b19bc
// fn_va = 0xb7b19bc
// return type (guess): unknown (no ret found)
void* fn_0xb7b19bc(void* this) {
        *(void**)(sp + 0x30) = rd8;
        // stp x29, x30, [sp, #0x40]  (0xb7b19c4)
        // stp x24, x23, [sp, #0x50]  (0xb7b19c8)
        // stp x22, x21, [sp, #0x60]  (0xb7b19cc)
        // stp x20, x19, [sp, #0x70]  (0xb7b19d0)
        fp = sp + 0x40;
        // mrs x22, tpidr_el0  (0xb7b19d8)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x18) = r8;
        r8 = *(void**)(this + 0x598);
        // scvtf s1, w8  (0xb7b19ec)
        // fmov s2, w8  (0xb7b19f4)
        // fcmpe s1, s2  (0xb7b19f8)
        if (/* cond: b.hi */) goto label_0xb7b1a2c;
        // fmov s2, w8  (0xb7b1a00)
        // fmov s3, #4  (0xb7b1a04)
        // fdiv s2, s1, s2  (0xb7b1a08)
        // fmul s2, s3, s2  (0xb7b1a0c)
        // fsub s8, s1, s2  (0xb7b1a10)
        r8 = *(uint8_t*)(r19 + 0x94e);
        // fmul s0, s8, s0  (0xb7b1a18)
        *(void**)(r19 + 0x5a4) = rs8;
        *(void**)(r19 + 0x5a0) = rs0;
        // tbnz w8, #0x0, 0xb7b1b9c  (0xb7b1a24)
        goto label_0xb7b1a5c;
    label_0xb7b1a2c:
        // fmov s3, #8  (0xb7b1a30)
        // fmov s2, w8  (0xb7b1a34)
        // fcmpe s1, s2  (0xb7b1a38)
        // fmov s2, #16  (0xb7b1a3c)
        // fcsel s2, s3, s2, ls  (0xb7b1a40)
        // fsub s8, s1, s2  (0xb7b1a44)
        r8 = *(uint8_t*)(r19 + 0x94e);
        // fmul s0, s8, s0  (0xb7b1a4c)
        *(void**)(r19 + 0x5a4) = rs8;
        *(void**)(r19 + 0x5a0) = rs0;
        // tbnz w8, #0x0, 0xb7b1b9c  (0xb7b1a58)
    label_0xb7b1a5c:
        r8 = *(void**)(r19 + 0x978);
        r8 = *(void**)(r8 + 0x430);
        this = *(void**)(r8 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x4a8);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7b1b9c  (0xb7b1a74)
        r21 = (void*)0x1407c848;
        this = r21;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r23 = *(void**)(r8 + 0x928);
        if (r23 == 0) goto label_0xb7b1be4;
        r8 = *(uint8_t*)(r23);
        if (r8 == 0) goto label_0xb7b1be4;
        r20 = *(void**)(r8 + 0x930);
        if (r20 == 0) goto label_0xb7b1aec;
        r1 = r20 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r9 = *(uint8_t*)(r23);
        *(void**)(sp) = r21;
        this = *(void**)(r8 + 0x938);
        *(uint8_t*)(sp + 0x8) = r24;
        // stp x23, x20, [sp, #0x10]  (0xb7b1acc)
        *(void**)(sp + 0x20) = this;
        if (r9 != 0) goto label_0xb7b1b08;
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0xb7b1ae0)
        *(void**)(r8) = r9;
        goto label_0xb7b1b08;
    label_0xb7b1aec:
        *(void**)(sp) = r21;
        this = *(void**)(r9 + 0x938);
        *(uint8_t*)(sp + 0x8) = r8;
        // stp x23, x20, [sp, #0x10]  (0xb7b1b00)
        *(void**)(sp + 0x20) = this;
    label_0xb7b1b08:
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x358);
        this = (*(void**)r8)(this);  // indirect call
        // fmul s0, s8, s0  (0xb7b1b14)
        rs1 = *(void**)(r19 + 0x5a0);
        // stp xzr, xzr, [sp, #0x10]  (0xb7b1b1c)
        // fcmpe s0, s1  (0xb7b1b20)
        // fcsel s0, s0, s1, mi  (0xb7b1b24)
        *(void**)(r19 + 0x5a0) = rs0;
        if (r20 == 0) goto label_0xb7b1b8c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b1b58;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b1b58:
        r20 = *(void**)(sp + 0x18);
        *(void**)(sp + 0x20) = rzr;
        if (r20 == 0) goto label_0xb7b1b8c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b1b8c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b1b8c:
        r8 = *(uint8_t*)(sp + 0x8);
        if (r8 == 0) goto label_0xb7b1b9c;
        this = *(void**)(sp);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7b1b9c:
        rs0 = *(void**)(r19 + 0x5a0);
        // fmov s1, w8  (0xb7b1ba4)
        // fcmpe s0, s1  (0xb7b1ba8)
        // fcsel s0, s1, s0, mi  (0xb7b1bac)
        *(void**)(r19 + 0x5a0) = rs0;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b1c14;
        this = r19;
        // ldp x20, x19, [sp, #0x70]  (0xb7b1bc8)
        rd8 = *(void**)(sp + 0x30);
        // ldp x22, x21, [sp, #0x60]  (0xb7b1bd0)
        // ldp x24, x23, [sp, #0x50]  (0xb7b1bd4)
        // ldp x29, x30, [sp, #0x40]  (0xb7b1bd8)
        sp = sp + 0x80;
        goto label_0xb7aef04;
    label_0xb7b1be4:
        this = (void*)0x1407c848;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        r19 = this;
        this = sp;
        this = fn_0x88c5ef4(this, r1, r2, r3);  // call  [0x88c5ef4]
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b1c14;
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
    label_0xb7b1c14:
        this = fn_0x135df9a0(this, r1, r2, r3);  // call  [0x135df9a0]
        *(void**)(sp + 0xa0) = rd10;
        // stp d9, d8, [sp, #0xa8]  (0xb7b1c20)
        // stp x29, x30, [sp, #0xb8]  (0xb7b1c24)
        *(void**)(sp + 0xc8) = r28;
        // stp x26, x25, [sp, #0xd0]  (0xb7b1c2c)
        // stp x24, x23, [sp, #0xe0]  (0xb7b1c30)
        // stp x22, x21, [sp, #0xf0]  (0xb7b1c34)
        // stp x20, x19, [sp, #0x100]  (0xb7b1c38)
        fp = sp + 0xb8;
        // mrs x26, tpidr_el0  (0xb7b1c40)
        r19 = this;
        r21 = r2;
        r8 = *(void**)(r26 + 0x28);
        r22 = r1;
        *(void**)(fp - 0x20) = r8;
        r8 = *(void**)(r1 + 0xa8);
        this = r8;
        this = fn_0x134c44c0(this, r1, r2, r3);  // call  [0x134c44c0]
        rs1 = *(void**)(r19 + 0x3f4);
        // fsub s1, s0, s1  (0xb7b1c68)
        // fcmpe s1, #0  (0xb7b1c6c)
        if (/* cond: b.le */) goto label_0xb7b1c7c;
        *(void**)(r19 + 0x3f4) = rs0;
        *(void**)(r19 + 0x3f0) = rs1;
    label_0xb7b1c7c:
        this = *(void**)(r22 + 0x18);
        this = fn_0x11a1c0dc(this, r1, r2, r3);  // call  [0x11a1c0dc]
        r8 = *(void**)(r19 + 0x978);
        r24 = *(void**)(r22 + 0x18);
        r20 = r19 + 0x700;
        r23 = *(void**)(r8 + 0x3d8);
        // cmp r20 == r24
        if (/* cond: b.eq */) goto label_0xb7b1e88;
        r9 = *(void**)(r24 + 0x20);
        // ldp x8, x11, [x24, #0x8]  (0xb7b1ca0)
        // lsr x10, x9, #0x6  (0xb7b1ca4)
        // cmp r11 == r8
        if (/* cond: b.eq */) goto label_0xb7b1d08;
        r10 = *(void**)(r24 + 0x28);
        // and x9, x9, #0x3f  (0xb7b1cbc)
        // lsr x11, x10, #0x6  (0xb7b1cc0)
        // and x10, x10, #0x3f  (0xb7b1cc4)
        r11 = *(void**)(r1);
        r12 = *(void**)(r8);
        // cmp r9 == r2
        if (/* cond: b.eq */) goto label_0xb7b1d28;
    label_0xb7b1ce4:
        r10 = *(void**)(r8);
        r10 = *(void**)(r1);
        // asr x9, x9, #0x6  (0xb7b1cf4)
        goto label_0xb7b1d2c;
    label_0xb7b1d08:
        r10 = *(void**)(r24 + 0x28);
        r2 = rzr;
        // lsr x9, x9, #0x6  (0xb7b1d14)
        r9 = rzr;
        // cmp rzr == rzr
        if (/* cond: b.ne */) goto label_0xb7b1ce4;
    label_0xb7b1d28:
        r3 = rzr;
    label_0xb7b1d2c:
        this = r20;
        this = fn_0xb7e5818(this, r1, r2, r3);  // call  [0xb7e5818]
        r8 = *(uint8_t*)(r24 + 0x40);
        rq0 = *(void**)(r24 + 0x30);
        *(uint8_t*)(r19 + 0x740) = r8;
        *(void**)(r19 + 0x730) = rq0;
        r9 = *(void**)(r24 + 0x68);
        // ldp x8, x11, [x24, #0x50]  (0xb7b1d48)
        // lsr x10, x9, #0x6  (0xb7b1d4c)
        // cmp r11 == r8
        if (/* cond: b.eq */) goto label_0xb7b1db0;
        r10 = *(void**)(r24 + 0x70);
        // and x9, x9, #0x3f  (0xb7b1d64)
        // lsr x11, x10, #0x6  (0xb7b1d68)
        // and x10, x10, #0x3f  (0xb7b1d6c)
        r11 = *(void**)(r1);
        r12 = *(void**)(r8);
        // cmp r9 == r2
        if (/* cond: b.eq */) goto label_0xb7b1dd0;
    label_0xb7b1d8c:
        r10 = *(void**)(r8);
        r10 = *(void**)(r1);
        // asr x9, x9, #0x6  (0xb7b1d9c)
        goto label_0xb7b1dd4;
    label_0xb7b1db0:
        r10 = *(void**)(r24 + 0x70);
        r2 = rzr;
        // lsr x9, x9, #0x6  (0xb7b1dbc)
        r9 = rzr;
        // cmp rzr == rzr
        if (/* cond: b.ne */) goto label_0xb7b1d8c;
    label_0xb7b1dd0:
        r3 = rzr;
    label_0xb7b1dd4:
        this = r19 + 0x748;
        this = fn_0xb7e5818(this, r1, r2, r3);  // call  [0xb7e5818]
        r8 = *(uint8_t*)(r24 + 0x88);
        rq0 = *(void**)(r24 + 0x78);
        r9 = r19 + 0x778;
        *(uint8_t*)(r19 + 0x788) = r8;
        *(void**)(r9) = rq0;
        r9 = *(void**)(r24 + 0xb0);
        // ldp x8, x11, [x24, #0x98]  (0xb7b1df4)
        // lsr x10, x9, #0x6  (0xb7b1df8)
        // cmp r11 == r8
        if (/* cond: b.eq */) goto label_0xb7b1e5c;
        r10 = *(void**)(r24 + 0xb8);
        // and x9, x9, #0x3f  (0xb7b1e10)
        // lsr x11, x10, #0x6  (0xb7b1e14)
        // and x10, x10, #0x3f  (0xb7b1e18)
        r11 = *(void**)(r1);
        r12 = *(void**)(r8);
        // cmp r9 == r2
        if (/* cond: b.eq */) goto label_0xb7b1e7c;
    label_0xb7b1e38:
        r10 = *(void**)(r8);
        r10 = *(void**)(r1);
        // asr x9, x9, #0x6  (0xb7b1e48)
        goto label_0xb7b1e80;
    label_0xb7b1e5c:
        r10 = *(void**)(r24 + 0xb8);
        r2 = rzr;
        // lsr x9, x9, #0x6  (0xb7b1e68)
        r9 = rzr;
        // cmp rzr == rzr
        if (/* cond: b.ne */) goto label_0xb7b1e38;
    label_0xb7b1e7c:
        r3 = rzr;
    label_0xb7b1e80:
        this = r19 + 0x790;
        this = fn_0xb7e5818(this, r1, r2, r3);  // call  [0xb7e5818]
    label_0xb7b1e88:
        r8 = *(uint8_t*)(r24 + 0xd0);
        rq0 = *(void**)(r24 + 0xc0);
        this = r20;
        *(uint8_t*)(r19 + 0x7d0) = r8;
        r8 = r24 + 0x148;
        *(void**)(r19 + 0x7c0) = rq0;
        rs0 = *(void**)(r24 + 0xd8);
        *(void**)(r19 + 0x7d8) = rs0;
        rs0 = *(void**)(r24 + 0xdc);
        *(void**)(r19 + 0x7dc) = rs0;
        rs0 = *(void**)(r24 + 0xe0);
        *(void**)(r19 + 0x7e0) = rs0;
        rs0 = *(void**)(r24 + 0xe4);
        *(void**)(r19 + 0x7e4) = rs0;
        rs0 = *(void**)(r24 + 0xe8);
        *(void**)(r19 + 0x7e8) = rs0;
        rs0 = *(void**)(r24 + 0xec);
        *(void**)(r19 + 0x7ec) = rs0;
        rs0 = *(void**)(r24 + 0xf0);
        *(void**)(r19 + 0x7f0) = rs0;
        rs0 = *(void**)(r24 + 0xf4);
        *(void**)(r19 + 0x7f4) = rs0;
        rs0 = *(void**)(r24 + 0xf8);
        *(void**)(r19 + 0x7f8) = rs0;
        rs0 = *(void**)(r24 + 0xfc);
        *(void**)(r19 + 0x7fc) = rs0;
        rs0 = *(void**)(r24 + 0x100);
        *(void**)(r19 + 0x800) = rs0;
        rs0 = *(void**)(r24 + 0x104);
        *(void**)(r19 + 0x804) = rs0;
        rs0 = *(void**)(r24 + 0x108);
        *(void**)(r19 + 0x808) = rs0;
        rs0 = *(void**)(r24 + 0x10c);
        *(void**)(r19 + 0x80c) = rs0;
        rs0 = *(void**)(r24 + 0x110);
        *(void**)(r19 + 0x810) = rs0;
        rs0 = *(void**)(r24 + 0x114);
        *(void**)(r19 + 0x814) = rs0;
        rs0 = *(void**)(r24 + 0x118);
        *(void**)(r19 + 0x818) = rs0;
        rs0 = *(void**)(r24 + 0x11c);
        *(void**)(r19 + 0x81c) = rs0;
        rs0 = *(void**)(r24 + 0x120);
        *(void**)(r19 + 0x820) = rs0;
        rs0 = *(void**)(r24 + 0x124);
        *(void**)(r19 + 0x824) = rs0;
        rs0 = *(void**)(r24 + 0x128);
        *(void**)(r19 + 0x828) = rs0;
        rs0 = *(void**)(r24 + 0x12c);
        *(void**)(r19 + 0x82c) = rs0;
        rs0 = *(void**)(r24 + 0x130);
        *(void**)(r19 + 0x830) = rs0;
        rs0 = *(void**)(r24 + 0x134);
        *(void**)(r19 + 0x834) = rs0;
        rs0 = *(void**)(r24 + 0x138);
        *(void**)(r19 + 0x838) = rs0;
        rs0 = *(void**)(r24 + 0x13c);
        *(void**)(r19 + 0x83c) = rs0;
        rs0 = *(void**)(r24 + 0x140);
        *(void**)(r19 + 0x840) = rs0;
        rs0 = *(void**)(r24 + 0x144);
        *(void**)(r19 + 0x844) = rs0;
        rq0 = *(void**)(r8);
        r8 = r19 + 0x848;
        *(void**)(r8) = rq0;
        rs0 = *(void**)(r24 + 0x158);
        *(void**)(r19 + 0x858) = rs0;
        rs0 = *(void**)(r24 + 0x15c);
        *(void**)(r19 + 0x85c) = rs0;
        rs0 = *(void**)(r24 + 0x160);
        *(void**)(r19 + 0x860) = rs0;
        rs0 = *(void**)(r24 + 0x164);
        *(void**)(r19 + 0x864) = rs0;
        rs0 = *(void**)(r24 + 0x168);
        *(void**)(r19 + 0x868) = rs0;
        rs0 = *(void**)(r24 + 0x16c);
        *(void**)(r19 + 0x86c) = rs0;
        rs0 = *(void**)(r24 + 0x170);
        *(void**)(r19 + 0x870) = rs0;
        rs0 = *(void**)(r24 + 0x174);
        *(void**)(r19 + 0x874) = rs0;
        rs0 = *(void**)(r24 + 0x178);
        *(void**)(r19 + 0x878) = rs0;
        rs0 = *(void**)(r24 + 0x17c);
        *(void**)(r19 + 0x87c) = rs0;
        rs0 = *(void**)(r24 + 0x180);
        *(void**)(r19 + 0x880) = rs0;
        rs0 = *(void**)(r24 + 0x184);
        *(void**)(r19 + 0x884) = rs0;
        rs0 = *(void**)(r24 + 0x188);
        *(void**)(r19 + 0x888) = rs0;
        rs0 = *(void**)(r24 + 0x18c);
        *(void**)(r19 + 0x88c) = rs0;
        rs0 = *(void**)(r24 + 0x190);
        *(void**)(r19 + 0x890) = rs0;
        rs0 = *(void**)(r24 + 0x194);
        *(void**)(r19 + 0x894) = rs0;
        rs0 = *(void**)(r24 + 0x198);
        *(void**)(r19 + 0x898) = rs0;
        rs0 = *(void**)(r24 + 0x19c);
        *(void**)(r19 + 0x89c) = rs0;
        rs0 = *(void**)(r24 + 0x1a0);
        *(void**)(r19 + 0x8a0) = rs0;
        rs0 = *(void**)(r24 + 0x1a4);
        *(void**)(r19 + 0x8a4) = rs0;
        rs0 = *(void**)(r24 + 0x1a8);
        *(void**)(r19 + 0x8a8) = rs0;
        rs0 = *(void**)(r24 + 0x1ac);
        *(void**)(r19 + 0x8ac) = rs0;
        rs0 = *(void**)(r24 + 0x1b0);
        *(void**)(r19 + 0x8b0) = rs0;
        rs0 = *(void**)(r24 + 0x1b4);
        *(void**)(r19 + 0x8b4) = rs0;
        rs0 = *(void**)(r24 + 0x1b8);
        *(void**)(r19 + 0x8b8) = rs0;
        rs0 = *(void**)(r24 + 0x1bc);
        *(void**)(r19 + 0x8bc) = rs0;
        rs0 = *(void**)(r24 + 0x1c0);
        *(void**)(r19 + 0x8c0) = rs0;
        rs0 = *(void**)(r24 + 0x1c4);
        *(void**)(r19 + 0x8c4) = rs0;
        rs0 = *(void**)(r24 + 0x1c8);
        *(void**)(r19 + 0x8c8) = rs0;
        rs0 = *(void**)(r24 + 0x1cc);
        *(void**)(r19 + 0x8cc) = rs0;
        rs0 = *(void**)(r24 + 0x1d0);
        *(void**)(r19 + 0x8d0) = rs0;
        rs0 = *(void**)(r24 + 0x1d4);
        *(void**)(r19 + 0x8d4) = rs0;
        rs0 = *(void**)(r24 + 0x1d8);
        *(void**)(r19 + 0x8d8) = rs0;
        rs0 = *(void**)(r24 + 0x1dc);
        *(void**)(r19 + 0x8dc) = rs0;
        rs0 = *(void**)(r24 + 0x1e0);
        *(void**)(r19 + 0x8e0) = rs0;
        rs0 = *(void**)(r24 + 0x1e4);
        *(void**)(r19 + 0x8e4) = rs0;
        rs0 = *(void**)(r24 + 0x1e8);
        *(void**)(r19 + 0x8e8) = rs0;
        rs0 = *(void**)(r24 + 0x1ec);
        *(void**)(r19 + 0x8ec) = rs0;
        rs0 = *(void**)(r24 + 0x1f0);
        *(void**)(r19 + 0x8f0) = rs0;
        rs0 = *(void**)(r24 + 0x1f4);
        *(void**)(r19 + 0x8f4) = rs0;
        rs0 = *(void**)(r24 + 0x1f8);
        *(void**)(r19 + 0x8f8) = rs0;
        rs0 = *(void**)(r24 + 0x1fc);
        *(void**)(r19 + 0x8fc) = rs0;
        rs0 = *(void**)(r24 + 0x200);
        *(void**)(r19 + 0x900) = rs0;
        rs0 = *(void**)(r24 + 0x204);
        *(void**)(r19 + 0x904) = rs0;
        rs0 = *(void**)(r24 + 0x208);
        *(void**)(r19 + 0x908) = rs0;
        rs0 = *(void**)(r24 + 0x20c);
        *(void**)(r19 + 0x90c) = rs0;
        rs0 = *(void**)(r24 + 0x210);
        *(void**)(r19 + 0x910) = rs0;
        rs0 = *(void**)(r24 + 0x214);
        *(void**)(r19 + 0x914) = rs0;
        this = fn_0x11a19728(this, r1, r2, r3);  // call  [0x11a19728]
        r24 = this;
        this = r23;
        this = fn_0x9c70b18(this, r1, r2, r3);  // call  [0x9c70b18]
        if (this == 0) goto label_0xb7b21c0;
        // ldp s0, s1, [x0, #0x38]  (0xb7b2120)
        rs2 = *(void**)(this + 0x40);
        // ldp s3, s4, [x24]  (0xb7b2128)
        rs6 = *(void**)(r24 + 0x8);
        // fneg s2, s2  (0xb7b2130)
        // ldp s7, s5, [x24, #0xc]  (0xb7b2134)
        // fneg s0, s0  (0xb7b2138)
        // fneg s1, s1  (0xb7b213c)
        // ldp s16, s17, [x24, #0x14]  (0xb7b2140)
        // ldp s18, s19, [x24, #0x1c]  (0xb7b2144)
        // fmul s3, s3, s0  (0xb7b2148)
        // fmul s5, s5, s1  (0xb7b214c)
        // fmul s4, s4, s0  (0xb7b2150)
        // fmul s16, s16, s1  (0xb7b2154)
        // fmul s6, s6, s0  (0xb7b2158)
        // fmul s17, s17, s1  (0xb7b215c)
        // fmul s0, s7, s0  (0xb7b2160)
        // fmul s1, s18, s1  (0xb7b2164)
        // fadd s3, s3, s5  (0xb7b2168)
        // ldp s7, s5, [x24, #0x24]  (0xb7b216c)
        // fmul s18, s19, s2  (0xb7b2170)
        // fadd s4, s4, s16  (0xb7b2174)
        rs16 = *(void**)(r24 + 0x2c);
        // fadd s6, s6, s17  (0xb7b217c)
        // fmul s7, s7, s2  (0xb7b2180)
        // fmul s5, s5, s2  (0xb7b2184)
        // fadd s0, s0, s1  (0xb7b2188)
        // fmul s2, s16, s2  (0xb7b218c)
        // fadd s1, s3, s18  (0xb7b2190)
        // fadd s3, s4, s7  (0xb7b2194)
        // fadd s4, s6, s5  (0xb7b2198)
        // ldp s5, s6, [x24, #0x30]  (0xb7b219c)
        // fadd s0, s0, s2  (0xb7b21a0)
        // fadd s1, s1, s5  (0xb7b21a4)
        // ldp s2, s5, [x24, #0x38]  (0xb7b21a8)
        // fadd s3, s3, s6  (0xb7b21ac)
        // fadd s2, s4, s2  (0xb7b21b0)
        // fadd s0, s0, s5  (0xb7b21b4)
        // stp s1, s3, [x24, #0x30]  (0xb7b21b8)
        // stp s2, s0, [x24, #0x38]  (0xb7b21bc)
    label_0xb7b21c0:
        this = r20;
        this = fn_0x11a1c0dc(this, r1, r2, r3);  // call  [0x11a1c0dc]
        r8 = *(uint8_t*)(r22 + 0x79);
        r9 = *(void**)(r19 + 0x594);
        *(uint8_t*)(r19 + 0x94e) = r8;
        *(void**)(r19 + 0x594) = r8;
        r8 = *(void**)(r21 + 0x40);
        if (r8 == 0) goto label_0xb7b21f8;
        // scvtf s0, wzr  (0xb7b21e4)
        r22 = *(void**)(r19 + 0x958);
        *(void**)(r19 + 0x58c) = rs0;
        if (r22 != 0) goto label_0xb7b2258;
        goto label_0xb7b23b0;
    label_0xb7b21f8:
        r23 = *(void**)(r19 + 0x968);
        this = r22;
        this = fn_0x9e93210(this, r1, r2, r3);  // call  [0x9e93210]
        this = *(void**)(r22 + 0x18);
        // fmov s8, s0  (0xb7b2208)
        this = fn_0x11a1c238(this, r1, r2, r3);  // call  [0x11a1c238]
        rd0 = *(void**)(this);
        rs1 = *(void**)(this + 0x8);
        this = r23;
        *(void**)(sp + 0x58) = rd0;
        *(void**)(sp + 0x60) = rs1;
        this = fn_0x10b3eb2c(this, r1, r2, r3);  // call  [0x10b3eb2c]
        this = fn_0x10aa06a0(this, r1, r2, r3);  // call  [0x10aa06a0]
        // fmov s2, s0  (0xb7b2230)
        // fmov s0, s8  (0xb7b2234)
        // movk w8, #0x3f66, lsl #0x10  (0xb7b2238)
        r1 = sp + 0x58;
        this = r23;
        // fmov s1, w8  (0xb7b2244)
        this = fn_0xb84aa3c(this, r1, r2, r3);  // call  [0xb84aa3c]
        r22 = *(void**)(r19 + 0x958);
        *(void**)(r19 + 0x58c) = rs0;
        if (r22 == 0) goto label_0xb7b23b0;
    label_0xb7b2258:
        this = sp + 0x58;
        r1 = r19 + 0x614;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r1 = sp + 0x58;
        this = r22;
        this = fn_0x10372d1c(this, r1, r2, r3);  // call  [0x10372d1c]
        // ubfx w8, w0, #0x8, #0x8  (0xb7b2270)
        // fmov s0, #16  (0xb7b2274)
        r23 = (void*)0x1407f080;
        // scvtf s1, w8  (0xb7b2280)
        // and w8, w0, #0xff  (0xb7b2284)
        this = r23;
        // fdiv s8, s1, s0  (0xb7b228c)
        // scvtf s1, w8  (0xb7b2290)
        // fdiv s9, s1, s0  (0xb7b2294)
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r24 = *(void**)(r8 + 0x160);
        if (r24 == 0) goto label_0xb7b22d4;
        r8 = *(uint8_t*)(r24);
        if (r8 == 0) goto label_0xb7b22d4;
        r22 = *(void**)(r8 + 0x168);
        if (r22 == 0) goto label_0xb7b2714;
        r1 = r22 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r24);
        goto label_0xb7b2718;
    label_0xb7b22d4:
        this = (void*)0x1407f080;
        *(void**)(sp + 0x58) = rzr;
        *(uint8_t*)(sp + 0x60) = rzr;
        // stp xzr, xzr, [sp, #0x70]  (0xb7b22e4)
        *(void**)(sp + 0x68) = rzr;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        // movi d0, #0x0  (0xb7b22f0)
        r22 = rzr;
    label_0xb7b22f8:
        rs1 = *(void**)(r19 + 0x3f0);
        this = fn_0x13606be0(this, r1, r2, r3);  // call  [0x13606be0]
        // fmov s1, #1  (0xb7b2300)
        rs3 = *(void**)(r19 + 0x410);
        // scvtf s2, w8  (0xb7b230c)
        // stp xzr, xzr, [sp, #0x68]  (0xb7b2310)
        // fsub s0, s1, s0  (0xb7b2314)
        // fsub s1, s2, s0  (0xb7b2318)
        rs2 = *(void**)(r19 + 0x40c);
        // fmul s4, s8, s0  (0xb7b2320)
        // fmul s0, s9, s0  (0xb7b2324)
        // fmul s2, s2, s1  (0xb7b2328)
        // fmul s1, s3, s1  (0xb7b232c)
        // fadd s2, s2, s4  (0xb7b2330)
        // fadd s0, s1, s0  (0xb7b2334)
        *(void**)(r19 + 0x40c) = rs2;
        *(void**)(r19 + 0x410) = rs0;
        if (r22 == 0) goto label_0xb7b23a0;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b236c;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b236c:
        r22 = *(void**)(sp + 0x70);
        *(void**)(sp + 0x78) = rzr;
        if (r22 == 0) goto label_0xb7b23a0;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b23a0;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b23a0:
        r8 = *(uint8_t*)(sp + 0x60);
        if (r8 == 0) goto label_0xb7b23b0;
        this = *(void**)(sp + 0x58);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7b23b0:
        r8 = *(void**)(r19);
        this = r19;
        r1 = r21;
        r8 = *(void**)(r8 + 0x90);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r19);
        this = r19;
        r1 = r21;
        r8 = *(void**)(r8 + 0x58);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r19 + 0x978);
        r21 = r19 + 0x614;
        r10 = *(void**)(r19 + 0x61c);
        r9 = *(void**)(r21);
        r22 = *(void**)(r19 + 0x958);
        r8 = *(void**)(r8 + 0x430);
        *(void**)(sp + 0x50) = r10;
        *(void**)(sp + 0x48) = r9;
        this = *(void**)(r8 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x158);
        r8 = fp - 0x38;
        this = (*(void**)r8)(this);  // indirect call
        this = sp + 0x58;
        r1 = fp - 0x38;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x58;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7b2608  (0xb7b2420)
        this = sp + 0x58;
        r1 = rzr;
        this = fn_0x1020b844(this, r1, r2, r3);  // call  [0x1020b844]
        r23 = this;
        if (this == 0) goto label_0xb7b2608;
        rs8 = *(void**)(sp + 0x4c);
        // fmov s0, s8  (0xb7b243c)
        this = fn_0x1351eb18(this, r1, r2, r3);  // call  [0x1351eb18]
        // scvtf s0, w0  (0xb7b2444)
        // movk w8, #0x3f33, lsl #0x10  (0xb7b244c)
        // fmov s1, w8  (0xb7b2450)
        // fsub s0, s8, s0  (0xb7b2454)
        // fabs s0, s0  (0xb7b2458)
        // fcmpe s0, s1  (0xb7b245c)
        if (/* cond: b.le */) goto label_0xb7b24d4;
        // fmov s0, s8  (0xb7b2464)
        this = fn_0x1351eb30(this, r1, r2, r3);  // call  [0x1351eb30]
        // scvtf s0, w0  (0xb7b246c)
        r8 = *(void**)(sp + 0x48);
        r9 = *(void**)(sp + 0x50);
        r24 = this;
        *(void**)(sp + 0x58) = r8;
        *(void**)(sp + 0x60) = r9;
        *(void**)(sp + 0x5c) = rs0;
        this = r23;
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r25 = this;
        this = sp + 0x38;
        r1 = sp + 0x58;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r8 = *(void**)(r25);
        r8 = *(void**)(r8 + 0x30);
        r1 = sp + 0x38;
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0x109f425c(this, r1, r2, r3);  // call  [0x109f425c]
        this = fn_0x111c98b4(this, r1, r2, r3);  // call  [0x111c98b4]
        // tbz w0, #0x0, 0xb7b24cc  (0xb7b24bc)
        // fmov s0, s8  (0xb7b24c0)
        this = fn_0x1351eb18(this, r1, r2, r3);  // call  [0x1351eb18]
        r24 = this;
    label_0xb7b24cc:
        // scvtf s0, w24  (0xb7b24cc)
        goto label_0xb7b24e0;
    label_0xb7b24d4:
        // fmov s0, s8  (0xb7b24d4)
        this = fn_0x1351eb18(this, r1, r2, r3);  // call  [0x1351eb18]
        // scvtf s0, w0  (0xb7b24dc)
    label_0xb7b24e0:
        this = r23;
        *(void**)(sp + 0x4c) = rs0;
        this = fn_0xfdaf978(this, r1, r2, r3);  // call  [0xfdaf978]
        // fneg s0, s0  (0xb7b24f0)
        // movk w8, #0x3c8e, lsl #0x10  (0xb7b24f4)
        // fmov s1, w8  (0xb7b24f8)
        // fmul s8, s0, s1  (0xb7b24fc)
        // fmov s0, s8  (0xb7b2500)
        this = fn_0x1360e640(this, r1, r2, r3);  // call  [0x1360e640]
        // fmov s9, s0  (0xb7b2508)
        // fmov s0, s8  (0xb7b250c)
        this = fn_0x13686950(this, r1, r2, r3);  // call  [0x13686950]
        // movi d1, #0x0  (0xb7b2518)
        rs5 = *(void**)(r19 + 0x61c);
        // movk w8, #0x3dcc, lsl #0x10  (0xb7b2520)
        this = r20;
        // fmov s2, w8  (0xb7b2528)
        // fmul s4, s1, s9  (0xb7b252c)
        // fmul s3, s2, s0  (0xb7b2530)
        // fmul s2, s2, s9  (0xb7b2534)
        // fmul s0, s1, s0  (0xb7b2538)
        // fadd s3, s4, s3  (0xb7b253c)
        rs4 = *(void**)(r19 + 0x614);
        // fsub s0, s2, s0  (0xb7b2544)
        rs2 = *(void**)(r19 + 0x618);
        // fadd s1, s2, s1  (0xb7b254c)
        // fadd s3, s4, s3  (0xb7b2550)
        // fadd s0, s5, s0  (0xb7b2554)
        // stp s3, s1, [sp, #0x58]  (0xb7b2558)
        *(void**)(sp + 0x60) = rs0;
        this = fn_0x11a1c2cc(this, r1, r2, r3);  // call  [0x11a1c2cc]
        this = fn_0x1351eadc(this, r1, r2, r3);  // call  [0x1351eadc]
        rd0 = *(void**)(this + 0x18);
        rs1 = *(void**)(this + 0x20);
        r20 = this;
        *(void**)(sp + 0x38) = rd0;
        *(void**)(sp + 0x40) = rs1;
        r1 = sp + 0x38;
        this = r22;
        this = fn_0x1037be34(this, r1, r2, r3);  // call  [0x1037be34]
        // tbnz w0, #0x0, 0xb7b25fc  (0xb7b2588)
        rd0 = *(void**)(r20 + 0x24);
        rs1 = *(void**)(r20 + 0x2c);
        *(void**)(sp + 0x28) = rd0;
        *(void**)(sp + 0x30) = rs1;
        r1 = sp + 0x28;
        this = r22;
        this = fn_0x1037be34(this, r1, r2, r3);  // call  [0x1037be34]
        // tbnz w0, #0x0, 0xb7b25fc  (0xb7b25a8)
        rd0 = *(void**)(r20);
        rs1 = *(void**)(r20 + 0x8);
        *(void**)(sp + 0x18) = rd0;
        *(void**)(sp + 0x20) = rs1;
        r1 = sp + 0x18;
        this = r22;
        this = fn_0x1037be34(this, r1, r2, r3);  // call  [0x1037be34]
        // tbnz w0, #0x0, 0xb7b25fc  (0xb7b25c8)
        rd0 = *(void**)(r20 + 0xc);
        rs1 = *(void**)(r20 + 0x14);
        *(void**)(sp + 0x8) = rd0;
        *(void**)(sp + 0x10) = rs1;
        r1 = sp + 0x8;
        this = r22;
        this = fn_0x1037be34(this, r1, r2, r3);  // call  [0x1037be34]
        // tbnz w0, #0x0, 0xb7b25fc  (0xb7b25e8)
        r1 = sp + 0x58;
        this = r22;
        this = fn_0x1037be34(this, r1, r2, r3);  // call  [0x1037be34]
        // tbz w0, #0x0, 0xb7b2808  (0xb7b25f8)
    label_0xb7b25fc:
    label_0xb7b2600:
        // and w8, w0, #0x1  (0xb7b2600)
        *(uint8_t*)(r19 + 0x94a) = r8;
    label_0xb7b2608:
        r1 = sp + 0x48;
        this = r22;
        this = fn_0xb8474ec(this, r1, r2, r3);  // call  [0xb8474ec]
        // and w8, w0, #0x1  (0xb7b2618)
        *(uint8_t*)(r19 + 0x948) = r8;
        r1 = sp + 0x48;
        this = r22;
        this = fn_0xb8474ec(this, r1, r2, r3);  // call  [0xb8474ec]
        r8 = *(uint8_t*)(r19 + 0x948);
        // and w9, w0, #0x1  (0xb7b2634)
        *(uint8_t*)(r19 + 0x94b) = r9;
        // orr w8, w0, w8  (0xb7b263c)
        // tbz w8, #0x0, 0xb7b264c  (0xb7b2640)
        goto label_0xb7b2650;
    label_0xb7b264c:
        r8 = *(uint8_t*)(r19 + 0x94a);
    label_0xb7b2650:
        this = sp + 0x58;
        r1 = r21;
        *(uint8_t*)(r19 + 0x949) = r8;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0x138);
        r1 = sp + 0x58;
        this = r22;
        this = (*(void**)r8)(this);  // indirect call
        r20 = this;
        this = sp + 0x38;
        r1 = r21;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r1 = sp + 0x38;
        this = r20;
        this = fn_0x10aa08a0(this, r1, r2, r3);  // call  [0x10aa08a0]
        // lsr x8, x0, #0x20  (0xb7b2690)
        rs1 = *(void**)(r19 + 0x618);
        this = *(void**)(r19 + 0x968);
        // scvtf s0, w8  (0xb7b269c)
        // fcmpe s0, s1  (0xb7b26a0)
        // cset w8, ls  (0xb7b26a4)
        *(uint8_t*)(r19 + 0x94c) = r8;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xf8);
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(r19 + 0x94b);
        // cmp r8 == <complex operand>
        r8 = *(void**)(fp - 0x30);
        // cset w9, eq  (0xb7b26c4)
        // and w9, w0, w9  (0xb7b26c8)
        *(uint8_t*)(r19 + 0x94d) = r9;
        if (r8 == 0) goto label_0xb7b26dc;
        this = r8;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b26dc:
        r8 = *(void**)(r26 + 0x28);
        r9 = *(void**)(fp - 0x20);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b287c;
        // ldp x20, x19, [sp, #0x100]  (0xb7b26ec)
        r28 = *(void**)(sp + 0xc8);
        // ldp x22, x21, [sp, #0xf0]  (0xb7b26f4)
        rd10 = *(void**)(sp + 0xa0);
        // ldp x24, x23, [sp, #0xe0]  (0xb7b26fc)
        // ldp x26, x25, [sp, #0xd0]  (0xb7b2700)
        // ldp x29, x30, [sp, #0xb8]  (0xb7b2704)
        // ldp d9, d8, [sp, #0xa8]  (0xb7b2708)
        sp = sp + 0x110;
        return this;
}

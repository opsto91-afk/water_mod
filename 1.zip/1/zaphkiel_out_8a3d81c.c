// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d81c
// fn_va = 0x8a3d81c
// return type (guess): unknown (no ret found)
void* fn_0x8a3d81c(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x8a3d81c)
        *(void**)(sp + 0x10) = r19;
        this = *(void**)(this + 0x8);
        r19 = r1;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xf0);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3d858;
        r8 = *(void**)(this);
        r2 = *(void**)(r8 + 0x50);
        r1 = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3d850)
        goto *r_indirect;  // indirect branch/tailcall
    label_0x8a3d858:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3d85c)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d6b0
// fn_va = 0x8a3d6b0
// return type (guess): unknown (no ret found)
void* fn_0x8a3d6b0(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x8a3d6b0)
        *(void**)(sp + 0x10) = r19;
        this = *(void**)(this + 0x8);
        r19 = r8;
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0x608);
        this = (*(void**)r8)(this);  // indirect call
        rd0 = *(void**)(this);
        *(void**)(r19) = rd0;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3d6dc)
        return this;
}

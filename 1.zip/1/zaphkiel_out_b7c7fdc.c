// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c7fdc
// fn_va = 0xb7c7fdc
// return type (guess): unknown (no ret found)
void* fn_0xb7c7fdc(void* this, void* r1) {
        // stp x29, x30, [sp, #0x100]  (0xb7c7fe0)
        // stp x28, x27, [sp, #0x110]  (0xb7c7fe4)
        // stp x26, x25, [sp, #0x120]  (0xb7c7fe8)
        // stp x24, x23, [sp, #0x130]  (0xb7c7fec)
        // stp x22, x21, [sp, #0x140]  (0xb7c7ff0)
        // stp x20, x19, [sp, #0x150]  (0xb7c7ff4)
        fp = sp + 0x100;
        // mrs x8, tpidr_el0  (0xb7c7ffc)
        r28 = this;
        this = r1;
        *(void**)(sp + 0x20) = r8;
        r21 = r2;
        r8 = *(void**)(r8 + 0x28);
        *(void**)(fp - 0x10) = r8;
        *(void**)(sp + 0x18) = r1;
        this = fn_0xae17d74(this, r1, r2, r3);  // call  [0xae17d74]
        r23 = (void*)0x1407f080;
        r22 = this;
        this = r23;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        *(void**)(sp + 0x28) = r28;
        r19 = *(void**)(r8 + 0x160);
        if (r19 == 0) goto label_0xb7c8070;
        r8 = *(uint8_t*)(r19);
        if (r8 == 0) goto label_0xb7c8070;
        r24 = *(void**)(r8 + 0x168);
        if (r24 == 0) goto label_0xb7c8364;
        r1 = r24 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r19);
        goto label_0xb7c8368;
    label_0xb7c8070:
        this = (void*)0x1407f080;
        *(void**)(fp - 0x58) = rzr;
        // sturb wzr, [x29, #0xffffffffffffffb0]  (0xb7c807c)
        // stp xzr, xzr, [x29, #0xffffffffffffffc0]  (0xb7c8080)
        *(void**)(fp - 0x48) = rzr;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        r24 = rzr;
    label_0xb7c8090:
        r19 = *(void**)(r21 + 0x3270);
        r26 = *(void**)(r21 + 0x3278);
        // cmp r19 == r26
        if (/* cond: b.eq */) goto label_0xb7c8150;
        *(void**)(sp + 0x10) = r24;
        r28 = (void*)0x13a564a8;
        r24 = (void*)0x13a56488;
        goto label_0xb7c80cc;
    label_0xb7c80c0:
        r19 = r19 + 0x20;
        // cmp r19 == r26
        if (/* cond: b.eq */) goto label_0xb7c8148;
    label_0xb7c80cc:
        r23 = *(void**)(r19);
        r25 = *(void**)(r19 + 0x10);
        this = sp + 0x80;
        this = fn_0x117b5c0c(this, r1, r2, r3);  // call  [0x117b5c0c]
        *(void**)(sp + 0xa0) = r20;
        *(void**)(fp - 0x18) = rzr;
        r1 = r22 + 0x10;
        r3 = sp + 0x80;
        r6 = fp - 0x30;
        this = r23;
        r2 = r25;
        r4 = rzr;
        r5 = rzr;
        r7 = rzr;
        this = fn_0x117ae714(this, r1, r2, r3);  // call  [0x117ae714]
        r8 = *(void**)(fp - 0x18);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c8128;
        this = sp + 0x30;
        r1 = fp - 0x30;
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7c8128:
        r8 = *(void**)(sp + 0xa0);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c80c0;
        this = fp - 0x30;
        r1 = sp + 0x80;
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7c80c0;
    label_0xb7c8148:
        r28 = *(void**)(sp + 0x28);
        r24 = *(void**)(sp + 0x10);
    label_0xb7c8150:
        // stp xzr, xzr, [x29, #0xffffffffffffffb8]  (0xb7c8150)
        if (r24 == 0) goto label_0xb7c81b4;
        r1 = (void*)0x13a56490;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c8180;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c8180:
        r21 = *(void**)(fp - 0x40);
        *(void**)(fp - 0x38) = rzr;
        if (r21 == 0) goto label_0xb7c81b4;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c81b4;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c81b4:
        // ldurb w8, [x29, #0xffffffffffffffb0]  (0xb7c81b4)
        if (r8 == 0) goto label_0xb7c81c4;
        this = *(void**)(fp - 0x58);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7c81c4:
        r8 = *(void**)(r28 + 0x958);
        if (r8 == 0) goto label_0xb7c85e4;
        this = fp - 0x58;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = fp - 0x58;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7c85e4  (0xb7c81e4)
        this = fp - 0x58;
        r1 = rzr;
        this = fn_0x1020b844(this, r1, r2, r3);  // call  [0x1020b844]
        if (this == 0) goto label_0xb7c85e4;
        r19 = *(void**)(r28 + 0xe88);
        // stp xzr, xzr, [x29, #0xffffffffffffffa8]  (0xb7c81fc)
        if (r19 == 0) goto label_0xb7c85e4;
        r21 = this;
        r26 = sp + 0x40;
        goto label_0xb7c8228;
    label_0xb7c8218:
        *(void**)(sp + 0x70) = r8;
    label_0xb7c8220:
        r19 = *(void**)(r19);
        if (r19 == 0) goto label_0xb7c85b4;
    label_0xb7c8228:
        // scvtf s0, wzr  (0xb7c8228)
        rs1 = *(void**)(r19 + 0x20);
        // fcmpe s1, s0  (0xb7c8230)
        if (/* cond: b.le */) goto label_0xb7c8220;
        r22 = *(void**)(r28 + 0x958);
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0x10);
        r1 = r19 + 0x10;
        this = r22;
        this = (*(void**)r8)(this);  // indirect call
        r23 = this;
        this = r28;
        r1 = r23;
        this = fn_0xb7c0020(this, r1, r2, r3);  // call  [0xb7c0020]
        // tbz w0, #0x0, 0xb7c8220  (0xb7c8260)
        r1 = r19 + 0x10;
        this = r22;
        this = fn_0x10371388(this, r1, r2, r3);  // call  [0x10371388]
        if (this == 0) goto label_0xb7c8220;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xb8);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7c8220;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x50);
        r2 = r19 + 0x10;
        r1 = r22;
        this = (*(void**)r8)(this);  // indirect call
        r24 = this;
        if (this == 0) goto label_0xb7c8220;
        this = r21;
        this = fn_0x102095c4(this, r1, r2, r3);  // call  [0x102095c4]
        this = fn_0x100a0ac4(this, r1, r2, r3);  // call  [0x100a0ac4]
        // scvtf s1, w27  (0xb7c82ac)
        this = *(void**)(sp + 0x18);
        // fmul s0, s0, s1  (0xb7c82b4)
        // fcvtzs w20, s0  (0xb7c82b8)
        this = fn_0xae177d4(this, r1, r2, r3);  // call  [0xae177d4]
        r8 = *(void**)(r28 + 0x1118);
        r9 = *(void**)(r8 + 0x2a0);
        r8 = *(void**)(r8 + 0x298);
        // lsr x9, x9, #0x5  (0xb7c82d0)
        // cmp r20 == r9
        if (/* cond: b.ge */) goto label_0xb7c8300;
        // sxtw x9, w20  (0xb7c82dc)
        r28 = this;
        this = r8;
        this = fn_0x117b5ff8(this, r1, r2, r3);  // call  [0x117b5ff8]
        r7 = this;
        this = r28;
        r28 = *(void**)(sp + 0x28);
        goto label_0xb7c8304;
    label_0xb7c8300:
        r7 = fp - 0x58;
    label_0xb7c8304:
        *(uint8_t*)(sp + 0x40) = rzr;
        *(uint8_t*)(sp + 0x78) = rzr;
        r1 = *(void**)(sp + 0x18);
        r5 = rzr;
        r2 = r22;
        r3 = r24;
        r4 = r23;
        *(void**)(sp + 0x8) = r26;
        *(void**)(sp) = r8;
        this = fn_0xaa49de0(this, r1, r2, r3);  // call  [0xaa49de0]
        r8 = *(uint8_t*)(sp + 0x78);
        if (r8 == 0) goto label_0xb7c8220;
        r8 = *(void**)(sp + 0x70);
        // cmp r8 == - <complex operand>
        if (/* cond: b.eq */) goto label_0xb7c8218;
        r9 = (void*)0x13a56488;
        this = sp + 0x80;
        r1 = r26 + 0x18;
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7c8218;
    label_0xb7c8364:
    label_0xb7c8368:
        *(void**)(fp - 0x58) = r23;
        this = *(void**)(r9 + 0x170);
        // sturb w20, [x29, #0xffffffffffffffb0]  (0xb7c8374)
        // stp x19, x24, [x29, #0xffffffffffffffb8]  (0xb7c8378)
        *(void**)(fp - 0x38) = this;
        if (r8 == 0) goto label_0xb7c8090;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7c8090  (0xb7c8390)
        this = fn_0x117b6098(this, r1, r2, r3);  // call  [0x117b6098]
        // tbz w0, #0x0, 0xb7c8150  (0xb7c83a0)
        r8 = *(void**)(r22 + 0x18);
        this = (void*)0x1407f048;
        this = fn_0x11a19728(this, r1, r2, r3);  // call  [0x11a19728]
        r19 = *(void**)(r21 + 0x3270);
        r26 = *(void**)(r21 + 0x3278);
        // cmp r19 == r26
        if (/* cond: b.eq */) goto label_0xb7c8150;
        r23 = this;
        goto label_0xb7c83d4;
    label_0xb7c83c8:
        r19 = r19 + 0x20;
        // cmp r19 == r26
        if (/* cond: b.eq */) goto label_0xb7c8618;
    label_0xb7c83d4:
        r8 = *(void**)(fp - 0x48);
        if (r8 == 0) goto label_0xb7c83f4;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7c83f4  (0xb7c83e0)
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0xb7c83ec)
        *(void**)(r8) = r9;
    label_0xb7c83f4:
        r28 = *(void**)(fp - 0x38);
        r25 = *(void**)(r19);
        this = fn_0x117b5ff8(this, r1, r2, r3);  // call  [0x117b5ff8]
        // stp xzr, xzr, [sp, #0x30]  (0xb7c8408)
        r8 = *(void**)(this);
        if (r8 == 0) goto label_0xb7c8528;
        r8 = (void*)0x1407f010;
        // ldarh wzr, [x8]  (0xb7c8418)
        // ldp x20, x24, [x0]  (0xb7c841c)
        if (r24 == 0) goto label_0xb7c8430;
    label_0xb7c8424:
        r1 = (void*)0x13a56490;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7c8430:
        r27 = *(void**)(sp + 0x38);
        // stp x20, x24, [sp, #0x30]  (0xb7c8434)
        if (r27 == 0) goto label_0xb7c8464;
        r1 = r27 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c8464;
        r8 = *(void**)(r27);
        this = r27;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r27;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c8464:
        r4 = *(uint8_t*)(r19 + 0x18);
        r5 = *(uint8_t*)(r22 + 0x74);
        this = sp + 0x80;
        r2 = sp + 0x30;
        r1 = r25;
        r3 = r23;
        this = fn_0x11939ef0(this, r1, r2, r3);  // call  [0x11939ef0]
        r8 = (void*)0x140aa6f8;
        // ldarb w8, [x8]  (0xb7c8488)
        // tbz w8, #0x0, 0xb7c8538  (0xb7c848c)
    label_0xb7c8490:
        this = fp - 0x30;
        r1 = (void*)0x140add80;
        this = fn_0x135c7250(this, r1, r2, r3);  // call  [0x135c7250]
        r8 = *(void**)(r28);
        r8 = *(void**)(r8 + 0x368);
        r1 = sp + 0x80;
        this = r28;
        this = (*(void**)r8)(this);  // indirect call
        this = fp - 0x30;
        this = fn_0x135c7324(this, r1, r2, r3);  // call  [0x135c7324]
        r25 = *(void**)(sp + 0x90);
        r28 = *(void**)(sp + 0x28);
        if (r25 == 0) goto label_0xb7c84f4;
        r1 = r25 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c84f4;
        r8 = *(void**)(r25);
        this = r25;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r25;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c84f4:
        r25 = *(void**)(sp + 0x38);
        if (r25 == 0) goto label_0xb7c83c8;
        r1 = r25 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c83c8;
        r8 = *(void**)(r25);
        this = r25;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r25;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7c83c8;
    label_0xb7c8528:
        r20 = rzr;
        r24 = *(void**)(this + 0x8);
        if (r24 != 0) goto label_0xb7c8424;
        goto label_0xb7c8430;
    label_0xb7c8538:
        this = (void*)0x140aa6f8;
        this = fn_0x135d36e0(this, r1, r2, r3);  // call  [0x135d36e0]
        if (this == 0) goto label_0xb7c8490;
        this = "BgfxFrameBuilder";  // 0x25dd848
        r2 = rzr;
        this = fn_0x135c6c3c(this, r1, r2, r3);  // call  [0x135c6c3c]
        r1 = this;
        r20 = (void*)0x140add80;
        this = r20;
        r3 = "FrameBuilder - Insert";  // 0x25beb4b
        r5 = rzr;
        r6 = (void*)0x13a58858;
        this = fn_0x135c6eb4(this, r1, r2, r3);  // call  [0x135c6eb4]
        this = (void*)0x99a0c64;
        r1 = r20;
        r2 = (void*)0x1368a9b0;
        this = fn_0x135d36c0(this, r1, r2, r3);  // call  [0x135d36c0]
        this = (void*)0x140aa6f8;
        this = fn_0x135d36f0(this, r1, r2, r3);  // call  [0x135d36f0]
        goto label_0xb7c8490;
    label_0xb7c85b4:
        r19 = *(void**)(fp - 0x50);
        if (r19 == 0) goto label_0xb7c85e4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7c85e4;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7c85e4:
        r8 = *(void**)(sp + 0x20);
        r8 = *(void**)(r8 + 0x28);
        r9 = *(void**)(fp - 0x10);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7c86dc;
        // ldp x20, x19, [sp, #0x150]  (0xb7c85f8)
        // ldp x22, x21, [sp, #0x140]  (0xb7c85fc)
        // ldp x24, x23, [sp, #0x130]  (0xb7c8600)
        // ldp x26, x25, [sp, #0x120]  (0xb7c8604)
        // ldp x28, x27, [sp, #0x110]  (0xb7c8608)
        // ldp x29, x30, [sp, #0x100]  (0xb7c860c)
        sp = sp + 0x160;
        return this;
}

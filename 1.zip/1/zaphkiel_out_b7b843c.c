// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7b843c
// fn_va = 0xb7b843c
// return type (guess): unknown (no ret found)
void* fn_0xb7b843c(void* this) {
        // stp x29, x30, [sp, #0x30]  (0xb7b8440)
        *(void**)(sp + 0x40) = r23;
        // stp x22, x21, [sp, #0x50]  (0xb7b8448)
        // stp x20, x19, [sp, #0x60]  (0xb7b844c)
        fp = sp + 0x30;
        // mrs x23, tpidr_el0  (0xb7b8454)
        r19 = this;
        this = (void*)0x1407d860;
        r8 = *(void**)(r23 + 0x28);
        r20 = r1;
        *(void**)(fp - 0x8) = r8;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r22 = *(void**)(r8 + 0x940);
        if (r22 == 0) goto label_0xb7b84e8;
        r8 = *(uint8_t*)(r22);
        if (r8 == 0) goto label_0xb7b84e8;
        r21 = *(void**)(r8 + 0x948);
        if (r21 == 0) goto label_0xb7b84a8;
        r1 = r21 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r22);
        if (r8 == 0) goto label_0xb7b84c0;
    label_0xb7b84a8:
        r8 = *(void**)(r8 + 0x950);
        r9 = *(uint8_t*)(r8 + 0x18);
        if (r9 == 0) goto label_0xb7b84bc;
        r20 = *(uint8_t*)(r8 + 0x1c);
    label_0xb7b84bc:
        if (r21 == 0) goto label_0xb7b84e8;
    label_0xb7b84c0:
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b84e8;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b84e8:
        this = (void*)0x1407d860;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        r22 = *(void**)(r19 + 0x980);
        r21 = *(void**)(r19 + 0x988);
        // stp x22, x21, [sp, #0x18]  (0xb7b84fc)
        if (r21 == 0) goto label_0xb7b8510;
        r1 = r21 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7b8510:
        r8 = *(uint8_t*)(r19 + 0x990);
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7b85f8;
        if (r22 == 0) goto label_0xb7b8534;
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0x50);
        this = r22;
        this = (*(void**)r8)(this);  // indirect call
        // tbnz w0, #0x0, 0xb7b85f8  (0xb7b8530)
    label_0xb7b8534:
        r21 = *(void**)(r19 + 0xc70);
        r22 = *(void**)(r19 + 0xc68);
        if (r21 == 0) goto label_0xb7b854c;
        r1 = r21 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0xb7b854c:
        r8 = *(void**)(r19 + 0x978);
        this = sp;
        r4 = (void*)0x1407d500;
        r1 = r20;
        r2 = r22;
        r3 = r21;
        this = fn_0xb7b86ac(this, r1, r2, r3);  // call  [0xb7b86ac]
        rq0 = *(void**)(sp);
        r22 = *(void**)(r19 + 0x988);
        // stp xzr, xzr, [sp]  (0xb7b8570)
        *(void**)(r19 + 0x980) = rq0;
        if (r22 == 0) goto label_0xb7b85a4;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b85a4;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b85a4:
        r22 = *(void**)(sp + 0x8);
        if (r22 == 0) goto label_0xb7b85d4;
        r1 = r22 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b85d4;
        r8 = *(void**)(r22);
        this = r22;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b85d4:
        if (r21 == 0) goto label_0xb7b85e0;
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b85e0:
        *(uint8_t*)(r19 + 0x990) = r20;
        this = r19;
        this = fn_0xb7b8e44(this, r1, r2, r3);  // call  [0xb7b8e44]
        r21 = *(void**)(sp + 0x20);
        *(uint8_t*)(r19 + 0x991) = r8;
    label_0xb7b85f8:
        if (r21 == 0) goto label_0xb7b860c;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7b8634;
    label_0xb7b860c:
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b86a8;
        // ldp x20, x19, [sp, #0x60]  (0xb7b861c)
        r23 = *(void**)(sp + 0x40);
        // ldp x22, x21, [sp, #0x50]  (0xb7b8624)
        // ldp x29, x30, [sp, #0x30]  (0xb7b8628)
        sp = sp + 0x70;
        return this;
}

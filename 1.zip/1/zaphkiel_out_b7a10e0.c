// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a10e0
// fn_va = 0xb7a10e0
// return type (guess): unknown (no ret found)
void* fn_0xb7a10e0(void* this) {
        // stp d9, d8, [sp, #0x60]  (0xb7a10e4)
        // stp x29, x30, [sp, #0x70]  (0xb7a10e8)
        *(void**)(sp + 0x80) = r23;
        // stp x22, x21, [sp, #0x90]  (0xb7a10f0)
        // stp x20, x19, [sp, #0xa0]  (0xb7a10f4)
        fp = sp + 0x70;
        // mrs x22, tpidr_el0  (0xb7a10fc)
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x18) = r8;
        r20 = *(void**)(this + 0x958);
        if (r20 == 0) goto label_0xb7a1904;
        r19 = this;
        this = *(void**)(this + 0x968);
        r23 = r19 + 0x414;
        if (this == 0) goto label_0xb7a113c;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        r20 = *(void**)(r19 + 0x958);
        // cmp this == <complex operand>
        // cset w8, eq  (0xb7a1134)
        goto label_0xb7a1140;
    label_0xb7a113c:
        r8 = rzr;
    label_0xb7a1140:
        r9 = *(uint8_t*)(r19 + 0x949);
        *(uint8_t*)(sp + 0x30) = r8;
        r21 = sp + 0x30;
        r8 = *(void**)(r23);
        this = r21 + 0xc;
        r1 = r19 + 0x614;
        *(uint8_t*)(sp + 0x31) = r9;
        *(void**)(sp + 0x34) = r8;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        // fmov s0, #1  (0xb7a1164)
        r8 = *(uint8_t*)(sp + 0x30);
        rs8 = *(void**)(sp + 0x34);
        *(void**)(sp + 0x48) = r20;
        // tbnz w8, #0x0, 0xb7a11c4  (0xb7a1174)
        r8 = *(uint8_t*)(sp + 0x31);
        if (r8 == 0) goto label_0xb7a11ac;
        r8 = *(void**)(r20);
        // fmov d0, #0.5  (0xb7a1184)
        r1 = r21 + 0xc;
        this = r20;
        r8 = *(void**)(r8 + 0xc8);
        // fcvt s0, d0  (0xb7a1194)
        this = (*(void**)r8)(this);  // indirect call
        // fmov s1, #0.5  (0xb7a119c)
        r20 = *(void**)(r19 + 0x958);
        // fmul s0, s0, s1  (0xb7a11a4)
        // fadd s0, s0, s1  (0xb7a11a8)
    label_0xb7a11ac:
        // fsub s0, s0, s8  (0xb7a11b0)
        // movk w8, #0x3dcc, lsl #0x10  (0xb7a11b4)
        // fmov s1, w8  (0xb7a11b8)
        // fmul s0, s0, s1  (0xb7a11bc)
        // fadd s0, s8, s0  (0xb7a11c0)
    label_0xb7a11c4:
        r8 = *(void**)(r19 + 0x930);
        *(void**)(r19 + 0x414) = rs0;
        *(void**)(r19 + 0x418) = rs8;
        if (r8 == 0) goto label_0xb7a11e8;
        if (r20 == 0) goto label_0xb7a11e8;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x50);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a11e8:
        rs0 = *(void**)(r19 + 0xfc8);
        rs1 = *(void**)(r19 + 0xfd0);
        rs2 = *(void**)(r19 + 0xfd8);
        this = *(void**)(r19 + 0x10f8);
        *(void**)(r19 + 0xfcc) = rs0;
        rs0 = *(void**)(r19 + 0xfe0);
        *(void**)(r19 + 0xfd4) = rs1;
        *(void**)(r19 + 0xfdc) = rs2;
        *(void**)(r19 + 0xfe4) = rs0;
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x158);
        r8 = sp + 0x30;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r19 + 0x1100);
        r20 = *(void**)(r19 + 0x1108);
        // stp x8, x20, [sp, #0x18]  (0xb7a1224)
        if (r20 == 0) goto label_0xb7a12fc;
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(void**)(r19 + 0x1110);
        this = sp + 0x30;
        r1 = sp + 0x18;
        *(void**)(sp + 0x28) = r8;
        this = fn_0x13468598(this, r1, r2, r3);  // call  [0x13468598]
        r21 = this;
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        this = *(void**)(sp + 0x38);
        if (this == 0) goto label_0xb7a1268;
    label_0xb7a1264:
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a1268:
        // tbnz w21, #0x0, 0xb7a12b8  (0xb7a1268)
        this = sp + 0x30;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x30;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7a12b8  (0xb7a1280)
        this = sp + 0x30;
        r1 = rzr;
        this = fn_0xaf67fb0(this, r1, r2, r3);  // call  [0xaf67fb0]
        if (this == 0) goto label_0xb7a12b8;
        rs0 = *(void**)(r19 + 0xea8);
        *(void**)(r19 + 0xeac) = rs0;
        this = fn_0xaf60330(this, r1, r2, r3);  // call  [0xaf60330]
        rs1 = *(void**)(r19 + 0xea8);
        // fmov s2, #0.5  (0xb7a12a4)
        // fsub s0, s0, s1  (0xb7a12a8)
        // fmul s0, s0, s2  (0xb7a12ac)
        // fadd s0, s1, s0  (0xb7a12b0)
        *(void**)(r19 + 0xea8) = rs0;
    label_0xb7a12b8:
        r8 = *(uint8_t*)(r19 + 0x948);
        rs0 = *(void**)(r19 + 0xff4);
        if (r8 == 0) goto label_0xb7a1324;
        rs1 = *(void**)(r19 + 0xc94);
        // fcmpe s0, s1  (0xb7a12c8)
        if (/* cond: b.pl */) goto label_0xb7a135c;
        // movk w8, #0x3d4c, lsl #0x10  (0xb7a12d4)
        // fmov s2, w8  (0xb7a12d8)
        // fadd s0, s0, s2  (0xb7a12dc)
        // fcmpe s0, s1  (0xb7a12e0)
        if (/* cond: b.gt */) goto label_0xb7a12f4;
    label_0xb7a12e8:
        // movi d1, #0x0  (0xb7a12e8)
        // fcmpe s0, #0  (0xb7a12ec)
        // fcsel s1, s0, s1, gt  (0xb7a12f0)
    label_0xb7a12f4:
        *(void**)(r19 + 0xff4) = rs1;
        goto label_0xb7a135c;
    label_0xb7a12fc:
        r8 = *(void**)(r19 + 0x1110);
        this = sp + 0x30;
        r1 = sp + 0x18;
        *(void**)(sp + 0x28) = r8;
        this = fn_0x13468598(this, r1, r2, r3);  // call  [0x13468598]
        r21 = this;
        this = *(void**)(sp + 0x38);
        if (this != 0) goto label_0xb7a1264;
        goto label_0xb7a1268;
    label_0xb7a1324:
        // scvtf s1, wzr  (0xb7a1324)
        // fcmpe s0, s1  (0xb7a1328)
        if (/* cond: b.le */) goto label_0xb7a135c;
        // scvtf s1, w8  (0xb7a1334)
        // movk w8, #0x3d4c, lsl #0x10  (0xb7a133c)
        // fmov s2, w8  (0xb7a1340)
        // fmul s1, s2, s1  (0xb7a1344)
        // fsub s0, s0, s1  (0xb7a1348)
        rs1 = *(void**)(r19 + 0xc94);
        // fcmpe s0, s1  (0xb7a1350)
        if (/* cond: b.le */) goto label_0xb7a12e8;
        goto label_0xb7a12f4;
    label_0xb7a135c:
        r8 = *(void**)(r19 + 0x1298);
        if (r8 == 0) goto label_0xb7a13ac;
        this = sp + 0x30;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x30;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7a13ac  (0xb7a1378)
        this = sp + 0x30;
        r1 = rzr;
        this = fn_0xaf67fb0(this, r1, r2, r3);  // call  [0xaf67fb0]
        if (this == 0) goto label_0xb7a13ac;
        r20 = *(void**)(r19 + 0x1298);
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r1 = this;
        r2 = r19 + 0x614;
        this = r20;
        this = fn_0x10b196ec(this, r1, r2, r3);  // call  [0x10b196ec]
    label_0xb7a13ac:
        r20 = *(void**)(r19 + 0x958);
        if (r20 == 0) goto label_0xb7a1538;
        this = sp + 0x30;
        r1 = r19 + 0x614;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r1 = sp + 0x30;
        this = r20;
        this = fn_0x1037ad4c(this, r1, r2, r3);  // call  [0x1037ad4c]
        r21 = this;
        this = sp + 0x30;
        r1 = r19 + 0x614;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r2 = sp + 0x30;
        this = r21;
        r1 = r20;
        this = fn_0x10a9fb74(this, r1, r2, r3);  // call  [0x10a9fb74]
        this = r21;
        this = fn_0xb8f59a4(this, r1, r2, r3);  // call  [0xb8f59a4]
        r8 = *(uint8_t*)(r23 + 0xdf0);
        if (r8 == 0) goto label_0xb7a1604;
        rs4 = *(void**)(r19 + 0x11e0);
        // fmov s5, w8  (0xb7a1404)
        // fmul s6, s4, s5  (0xb7a1408)
        // fmul s5, s0, s5  (0xb7a140c)
        // fcvtzs w8, s6  (0xb7a1410)
        // fcvtzs w9, s5  (0xb7a1414)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a1560;
        rs5 = *(void**)(r19 + 0x11e4);
        // fmov s6, w8  (0xb7a1428)
        // fmul s7, s5, s6  (0xb7a142c)
        // fmul s6, s1, s6  (0xb7a1430)
        // fcvtzs w8, s7  (0xb7a1434)
        // fcvtzs w9, s6  (0xb7a1438)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a1560;
        rs6 = *(void**)(r19 + 0x11e8);
        // fmov s7, w8  (0xb7a144c)
        // fmul s16, s6, s7  (0xb7a1450)
        // fmul s7, s2, s7  (0xb7a1454)
        // fcvtzs w8, s16  (0xb7a1458)
        // fcvtzs w9, s7  (0xb7a145c)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a1560;
        rs7 = *(void**)(r19 + 0x11ec);
        // fmov s16, w8  (0xb7a1470)
        // fmul s17, s7, s16  (0xb7a1474)
        // fmul s16, s3, s16  (0xb7a1478)
        // fcvtzs w8, s17  (0xb7a147c)
        // fcvtzs w9, s16  (0xb7a1480)
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a1560;
        rs0 = *(void**)(r19 + 0x3f0);
        rs1 = *(void**)(r19 + 0x1200);
        // movk w8, #0x3ecc, lsl #0x10  (0xb7a1498)
        // fadd s3, s1, s0  (0xb7a149c)
        // fmov s0, w8  (0xb7a14a0)
        // fmov s1, #1  (0xb7a14a4)
        // fdiv s2, s3, s0  (0xb7a14a8)
        // fmov s0, #1  (0xb7a14ac)
        *(void**)(r19 + 0x1200) = rs3;
        // fcmpe s2, s1  (0xb7a14b4)
        if (/* cond: b.gt */) goto label_0xb7a14c8;
        // movi d0, #0x0  (0xb7a14bc)
        // fcmpe s2, #0  (0xb7a14c0)
        // fcsel s0, s2, s0, gt  (0xb7a14c4)
    label_0xb7a14c8:
        // fsub s1, s1, s0  (0xb7a14c8)
        rs2 = *(void**)(r19 + 0x11d0);
        rs3 = *(void**)(r19 + 0x11d4);
        rs16 = *(void**)(r19 + 0x11d8);
        rs17 = *(void**)(r19 + 0x11dc);
        // fmul s4, s4, s0  (0xb7a14dc)
        // fmul s5, s5, s0  (0xb7a14e0)
        // fmul s6, s6, s0  (0xb7a14e4)
        // fmul s0, s7, s0  (0xb7a14e8)
        // fmul s2, s2, s1  (0xb7a14ec)
        // fmul s3, s3, s1  (0xb7a14f0)
        // fmul s16, s16, s1  (0xb7a14f4)
        // fmul s1, s17, s1  (0xb7a14f8)
        // fadd s2, s2, s4  (0xb7a14fc)
        // fadd s3, s3, s5  (0xb7a1500)
        // fadd s4, s16, s6  (0xb7a1504)
        // fadd s0, s1, s0  (0xb7a1508)
        *(void**)(r19 + 0x11f0) = rs2;
        *(void**)(r19 + 0x11f4) = rs3;
        *(void**)(r19 + 0x11f8) = rs4;
        *(void**)(r19 + 0x11fc) = rs0;
        r8 = *(void**)(r19 + 0x1118);
        // nop   (0xb7a1520)
        // adr x21, 0xb7e9c84  (0xb7a1524)
        *(void**)(sp + 0x10) = r19;
        r20 = *(void**)(r8 + 0x80);
        if (r20 != 0) goto label_0xb7a1598;
        goto label_0xb7a1658;
    label_0xb7a1538:
        r8 = *(uint8_t*)(r23 + 0xdf0);
        if (r8 == 0) goto label_0xb7a1580;
        *(uint8_t*)(r23 + 0xdf0) = rzr;
        r8 = *(void**)(r19 + 0x1118);
        // nop   (0xb7a1548)
        // adr x21, 0xb7e9c84  (0xb7a154c)
        *(void**)(sp + 0x10) = r19;
        r20 = *(void**)(r8 + 0x80);
        if (r20 != 0) goto label_0xb7a1598;
        goto label_0xb7a1658;
    label_0xb7a1560:
        rq4 = *(void**)(r19 + 0x11f0);
        *(void**)(r19 + 0x11e0) = rs0;
        *(void**)(r19 + 0x11e4) = rs1;
        *(void**)(r19 + 0x11e8) = rs2;
        *(void**)(r19 + 0x11ec) = rs3;
        *(void**)(r19 + 0x1200) = rzr;
    label_0xb7a1580:
        r8 = *(void**)(r19 + 0x1118);
        // nop   (0xb7a1584)
        // adr x21, 0xb7e9c84  (0xb7a1588)
        *(void**)(sp + 0x10) = r19;
        r20 = *(void**)(r8 + 0x80);
        if (r20 == 0) goto label_0xb7a1658;
    label_0xb7a1598:
        r23 = *(void**)(r8 + 0x78);
        r1 = r20 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        this = r20;
        *(void**)(sp + 0x30) = rzr;
        this = fn_0x135d3990(this, r1, r2, r3);  // call  [0x135d3990]
        *(void**)(sp + 0x38) = this;
        if (this == 0) goto label_0xb7a15c0;
        *(void**)(sp + 0x30) = r23;
    label_0xb7a15c0:
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        r8 = *(void**)(sp + 0x30);
        if (r8 == 0) goto label_0xb7a165c;
        this = *(void**)(r19 + 0x1140);
        r8 = sp + 0x30;
        r9 = sp + 0x10;
        *(void**)(sp + 0x8) = r8;
        // nop   (0xb7a15e4)
        // adr x3, 0xb7e9da0  (0xb7a15e8)
        // stp x21, x9, [sp, #0x18]  (0xb7a15ec)
        r2 = sp + 0x18;
        r4 = sp + 0x8;
        this = fn_0xbd0f140(this, r1, r2, r3);  // call  [0xbd0f140]
        goto label_0xb7a1684;
    label_0xb7a1604:
        *(void**)(r19 + 0x11d0) = rs0;
        *(void**)(r19 + 0x11d4) = rs1;
        *(void**)(r19 + 0x11d8) = rs2;
        *(void**)(r19 + 0x11dc) = rs3;
        *(void**)(r19 + 0x11e0) = rs0;
        *(void**)(r19 + 0x11e4) = rs1;
        *(void**)(r19 + 0x11e8) = rs2;
        *(void**)(r19 + 0x11ec) = rs3;
        *(void**)(r19 + 0x11f0) = rs0;
        *(void**)(r19 + 0x11f4) = rs1;
        *(void**)(r19 + 0x11f8) = rs2;
        *(void**)(r19 + 0x11fc) = rs3;
        *(void**)(r19 + 0x1200) = rzr;
        *(uint8_t*)(r23 + 0xdf0) = r8;
        r8 = *(void**)(r19 + 0x1118);
        // nop   (0xb7a1644)
        // adr x21, 0xb7e9c84  (0xb7a1648)
        *(void**)(sp + 0x10) = r19;
        r20 = *(void**)(r8 + 0x80);
        if (r20 != 0) goto label_0xb7a1598;
    label_0xb7a1658:
        // stp xzr, xzr, [sp, #0x30]  (0xb7a1658)
    label_0xb7a165c:
        this = *(void**)(r19 + 0x1140);
        r9 = sp + 0x10;
        // stp x21, x9, [sp, #0x18]  (0xb7a1668)
        // nop   (0xb7a166c)
        // adr x3, 0xb7e9ea4  (0xb7a1670)
        r2 = sp + 0x18;
        r4 = sp + 0x8;
        this = fn_0xbd0f140(this, r1, r2, r3);  // call  [0xbd0f140]
    label_0xb7a1684:
        r20 = *(void**)(sp + 0x38);
        if (r20 == 0) goto label_0xb7a16b4;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a16b4;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a16b4:
        r20 = *(void**)(r19 + 0x958);
        this = sp + 0x30;
        // movk w21, #0xdead, lsl #0x10  (0xb7a16c8)
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        r1 = sp + 0x30;
        this = r20;
        this = fn_0x1037ad4c(this, r1, r2, r3);  // call  [0x1037ad4c]
        this = fn_0xb8f5af0(this, r1, r2, r3);  // call  [0xb8f5af0]
        this = *(void**)(r19 + 0x10f8);
        // fmov s8, s0  (0xb7a16e4)
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x9c8);
        r8 = sp + 0x30;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x30);
        if (r8 == 0) goto label_0xb7a184c;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7a185c  (0xb7a1704)
    label_0xb7a1708:
        this = *(void**)(sp + 0x40);
        // fmov s0, s8  (0xb7a170c)
        this = fn_0xbce1658(this, r1, r2, r3);  // call  [0xbce1658]
        r20 = *(void**)(sp + 0x38);
        // stp xzr, xzr, [sp, #0x30]  (0xb7a1718)
        if (r20 == 0) goto label_0xb7a177c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a1748;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a1748:
        r20 = *(void**)(sp + 0x38);
        *(void**)(sp + 0x40) = rzr;
        if (r20 == 0) goto label_0xb7a177c;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a177c;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a177c:
        // fmov s8, #1  (0xb7a177c)
        r8 = *(void**)(r19 + 0xe68);
        if (r8 == 0) goto label_0xb7a186c;
        r20 = *(void**)(r19 + 0xe60);
        if (r20 == 0) goto label_0xb7a186c;
        // fmov s9, #0.5  (0xb7a1790)
        goto label_0xb7a17a0;
    label_0xb7a1798:
        r20 = *(void**)(r20);
        if (r20 == 0) goto label_0xb7a186c;
    label_0xb7a17a0:
        r8 = *(void**)(r19 + 0x1120);
        if (r8 == 0) goto label_0xb7a1830;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7a1840  (0xb7a17ac)
    label_0xb7a17b0:
        this = *(void**)(r19 + 0x1130);
        r1 = *(void**)(r20 + 0x20);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x130);
        r8 = sp + 0x30;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(sp + 0x44);
        if (r8 == 0) goto label_0xb7a1798;
        // ldp w8, w9, [x20, #0x10]  (0xb7a17d0)
        rs3 = *(void**)(r19 + 0x1148);
        rs4 = *(void**)(r19 + 0x114c);
        // scvtf s0, w8  (0xb7a17dc)
        // scvtf s1, w9  (0xb7a17e0)
        r8 = *(void**)(r20 + 0x18);
        // scvtf s2, w8  (0xb7a17e8)
        // fadd s0, s0, s9  (0xb7a17ec)
        // fadd s1, s1, s9  (0xb7a17f0)
        // fadd s2, s2, s9  (0xb7a17f4)
        // fsub s0, s0, s3  (0xb7a17f8)
        // fsub s1, s1, s4  (0xb7a17fc)
        rs3 = *(void**)(r19 + 0x1150);
        // fsub s2, s2, s3  (0xb7a1804)
        // fmul s0, s0, s0  (0xb7a1808)
        // fmul s1, s1, s1  (0xb7a180c)
        // fadd s0, s0, s1  (0xb7a1810)
        // fmul s1, s2, s2  (0xb7a1814)
        rs2 = *(void**)(sp + 0x3c);
        // fadd s0, s0, s1  (0xb7a181c)
        // fmul s1, s2, s2  (0xb7a1820)
        // fcmpe s0, s1  (0xb7a1824)
        if (/* cond: b.hi */) goto label_0xb7a1798;
        goto label_0xb7a1868;
    label_0xb7a1830:
        r9 = rzr;
        *(void**)(r9) = r21;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7a17b0  (0xb7a183c)
    label_0xb7a1840:
        r8 = rzr;
        *(void**)(r8) = r21;
        goto label_0xb7a17b0;
    label_0xb7a184c:
        r9 = rzr;
        *(void**)(r9) = r21;
        r8 = *(uint8_t*)(r8);
        // tbnz w8, #0x0, 0xb7a1708  (0xb7a1858)
    label_0xb7a185c:
        r8 = rzr;
        *(void**)(r8) = r21;
        goto label_0xb7a1708;
    label_0xb7a1868:
        // movi d8, #0x0  (0xb7a1868)
    label_0xb7a186c:
        this = *(void**)(r19 + 0x10f8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x9c8);
        r8 = sp + 0x30;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(sp + 0x30);
        if (r8 == 0) goto label_0xb7a1930;
        r8 = *(uint8_t*)(r8);
        // tbz w8, #0x0, 0xb7a1940  (0xb7a188c)
    label_0xb7a1890:
        this = *(void**)(sp + 0x40);
        // fmov s0, s8  (0xb7a1894)
        this = fn_0xbce1760(this, r1, r2, r3);  // call  [0xbce1760]
        r19 = *(void**)(sp + 0x38);
        // stp xzr, xzr, [sp, #0x30]  (0xb7a18a0)
        if (r19 == 0) goto label_0xb7a1904;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a18d0;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a18d0:
        r19 = *(void**)(sp + 0x38);
        *(void**)(sp + 0x40) = rzr;
        if (r19 == 0) goto label_0xb7a1904;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a1904;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7a1904:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a1988;
        // ldp x20, x19, [sp, #0xa0]  (0xb7a1914)
        r23 = *(void**)(sp + 0x80);
        // ldp x22, x21, [sp, #0x90]  (0xb7a191c)
        // ldp x29, x30, [sp, #0x70]  (0xb7a1920)
        // ldp d9, d8, [sp, #0x60]  (0xb7a1924)
        sp = sp + 0xb0;
        return this;
}

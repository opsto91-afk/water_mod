// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d00b4
// fn_va = 0xb7d00b4
// return type (guess): unknown (no ret found)
void* fn_0xb7d00b4(void* this) {
        // stp x29, x30, [sp, #0x20]  (0xb7d00b8)
        *(void**)(sp + 0x30) = r25;
        // stp x24, x23, [sp, #0x40]  (0xb7d00c0)
        // stp x22, x21, [sp, #0x50]  (0xb7d00c4)
        // stp x20, x19, [sp, #0x60]  (0xb7d00c8)
        fp = sp + 0x20;
        // mrs x22, tpidr_el0  (0xb7d00d0)
        r21 = this;
        this = r1;
        r8 = *(void**)(r22 + 0x28);
        r19 = r1;
        *(void**)(fp - 0x8) = r8;
        r8 = sp + 0x8;
        this = fn_0xae04b88(this, r1, r2, r3);  // call  [0xae04b88]
        r20 = *(void**)(sp + 0x8);
        if (r20 == 0) goto label_0xb7d0174;
        r1 = r21 + 0x614;
        this = r19;
        this = fn_0xae17d0c(this, r1, r2, r3);  // call  [0xae17d0c]
        r1 = r21 + 0x620;
        this = r19;
        this = fn_0xae17cf4(this, r1, r2, r3);  // call  [0xae17cf4]
        r1 = (void*)0x14276bec;
        this = r19;
        this = fn_0xae17d30(this, r1, r2, r3);  // call  [0xae17d30]
        // ldp x9, x23, [x21, #0x1d8]  (0xb7d0120)
        // ldp x8, x21, [x21, #0x1f0]  (0xb7d0124)
        // cmp r9 == r23
        if (/* cond: b.ne */) goto label_0xb7d0138;
        // cmp r8 == r21
        if (/* cond: b.eq */) goto label_0xb7d0174;
    label_0xb7d0138:
        r8 = r8 + 0x1;
        r24 = r9 + 0x8;
    label_0xb7d0140:
        r2 = *(void**)(r24 - 0x8);
        r25 = r8;
        this = r20;
        r1 = r19;
        this = fn_0xab50590(this, r1, r2, r3);  // call  [0xab50590]
        r9 = r24 + 0x8;
        // cmp r24 == r23
        r8 = r25 + 0x1;
        r24 = r9;
        if (/* cond: b.ne */) goto label_0xb7d0140;
        // cmp r25 == r21
        r24 = r9;
        if (/* cond: b.ne */) goto label_0xb7d0140;
    label_0xb7d0174:
        r19 = *(void**)(sp + 0x10);
        if (r19 == 0) goto label_0xb7d018c;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7d01b8;
    label_0xb7d018c:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d021c;
        // ldp x20, x19, [sp, #0x60]  (0xb7d019c)
        r25 = *(void**)(sp + 0x30);
        // ldp x22, x21, [sp, #0x50]  (0xb7d01a4)
        // ldp x24, x23, [sp, #0x40]  (0xb7d01a8)
        // ldp x29, x30, [sp, #0x20]  (0xb7d01ac)
        sp = sp + 0x70;
        return this;
}

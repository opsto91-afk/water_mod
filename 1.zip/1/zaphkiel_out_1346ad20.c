// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x1346ad20
// fn_va = 0x1346ad20
// return type (guess): unknown (no ret found)
void* fn_0x1346ad20(void* this) {
        // stp x20, x19, [sp, #0x30]  (0x1346ad20)
        r22 = r8;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // movi v0.2d, #0x0  (0x1346ad34)
        r8 = (void*)0x13f3a738;
        r19 = this;
        *(void**)(this) = r8;
        r20 = this;
        r21 = this;
        r23 = this;
        *(void**)(this + 0xa8) = rzr;
        // stp q0, q0, [x0, #0xb0]  (0x1346ad5c)
        *(void**)(this + 0xd0) = rq0;
        *(void**)(r20 + 0x8) = rq0;
        *(void**)(r21 + 0x38) = rq0;
        *(void**)(r23 + 0x68) = rq0;
        *(void**)(this + 0x18) = rq0;
        *(void**)(this + 0x28) = rq0;
        *(void**)(this + 0x48) = rq0;
        *(void**)(this + 0x58) = rq0;
        *(void**)(this + 0x78) = rq0;
        *(void**)(this + 0x88) = rq0;
        *(void**)(this + 0x98) = rq0;
        *(void**)(this + 0xb0) = r8;
        this = this + 0x80;
        this = fn_0x1346f20c(this, r1, r2, r3);  // call  [0x1346f20c]
        // movi v0.2d, #0x0  (0x1346ad9c)
        *(void**)(r19 + 0xd8) = rzr;
        *(void**)(r19 + 0xc8) = rq0;
        *(void**)(r19 + 0xb8) = rq0;
        *(void**)(r22) = r19;
        // ldp x20, x19, [sp, #0x30]  (0x1346adb0)
        r23 = *(void**)(sp + 0x10);
        // ldp x22, x21, [sp, #0x20]  (0x1346adb8)
        // ldp x29, x30, [sp], #0x40  (0x1346adbc)
        return this;
}

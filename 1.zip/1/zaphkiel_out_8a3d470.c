// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d470
// fn_va = 0x8a3d470
// return type (guess): unknown (no ret found)
void* fn_0x8a3d470(void* this, void* r1) {
        // stp x29, x30, [sp, #0x40]  (0x8a3d474)
        // stp x22, x21, [sp, #0x50]  (0x8a3d478)
        // stp x20, x19, [sp, #0x60]  (0x8a3d47c)
        fp = sp + 0x40;
        // mrs x22, tpidr_el0  (0x8a3d484)
        r20 = r1;
        r21 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x8) = r8;
        // ldp x8, x19, [x1]  (0x8a3d498)
        // stp x8, x19, [sp]  (0x8a3d49c)
        if (r19 == 0) goto label_0x8a3d4b0;
        r1 = r19 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3d4b0:
        this = *(void**)(r21 + 0x8);
        r9 = *(void**)(r20 + 0x10);
        r8 = *(void**)(this);
        *(void**)(sp + 0x10) = r9;
        r8 = *(void**)(r8 + 0x538);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3d4fc;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3d4fc  (0x8a3d4e0)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        r20 = this;
        if (r19 != 0) goto label_0x8a3d504;
        goto label_0x8a3d50c;
    label_0x8a3d4fc:
        r20 = rzr;
        if (r19 == 0) goto label_0x8a3d50c;
    label_0x8a3d504:
        this = r19;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3d50c:
        if (r20 == 0) goto label_0x8a3d538;
        this = r20;
        this = fn_0xfd8da84(this, r1, r2, r3);  // call  [0xfd8da84]
        r8 = *(void**)(this + 0x8);
        this = *(void**)(this);
        // orr x1, x8, #0x100000000  (0x8a3d520)
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0x8a3d550;
        goto label_0x8a3d58c;
    label_0x8a3d538:
        r1 = rzr;
        this = rzr;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x8a3d58c;
    label_0x8a3d550:
        // ldp x20, x19, [sp, #0x60]  (0x8a3d550)
        // ldp x22, x21, [sp, #0x50]  (0x8a3d554)
        // ldp x29, x30, [sp, #0x40]  (0x8a3d558)
        sp = sp + 0x70;
        return this;
}

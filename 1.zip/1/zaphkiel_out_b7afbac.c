// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7afbac
// fn_va = 0xb7afbac
// return type (guess): unknown (no ret found)
void* fn_0xb7afbac(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7afbac)
        // stp x20, x19, [sp, #0x10]  (0xb7afbb0)
        r20 = r1;
        r19 = this;
        this = fn_0xb7afc3c(this, r1, r2, r3);  // call  [0xb7afc3c]
        this = r20;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0xb7afbdc  (0xb7afbcc)
        r1 = r19 + 0xc60;
        this = r20;
        this = fn_0xaf66c9c(this, r1, r2, r3);  // call  [0xaf66c9c]
    label_0xb7afbdc:
        r8 = *(void**)(r19 + 0x978);
        this = r8 + 0x500;
        this = fn_0xb81cdd4(this, r1, r2, r3);  // call  [0xb81cdd4]
        this = *(void**)(r19 + 0x978);
        this = fn_0xb7a583c(this, r1, r2, r3);  // call  [0xb7a583c]
        this = *(void**)(r19 + 0x968);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7afc18  (0xb7afc00)
        this = *(void**)(r19 + 0x968);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xd0);
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7afc1c;
    label_0xb7afc18:
    label_0xb7afc1c:
        *(uint16_t*)(r19 + 0x970) = this;
        *(uint8_t*)(r19 + 0x4cb) = rzr;
        *(void**)(r19 + 0x5f0) = rzr;
        *(void**)(r19 + 0x600) = rzr;
        *(void**)(r19 + 0x5f8) = rzr;
        // ldp x20, x19, [sp, #0x10]  (0xb7afc30)
        // ldp x29, x30, [sp], #0x20  (0xb7afc34)
        return this;
}

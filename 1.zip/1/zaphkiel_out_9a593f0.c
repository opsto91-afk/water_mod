// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a593f0
// fn_va = 0x9a593f0
// return type (guess): unknown (no ret found)
void* fn_0x9a593f0(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a593f0)
        *(void**)(sp + 0x10) = r19;
        r8 = *(uint8_t*)(this + 0xb8);
        r19 = this;
        // tbnz w8, #0x0, 0x9a59444  (0x9a59404)
        r8 = *(uint8_t*)(r19 + 0x98);
        // tbnz w8, #0x0, 0x9a59454  (0x9a5940c)
    label_0x9a59410:
        r8 = *(uint8_t*)(r19 + 0x80);
        // tbnz w8, #0x0, 0x9a59464  (0x9a59414)
    label_0x9a59418:
        r8 = *(uint8_t*)(r19 + 0x68);
        // tbnz w8, #0x0, 0x9a59474  (0x9a5941c)
    label_0x9a59420:
        r8 = *(uint8_t*)(r19 + 0x48);
        // tbnz w8, #0x0, 0x9a59484  (0x9a59424)
    label_0x9a59428:
        r8 = *(uint8_t*)(r19 + 0x30);
        // tbnz w8, #0x0, 0x9a59494  (0x9a5942c)
    label_0x9a59430:
        r8 = *(uint8_t*)(r19 + 0x18);
        // tbnz w8, #0x0, 0x9a594a4  (0x9a59434)
    label_0x9a59438:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9a5943c)
        return this;
}

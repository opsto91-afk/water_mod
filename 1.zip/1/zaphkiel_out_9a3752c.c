// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a3752c
// fn_va = 0x9a3752c
// return type (guess): unknown (no ret found)
void* fn_0x9a3752c(void* this) {
        // stp x10, x8, [sp, #0xa8]  (0x9a3752c)
        // tbz w9, #0x0, 0x9a3753c  (0x9a37530)
        this = *(void**)(sp + 0x100);
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
    label_0x9a3753c:
        this = r20 + 0x18;
        this = fn_0xe803550(this, r1, r2, r3);  // call  [0xe803550]
        this = sp + 0x98;
        r1 = r19 + 0x8;
        this = fn_0xe811614(this, r1, r2, r3);  // call  [0xe811614]
        this = r20 + 0x80;
        this = fn_0xe803558(this, r1, r2, r3);  // call  [0xe803558]
        r8 = *(void**)(r26 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9a37658;
        sp = sp + 0x1d0;
        // ldp x20, x19, [sp, #0x70]  (0x9a3756c)
        // ldp x22, x21, [sp, #0x60]  (0x9a37570)
        // ldp x24, x23, [sp, #0x50]  (0x9a37574)
        // ldp x26, x25, [sp, #0x40]  (0x9a37578)
        // ldp x28, x27, [sp, #0x30]  (0x9a3757c)
        // ldp x29, x30, [sp, #0x20]  (0x9a37580)
        // ldp d9, d8, [sp, #0x10]  (0x9a37584)
        // ldp d11, d10, [sp], #0x80  (0x9a37588)
        return this;
}

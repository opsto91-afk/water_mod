// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3de78
// fn_va = 0x8a3de78
// return type (guess): unknown (no ret found)
void* fn_0x8a3de78(void* this) {
        // stp x29, x30, [sp, #0xfffffffffffffff0]!  (0x8a3de78)
        this = fn_0xe82fbf8(this, r1, r2, r3);  // call  [0xe82fbf8]
        // fcvt s0, d0  (0x8a3de84)
        // ldp x29, x30, [sp], #0x10  (0x8a3de88)
        return this;
}

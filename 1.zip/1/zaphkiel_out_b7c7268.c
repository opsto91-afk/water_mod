// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c7268
// fn_va = 0xb7c7268
// return type (guess): unknown (no ret found)
void* fn_0xb7c7268(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7c7268)
        // stp x20, x19, [sp, #0x10]  (0xb7c726c)
        r19 = r1;
        r20 = this;
        this = fn_0xb7a8c50(this, r1, r2, r3);  // call  [0xb7a8c50]
        rd0 = *(void**)(r19 + 0x8);
        rs1 = *(void**)(r19 + 0x10);
        r8 = r20 + 0x614;
        *(void**)(r8) = rd0;
        *(void**)(r20 + 0x61c) = rs1;
        rd0 = *(void**)(r19 + 0x14);
        rs1 = *(void**)(r19 + 0x1c);
        *(void**)(r20 + 0x620) = rd0;
        *(void**)(r20 + 0x628) = rs1;
        // ldp x20, x19, [sp, #0x10]  (0xb7c72a4)
        // ldp x29, x30, [sp], #0x20  (0xb7c72a8)
        return this;
}

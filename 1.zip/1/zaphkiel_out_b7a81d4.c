// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a81d4
// fn_va = 0xb7a81d4
// return type (guess): unknown (no ret found)
void* fn_0xb7a81d4(void* this) {
        // stp x20, x19, [sp, #0x50]  (0xb7a81d4)
        fp = sp + 0x20;
        // mrs x22, tpidr_el0  (0xb7a81dc)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r8 = *(void**)(this + 0x5b0);
        // ldp x23, x24, [x8, #0xc8]  (0xb7a81f0)
        // cmp r23 == r24
        if (/* cond: b.eq */) goto label_0xb7a8244;
        r8 = *(void**)(r19 + 0x978);
        r20 = *(void**)(r8 + 0x350);
        goto label_0xb7a821c;
    label_0xb7a8208:
        this = r21;
        this = fn_0xa9d4da0(this, r1, r2, r3);  // call  [0xa9d4da0]
    label_0xb7a8210:
        r23 = r23 + 0x10;
        // cmp r23 == r24
        if (/* cond: b.eq */) goto label_0xb7a8244;
    label_0xb7a821c:
        r21 = *(void**)(r23);
        if (r21 == 0) goto label_0xb7a8210;
        this = r21;
        this = fn_0xa9d3b6c(this, r1, r2, r3);  // call  [0xa9d3b6c]
        if (this == 0) goto label_0xb7a8208;
        r1 = r20;
        r2 = rzr;
        this = fn_0xa9ce4c0(this, r1, r2, r3);  // call  [0xa9ce4c0]
        r21 = *(void**)(r23);
        goto label_0xb7a8208;
    label_0xb7a8244:
        this = fn_0xab4c360(this, r1, r2, r3);  // call  [0xab4c360]
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0xe8);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0xb7af424(this, r1, r2, r3);  // call  [0xb7af424]
        r20 = this;
        this = *(void**)(this + 0x20);
        if (this == 0) goto label_0xb7a8284;
        rq0 = *(void**)(r20 + 0xc8);
        r1 = sp;
        *(void**)(sp) = rq0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x30);
        this = (*(void**)r8)(this);  // indirect call
    label_0xb7a8284:
        // ldp x23, x24, [x20, #0xc8]  (0xb7a8284)
        goto label_0xb7a8290;
    label_0xb7a828c:
        r24 = r24 - 0x10;
    label_0xb7a8290:
        // cmp r24 == r23
        if (/* cond: b.eq */) goto label_0xb7a82cc;
        r21 = *(void**)(r24 - 0x8);
        if (r21 == 0) goto label_0xb7a828c;
        r1 = r21 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7a828c;
        r8 = *(void**)(r21);
        this = r21;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r21;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7a828c;
    label_0xb7a82cc:
        // movi v0.2d, #0x0  (0xb7a82cc)
        *(void**)(r20 + 0xd0) = r23;
        this = r19;
        *(void**)(r20 + 0x98) = rq0;
        *(void**)(r20 + 0xa8) = rq0;
        *(void**)(r20 + 0xb8) = rq0;
        r8 = *(void**)(r19);
        *(void**)(r19 + 0x594) = rzr;
        r8 = *(void**)(r8 + 0xf0);
        this = (*(void**)r8)(this);  // indirect call
        r8 = r19 + 0x614;
        r9 = *(void**)(r19 + 0x61c);
        r8 = *(void**)(r8);
        *(void**)(r19 + 0x5e0) = r9;
        *(void**)(r19 + 0x5d8) = r8;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7a8330;
        // ldp x20, x19, [sp, #0x50]  (0xb7a8318)
        // ldp x22, x21, [sp, #0x40]  (0xb7a831c)
        // ldp x24, x23, [sp, #0x30]  (0xb7a8320)
        // ldp x29, x30, [sp, #0x20]  (0xb7a8324)
        sp = sp + 0x60;
        return this;
}

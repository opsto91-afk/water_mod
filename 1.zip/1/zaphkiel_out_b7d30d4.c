// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d30d4
// fn_va = 0xb7d30d4
// return type (guess): unknown (no ret found)
void* fn_0xb7d30d4(void* this) {
        *(void**)(sp + 0xa0) = rd12;
        // stp d11, d10, [sp, #0xb0]  (0xb7d30dc)
        // stp d9, d8, [sp, #0xc0]  (0xb7d30e0)
        // stp x29, x30, [sp, #0xd0]  (0xb7d30e4)
        // stp x28, x27, [sp, #0xe0]  (0xb7d30e8)
        // stp x26, x25, [sp, #0xf0]  (0xb7d30ec)
        // stp x24, x23, [sp, #0x100]  (0xb7d30f0)
        // stp x22, x21, [sp, #0x110]  (0xb7d30f4)
        // stp x20, x19, [sp, #0x120]  (0xb7d30f8)
        fp = sp + 0xd0;
        // mrs x8, tpidr_el0  (0xb7d3100)
        r20 = this;
        r2 = fp - 0x50;
        *(void**)(sp + 0x10) = r8;
        r8 = *(void**)(r8 + 0x28);
        *(void**)(fp - 0x40) = r8;
        r8 = *(void**)(this + 0x1d8);
        r9 = *(void**)(this + 0x1f0);
        rs0 = *(void**)(this + 0xd88);
        r22 = *(void**)(this + 0x958);
        *(void**)(this + 0x1e0) = r8;
        r8 = *(void**)(this + 0x918);
        // fmul s11, s0, s0  (0xb7d3130)
        *(void**)(this + 0x1f8) = r9;
        r9 = *(void**)(this + 0x220);
        *(void**)(this + 0x920) = r8;
        r8 = *(void**)(this + 0x238);
        *(void**)(this + 0x228) = r9;
        r9 = *(void**)(this + 0x250);
        *(void**)(this + 0x240) = r8;
        *(void**)(this + 0x258) = r9;
        this = sp + 0x50;
        // ldp s1, s2, [x1, #0x14]  (0xb7d3158)
        rs3 = *(void**)(r1 + 0x1c);
        r1 = sp + 0x28;
        // fsub s6, s3, s0  (0xb7d3164)
        *(void**)(sp + 0x70) = rs3;
        // fadd s3, s3, s0  (0xb7d316c)
        // fsub s4, s1, s0  (0xb7d3170)
        // fsub s5, s2, s0  (0xb7d3174)
        // stp s1, s2, [sp, #0x68]  (0xb7d3178)
        // fadd s1, s1, s0  (0xb7d317c)
        // fadd s2, s2, s0  (0xb7d3180)
        *(void**)(sp + 0x30) = rs6;
        // stp s4, s5, [sp, #0x28]  (0xb7d3188)
        // stp s1, s2, [x29, #0xffffffffffffffb0]  (0xb7d318c)
        *(void**)(fp - 0x48) = rs3;
        this = fn_0x11f0f24c(this, r1, r2, r3);  // call  [0x11f0f24c]
        r8 = *(void**)(r20 + 0x978);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0xae0);
        r8 = sp + 0x28;
        this = (*(void**)r8)(this);  // indirect call
        // ldp x8, x19, [sp, #0x28]  (0xb7d31b0)
        *(void**)(sp + 0x20) = r8;
        if (r19 == 0) goto label_0xb7d31e0;
        r1 = r19 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r23 = *(void**)(sp + 0x30);
        if (r23 == 0) goto label_0xb7d31e0;
        r1 = r23 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7d39d8;
    label_0xb7d31e0:
        r8 = *(void**)(sp + 0x20);
        *(void**)(sp + 0x8) = r19;
        if (r8 == 0) goto label_0xb7d3968;
    label_0xb7d31ec:
        r8 = *(void**)(r22);
        r8 = *(void**)(r8 + 0xe8);
        r2 = sp + 0x50;
        this = r22;
        r1 = rzr;
        r3 = rzr;
        r4 = rzr;
        this = (*(void**)r8)(this);  // indirect call
        // tbnz x0, #0x3f, 0xb7d3a00  (0xb7d320c)
        if (this == 0) goto label_0xb7d359c;
        r23 = r1;
        r28 = fp - 0x50;
        goto label_0xb7d3240;
    label_0xb7d322c:
        this = fn_0xfdabf60(this, r1, r2, r3);  // call  [0xfdabf60]
    label_0xb7d3230:
        *(uint8_t*)(this + 0xf4) = r27;
    label_0xb7d3234:
        r23 = r23 + 0x8;
        // cmp r23 == r25
        if (/* cond: b.eq */) goto label_0xb7d359c;
    label_0xb7d3240:
        r24 = *(void**)(r23);
        if (r24 == 0) goto label_0xb7d3234;
        this = r24;
        this = fn_0xfd98a68(this, r1, r2, r3);  // call  [0xfd98a68]
        // tbnz w0, #0x0, 0xb7d3234  (0xb7d3250)
        this = r24;
        this = fn_0xfd86998(this, r1, r2, r3);  // call  [0xfd86998]
        // ldp s8, s9, [sp, #0x68]  (0xb7d325c)
        rs10 = *(void**)(sp + 0x70);
        // ldp s0, s1, [x0]  (0xb7d3264)
        rs2 = *(void**)(this + 0x8);
        // fsub s2, s10, s2  (0xb7d326c)
        // fsub s0, s8, s0  (0xb7d3270)
        // fsub s1, s9, s1  (0xb7d3274)
        // fmul s0, s0, s0  (0xb7d3278)
        // fmul s1, s1, s1  (0xb7d327c)
        // fadd s0, s0, s1  (0xb7d3280)
        // fmul s1, s2, s2  (0xb7d3284)
        // fadd s12, s0, s1  (0xb7d3288)
        // fcmpe s12, s11  (0xb7d328c)
        if (/* cond: b.gt */) goto label_0xb7d3234;
        r8 = *(void**)(r20 + 0xdb0);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xf8);
        this = (*(void**)r8)(this);  // indirect call
        r24 = this;
        this = fn_0xfd7b6c0(this, r1, r2, r3);  // call  [0xfd7b6c0]
        // tbnz w0, #0x0, 0xb7d32c0  (0xb7d32b0)
        this = *(void**)(r23);
        this = fn_0xfd7b6c0(this, r1, r2, r3);  // call  [0xfd7b6c0]
        // tbnz w0, #0x0, 0xb7d3234  (0xb7d32bc)
    label_0xb7d32c0:
        this = *(void**)(r23);
        this = fn_0xfd94eb0(this, r1, r2, r3);  // call  [0xfd94eb0]
        // tbz w0, #0x0, 0xb7d32f4  (0xb7d32c8)
        this = *(void**)(r23);
        this = fn_0xfd89a58(this, r1, r2, r3);  // call  [0xfd89a58]
        // cmp this == r24
        if (/* cond: b.ne */) goto label_0xb7d32f4;
        r8 = *(void**)(r20 + 0xdb0);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x688);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7d34d8  (0xb7d32f0)
    label_0xb7d32f4:
        r8 = *(void**)(r20 + 0xdb0);
        this = *(void**)(r8 + 0x3d8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x688);
        this = (*(void**)r8)(this);  // indirect call
        r8 = this;
        this = *(void**)(r23);
        // cmp this == r24
        // cset w9, ne  (0xb7d3314)
        // orr w8, w8, w9  (0xb7d3318)
        // tbnz w8, #0x0, 0xb7d333c  (0xb7d331c)
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0x150);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r8 = this;
        this = *(void**)(r23);
        // tbz w8, #0x0, 0xb7d322c  (0xb7d3338)
    label_0xb7d333c:
        this = fn_0xfdabf60(this, r1, r2, r3);  // call  [0xfdabf60]
        *(uint8_t*)(this + 0xf4) = rzr;
        r24 = *(void**)(r23);
        this = r24;
        this = fn_0xfdabfb4(this, r1, r2, r3);  // call  [0xfdabfb4]
        // tbnz w0, #0x0, 0xb7d3234  (0xb7d3350)
        // fsqrt s0, s12  (0xb7d3354)
        this = r24;
        this = fn_0xfdabfe0(this, r1, r2, r3);  // call  [0xfdabfe0]
        r1 = *(void**)(r23);
        this = *(void**)(sp + 0x20);
        r8 = sp + 0x40;
        this = fn_0xab4e914(this, r1, r2, r3);  // call  [0xab4e914]
        this = *(void**)(sp + 0x40);
        if (this == 0) goto label_0xb7d3568;
        r8 = *(void**)(this);
        r1 = *(void**)(r23);
        r9 = *(void**)(r8 + 0x48);
        r8 = sp + 0x28;
        this = (*(void**)r8)(this);  // indirect call
        r1 = sp + 0x28;
        this = r20;
        this = fn_0xb7aecb0(this, r1, r2, r3);  // call  [0xb7aecb0]
        // tbz w0, #0x0, 0xb7d3458  (0xb7d3398)
        // ldp s1, s2, [sp, #0x28]  (0xb7d339c)
        rs0 = *(void**)(r20 + 0x6ec);
        rs3 = *(void**)(r20 + 0x6f0);
        rs4 = *(void**)(r20 + 0x6f4);
        // ldp s5, s6, [sp, #0x30]  (0xb7d33ac)
        // fsub s1, s1, s0  (0xb7d33b0)
        // fsub s2, s2, s3  (0xb7d33b4)
        // fsub s0, s6, s0  (0xb7d33b8)
        // ldp s7, s6, [sp, #0x38]  (0xb7d33bc)
        // fsub s5, s5, s4  (0xb7d33c0)
        // stp s1, s2, [x29, #0xffffffffffffffb0]  (0xb7d33c4)
        // fsub s3, s7, s3  (0xb7d33c8)
        // fsub s1, s6, s4  (0xb7d33cc)
        *(void**)(fp - 0x48) = rs5;
        // stp s0, s3, [x29, #0xffffffffffffffa4]  (0xb7d33d4)
        *(void**)(fp - 0x54) = rs1;
        this = r20 + 0x62c;
        r1 = fp - 0x50;
        r2 = fp - 0x5c;
        this = fn_0x1351dda0(this, r1, r2, r3);  // call  [0x1351dda0]
        r24 = this;
        this = *(void**)(r23);
        // and w1, w24, #0x1  (0xb7d33f4)
        this = fn_0xfdac028(this, r1, r2, r3);  // call  [0xfdac028]
        // tbz w24, #0x0, 0xb7d3464  (0xb7d33fc)
        r8 = *(void**)(r23);
        *(void**)(fp - 0x50) = r8;
        if (r8 == 0) goto label_0xb7d3a00;
        // ldp x19, x9, [x20, #0x1d8]  (0xb7d340c)
        // sturb w26, [x29, #0xffffffffffffffb8]  (0xb7d3410)
        // subs x10, x9, x19  (0xb7d3414)
        if (/* cond: b.eq */) goto label_0xb7d3528;
        // asr x10, x10, #0x3  (0xb7d341c)
        r24 = r19;
    label_0xb7d3424:
        // lsr x11, x10, #0x1  (0xb7d3424)
        // mvn x14, x11  (0xb7d342c)
        // cmp r13 == r8
        // csel x10, x10, x11, cc  (0xb7d343c)
        // csel x24, x12, x24, cc  (0xb7d3440)
        if (r10 != 0) goto label_0xb7d3424;
        r21 = *(void**)(r20 + 0x1f0);
        // cmp r9 == r24
        if (/* cond: b.ne */) goto label_0xb7d3538;
        goto label_0xb7d3544;
    label_0xb7d3458:
        this = *(void**)(r23);
        r1 = rzr;
        this = fn_0xfdac028(this, r1, r2, r3);  // call  [0xfdac028]
    label_0xb7d3464:
        r1 = *(void**)(r23);
        // fmov s0, s8  (0xb7d3468)
        // fmov s1, s9  (0xb7d346c)
        this = r20;
        // fmov s2, s10  (0xb7d3474)
        this = fn_0xb7b95c0(this, r1, r2, r3);  // call  [0xb7b95c0]
        // tbz w0, #0x0, 0xb7d3568  (0xb7d347c)
        r8 = *(void**)(r23);
        *(void**)(fp - 0x50) = r8;
        if (r8 == 0) goto label_0xb7d3a00;
        // ldp x19, x9, [x20, #0x1d8]  (0xb7d348c)
        // sturb w26, [x29, #0xffffffffffffffb8]  (0xb7d3490)
        // subs x10, x9, x19  (0xb7d3494)
        if (/* cond: b.eq */) goto label_0xb7d34e4;
        // asr x10, x10, #0x3  (0xb7d349c)
        r24 = r19;
    label_0xb7d34a4:
        // lsr x11, x10, #0x1  (0xb7d34a4)
        // mvn x14, x11  (0xb7d34ac)
        // cmp r13 == r8
        // csel x10, x10, x11, cc  (0xb7d34bc)
        // csel x24, x12, x24, cc  (0xb7d34c0)
        if (r10 != 0) goto label_0xb7d34a4;
        r21 = *(void**)(r20 + 0x1f0);
        // cmp r9 == r24
        if (/* cond: b.ne */) goto label_0xb7d34f4;
        goto label_0xb7d3500;
    label_0xb7d34d8:
        this = *(void**)(r23);
        this = fn_0xfdabf60(this, r1, r2, r3);  // call  [0xfdabf60]
        goto label_0xb7d3230;
    label_0xb7d34e4:
        r24 = r19;
        r21 = *(void**)(r20 + 0x1f0);
        // cmp r9 == r19
        if (/* cond: b.eq */) goto label_0xb7d3500;
    label_0xb7d34f4:
        r9 = *(void**)(r24);
        // cmp r8 == r9
        if (/* cond: b.hs */) goto label_0xb7d3568;
    label_0xb7d3500:
        this = r20 + 0x1d8;
        r2 = fp - 0x50;
        r1 = r24;
        this = fn_0xb7f7704(this, r1, r2, r3);  // call  [0xb7f7704]
        this = r20 + 0x1f0;
        r2 = r28 + 0x8;
        this = fn_0xb7f7944(this, r1, r2, r3);  // call  [0xb7f7944]
        goto label_0xb7d3568;
    label_0xb7d3528:
        r24 = r19;
        r21 = *(void**)(r20 + 0x1f0);
        // cmp r9 == r19
        if (/* cond: b.eq */) goto label_0xb7d3544;
    label_0xb7d3538:
        r9 = *(void**)(r24);
        // cmp r8 == r9
        if (/* cond: b.hs */) goto label_0xb7d3568;
    label_0xb7d3544:
        this = r20 + 0x1d8;
        r2 = fp - 0x50;
        r1 = r24;
        this = fn_0xb7f7704(this, r1, r2, r3);  // call  [0xb7f7704]
        this = r20 + 0x1f0;
        r2 = r28 + 0x8;
        this = fn_0xb7f7944(this, r1, r2, r3);  // call  [0xb7f7944]
    label_0xb7d3568:
        r24 = *(void**)(sp + 0x48);
        if (r24 == 0) goto label_0xb7d3234;
        r1 = r24 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d3234;
        r8 = *(void**)(r24);
        this = r24;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r24;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7d3234;
    label_0xb7d359c:
        r8 = *(void**)(r20 + 0x9e8);
        r23 = r20 + 0x9e8;
        *(void**)(r20 + 0x9f0) = r8;
        r1 = sp + 0x50;
        this = r22;
        r2 = r23;
        this = fn_0x10376000(this, r1, r2, r3);  // call  [0x10376000]
        r28 = *(void**)(r20 + 0x9e8);
        r22 = *(void**)(r20 + 0x9f0);
        // cmp r28 == r22
        if (/* cond: b.eq */) goto label_0xb7d3854;
        r8 = r20 + 0x220;
        *(void**)(sp + 0x18) = r8;
        r8 = r20 + 0x250;
        *(void**)(sp) = r8;
        goto label_0xb7d35f4;
    label_0xb7d35e0:
    label_0xb7d35e4:
        *(void**)(r20 + 0x258) = r19;
    label_0xb7d35e8:
        r28 = r28 + 0x8;
        // cmp r28 == r22
        if (/* cond: b.eq */) goto label_0xb7d3850;
    label_0xb7d35f4:
        r24 = *(void**)(r28);
        if (r24 == 0) goto label_0xb7d35e8;
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0x10);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r25 = this;
        this = sp + 0x28;
        r1 = sp + 0x68;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        // ldpsw x8, x11, [sp, #0x28]  (0xb7d361c)
        // ldpsw x9, x10, [x25]  (0xb7d3620)
        r10 = *(int32_t*)(r25 + 0x8);
        // mul x8, x8, x8  (0xb7d3630)
        r11 = *(int32_t*)(sp + 0x30);
        // nop   (0xb7d3638)
        // madd x8, x9, x9, x8  (0xb7d363c)
        // madd x8, x9, x9, x8  (0xb7d3644)
        // ucvtf s0, x8  (0xb7d3648)
        // fcmpe s0, s11  (0xb7d364c)
        if (/* cond: b.gt */) goto label_0xb7d35e8;
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0x58);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        r1 = this;
        this = r20;
        this = fn_0xb7aecb0(this, r1, r2, r3);  // call  [0xb7aecb0]
        // tbz w0, #0x0, 0xb7d35e8  (0xb7d3670)
        r8 = *(void**)(r24);
        r8 = *(void**)(r8 + 0x58);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        // ldp s1, s2, [x0]  (0xb7d3684)
        rs0 = *(void**)(r20 + 0x6ec);
        rs3 = *(void**)(r20 + 0x6f0);
        rs4 = *(void**)(r20 + 0x6f4);
        // ldp s5, s6, [x0, #0x8]  (0xb7d3694)
        // fsub s1, s1, s0  (0xb7d3698)
        // fsub s2, s2, s3  (0xb7d369c)
        // fsub s0, s6, s0  (0xb7d36a0)
        // ldp s7, s6, [x0, #0x10]  (0xb7d36a4)
        // fsub s5, s5, s4  (0xb7d36a8)
        // stp s1, s2, [sp, #0x28]  (0xb7d36ac)
        // fsub s3, s7, s3  (0xb7d36b0)
        // fsub s1, s6, s4  (0xb7d36b4)
        *(void**)(sp + 0x30) = rs5;
        // stp s0, s3, [x29, #0xffffffffffffffb0]  (0xb7d36bc)
        *(void**)(fp - 0x48) = rs1;
        this = r20 + 0x62c;
        r1 = sp + 0x28;
        r2 = fp - 0x50;
        this = fn_0x1351dda0(this, r1, r2, r3);  // call  [0x1351dda0]
        // tbz w0, #0x0, 0xb7d35e8  (0xb7d36d4)
        r19 = *(void**)(r20 + 0x228);
        r8 = *(void**)(r20 + 0x230);
        // cmp r19 == r8
        if (/* cond: b.hs */) goto label_0xb7d36f0;
        goto label_0xb7d3780;
    label_0xb7d36f0:
        r9 = *(void**)(sp + 0x18);
        r25 = *(void**)(r9);
        // asr x19, x26, #0x3  (0xb7d36fc)
        r9 = r19 + 0x1;
        // lsr x10, x9, #0x3d  (0xb7d3704)
        if (r10 != 0) goto label_0xb7d3a58;
        // asr x10, x8, #0x2  (0xb7d3710)
        // cmp r10 == r9
        // csel x9, x10, x9, hi  (0xb7d3718)
        r10 = 0x7ffffffffffffff8;
        // cmp r8 == r10
        r8 = 0x1fffffffffffffff;
        // csel x21, x9, x8, cc  (0xb7d3728)
        if (r21 == 0) goto label_0xb7d3748;
        // lsr x8, x21, #0x3d  (0xb7d3730)
        if (r8 != 0) goto label_0xb7d3a38;
        // lsl x0, x21, #0x3  (0xb7d3738)
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r27 = this;
        goto label_0xb7d374c;
    label_0xb7d3748:
        r27 = rzr;
    label_0xb7d374c:
        this = r27;
        r1 = r25;
        r2 = r26;
        this = fn_0x135df980(this, r1, r2, r3);  // call  [0x135df980]
        *(void**)(r20 + 0x220) = r27;
        *(void**)(r20 + 0x228) = r19;
        *(void**)(r20 + 0x230) = r21;
        if (r25 == 0) goto label_0xb7d3780;
        this = r25;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d3780:
        *(void**)(r20 + 0x228) = r19;
        this = r20;
        r1 = r24;
        this = fn_0xb7bb54c(this, r1, r2, r3);  // call  [0xb7bb54c]
        r8 = *(void**)(r24);
        r1 = *(void**)(r20 + 0x958);
        r8 = *(void**)(r8 + 0x40);
        this = r24;
        this = (*(void**)r8)(this);  // indirect call
        // fcmp s0, #0  (0xb7d37a4)
        if (/* cond: b.eq */) goto label_0xb7d35e8;
        r19 = *(void**)(r20 + 0x258);
        r8 = *(void**)(r20 + 0x260);
        // cmp r19 == r8
        if (/* cond: b.lo */) goto label_0xb7d35e0;
        r9 = *(void**)(sp);
        r25 = *(void**)(r9);
        // asr x19, x26, #0x3  (0xb7d37c8)
        r9 = r19 + 0x1;
        // lsr x10, x9, #0x3d  (0xb7d37d0)
        if (r10 != 0) goto label_0xb7d3a50;
        // asr x10, x8, #0x2  (0xb7d37dc)
        // cmp r10 == r9
        // csel x9, x10, x9, hi  (0xb7d37e4)
        r10 = 0x7ffffffffffffff8;
        // cmp r8 == r10
        r8 = 0x1fffffffffffffff;
        // csel x21, x9, x8, cc  (0xb7d37f4)
        if (r21 == 0) goto label_0xb7d3814;
        // lsr x8, x21, #0x3d  (0xb7d37fc)
        if (r8 != 0) goto label_0xb7d3a38;
        // lsl x0, x21, #0x3  (0xb7d3804)
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r27 = this;
        goto label_0xb7d3818;
    label_0xb7d3814:
        r27 = rzr;
    label_0xb7d3818:
        this = r27;
        r1 = r25;
        r2 = r26;
        this = fn_0x135df980(this, r1, r2, r3);  // call  [0x135df980]
        *(void**)(r20 + 0x250) = r27;
        *(void**)(r20 + 0x258) = r19;
        *(void**)(r20 + 0x260) = r21;
        if (r25 == 0) goto label_0xb7d35e4;
        this = r25;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
        goto label_0xb7d35e4;
    label_0xb7d3850:
        r28 = *(void**)(r23);
    label_0xb7d3854:
        // ldp x9, x26, [x20, #0x1d8]  (0xb7d3854)
        *(void**)(r20 + 0x9f0) = r28;
        // ldp x8, x27, [x20, #0x1f0]  (0xb7d385c)
        // cmp r9 == r26
        if (/* cond: b.ne */) goto label_0xb7d3870;
        // cmp r8 == r27
        if (/* cond: b.eq */) goto label_0xb7d3968;
    label_0xb7d3870:
        r10 = r20 + 0x918;
        r8 = r8 + 0x1;
        r28 = r9 + 0x8;
        *(void**)(sp + 0x18) = r10;
    label_0xb7d3880:
        r1 = *(void**)(r28 - 0x8);
        r19 = r8;
        this = *(void**)(sp + 0x20);
        this = fn_0xab51614(this, r1, r2, r3);  // call  [0xab51614]
        // tbz w0, #0x0, 0xb7d3948  (0xb7d3890)
        r21 = *(void**)(r20 + 0x920);
        r8 = *(void**)(r20 + 0x928);
        // cmp r21 == r8
        if (/* cond: b.hs */) goto label_0xb7d38b0;
        r8 = *(void**)(r28 - 0x8);
        goto label_0xb7d3944;
    label_0xb7d38b0:
        r9 = *(void**)(sp + 0x18);
        r23 = *(void**)(r9);
        // asr x21, x24, #0x3  (0xb7d38bc)
        r9 = r21 + 0x1;
        // lsr x10, x9, #0x3d  (0xb7d38c4)
        if (r10 != 0) goto label_0xb7d3a04;
        // asr x10, x8, #0x2  (0xb7d38d0)
        // cmp r10 == r9
        // csel x9, x10, x9, hi  (0xb7d38d8)
        r10 = 0x7ffffffffffffff8;
        // cmp r8 == r10
        r8 = 0x1fffffffffffffff;
        // csel x22, x9, x8, cc  (0xb7d38e8)
        if (r22 == 0) goto label_0xb7d3908;
        // lsr x8, x22, #0x3d  (0xb7d38f0)
        if (r8 != 0) goto label_0xb7d3a20;
        // lsl x0, x22, #0x3  (0xb7d38f8)
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        r25 = this;
        goto label_0xb7d390c;
    label_0xb7d3908:
        r25 = rzr;
    label_0xb7d390c:
        r8 = *(void**)(r28 - 0x8);
        this = r25;
        r1 = r23;
        r2 = r24;
        this = fn_0x135df980(this, r1, r2, r3);  // call  [0x135df980]
        *(void**)(r20 + 0x918) = r25;
        *(void**)(r20 + 0x920) = r21;
        *(void**)(r20 + 0x928) = r22;
        if (r23 == 0) goto label_0xb7d3944;
        this = r23;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d3944:
        *(void**)(r20 + 0x920) = r21;
    label_0xb7d3948:
        r9 = r28 + 0x8;
        // cmp r28 == r26
        r8 = r19 + 0x1;
        r28 = r9;
        if (/* cond: b.ne */) goto label_0xb7d3880;
        // cmp r19 == r27
        r28 = r9;
        if (/* cond: b.ne */) goto label_0xb7d3880;
    label_0xb7d3968:
        r19 = *(void**)(sp + 0x8);
        if (r19 == 0) goto label_0xb7d3998;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d3998;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d3998:
        r8 = *(void**)(sp + 0x10);
        r8 = *(void**)(r8 + 0x28);
        r9 = *(void**)(fp - 0x40);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d3ad4;
        // ldp x20, x19, [sp, #0x120]  (0xb7d39ac)
        rd12 = *(void**)(sp + 0xa0);
        // ldp x22, x21, [sp, #0x110]  (0xb7d39b4)
        // ldp x24, x23, [sp, #0x100]  (0xb7d39b8)
        // ldp x26, x25, [sp, #0xf0]  (0xb7d39bc)
        // ldp x28, x27, [sp, #0xe0]  (0xb7d39c0)
        // ldp x29, x30, [sp, #0xd0]  (0xb7d39c4)
        // ldp d9, d8, [sp, #0xc0]  (0xb7d39c8)
        // ldp d11, d10, [sp, #0xb0]  (0xb7d39cc)
        sp = sp + 0x130;
        return this;
}

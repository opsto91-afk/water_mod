// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d0dd8
// fn_va = 0xb7d0dd8
// return type (guess): unknown (no ret found)
void* fn_0xb7d0dd8(void* this) {
        // stp x29, x30, [sp, #0x120]  (0xb7d0ddc)
        *(void**)(sp + 0x130) = r28;
        // stp x26, x25, [sp, #0x140]  (0xb7d0de4)
        // stp x24, x23, [sp, #0x150]  (0xb7d0de8)
        // stp x22, x21, [sp, #0x160]  (0xb7d0dec)
        // stp x20, x19, [sp, #0x170]  (0xb7d0df0)
        fp = sp + 0x120;
        // mrs x24, tpidr_el0  (0xb7d0df8)
        r19 = r1;
        r21 = this;
        r8 = *(void**)(r24 + 0x28);
        this = r3;
        r1 = rzr;
        r20 = r3;
        r22 = r2;
        *(void**)(fp - 0x8) = r8;
        this = fn_0xb92ae48(this, r1, r2, r3);  // call  [0xb92ae48]
        r23 = this;
        this = fp - 0x40;
        this = fn_0xffb4dc0(this, r1, r2, r3);  // call  [0xffb4dc0]
        // ldp s0, s1, [x23, #0x4]  (0xb7d0e2c)
        this = sp;
        r1 = rzr;
        this = fn_0xff99778(this, r1, r2, r3);  // call  [0xff99778]
        // movi v0.2d, #0x0  (0xb7d0e3c)
        r25 = sp + 0x88;
        this = r25 + 0x10;
        r1 = sp;
        *(void**)(sp + 0x88) = r8;
        *(void**)(sp + 0xd0) = rzr;
        *(void**)(r25 + 0x8) = rq0;
        *(void**)(r25 + 0x18) = rq0;
        *(void**)(r25 + 0x28) = rq0;
        *(void**)(r25 + 0x38) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x88;
        *(void**)(sp + 0xd8) = r8;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        r1 = 0x9a99;
        r2 = "variable.emittertexturecoord";  // 0x27da54d
        // movk x1, #0x9314, lsl #0x10  (0xb7d0e8c)
        this = fp - 0x40;
        r3 = sp + 0x88;
        // movk x1, #0xe058, lsl #0x20  (0xb7d0e98)
        // movk x1, #0x3a1a, lsl #0x30  (0xb7d0e9c)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x88;
        r26 = sp + 0x88;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        // ldp s0, s1, [x23, #0xc]  (0xb7d0eb8)
        // ldp s2, s3, [x23, #0x4]  (0xb7d0ebc)
        // fsub s0, s0, s2  (0xb7d0ec0)
        // fsub s1, s1, s3  (0xb7d0ec4)
        this = sp;
        r1 = rzr;
        this = fn_0xff99778(this, r1, r2, r3);  // call  [0xff99778]
        // movi v0.2d, #0x0  (0xb7d0ed4)
        this = r26 + 0x10;
        r1 = sp;
        *(void**)(sp + 0x88) = r8;
        *(void**)(sp + 0xd0) = rzr;
        *(void**)(r25 + 0x8) = rq0;
        *(void**)(r25 + 0x18) = rq0;
        *(void**)(r25 + 0x28) = rq0;
        *(void**)(r25 + 0x38) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x88;
        *(void**)(sp + 0xd8) = r8;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        r1 = 0x78d;
        r2 = "variable.emittertexturesize";  // 0x2486dc1
        // movk x1, #0x3e3e, lsl #0x10  (0xb7d0f20)
        this = fp - 0x40;
        r3 = sp + 0x88;
        // movk x1, #0xfae4, lsl #0x20  (0xb7d0f2c)
        // movk x1, #0xfb03, lsl #0x30  (0xb7d0f30)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x88;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        r1 = 0x20fa;
        // fmov s0, #0.25  (0xb7d0f4c)
        r2 = "variable.emitter_radius";  // 0x26802d2
        // movk x1, #0x45, lsl #0x10  (0xb7d0f58)
        this = fp - 0x40;
        // movk x1, #0x8087, lsl #0x20  (0xb7d0f60)
        // movk x1, #0x93fd, lsl #0x30  (0xb7d0f64)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        r8 = *(void**)(r22 + 0x4);
        // ucvtf s0, w8  (0xb7d0f70)
        r1 = 0x7ac3;
        r2 = "variable.num_particles";  // 0x265c4f3
        // movk x1, #0xdd6b, lsl #0x10  (0xb7d0f80)
        this = fp - 0x40;
        // movk x1, #0x95aa, lsl #0x20  (0xb7d0f88)
        // movk x1, #0x8421, lsl #0x30  (0xb7d0f8c)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        rs0 = *(void**)(r22 + 0x8);
        r1 = 0x4fc6;
        r2 = "variable.size_modifier";  // 0x25062c4
        // movk x1, #0x5a1f, lsl #0x10  (0xb7d0fa4)
        this = fp - 0x40;
        // movk x1, #0x501b, lsl #0x20  (0xb7d0fac)
        // movk x1, #0x650d, lsl #0x30  (0xb7d0fb0)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        rs0 = *(void**)(r22 + 0xc);
        r1 = 0x12a;
        r2 = "variable.speed_modifier";  // 0x25e14b3
        // movk x1, #0x4cb3, lsl #0x10  (0xb7d0fc8)
        this = fp - 0x40;
        // movk x1, #0xcc6f, lsl #0x20  (0xb7d0fd0)
        // movk x1, #0xad3a, lsl #0x30  (0xb7d0fd4)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        r8 = *(void**)(r21 + 0x1118);
        r9 = *(void**)(r8 + 0x380);
        if (r9 == 0) goto label_0xb7d1084;
        r9 = *(uint8_t*)(r9);
        // tbz w9, #0x0, 0xb7d109c  (0xb7d0fec)
    label_0xb7d0ff0:
        r9 = *(void**)(r20 + 0x1c);
        r20 = *(void**)(r8 + 0x390);
        // orr w9, w9, #0x2  (0xb7d0ff8)
        // cmp r9 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7d10c0;
    label_0xb7d1004:
        r1 = "minecraft:breaking_item_terrain";  // 0x25062db
        this = sp + 0x88;
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        this = sp + 0x50;
        r1 = fp - 0x40;
        this = fn_0xffb53d8(this, r1, r2, r3);  // call  [0xffb53d8]
        r1 = sp + 0x88;
        r3 = sp + 0x50;
        this = r20;
        r2 = r19;
        this = fn_0xb05f824(this, r1, r2, r3);  // call  [0xb05f824]
        this = sp + 0x50;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        r8 = *(uint8_t*)(sp + 0x90);
        // tbz w8, #0x0, 0xb7d104c  (0xb7d1040)
    label_0xb7d1044:
        this = *(void**)(sp + 0xa0);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7d104c:
        this = fp - 0x40;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d1180;
        // ldp x20, x19, [sp, #0x170]  (0xb7d1064)
        r28 = *(void**)(sp + 0x130);
        // ldp x22, x21, [sp, #0x160]  (0xb7d106c)
        // ldp x24, x23, [sp, #0x150]  (0xb7d1070)
        // ldp x26, x25, [sp, #0x140]  (0xb7d1074)
        // ldp x29, x30, [sp, #0x120]  (0xb7d1078)
        sp = sp + 0x180;
        return this;
}

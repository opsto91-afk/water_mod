// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d0234
// fn_va = 0xb7d0234
// return type (guess): unknown (no ret found)
void* fn_0xb7d0234(void* this) {
        // stp x20, x19, [sp, #0x40]  (0xb7d0234)
        fp = sp + 0x8;
        r23 = this;
        this = r1;
        r22 = r1;
        r19 = r8;
        this = fn_0x10dde16c(this, r1, r2, r3);  // call  [0x10dde16c]
        r8 = *(uint8_t*)(this);
        r9 = *(void**)(this + 0x8);
        // lsr x10, x8, #0x1  (0xb7d0258)
        // tst w8, #0x1  (0xb7d025c)
        // csel x8, x10, x9, eq  (0xb7d0260)
        if (r8 == 0) goto label_0xb7d0290;
        // and w1, w1, #0xffff  (0xb7d0268)
        r8 = r19;
        r2 = rzr;
        // ldp x20, x19, [sp, #0x40]  (0xb7d0274)
        r25 = *(void**)(sp + 0x18);
        // ldp x22, x21, [sp, #0x30]  (0xb7d027c)
        // ldp x24, x23, [sp, #0x20]  (0xb7d0280)
        // ldp x29, x30, [sp, #0x8]  (0xb7d0284)
        goto label_0xab12fe4;
    label_0xb7d0290:
        this = r22;
        this = fn_0xab0446c(this, r1, r2, r3);  // call  [0xab0446c]
        if (this == 0) goto label_0xb7d03e8;
        r24 = this;
        this = fn_0xab049b8(this, r1, r2, r3);  // call  [0xab049b8]
        r8 = *(void**)(this + 0x68);
        this = r8 + 0xc8;
        this = fn_0x134eea4c(this, r1, r2, r3);  // call  [0x134eea4c]
        r20 = this;
        this = (void*)0x1421dec8;
        this = fn_0x134eea4c(this, r1, r2, r3);  // call  [0x134eea4c]
        r8 = *(void**)(r23);
        // cmp r20 == this
        r21 = this;
        // cset w9, eq  (0xb7d02cc)
        this = r23;
        r8 = *(void**)(r8 + 0x30);
        // ubfiz x25, x9, #0x1, #0x20  (0xb7d02d8)
        this = (*(void**)r8)(this);  // indirect call
        this = r22;
        // fmov s8, s0  (0xb7d02e4)
        this = fn_0x109f7f30(this, r1, r2, r3);  // call  [0x109f7f30]
        r2 = this;
        this = r24;
        r1 = r25;
        this = fn_0xab11a90(this, r1, r2, r3);  // call  [0xab11a90]
        // fmov s0, s8  (0xb7d02fc)
        this = fn_0xab11dbc(this, r1, r2, r3);  // call  [0xab11dbc]
        rq0 = *(void**)(this + 0xc);
        rq1 = *(void**)(this);
        r22 = this;
        *(void**)(r19 + 0xc) = rq0;
        *(void**)(r19) = rq1;
        r8 = *(void**)(this + 0x20);
        *(void**)(r19 + 0x20) = r8;
        r8 = this;
        r9 = *(uint8_t*)(r8 + 0x28);
        // tbnz w9, #0x0, 0xb7d0340  (0xb7d0328)
        r9 = *(void**)(r8 + 0x10);
        rq0 = *(void**)(r8);
        *(void**)(r19 + 0x38) = r9;
        *(void**)(r19 + 0x28) = rq0;
        goto label_0xb7d034c;
    label_0xb7d0340:
        // ldp x2, x1, [x22, #0x30]  (0xb7d0340)
        this = r19 + 0x28;
        this = fn_0x88a6328(this, r1, r2, r3);  // call  [0x88a6328]
    label_0xb7d034c:
        rq0 = *(void**)(r22 + 0x40);
        // cmp r20 == r21
        *(void**)(r19 + 0x40) = rq0;
        r8 = *(uint16_t*)(r22 + 0x54);
        r9 = *(void**)(r22 + 0x50);
        *(uint16_t*)(r19 + 0x54) = r8;
        *(void**)(r19 + 0x50) = r9;
        if (/* cond: b.ne */) goto label_0xb7d03cc;
        // scvtf s0, wzr  (0xb7d036c)
        this = r19;
        // fmov s1, s0  (0xb7d0374)
        this = fn_0xb74e108(this, r1, r2, r3);  // call  [0xb74e108]
        // scvtf s1, wzr  (0xb7d037c)
        *(void**)(r19 + 0x4) = rs0;
        this = r19;
        // fmov s0, s1  (0xb7d0388)
        this = fn_0xb74e194(this, r1, r2, r3);  // call  [0xb74e194]
        // scvtf s1, wzr  (0xb7d0394)
        *(void**)(r19 + 0x8) = rs0;
        // scvtf s2, w8  (0xb7d039c)
        this = r19;
        // fmov s0, s2  (0xb7d03a4)
        this = fn_0xb74e108(this, r1, r2, r3);  // call  [0xb74e108]
        // scvtf s1, wzr  (0xb7d03b0)
        *(void**)(r19 + 0xc) = rs0;
        // scvtf s2, w8  (0xb7d03b8)
        this = r19;
        // fmov s0, s2  (0xb7d03c0)
        this = fn_0xb74e194(this, r1, r2, r3);  // call  [0xb74e194]
        *(void**)(r19 + 0x10) = rs0;
    label_0xb7d03cc:
        // ldp x20, x19, [sp, #0x40]  (0xb7d03cc)
        r25 = *(void**)(sp + 0x18);
        // ldp x22, x21, [sp, #0x30]  (0xb7d03d4)
        // ldp x24, x23, [sp, #0x20]  (0xb7d03d8)
        // ldp x29, x30, [sp, #0x8]  (0xb7d03dc)
        return this;
}

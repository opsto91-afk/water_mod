// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7c8a60
// fn_va = 0xb7c8a60
// return type (guess): unknown (no ret found)
void* fn_0xb7c8a60(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0xb7c8a60)
        // stp x22, x21, [sp, #0x10]  (0xb7c8a64)
        // stp x20, x19, [sp, #0x20]  (0xb7c8a68)
        r21 = this;
        this = *(void**)(this + 0x10f8);
        r19 = r1;
        this = fn_0x9c773d8(this, r1, r2, r3);  // call  [0x9c773d8]
        r20 = this;
        this = r19;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tbz w0, #0x0, 0xb7c8b00  (0xb7c8a90)
        this = fn_0x10101aa0(this, r1, r2, r3);  // call  [0x10101aa0]
        if (this == 0) goto label_0xb7c8acc;
        this = r19;
        this = fn_0xfd98d48(this, r1, r2, r3);  // call  [0xfd98d48]
        // tbz w0, #0x0, 0xb7c8acc  (0xb7c8aac)
        r8 = *(uint8_t*)(r21 + 0x949);
        // cmp r8 == <complex operand>
        // cset w9, eq  (0xb7c8abc)
        // orn w9, w9, w20  (0xb7c8ac0)
        // tbz w9, #0x0, 0xb7c8b18  (0xb7c8ac4)
        goto label_0xb7c8b28;
    label_0xb7c8acc:
        this = fn_0x10101aa0(this, r1, r2, r3);  // call  [0x10101aa0]
        if (this == 0) goto label_0xb7c8b00;
        this = r19;
        this = fn_0xfd98d48(this, r1, r2, r3);  // call  [0xfd98d48]
        r22 = this;
        r8 = *(uint8_t*)(r21 + 0x949);
        // cmp r8 == <complex operand>
        // cset w9, eq  (0xb7c8af0)
        // orn w9, w9, w20  (0xb7c8af4)
        // tbnz w9, #0x0, 0xb7c8b28  (0xb7c8af8)
        goto label_0xb7c8b18;
    label_0xb7c8b00:
        r22 = rzr;
        r8 = *(uint8_t*)(r21 + 0x949);
        // cmp r8 == <complex operand>
        // cset w9, eq  (0xb7c8b0c)
        // orn w9, w9, w20  (0xb7c8b10)
        // tbnz w9, #0x0, 0xb7c8b28  (0xb7c8b14)
    label_0xb7c8b18:
        this = r19;
        this = fn_0xfd7b6c0(this, r1, r2, r3);  // call  [0xfd7b6c0]
        // bic w8, w8, w0  (0xb7c8b24)
    label_0xb7c8b28:
        // and w9, w20, w22  (0xb7c8b28)
        this = r19;
        // orr w20, w8, w9  (0xb7c8b30)
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r8 = *(void**)(this);
        r19 = this;
        r8 = *(void**)(r8 + 0x130);
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0x10b3eb2c(this, r1, r2, r3);  // call  [0x10b3eb2c]
        this = fn_0x10aa06a0(this, r1, r2, r3);  // call  [0x10aa06a0]
        this = r19;
        // movk w8, #0x3d4c, lsl #0x10  (0xb7c8b58)
        // fmov s1, w8  (0xb7c8b5c)
        r8 = *(void**)(r19);
        r8 = *(void**)(r8 + 0x130);
        // fcmpe s0, s1  (0xb7c8b68)
        // cset w9, gt  (0xb7c8b6c)
        // orr w20, w20, w9  (0xb7c8b70)
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        // orn w8, w20, w0  (0xb7c8b84)
        // and w0, w8, #0x1  (0xb7c8b88)
        // ldp x20, x19, [sp, #0x20]  (0xb7c8b8c)
        // ldp x22, x21, [sp, #0x10]  (0xb7c8b90)
        // ldp x29, x30, [sp], #0x30  (0xb7c8b94)
        return this;
}

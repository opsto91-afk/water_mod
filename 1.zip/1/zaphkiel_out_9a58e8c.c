// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a58e8c
// fn_va = 0x9a58e8c
// return type (guess): unknown (no ret found)
void* fn_0x9a58e8c(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a58e8c)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = r1;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0x9a58eb0  (0x9a58ea4)
        *(void**)(r19 + 0x18) = r8;
    label_0x9a58eb0:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9a58eb4)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7cdf34
// fn_va = 0xb7cdf34
// return type (guess): unknown (no ret found)
void* fn_0xb7cdf34(void* this) {
        // stp d15, d14, [sp, #0x130]  (0xb7cdf38)
        // stp d13, d12, [sp, #0x140]  (0xb7cdf3c)
        // stp d11, d10, [sp, #0x150]  (0xb7cdf40)
        // stp d9, d8, [sp, #0x160]  (0xb7cdf44)
        // stp x29, x30, [sp, #0x170]  (0xb7cdf48)
        // stp x28, x27, [sp, #0x180]  (0xb7cdf4c)
        // stp x26, x25, [sp, #0x190]  (0xb7cdf50)
        // stp x24, x23, [sp, #0x1a0]  (0xb7cdf54)
        // stp x22, x21, [sp, #0x1b0]  (0xb7cdf58)
        // stp x20, x19, [sp, #0x1c0]  (0xb7cdf5c)
        fp = sp + 0x170;
        // mrs x24, tpidr_el0  (0xb7cdf64)
        r19 = this;
        r27 = r2;
        r8 = *(void**)(r24 + 0x28);
        r21 = r1;
        *(void**)(fp - 0x50) = r8;
        this = *(void**)(this + 0x1138);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xa70);
        this = (*(void**)r8)(this);  // indirect call
        // and w8, w21, #0xffff  (0xb7cdf8c)
        r21 = this;
        // cmp r8 == <complex operand>
        if (/* cond: b.le */) goto label_0xb7ce034;
        // cmp r8 == <complex operand>
        if (/* cond: b.gt */) goto label_0xb7ce0ec;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7cefac;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7cec44;
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7cf24c;
        this = sp + 0x90;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x90;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7cf24c  (0xb7cdfd4)
        this = sp + 0x90;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7cf24c;
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x50);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7cf548;
        r1 = r27;
        r2 = r21;
        // ldp x20, x19, [sp, #0x1c0]  (0xb7ce004)
        // ldp x22, x21, [sp, #0x1b0]  (0xb7ce008)
        // ldp x24, x23, [sp, #0x1a0]  (0xb7ce00c)
        // ldp x26, x25, [sp, #0x190]  (0xb7ce010)
        // ldp x28, x27, [sp, #0x180]  (0xb7ce014)
        // ldp x29, x30, [sp, #0x170]  (0xb7ce018)
        // ldp d9, d8, [sp, #0x160]  (0xb7ce01c)
        // ldp d11, d10, [sp, #0x150]  (0xb7ce020)
        // ldp d13, d12, [sp, #0x140]  (0xb7ce024)
        // ldp d15, d14, [sp, #0x130]  (0xb7ce028)
        sp = sp + 0x1d0;
        return fn_0x1101482c(/* tail call */);
    label_0xb7ce034:
        // cmp r8 == <complex operand>
        if (/* cond: b.le */) goto label_0xb7ce154;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7ced30;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7cea8c;
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7cf24c;
        r1 = "originX";  // 0x279afae
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        r21 = this;
        r1 = "originY";  // 0x279afb6
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        r22 = this;
        r1 = "originZ";  // 0x25062bc
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        // scvtf s0, w21  (0xb7ce098)
        // scvtf s1, w22  (0xb7ce09c)
        r3 = (void*)0x3780428;
        // scvtf s3, w0  (0xb7ce0a8)
        // fmov s2, #0.5  (0xb7ce0ac)
        this = *(void**)(r19 + 0x1138);
        r2 = sp + 0x90;
        r4 = rzr;
        r5 = rzr;
        r6 = rzr;
        // fadd s0, s0, s2  (0xb7ce0c8)
        // fadd s1, s1, s2  (0xb7ce0cc)
        // fadd s2, s3, s2  (0xb7ce0d0)
        // stp s0, s1, [sp, #0x90]  (0xb7ce0d4)
        *(void**)(sp + 0x98) = rs2;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x7f0);
        this = (*(void**)r8)(this);  // indirect call
        goto label_0xb7cf24c;
    label_0xb7ce0ec:
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7cf15c;
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7cecbc;
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7cf24c;
        this = *(void**)(r19 + 0x1138);
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x50);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7cf548;
        r1 = r27;
        r2 = r21;
        // ldp x20, x19, [sp, #0x1c0]  (0xb7ce124)
        // ldp x22, x21, [sp, #0x1b0]  (0xb7ce128)
        // ldp x24, x23, [sp, #0x1a0]  (0xb7ce12c)
        // ldp x26, x25, [sp, #0x190]  (0xb7ce130)
        // ldp x28, x27, [sp, #0x180]  (0xb7ce134)
        // ldp x29, x30, [sp, #0x170]  (0xb7ce138)
        // ldp d9, d8, [sp, #0x160]  (0xb7ce13c)
        // ldp d11, d10, [sp, #0x150]  (0xb7ce140)
        // ldp d13, d12, [sp, #0x140]  (0xb7ce144)
        // ldp d15, d14, [sp, #0x130]  (0xb7ce148)
        sp = sp + 0x1d0;
        return fn_0x10f500e0(/* tail call */);
    label_0xb7ce154:
        // cmp r8 == <complex operand>
        if (/* cond: b.eq */) goto label_0xb7ce824;
        // cmp r8 == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7cf24c;
        r1 = "particalType";  // 0x25266d8
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        r20 = this;
        this = sp + 0x90;
        r2 = rzr;
        this = fn_0x135d4450(this, r1, r2, r3);  // call  [0x135d4450]
        r1 = "size";  // 0x27ad41b
        this = r27;
        *(void**)(sp) = r24;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        // cmp this == <complex operand>
        *(void**)(sp + 0x10) = r20;
        if (/* cond: b.lt */) goto label_0xb7cf1dc;
        r8 = sp + 0x90;
        r9 = fp - 0x88;
        r23 = rzr;
        r20 = rzr;
        r24 = rzr;
        // orr x28, x8, #0x1  (0xb7ce1c4)
        // orr x8, x8, #0x2  (0xb7ce1c8)
        // orr x22, x9, #0x1  (0xb7ce1cc)
        *(void**)(sp + 0x14) = this;
        // stp x8, xzr, [sp, #0x18]  (0xb7ce1d4)
        *(void**)(sp + 0x30) = r27;
        goto label_0xb7ce200;
    label_0xb7ce1e0:
        // stp s8, s9, [x23]  (0xb7ce1e0)
        // stp s10, s11, [x23, #0x8]  (0xb7ce1e4)
        // stp s12, s13, [x23, #0x10]  (0xb7ce1e8)
        r23 = r23 + 0x18;
        r8 = *(void**)(sp + 0x14);
        // cmp r8 == r24
        if (/* cond: b.eq */) goto label_0xb7cf1e4;
    label_0xb7ce200:
        r8 = *(uint8_t*)(sp + 0x90);
        r9 = *(void**)(sp + 0xa0);
        this = r24;
        *(void**)(sp + 0x28) = r20;
        r20 = r19;
        // tst w8, #0x1  (0xb7ce218)
        // csel x8, x28, x9, eq  (0xb7ce21c)
        *(void**)(r8) = rzr;
        r8 = *(void**)(sp + 0x18);
        // csinc x1, x8, x9, eq  (0xb7ce228)
        this = fn_0x11bc752c(this, r1, r2, r3);  // call  [0x11bc752c]
        r8 = *(uint8_t*)(sp + 0x90);
        r9 = *(void**)(sp + 0xa0);
        // tst w8, #0x1  (0xb7ce238)
        // csel x8, x28, x9, eq  (0xb7ce23c)
        *(uint8_t*)(r8) = r9;
        r21 = *(uint8_t*)(sp + 0x90);
        r8 = *(void**)(sp + 0x98);
        // lsr x9, x21, #0x1  (0xb7ce250)
        // tst w21, #0x1  (0xb7ce254)
        // csel x25, x9, x8, eq  (0xb7ce258)
        r19 = r25 + 0x1;
        // cmp r19 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7cf2e0;
        // cmp r19 == 0x17
        if (/* cond: b.hs */) goto label_0xb7ce28c;
        // lsl w8, w19, #0x1  (0xb7ce270)
        r26 = r22;
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7ce278)
        *(void**)(fp - 0x78) = rzr;
        // sturb w8, [x29, #0xffffffffffffff78]  (0xb7ce280)
        if (r25 != 0) goto label_0xb7ce2c0;
        goto label_0xb7ce2d8;
    label_0xb7ce28c:
        // and x8, x19, #0xfffffffffffffff8  (0xb7ce28c)
        // orr x9, x19, #0x7  (0xb7ce290)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7ce29c)
        r27 = r8 + 0x1;
        this = r27;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // orr x8, x27, #0x1  (0xb7ce2ac)
        r27 = *(void**)(sp + 0x30);
        r26 = this;
        // stp x19, x0, [x29, #0xffffffffffffff80]  (0xb7ce2b8)
        *(void**)(fp - 0x88) = r8;
    label_0xb7ce2c0:
        r8 = *(void**)(sp + 0xa0);
        // tst w21, #0x1  (0xb7ce2c4)
        this = r26;
        r2 = r25;
        // csel x1, x28, x8, eq  (0xb7ce2d0)
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7ce2d8:
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce2e0)
        // ldp x10, x9, [x29, #0xffffffffffffff80]  (0xb7ce2e4)
        // lsr x11, x8, #0x1  (0xb7ce2e8)
        // tst w8, #0x1  (0xb7ce2ec)
        // csel x1, x22, x9, eq  (0xb7ce2f0)
        // csel x2, x11, x10, eq  (0xb7ce2f4)
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        // fmov s8, s0  (0xb7ce300)
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce304)
        // tbz w8, #0x0, 0xb7ce314  (0xb7ce308)
        this = *(void**)(fp - 0x78);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce314:
        r21 = *(uint8_t*)(sp + 0x90);
        r8 = *(void**)(sp + 0x98);
        // lsr x9, x21, #0x1  (0xb7ce31c)
        // tst w21, #0x1  (0xb7ce320)
        // csel x25, x9, x8, eq  (0xb7ce324)
        r19 = r25 + 0x1;
        // cmp r19 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7cf2fc;
        // cmp r19 == 0x17
        if (/* cond: b.hs */) goto label_0xb7ce358;
        // lsl w8, w19, #0x1  (0xb7ce33c)
        r26 = r22;
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7ce344)
        *(void**)(fp - 0x78) = rzr;
        // sturb w8, [x29, #0xffffffffffffff78]  (0xb7ce34c)
        if (r25 != 0) goto label_0xb7ce38c;
        goto label_0xb7ce3a4;
    label_0xb7ce358:
        // and x8, x19, #0xfffffffffffffff8  (0xb7ce358)
        // orr x9, x19, #0x7  (0xb7ce35c)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7ce368)
        r27 = r8 + 0x1;
        this = r27;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // orr x8, x27, #0x1  (0xb7ce378)
        r27 = *(void**)(sp + 0x30);
        r26 = this;
        // stp x19, x0, [x29, #0xffffffffffffff80]  (0xb7ce384)
        *(void**)(fp - 0x88) = r8;
    label_0xb7ce38c:
        r8 = *(void**)(sp + 0xa0);
        // tst w21, #0x1  (0xb7ce390)
        this = r26;
        r2 = r25;
        // csel x1, x28, x8, eq  (0xb7ce39c)
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7ce3a4:
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce3ac)
        // ldp x10, x9, [x29, #0xffffffffffffff80]  (0xb7ce3b0)
        // lsr x11, x8, #0x1  (0xb7ce3b4)
        // tst w8, #0x1  (0xb7ce3b8)
        // csel x1, x22, x9, eq  (0xb7ce3bc)
        // csel x2, x11, x10, eq  (0xb7ce3c0)
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        // fmov s9, s0  (0xb7ce3cc)
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce3d0)
        // tbz w8, #0x0, 0xb7ce3e0  (0xb7ce3d4)
        this = *(void**)(fp - 0x78);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce3e0:
        r21 = *(uint8_t*)(sp + 0x90);
        r8 = *(void**)(sp + 0x98);
        // lsr x9, x21, #0x1  (0xb7ce3e8)
        // tst w21, #0x1  (0xb7ce3ec)
        // csel x25, x9, x8, eq  (0xb7ce3f0)
        r19 = r25 + 0x1;
        // cmp r19 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7cf2a8;
        // cmp r19 == 0x17
        if (/* cond: b.hs */) goto label_0xb7ce424;
        // lsl w8, w19, #0x1  (0xb7ce408)
        r26 = r22;
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7ce410)
        *(void**)(fp - 0x78) = rzr;
        // sturb w8, [x29, #0xffffffffffffff78]  (0xb7ce418)
        if (r25 != 0) goto label_0xb7ce458;
        goto label_0xb7ce470;
    label_0xb7ce424:
        // and x8, x19, #0xfffffffffffffff8  (0xb7ce424)
        // orr x9, x19, #0x7  (0xb7ce428)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7ce434)
        r27 = r8 + 0x1;
        this = r27;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // orr x8, x27, #0x1  (0xb7ce444)
        r27 = *(void**)(sp + 0x30);
        r26 = this;
        // stp x19, x0, [x29, #0xffffffffffffff80]  (0xb7ce450)
        *(void**)(fp - 0x88) = r8;
    label_0xb7ce458:
        r8 = *(void**)(sp + 0xa0);
        // tst w21, #0x1  (0xb7ce45c)
        this = r26;
        r2 = r25;
        // csel x1, x28, x8, eq  (0xb7ce468)
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7ce470:
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce478)
        // ldp x10, x9, [x29, #0xffffffffffffff80]  (0xb7ce47c)
        // lsr x11, x8, #0x1  (0xb7ce480)
        // tst w8, #0x1  (0xb7ce484)
        // csel x1, x22, x9, eq  (0xb7ce488)
        // csel x2, x11, x10, eq  (0xb7ce48c)
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        // fmov s10, s0  (0xb7ce498)
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce49c)
        // tbz w8, #0x0, 0xb7ce4ac  (0xb7ce4a0)
        this = *(void**)(fp - 0x78);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce4ac:
        r8 = *(uint8_t*)(sp + 0x90);
        r9 = *(void**)(sp + 0xa0);
        // tst w8, #0x1  (0xb7ce4b4)
        // csel x8, x28, x9, eq  (0xb7ce4b8)
        *(uint8_t*)(r8) = r9;
        r21 = *(uint8_t*)(sp + 0x90);
        r8 = *(void**)(sp + 0x98);
        // lsr x9, x21, #0x1  (0xb7ce4cc)
        // tst w21, #0x1  (0xb7ce4d0)
        // csel x25, x9, x8, eq  (0xb7ce4d4)
        r19 = r25 + 0x1;
        // cmp r19 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7cf2c4;
        // cmp r19 == 0x17
        if (/* cond: b.hs */) goto label_0xb7ce508;
        // lsl w8, w19, #0x1  (0xb7ce4ec)
        r26 = r22;
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7ce4f4)
        *(void**)(fp - 0x78) = rzr;
        // sturb w8, [x29, #0xffffffffffffff78]  (0xb7ce4fc)
        if (r25 != 0) goto label_0xb7ce53c;
        goto label_0xb7ce554;
    label_0xb7ce508:
        // and x8, x19, #0xfffffffffffffff8  (0xb7ce508)
        // orr x9, x19, #0x7  (0xb7ce50c)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7ce518)
        r27 = r8 + 0x1;
        this = r27;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // orr x8, x27, #0x1  (0xb7ce528)
        r27 = *(void**)(sp + 0x30);
        r26 = this;
        // stp x19, x0, [x29, #0xffffffffffffff80]  (0xb7ce534)
        *(void**)(fp - 0x88) = r8;
    label_0xb7ce53c:
        r8 = *(void**)(sp + 0xa0);
        // tst w21, #0x1  (0xb7ce540)
        this = r26;
        r2 = r25;
        // csel x1, x28, x8, eq  (0xb7ce54c)
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7ce554:
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce55c)
        // ldp x10, x9, [x29, #0xffffffffffffff80]  (0xb7ce560)
        // lsr x11, x8, #0x1  (0xb7ce564)
        // tst w8, #0x1  (0xb7ce568)
        // csel x1, x22, x9, eq  (0xb7ce56c)
        // csel x2, x11, x10, eq  (0xb7ce570)
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        // fmov s11, s0  (0xb7ce57c)
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce580)
        // tbz w8, #0x0, 0xb7ce590  (0xb7ce584)
        this = *(void**)(fp - 0x78);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce590:
        r21 = *(uint8_t*)(sp + 0x90);
        r8 = *(void**)(sp + 0x98);
        // lsr x9, x21, #0x1  (0xb7ce598)
        // tst w21, #0x1  (0xb7ce59c)
        // csel x25, x9, x8, eq  (0xb7ce5a0)
        r19 = r25 + 0x1;
        // cmp r19 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7cf28c;
        // cmp r19 == 0x17
        if (/* cond: b.hs */) goto label_0xb7ce5d4;
        // lsl w8, w19, #0x1  (0xb7ce5b8)
        r26 = r22;
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7ce5c0)
        *(void**)(fp - 0x78) = rzr;
        // sturb w8, [x29, #0xffffffffffffff78]  (0xb7ce5c8)
        if (r25 != 0) goto label_0xb7ce608;
        goto label_0xb7ce620;
    label_0xb7ce5d4:
        // and x8, x19, #0xfffffffffffffff8  (0xb7ce5d4)
        // orr x9, x19, #0x7  (0xb7ce5d8)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7ce5e4)
        r27 = r8 + 0x1;
        this = r27;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // orr x8, x27, #0x1  (0xb7ce5f4)
        r27 = *(void**)(sp + 0x30);
        r26 = this;
        // stp x19, x0, [x29, #0xffffffffffffff80]  (0xb7ce600)
        *(void**)(fp - 0x88) = r8;
    label_0xb7ce608:
        r8 = *(void**)(sp + 0xa0);
        // tst w21, #0x1  (0xb7ce60c)
        this = r26;
        r2 = r25;
        // csel x1, x28, x8, eq  (0xb7ce618)
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7ce620:
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce628)
        // ldp x10, x9, [x29, #0xffffffffffffff80]  (0xb7ce62c)
        // lsr x11, x8, #0x1  (0xb7ce630)
        // tst w8, #0x1  (0xb7ce634)
        // csel x1, x22, x9, eq  (0xb7ce638)
        // csel x2, x11, x10, eq  (0xb7ce63c)
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        // fmov s12, s0  (0xb7ce648)
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce64c)
        // tbz w8, #0x0, 0xb7ce65c  (0xb7ce650)
        this = *(void**)(fp - 0x78);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce65c:
        r21 = *(uint8_t*)(sp + 0x90);
        r8 = *(void**)(sp + 0x98);
        // lsr x9, x21, #0x1  (0xb7ce664)
        // tst w21, #0x1  (0xb7ce668)
        // csel x25, x9, x8, eq  (0xb7ce66c)
        r19 = r25 + 0x1;
        // cmp r19 == - 0x8
        if (/* cond: b.hs */) goto label_0xb7cf318;
        // cmp r19 == 0x17
        if (/* cond: b.hs */) goto label_0xb7ce6a0;
        // lsl w8, w19, #0x1  (0xb7ce684)
        r26 = r22;
        // stp xzr, xzr, [x29, #0xffffffffffffff78]  (0xb7ce68c)
        *(void**)(fp - 0x78) = rzr;
        // sturb w8, [x29, #0xffffffffffffff78]  (0xb7ce694)
        if (r25 != 0) goto label_0xb7ce6d4;
        goto label_0xb7ce6ec;
    label_0xb7ce6a0:
        // and x8, x19, #0xfffffffffffffff8  (0xb7ce6a0)
        // orr x9, x19, #0x7  (0xb7ce6a4)
        r8 = r8 + 0x8;
        // cmp r9 == 0x17
        // csel x8, x8, x9, eq  (0xb7ce6b0)
        r27 = r8 + 0x1;
        this = r27;
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        // orr x8, x27, #0x1  (0xb7ce6c0)
        r27 = *(void**)(sp + 0x30);
        r26 = this;
        // stp x19, x0, [x29, #0xffffffffffffff80]  (0xb7ce6cc)
        *(void**)(fp - 0x88) = r8;
    label_0xb7ce6d4:
        r8 = *(void**)(sp + 0xa0);
        // tst w21, #0x1  (0xb7ce6d8)
        this = r26;
        r2 = r25;
        // csel x1, x28, x8, eq  (0xb7ce6e4)
        this = fn_0x135dfa70(this, r1, r2, r3);  // call  [0x135dfa70]
    label_0xb7ce6ec:
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce6f4)
        // ldp x10, x9, [x29, #0xffffffffffffff80]  (0xb7ce6f8)
        // lsr x11, x8, #0x1  (0xb7ce6fc)
        // tst w8, #0x1  (0xb7ce700)
        // csel x1, x22, x9, eq  (0xb7ce704)
        // csel x2, x11, x10, eq  (0xb7ce708)
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        // fmov s13, s0  (0xb7ce714)
        // ldurb w8, [x29, #0xffffffffffffff78]  (0xb7ce718)
        r19 = r20;
        // tbz w8, #0x0, 0xb7ce72c  (0xb7ce720)
        this = *(void**)(fp - 0x78);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce72c:
        // ldp x8, x20, [sp, #0x20]  (0xb7ce72c)
        // cmp r23 == r8
        if (/* cond: b.lo */) goto label_0xb7ce1e0;
        r10 = 0xaaaaaaaaaaaaaaaa;
        r9 = 0xaaaaaaaaaaaaaaaa;
        // asr x8, x25, #0x3  (0xb7ce744)
        // movk x10, #0xaaab  (0xb7ce748)
        // movk x9, #0xaaa, lsl #0x30  (0xb7ce74c)
        // mul x21, x8, x10  (0xb7ce750)
        r8 = r21 + 0x1;
        // cmp r8 == r9
        if (/* cond: b.hi */) goto label_0xb7cf334;
        r9 = *(void**)(sp + 0x20);
        // asr x9, x9, #0x3  (0xb7ce768)
        // mul x9, x9, x10  (0xb7ce76c)
        // lsl x10, x9, #0x1  (0xb7ce770)
        // cmp r10 == r8
        // csel x8, x10, x8, hi  (0xb7ce778)
        r10 = 0x5555555555555555;
        // movk x10, #0x555, lsl #0x30  (0xb7ce780)
        // cmp r9 == r10
        r9 = 0xaaaaaaaaaaaaaaaa;
        // movk x9, #0xaaa, lsl #0x30  (0xb7ce78c)
        // csel x23, x8, x9, cc  (0xb7ce790)
        if (r23 == 0) goto label_0xb7ce7b0;
        // cmp r23 == r9
        if (/* cond: b.hi */) goto label_0xb7cf34c;
        // lsl x0, x8, #0x3  (0xb7ce7a4)
        this = fn_0x135d38f0(this, r1, r2, r3);  // call  [0x135d38f0]
        goto label_0xb7ce7b4;
    label_0xb7ce7b0:
        this = rzr;
    label_0xb7ce7b4:
        r8 = 0x5555555555555555;
        r1 = r20;
        // movk x8, #0xd555, lsl #0x30  (0xb7ce7c0)
        // madd x9, x21, x11, x0  (0xb7ce7c4)
        r2 = r25;
        // smulh x8, x25, x8  (0xb7ce7cc)
        // madd x12, x23, x11, x0  (0xb7ce7d0)
        // stp s8, s9, [x9]  (0xb7ce7d4)
        r23 = r9 + 0x18;
        // stp s10, s11, [x9, #0x8]  (0xb7ce7dc)
        // asr x10, x8, #0x2  (0xb7ce7e0)
        // stp s12, s13, [x9, #0x10]  (0xb7ce7e4)
        *(void**)(sp + 0x20) = r12;
        // nop   (0xb7ce7f0)
        // madd x26, x8, x11, x9  (0xb7ce7f4)
        this = r26;
        this = fn_0x135df980(this, r1, r2, r3);  // call  [0x135df980]
        if (r20 == 0) goto label_0xb7ce80c;
        this = r20;
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7ce80c:
        r20 = r26;
        r8 = *(void**)(sp + 0x14);
        // cmp r8 == r24
        if (/* cond: b.ne */) goto label_0xb7ce200;
        goto label_0xb7cf1e4;
    label_0xb7ce824:
        r1 = "Startx";  // 0x25459a5
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Starty";  // 0x2468a8e
        this = r27;
        // fmov s14, s0  (0xb7ce848)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Startz";  // 0x26fda00
        this = r27;
        // fmov s8, s0  (0xb7ce860)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Endx";  // 0x24e627c
        this = r27;
        // fmov s9, s0  (0xb7ce878)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Endy";  // 0x260081d
        this = r27;
        // fmov s10, s0  (0xb7ce890)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Endz";  // 0x24e6281
        this = r27;
        // fmov s11, s0  (0xb7ce8a8)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Variationx";  // 0x2447ecd
        this = r27;
        // fmov s12, s0  (0xb7ce8c0)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Variationy";  // 0x2583689
        this = r27;
        *(void**)(sp + 0x18) = rs0;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "DirScale";  // 0x24c6a47
        this = r27;
        *(void**)(sp + 0x20) = rs0;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = "Count";  // 0x26566e4
        this = r27;
        // fmov s13, s0  (0xb7ce908)
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        // fsub s3, s10, s14  (0xb7ce910)
        *(void**)(sp + 0x30) = rs8;
        // fsub s8, s11, s8  (0xb7ce918)
        // fsub s0, s12, s9  (0xb7ce91c)
        // cmp this == <complex operand>
        *(void**)(sp + 0x28) = rs9;
        *(void**)(sp + 0x14) = rs0;
        if (/* cond: b.lt */) goto label_0xb7cf24c;
        // fmov s10, #2  (0xb7ce930)
        r20 = this;
        r22 = rzr;
        // stp s8, s3, [sp, #0xc]  (0xb7ce93c)
    label_0xb7ce940:
        // scvtf s0, w20  (0xb7ce940)
        // fmov s2, #1  (0xb7ce944)
        r8 = *(void**)(r21);
        // scvtf s1, w22  (0xb7ce94c)
        this = r21;
        r8 = *(void**)(r8 + 0x30);
        // fsub s0, s0, s2  (0xb7ce958)
        // fdiv s12, s1, s0  (0xb7ce95c)
        // fmul s0, s3, s12  (0xb7ce960)
        // fadd s15, s14, s0  (0xb7ce964)
        this = (*(void**)r8)(this);  // indirect call
        // fmul s1, s8, s12  (0xb7ce96c)
        // fmov s8, #0.5  (0xb7ce970)
        // fmov s9, s13  (0xb7ce974)
        rs13 = *(void**)(sp + 0x18);
        r8 = *(void**)(r21);
        rs2 = *(void**)(sp + 0x30);
        this = r21;
        // fmov s11, s14  (0xb7ce988)
        // fsub s0, s0, s8  (0xb7ce98c)
        r8 = *(void**)(r8 + 0x30);
        // fadd s14, s2, s1  (0xb7ce994)
        // fmul s0, s0, s10  (0xb7ce998)
        // fmul s0, s0, s13  (0xb7ce99c)
        // fadd s15, s15, s0  (0xb7ce9a0)
        this = (*(void**)r8)(this);  // indirect call
        rs1 = *(void**)(sp + 0x14);
        // fsub s0, s0, s8  (0xb7ce9ac)
        rs2 = *(void**)(sp + 0x28);
        r8 = *(void**)(r21);
        this = r21;
        // fmul s1, s1, s12  (0xb7ce9bc)
        r8 = *(void**)(r8 + 0x30);
        // fmul s0, s0, s10  (0xb7ce9c4)
        // fadd s12, s2, s1  (0xb7ce9c8)
        rs1 = *(void**)(sp + 0x20);
        // fmul s0, s0, s1  (0xb7ce9d0)
        // fadd s14, s14, s0  (0xb7ce9d4)
        this = (*(void**)r8)(this);  // indirect call
        // fsub s0, s0, s8  (0xb7ce9dc)
        r8 = *(void**)(r21);
        this = r21;
        // stp s15, s14, [sp, #0x90]  (0xb7ce9e8)
        r8 = *(void**)(r8 + 0x30);
        // fmul s0, s0, s10  (0xb7ce9f0)
        // fmul s0, s0, s13  (0xb7ce9f4)
        // fmov s13, s9  (0xb7ce9f8)
        // fadd s0, s12, s0  (0xb7ce9fc)
        *(void**)(sp + 0x98) = rs0;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r21);
        // fsub s0, s0, s8  (0xb7cea0c)
        this = r21;
        r8 = *(void**)(r8 + 0x30);
        // fmul s12, s0, s9  (0xb7cea18)
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(void**)(r21);
        // fsub s0, s0, s8  (0xb7cea24)
        this = r21;
        r8 = *(void**)(r8 + 0x30);
        // fmul s14, s0, s9  (0xb7cea30)
        this = (*(void**)r8)(this);  // indirect call
        // fsub s0, s0, s8  (0xb7cea38)
        this = *(void**)(r19 + 0x1138);
        // stp s12, s14, [x29, #0xffffffffffffff78]  (0xb7cea40)
        rs8 = *(void**)(sp + 0xc);
        r2 = sp + 0x90;
        r3 = fp - 0x88;
        r4 = rzr;
        r5 = rzr;
        r6 = rzr;
        // fmov s14, s11  (0xb7cea60)
        // fmul s0, s0, s9  (0xb7cea64)
        *(void**)(fp - 0x80) = rs0;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x7f0);
        this = (*(void**)r8)(this);  // indirect call
        rs3 = *(void**)(sp + 0x10);
        // cmp r20 == r22
        if (/* cond: b.ne */) goto label_0xb7ce940;
        goto label_0xb7cf24c;
    label_0xb7cea8c:
        this = sp + 0x90;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x90;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7cf24c  (0xb7ceaa4)
        this = sp + 0x90;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7cf24c;
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r23 = this;
        r1 = "origin";  // 0x2691d74
        this = r27;
        r2 = r23;
        this = fn_0x100dbf44(this, r1, r2, r3);  // call  [0x100dbf44]
        r22 = this;
        r21 = r1;
        // stp x0, x1, [sp, #0x78]  (0xb7ceadc)
        r1 = "target";  // 0x272e772
        this = r27;
        r2 = r23;
        this = fn_0x100dbf44(this, r1, r2, r3);  // call  [0x100dbf44]
        // tst x21, #0xff00000000  (0xb7ceaf4)
        if (/* cond: b.eq */) goto label_0xb7cf24c;
        // and x8, x1, #0xff00000000  (0xb7ceafc)
        if (r8 == 0) goto label_0xb7cf24c;
        // fmov s0, w22  (0xb7ceb04)
        // fmov s1, w0  (0xb7ceb08)
        // lsr x8, x22, #0x20  (0xb7ceb0c)
        // lsr x9, x0, #0x20  (0xb7ceb10)
        // fmov s3, w21  (0xb7ceb14)
        // fmov s4, w1  (0xb7ceb18)
        this = fp - 0x88;
        // fsub s0, s1, s0  (0xb7ceb20)
        // fmov s1, w8  (0xb7ceb24)
        // fmov s2, w9  (0xb7ceb28)
        // fsub s1, s2, s1  (0xb7ceb2c)
        // fsub s2, s4, s3  (0xb7ceb30)
        // stp s0, s1, [sp, #0x44]  (0xb7ceb34)
        *(void**)(sp + 0x4c) = rs2;
        this = fn_0xffb4dc0(this, r1, r2, r3);  // call  [0xffb4dc0]
        r1 = "speed";  // 0x2540be9
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = 0x678a;
        r2 = "variable.particle_initial_speed";  // 0x2583633
        // movk x1, #0xead1, lsl #0x10  (0xb7ceb60)
        this = fp - 0x88;
        // movk x1, #0x10d7, lsl #0x20  (0xb7ceb68)
        // movk x1, #0x2daf, lsl #0x30  (0xb7ceb6c)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        this = sp + 0x50;
        r2 = sp + 0x44;
        r1 = rzr;
        this = fn_0xff99e64(this, r1, r2, r3);  // call  [0xff99e64]
        this = sp + 0x90;
        r1 = sp + 0x50;
        this = fn_0xb0c8e5c(this, r1, r2, r3);  // call  [0xb0c8e5c]
        r1 = 0x6d30;
        r2 = "variable.direction";  // 0x25e0bcf
        // movk x1, #0x8da2, lsl #0x10  (0xb7ceb9c)
        this = fp - 0x88;
        r3 = sp + 0x90;
        // movk x1, #0xb5c9, lsl #0x20  (0xb7ceba8)
        // movk x1, #0x1bfe, lsl #0x30  (0xb7cebac)
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x90;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp + 0x50;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        r1 = "timeToLive";  // 0x26007e0
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = 0x47b1;
        r2 = "variable.max_lifetime";  // 0x271ba4d
        // movk x1, #0x1f01, lsl #0x10  (0xb7cebe4)
        this = fp - 0x88;
        // movk x1, #0x8484, lsl #0x20  (0xb7cebec)
        // movk x1, #0xf51b, lsl #0x30  (0xb7cebf0)
        this = fn_0xffb47a0(this, r1, r2, r3);  // call  [0xffb47a0]
        r19 = *(void**)(r19 + 0x1138);
        r1 = "minecraft:vibration_signal";  // 0x258261e
        this = sp + 0x90;
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        r8 = *(void**)(r19);
        r8 = *(void**)(r8 + 0x7f8);
        r1 = sp + 0x90;
        r2 = sp + 0x78;
        r3 = fp - 0x88;
        this = r19;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(sp + 0x98);
        // tbz w8, #0x0, 0xb7cec38  (0xb7cec2c)
        this = *(void**)(sp + 0xa8);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7cec38:
        this = fp - 0x88;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        goto label_0xb7cf24c;
    label_0xb7cec44:
        this = sp + 0x90;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x90;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7cf24c  (0xb7cec5c)
        this = sp + 0x90;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7cf24c;
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x50);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7cf548;
        r1 = r27;
        r2 = r21;
        // ldp x20, x19, [sp, #0x1c0]  (0xb7cec8c)
        // ldp x22, x21, [sp, #0x1b0]  (0xb7cec90)
        // ldp x24, x23, [sp, #0x1a0]  (0xb7cec94)
        // ldp x26, x25, [sp, #0x190]  (0xb7cec98)
        // ldp x28, x27, [sp, #0x180]  (0xb7cec9c)
        // ldp x29, x30, [sp, #0x170]  (0xb7ceca0)
        // ldp d9, d8, [sp, #0x160]  (0xb7ceca4)
        // ldp d11, d10, [sp, #0x150]  (0xb7ceca8)
        // ldp d13, d12, [sp, #0x140]  (0xb7cecac)
        // ldp d15, d14, [sp, #0x130]  (0xb7cecb0)
        sp = sp + 0x1d0;
        return fn_0x1101426c(/* tail call */);
    label_0xb7cecbc:
        r1 = (void*)0x26131f7;
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = (void*)0x274e39c;
        this = r27;
        // fmov s8, s0  (0xb7cece0)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = (void*)0x27ad44f;
        this = r27;
        // fmov s9, s0  (0xb7cecf8)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r19 = *(void**)(r19 + 0x1138);
        r1 = "minecraft:dust_plume";  // 0x26fcf04
        this = sp + 0x90;
        // stp s8, s9, [x29, #0xffffffffffffff78]  (0xb7ced10)
        *(void**)(fp - 0x80) = rs0;
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        r1 = sp + 0x90;
        r2 = fp - 0x88;
        this = r19;
        this = fn_0x10344288(this, r1, r2, r3);  // call  [0x10344288]
        goto label_0xb7cf1cc;
    label_0xb7ced30:
        // scvtf s0, wzr  (0xb7ced30)
        // movi v1.2d, #0x0  (0xb7ced34)
        *(void**)(sp + 0x74) = rzr;
        *(void**)(sp + 0x50) = rs0;
        *(void**)(sp + 0x54) = rq1;
        *(void**)(sp + 0x64) = rq1;
        this = sp + 0x50;
        r1 = r27;
        *(void**)(sp) = r24;
        this = fn_0x10b26bec(this, r1, r2, r3);  // call  [0x10b26bec]
        this = *(void**)(r19 + 0x1138);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0xa70);
        this = (*(void**)r8)(this);  // indirect call
        // ldp x20, x26, [sp, #0x60]  (0xb7ced68)
        // cmp r20 == r26
        if (/* cond: b.eq */) goto label_0xb7cef98;
        r23 = 0xf9e0;
        // ldp s9, s10, [sp, #0x54]  (0xb7ced78)
        // fmov s12, #2  (0xb7ced7c)
        // fmov s13, #0.5  (0xb7ced80)
        // movk x23, #0xe836, lsl #0x10  (0xb7ced84)
        rs11 = *(void**)(sp + 0x5c);
        // movk x23, #0xf1b4, lsl #0x20  (0xb7ced8c)
        r21 = this;
        r27 = sp + 0x90;
        r22 = "variable.velocity";  // 0x2564620
        // movk x23, #0x1f1a, lsl #0x30  (0xb7ceda4)
        r24 = "minecraft:explosion_particle";  // 0x2660d5b
    label_0xb7cedb0:
        this = *(void**)(r21 + 0x9f8);
        r8 = sp + 0x90;
        this = fn_0x1352149c(this, r1, r2, r3);  // call  [0x1352149c]
        // ldp s0, s1, [sp, #0x90]  (0xb7cedbc)
        // ldp s2, s3, [x20]  (0xb7cedc0)
        // fadd s0, s2, s0  (0xb7cedc4)
        // fadd s1, s3, s1  (0xb7cedc8)
        rs2 = *(void**)(sp + 0x98);
        rs3 = *(void**)(r20 + 0x8);
        // fadd s2, s3, s2  (0xb7cedd4)
        // fsub s3, s0, s9  (0xb7cedd8)
        // fsub s4, s1, s10  (0xb7ceddc)
        // stp s0, s1, [x20]  (0xb7cede0)
        // fsub s5, s2, s11  (0xb7cede4)
        *(void**)(r20 + 0x8) = rs2;
        // fmul s6, s3, s3  (0xb7cedec)
        // fmul s7, s4, s4  (0xb7cedf0)
        r8 = *(void**)(r21);
        // stp s3, s4, [sp, #0x44]  (0xb7cedf8)
        r8 = *(void**)(r8 + 0x30);
        *(void**)(sp + 0x4c) = rs5;
        // fadd s6, s6, s7  (0xb7cee04)
        // fmul s7, s5, s5  (0xb7cee08)
        // fadd s14, s6, s7  (0xb7cee0c)
        this = r21;
        this = (*(void**)r8)(this);  // indirect call
        // fmov s8, s0  (0xb7cee1c)
        // fmul s0, s12, s14  (0xb7cee20)
        // movk w8, #0x3dcc, lsl #0x10  (0xb7cee24)
        // fmov s1, w8  (0xb7cee28)
        r8 = *(void**)(r21);
        r8 = *(void**)(r8 + 0x30);
        // fadd s0, s0, s1  (0xb7cee34)
        rs1 = *(void**)(sp + 0x50);
        // fdiv s14, s1, s0  (0xb7cee3c)
        this = r21;
        this = (*(void**)r8)(this);  // indirect call
        // fmul s0, s8, s0  (0xb7cee4c)
        rs3 = *(void**)(sp + 0x4c);
        // movk w8, #0x3e99, lsl #0x10  (0xb7cee54)
        this = fp - 0x88;
        // fmov s1, w8  (0xb7cee5c)
        // fadd s0, s0, s1  (0xb7cee60)
        // ldp s1, s2, [sp, #0x44]  (0xb7cee64)
        // fmul s0, s14, s0  (0xb7cee68)
        // fmul s1, s1, s0  (0xb7cee6c)
        // fmul s2, s2, s0  (0xb7cee70)
        // fmul s0, s3, s0  (0xb7cee74)
        // stp s1, s2, [sp, #0x44]  (0xb7cee78)
        *(void**)(sp + 0x4c) = rs0;
        // ldp s0, s1, [x20]  (0xb7cee80)
        rs2 = *(void**)(r20 + 0x8);
        // fadd s2, s2, s11  (0xb7cee88)
        // fadd s0, s0, s9  (0xb7cee8c)
        // fadd s1, s1, s10  (0xb7cee90)
        // fmul s2, s2, s13  (0xb7cee94)
        // fmul s0, s0, s13  (0xb7cee98)
        // fmul s1, s1, s13  (0xb7cee9c)
        *(void**)(sp + 0x40) = rs2;
        // stp s0, s1, [sp, #0x38]  (0xb7ceea4)
        this = fn_0xffb4dc0(this, r1, r2, r3);  // call  [0xffb4dc0]
        this = sp + 0x78;
        r2 = sp + 0x44;
        r1 = rzr;
        this = fn_0xff99e64(this, r1, r2, r3);  // call  [0xff99e64]
        // movi v0.2d, #0x0  (0xb7ceebc)
        this = r27 + 0x10;
        r1 = sp + 0x78;
        *(void**)(sp + 0x90) = r8;
        *(void**)(r27 + 0x48) = rzr;
        *(void**)(r27 + 0x8) = rq0;
        *(void**)(r27 + 0x18) = rq0;
        *(void**)(r27 + 0x28) = rq0;
        *(void**)(r27 + 0x38) = rq0;
        this = fn_0xff96ea8(this, r1, r2, r3);  // call  [0xff96ea8]
        this = sp + 0x90;
        *(void**)(sp + 0xe0) = r28;
        this = fn_0xff9b044(this, r1, r2, r3);  // call  [0xff9b044]
        this = fp - 0x88;
        r3 = sp + 0x90;
        r1 = r23;
        r2 = r22;
        this = fn_0xffb469c(this, r1, r2, r3);  // call  [0xffb469c]
        this = sp + 0x90;
        this = fn_0xff9afd0(this, r1, r2, r3);  // call  [0xff9afd0]
        this = sp + 0x78;
        this = fn_0xff96ddc(this, r1, r2, r3);  // call  [0xff96ddc]
        r25 = *(void**)(r19 + 0x1138);
        this = sp + 0x90;
        r1 = r24;
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        r8 = *(void**)(r25);
        r8 = *(void**)(r8 + 0x7f8);
        r1 = sp + 0x90;
        r2 = sp + 0x38;
        r3 = fp - 0x88;
        this = r25;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(sp + 0x98);
        // tbz w8, #0x0, 0xb7cef58  (0xb7cef4c)
        this = *(void**)(sp + 0xa8);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7cef58:
        this = *(void**)(r19 + 0x1138);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x7f0);
        r3 = sp + 0x44;
        r2 = r20;
        r4 = rzr;
        r5 = rzr;
        r6 = rzr;
        this = (*(void**)r8)(this);  // indirect call
        this = fp - 0x88;
        this = fn_0xffb4dd4(this, r1, r2, r3);  // call  [0xffb4dd4]
        r20 = r20 + 0xc;
        // cmp r20 == r26
        if (/* cond: b.ne */) goto label_0xb7cedb0;
        r20 = *(void**)(sp + 0x60);
    label_0xb7cef98:
        r24 = *(void**)(sp);
        if (r20 == 0) goto label_0xb7cf24c;
        this = r20;
        *(void**)(sp + 0x68) = r20;
        goto label_0xb7cf248;
    label_0xb7cefac:
        r1 = "originX";  // 0x279afae
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        r21 = this;
        r1 = "originY";  // 0x279afb6
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        r22 = this;
        r1 = "originZ";  // 0x25062bc
        this = r27;
        this = fn_0x11ba1f70(this, r1, r2, r3);  // call  [0x11ba1f70]
        // scvtf s0, w21  (0xb7ceff0)
        // scvtf s1, w22  (0xb7ceff4)
        // scvtf s3, w0  (0xb7ceffc)
        // fmov s2, #0.5  (0xb7cf000)
        // movk w8, #0x3f26, lsl #0x10  (0xb7cf004)
        // movi d4, #0x0  (0xb7cf008)
        r20 = this;
        this = *(void**)(r19 + 0x1138);
        r2 = sp + 0x90;
        r3 = fp - 0x88;
        // fadd s0, s0, s2  (0xb7cf020)
        // fadd s1, s1, s2  (0xb7cf024)
        // fadd s2, s3, s2  (0xb7cf02c)
        // fmov s3, w8  (0xb7cf030)
        // movk w8, #0x3e4c, lsl #0x10  (0xb7cf038)
        r4 = rzr;
        r5 = rzr;
        *(void**)(fp - 0x80) = r8;
        r6 = rzr;
        // fadd s0, s0, s4  (0xb7cf04c)
        // fadd s1, s1, s3  (0xb7cf050)
        rd3 = *(void**)(r9 + 0x198);
        // fadd s2, s2, s4  (0xb7cf058)
        *(void**)(fp - 0x88) = rd3;
        // stp s0, s1, [sp, #0x90]  (0xb7cf060)
        *(void**)(sp + 0x98) = rs2;
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x7f0);
        this = (*(void**)r8)(this);  // indirect call
        this = sp + 0x90;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x90;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7cf24c  (0xb7cf08c)
        this = sp + 0x90;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7cf24c;
        r19 = *(void**)(r19 + 0x1138);
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        // scvtf s0, w21  (0xb7cf0a8)
        // scvtf s1, w22  (0xb7cf0ac)
        r23 = this;
        // scvtf s2, w20  (0xb7cf0b4)
        this = sp + 0x90;
        // stp s0, s1, [x29, #0xffffffffffffff78]  (0xb7cf0bc)
        *(void**)(fp - 0x80) = rs2;
        this = fn_0xfae05d0(this, r1, r2, r3);  // call  [0xfae05d0]
        r8 = *(void**)(r19);
        r8 = *(void**)(r8 + 0x5f8);
        r3 = fp - 0x88;
        r5 = sp + 0x90;
        this = r19;
        r1 = r23;
        r6 = rzr;
        this = (*(void**)r8)(this);  // indirect call
        r19 = *(void**)(sp + 0xa0);
        // stp xzr, xzr, [sp, #0x98]  (0xb7cf0f4)
        if (r19 == 0) goto label_0xb7cf24c;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7cf124;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7cf124:
        r19 = *(void**)(sp + 0xa0);
        *(void**)(sp + 0xa8) = rzr;
        if (r19 == 0) goto label_0xb7cf24c;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7cf24c;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
        goto label_0xb7cf24c;
    label_0xb7cf15c:
        r1 = (void*)0x26131f7;
        this = r27;
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = (void*)0x274e39c;
        this = r27;
        // fmov s8, s0  (0xb7cf180)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r1 = (void*)0x27ad44f;
        this = r27;
        // fmov s9, s0  (0xb7cf198)
        this = fn_0x11ba2168(this, r1, r2, r3);  // call  [0x11ba2168]
        r19 = *(void**)(r19 + 0x1138);
        r1 = "minecraft:sonic_explosion";  // 0x2446ef2
        this = sp + 0x90;
        // stp s8, s9, [x29, #0xffffffffffffff78]  (0xb7cf1b0)
        *(void**)(fp - 0x80) = rs0;
        this = fn_0x134ee6b4(this, r1, r2, r3);  // call  [0x134ee6b4]
        r1 = sp + 0x90;
        r2 = fp - 0x88;
        this = r19;
        this = fn_0x10344288(this, r1, r2, r3);  // call  [0x10344288]
    label_0xb7cf1cc:
        r8 = *(uint8_t*)(sp + 0x98);
        // tbz w8, #0x0, 0xb7cf24c  (0xb7cf1d0)
        this = *(void**)(sp + 0xa8);
        goto label_0xb7cf248;
    label_0xb7cf1dc:
        r23 = rzr;
        r20 = rzr;
    label_0xb7cf1e4:
        r8 = *(uint8_t*)(sp + 0x90);
        r24 = *(void**)(sp);
        r21 = *(void**)(sp + 0x10);
        // tbz w8, #0x0, 0xb7cf1fc  (0xb7cf1f0)
        this = *(void**)(sp + 0xa0);
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7cf1fc:
        // cmp r20 == r23
        *(void**)(sp + 0x28) = r20;
        if (/* cond: b.eq */) goto label_0xb7cf240;
        r2 = *(void**)(sp + 0x28);
    label_0xb7cf20c:
        this = *(void**)(r19 + 0x1138);
        r20 = "_lifetime";  // 0x271ba59
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x7f0);
        r1 = r21;
        r3 = r20;
        r4 = rzr;
        r5 = rzr;
        r6 = rzr;
        this = (*(void**)r8)(this);  // indirect call
        r2 = "rticleEffect data legacy parser expects jsonString input format";  // 0x271ba65
        // cmp r2 == r23
        if (/* cond: b.ne */) goto label_0xb7cf20c;
    label_0xb7cf240:
        this = *(void**)(sp + 0x28);
        if (this == 0) goto label_0xb7cf24c;
    label_0xb7cf248:
        this = fn_0x135d37b0(this, r1, r2, r3);  // call  [0x135d37b0]
    label_0xb7cf24c:
        r8 = *(void**)(r24 + 0x28);
        r9 = *(void**)(fp - 0x50);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7cf548;
        // ldp x20, x19, [sp, #0x1c0]  (0xb7cf25c)
        // ldp x22, x21, [sp, #0x1b0]  (0xb7cf260)
        // ldp x24, x23, [sp, #0x1a0]  (0xb7cf264)
        // ldp x26, x25, [sp, #0x190]  (0xb7cf268)
        // ldp x28, x27, [sp, #0x180]  (0xb7cf26c)
        // ldp x29, x30, [sp, #0x170]  (0xb7cf270)
        // ldp d9, d8, [sp, #0x160]  (0xb7cf274)
        // ldp d11, d10, [sp, #0x150]  (0xb7cf278)
        // ldp d13, d12, [sp, #0x140]  (0xb7cf27c)
        // ldp d15, d14, [sp, #0x130]  (0xb7cf280)
        sp = sp + 0x1d0;
        return this;
}

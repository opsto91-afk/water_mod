// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7bf4b8
// fn_va = 0xb7bf4b8
// return type (guess): unknown (no ret found)
void* fn_0xb7bf4b8(void* this) {
        *(void**)(sp + 0x30) = rd8;
        // stp x29, x30, [sp, #0x40]  (0xb7bf4c0)
        // stp x24, x23, [sp, #0x50]  (0xb7bf4c4)
        // stp x22, x21, [sp, #0x60]  (0xb7bf4c8)
        // stp x20, x19, [sp, #0x70]  (0xb7bf4cc)
        fp = sp + 0x40;
        // mrs x22, tpidr_el0  (0xb7bf4d4)
        r19 = this;
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x18) = r8;
        r8 = *(void**)(this + 0x598);
        // scvtf s1, w8  (0xb7bf4e8)
        // fmov s2, w8  (0xb7bf4f0)
        // fcmpe s1, s2  (0xb7bf4f4)
        if (/* cond: b.hi */) goto label_0xb7bf528;
        // fmov s2, w8  (0xb7bf4fc)
        // fmov s3, #4  (0xb7bf500)
        // fdiv s2, s1, s2  (0xb7bf504)
        // fmul s2, s3, s2  (0xb7bf508)
        // fsub s8, s1, s2  (0xb7bf50c)
        r8 = *(uint8_t*)(r19 + 0x94e);
        // fmul s0, s8, s0  (0xb7bf514)
        *(void**)(r19 + 0x5a4) = rs8;
        *(void**)(r19 + 0x5a0) = rs0;
        // tbnz w8, #0x0, 0xb7bf698  (0xb7bf520)
        goto label_0xb7bf558;
    label_0xb7bf528:
        // fmov s3, #8  (0xb7bf52c)
        // fmov s2, w8  (0xb7bf530)
        // fcmpe s1, s2  (0xb7bf534)
        // fmov s2, #16  (0xb7bf538)
        // fcsel s2, s3, s2, ls  (0xb7bf53c)
        // fsub s8, s1, s2  (0xb7bf540)
        r8 = *(uint8_t*)(r19 + 0x94e);
        // fmul s0, s8, s0  (0xb7bf548)
        *(void**)(r19 + 0x5a4) = rs8;
        *(void**)(r19 + 0x5a0) = rs0;
        // tbnz w8, #0x0, 0xb7bf698  (0xb7bf554)
    label_0xb7bf558:
        r8 = *(void**)(r19 + 0x1118);
        r8 = *(void**)(r8 + 0x430);
        this = *(void**)(r8 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x4a8);
        this = (*(void**)r8)(this);  // indirect call
        // tbz w0, #0x0, 0xb7bf698  (0xb7bf570)
        r21 = (void*)0x1407c848;
        this = r21;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r23 = *(void**)(r8 + 0x928);
        if (r23 == 0) goto label_0xb7bf6e0;
        r8 = *(uint8_t*)(r23);
        if (r8 == 0) goto label_0xb7bf6e0;
        r20 = *(void**)(r8 + 0x930);
        if (r20 == 0) goto label_0xb7bf5e8;
        r1 = r20 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r9 = *(uint8_t*)(r23);
        *(void**)(sp) = r21;
        this = *(void**)(r8 + 0x938);
        *(uint8_t*)(sp + 0x8) = r24;
        // stp x23, x20, [sp, #0x10]  (0xb7bf5c8)
        *(void**)(sp + 0x20) = this;
        if (r9 != 0) goto label_0xb7bf604;
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0xb7bf5dc)
        *(void**)(r8) = r9;
        goto label_0xb7bf604;
    label_0xb7bf5e8:
        *(void**)(sp) = r21;
        this = *(void**)(r9 + 0x938);
        *(uint8_t*)(sp + 0x8) = r8;
        // stp x23, x20, [sp, #0x10]  (0xb7bf5fc)
        *(void**)(sp + 0x20) = this;
    label_0xb7bf604:
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x358);
        this = (*(void**)r8)(this);  // indirect call
        // fmul s0, s8, s0  (0xb7bf610)
        rs1 = *(void**)(r19 + 0x5a0);
        // stp xzr, xzr, [sp, #0x10]  (0xb7bf618)
        // fcmpe s0, s1  (0xb7bf61c)
        // fcsel s0, s0, s1, mi  (0xb7bf620)
        *(void**)(r19 + 0x5a0) = rs0;
        if (r20 == 0) goto label_0xb7bf688;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bf654;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bf654:
        r20 = *(void**)(sp + 0x18);
        *(void**)(sp + 0x20) = rzr;
        if (r20 == 0) goto label_0xb7bf688;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bf688;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bf688:
        r8 = *(uint8_t*)(sp + 0x8);
        if (r8 == 0) goto label_0xb7bf698;
        this = *(void**)(sp);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7bf698:
        rs0 = *(void**)(r19 + 0x5a0);
        // fmov s1, w8  (0xb7bf6a0)
        // fcmpe s0, s1  (0xb7bf6a4)
        // fcsel s0, s1, s0, mi  (0xb7bf6a8)
        *(void**)(r19 + 0x5a0) = rs0;
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bf710;
        this = r19;
        // ldp x20, x19, [sp, #0x70]  (0xb7bf6c4)
        rd8 = *(void**)(sp + 0x30);
        // ldp x22, x21, [sp, #0x60]  (0xb7bf6cc)
        // ldp x24, x23, [sp, #0x50]  (0xb7bf6d0)
        // ldp x29, x30, [sp, #0x40]  (0xb7bf6d4)
        sp = sp + 0x80;
        goto label_0xb7aef04;
    label_0xb7bf6e0:
        this = (void*)0x1407c848;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        r19 = this;
        this = sp;
        this = fn_0x88c5ef4(this, r1, r2, r3);  // call  [0x88c5ef4]
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bf710;
        this = r19;
        this = fn_0x8897594(this, r1, r2, r3);  // call  [0x8897594]
    label_0xb7bf710:
        this = fn_0x135df9a0(this, r1, r2, r3);  // call  [0x135df9a0]
        *(void**)(sp + 0x50) = rd10;
        // stp d9, d8, [sp, #0x60]  (0xb7bf71c)
        // stp x29, x30, [sp, #0x70]  (0xb7bf720)
        // stp x24, x23, [sp, #0x80]  (0xb7bf724)
        // stp x22, x21, [sp, #0x90]  (0xb7bf728)
        // stp x20, x19, [sp, #0xa0]  (0xb7bf72c)
        fp = sp + 0x70;
        // mrs x23, tpidr_el0  (0xb7bf734)
        r19 = this;
        this = r1;
        r8 = *(void**)(r23 + 0x28);
        // fmov s9, s0  (0xb7bf744)
        r20 = r1;
        *(void**)(fp - 0x28) = r8;
        this = fn_0x9e93210(this, r1, r2, r3);  // call  [0x9e93210]
        // fmov s8, s0  (0xb7bf754)
        // fmov s0, s9  (0xb7bf758)
        this = r19;
        r1 = r20;
        this = fn_0xb7b00c8(this, r1, r2, r3);  // call  [0xb7b00c8]
        this = *(void**)(r19 + 0x10f8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x130);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0xb7bfe38;
        r20 = this;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tbz w0, #0x0, 0xb7bf858  (0xb7bf788)
        this = *(void**)(r19 + 0x10f8);
        this = fn_0x9c773d8(this, r1, r2, r3);  // call  [0x9c773d8]
        r21 = this;
        *(void**)(r19 + 0x4cc) = rzr;
        // tbz w0, #0x0, 0xb7bf8e8  (0xb7bf79c)
        r8 = *(uint8_t*)(r19 + 0x94b);
        if (r8 != 0) goto label_0xb7bf8e8;
        r8 = *(uint8_t*)(r19 + 0x94a);
        if (r8 != 0) goto label_0xb7bf8e8;
        this = r20;
        this = fn_0xfdad978(this, r1, r2, r3);  // call  [0xfdad978]
        r22 = this;
        this = fn_0x10101aa0(this, r1, r2, r3);  // call  [0x10101aa0]
        if (r22 == 0) goto label_0xb7bf860;
        r8 = this;
        if (this == 0) goto label_0xb7bf860;
        this = r22;
        this = fn_0x10102e60(this, r1, r2, r3);  // call  [0x10102e60]
        *(void**)(sp + 0x20) = this;
        this = sp + 0x20;
        this = fn_0x100fd07c(this, r1, r2, r3);  // call  [0x100fd07c]
        // tst x0, #0xff00000000  (0xb7bf7ec)
        // movi d2, #0x0  (0xb7bf7f0)
        // csel w24, w22, w0, eq  (0xb7bf7f4)
        // scvtf s1, w22  (0xb7bf7f8)
        // fmov s3, #5  (0xb7bf7fc)
        // scvtf s0, w24  (0xb7bf800)
        rs4 = *(void**)(r19 + 0x5a0);
        // movi d10, #0x0  (0xb7bf808)
        this = fn_0x1351ef70(this, r1, r2, r3);  // call  [0x1351ef70]
        // fmov s1, #0.25  (0xb7bf810)
        // scvtf s5, w24  (0xb7bf814)
        *(void**)(r19 + 0x430) = rs0;
        // movi d3, #0x0  (0xb7bf81c)
        // fmov s4, #1  (0xb7bf820)
        // fmov s9, #1  (0xb7bf824)
        // fmul s2, s0, s1  (0xb7bf828)
        // scvtf s1, w22  (0xb7bf82c)
        // fmov s0, s5  (0xb7bf830)
        *(void**)(r19 + 0x42c) = rs2;
        // movi d2, #0x0  (0xb7bf838)
        this = fn_0x1351ef70(this, r1, r2, r3);  // call  [0x1351ef70]
        // fmul s0, s0, s0  (0xb7bf840)
        // fcmpe s0, s9  (0xb7bf844)
        if (/* cond: b.gt */) goto label_0xb7bf8d0;
        // fcmpe s0, #0  (0xb7bf84c)
        // fcsel s9, s0, s10, gt  (0xb7bf850)
        goto label_0xb7bf8d0;
    label_0xb7bf858:
        *(void**)(r19 + 0x4cc) = rzr;
        goto label_0xb7bfc80;
    label_0xb7bf860:
        this = r20;
        this = fn_0xfdad978(this, r1, r2, r3);  // call  [0xfdad978]
        r22 = this;
        this = fn_0x10101aa0(this, r1, r2, r3);  // call  [0x10101aa0]
        if (r22 == 0) goto label_0xb7bf8e8;
        if (this == 0) goto label_0xb7bf8e8;
        // fmov s0, s8  (0xb7bf880)
        this = r22 + 0x50;
        this = fn_0x101026d4(this, r1, r2, r3);  // call  [0x101026d4]
        // fmov s1, #15  (0xb7bf88c)
        rs2 = *(void**)(r19 + 0x5a0);
        // fmov s9, #1  (0xb7bf894)
        // fsub s1, s1, s2  (0xb7bf898)
        // fmul s1, s1, s0  (0xb7bf89c)
        // fsub s0, s9, s0  (0xb7bf8a0)
        // fadd s1, s2, s1  (0xb7bf8a4)
        // fmov s2, #0.75  (0xb7bf8a8)
        // fmul s0, s0, s0  (0xb7bf8ac)
        // fmul s2, s1, s2  (0xb7bf8b0)
        // fcmpe s0, s9  (0xb7bf8b4)
        *(void**)(r19 + 0x430) = rs1;
        *(void**)(r19 + 0x42c) = rs2;
        if (/* cond: b.gt */) goto label_0xb7bf8d0;
        // movi d1, #0x0  (0xb7bf8c4)
        // fcmpe s0, #0  (0xb7bf8c8)
        // fcsel s9, s0, s1, gt  (0xb7bf8cc)
    label_0xb7bf8d0:
        // fmov s0, s9  (0xb7bf8d0)
        this = r19 + 0x41c;
        this = fn_0x135394d8(this, r1, r2, r3);  // call  [0x135394d8]
        // fmov s0, #1  (0xb7bf8dc)
        // fsub s0, s0, s9  (0xb7bf8e0)
        *(void**)(r19 + 0x4cc) = rs0;
    label_0xb7bf8e8:
        r8 = *(uint8_t*)(r19 + 0x948);
        if (r8 == 0) goto label_0xb7bfad0;
        this = sp + 0x20;
        this = fn_0x1346904c(this, r1, r2, r3);  // call  [0x1346904c]
        this = sp + 0x20;
        this = fn_0x1346923c(this, r1, r2, r3);  // call  [0x1346923c]
        // tbz w0, #0x0, 0xb7bf9e8  (0xb7bf908)
        this = sp + 0x20;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0xb7bf9e8;
        r20 = this;
        this = sp + 0x20;
        r1 = r19 + 0x614;
        this = fn_0x11f0ca80(this, r1, r2, r3);  // call  [0x11f0ca80]
        this = r20;
        this = fn_0xfd8d070(this, r1, r2, r3);  // call  [0xfd8d070]
        this = fn_0x10b3eb34(this, r1, r2, r3);  // call  [0x10b3eb34]
        // and w8, w0, #0xff  (0xb7bf938)
        this = r20;
        // ucvtf s8, w8  (0xb7bf940)
        this = fn_0xfd827a0(this, r1, r2, r3);  // call  [0xfd827a0]
        r1 = sp + 0x20;
        r2 = rzr;
        this = fn_0x10372c30(this, r1, r2, r3);  // call  [0x10372c30]
        // and w8, w0, #0xff  (0xb7bf954)
        // fmov s2, #2  (0xb7bf958)
        // fmov s0, #1  (0xb7bf95c)
        // ucvtf s1, w8  (0xb7bf960)
        // fcmpe s1, s2  (0xb7bf964)
        // fcsel s1, s1, s2, gt  (0xb7bf968)
        // fcmpe s8, s0  (0xb7bf96c)
        if (/* cond: b.le */) goto label_0xb7bf990;
        // fmov s4, #13  (0xb7bf978)
        // scvtf s2, w8  (0xb7bf97c)
        // fadd s3, s8, s2  (0xb7bf980)
        // fdiv s3, s3, s4  (0xb7bf984)
        // fsub s2, s2, s3  (0xb7bf988)
        // fmul s1, s1, s2  (0xb7bf98c)
    label_0xb7bf990:
        rs2 = *(void**)(r19 + 0x1004);
        // movk w8, #0x3f66, lsl #0x10  (0xb7bf99c)
        // movk w9, #0x3dcc, lsl #0x10  (0xb7bf9a0)
        // fmov s3, w8  (0xb7bf9a4)
        // fmov s4, w9  (0xb7bf9a8)
        // movk w8, #0x3e2b, lsl #0x10  (0xb7bf9b0)
        // fmul s2, s3, s2  (0xb7bf9b4)
        // fmul s1, s4, s1  (0xb7bf9b8)
        // fmov s3, w8  (0xb7bf9bc)
        // fadd s1, s2, s1  (0xb7bf9c0)
        // fmov s2, #15  (0xb7bf9c4)
        // fmul s0, s1, s0  (0xb7bf9c8)
        *(void**)(r19 + 0x1004) = rs1;
        // fdiv s0, s0, s2  (0xb7bf9d0)
        rs2 = *(void**)(r19 + 0x1000);
        // fsub s0, s0, s2  (0xb7bf9d8)
        // fmul s0, s0, s3  (0xb7bf9dc)
        // fadd s0, s2, s0  (0xb7bf9e0)
        *(void**)(r19 + 0x1000) = rs0;
    label_0xb7bf9e8:
        // fmov s8, #1  (0xb7bf9ec)
        rs0 = *(void**)(r19 + 0x41c);
        // fmov s2, w8  (0xb7bf9f4)
        rs1 = *(void**)(r19 + 0x420);
        r20 = r19 + 0x41c;
        // fcmpe s0, s1  (0xb7bfa08)
        this = r20;
        // fdiv s2, s8, s2  (0xb7bfa10)
        // fcsel s0, s1, s0, mi  (0xb7bfa14)
        rs1 = *(void**)(r19 + 0x424);
        // csel x8, x9, x8, mi  (0xb7bfa1c)
        // fcmpe s0, s1  (0xb7bfa24)
        rs1 = *(void**)(r19 + 0x1000);
        // csel x8, x9, x8, mi  (0xb7bfa2c)
        // movk w8, #0x3f0c, lsl #0x10  (0xb7bfa38)
        // fcmpe s0, s2  (0xb7bfa3c)
        // fcsel s0, s2, s0, mi  (0xb7bfa40)
        // fmov s2, w8  (0xb7bfa44)
        // fdiv s0, s8, s0  (0xb7bfa48)
        // fmul s1, s1, s2  (0xb7bfa4c)
        // fsub s0, s0, s8  (0xb7bfa50)
        // fmul s0, s0, s1  (0xb7bfa54)
        // fadd s0, s8, s0  (0xb7bfa58)
        this = fn_0x135394d8(this, r1, r2, r3);  // call  [0x135394d8]
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x158);
        this = (*(void**)r8)(this);  // indirect call
        // scvtf s1, w8  (0xb7bfa74)
        // fmul s1, s0, s1  (0xb7bfa78)
        // fmov s0, #1  (0xb7bfa7c)
        // fcmpe s1, s8  (0xb7bfa80)
        if (/* cond: b.gt */) goto label_0xb7bfa94;
        // movi d0, #0x0  (0xb7bfa88)
        // fcmpe s1, #0  (0xb7bfa8c)
        // fcsel s0, s1, s0, gt  (0xb7bfa90)
    label_0xb7bfa94:
        this = r20;
        // movk w8, #0x3e4c, lsl #0x10  (0xb7bfa9c)
        // fmov s1, w8  (0xb7bfaa0)
        // fsub s2, s8, s1  (0xb7bfaa4)
        // fmul s0, s2, s0  (0xb7bfaa8)
        // fadd s0, s1, s0  (0xb7bfaac)
        this = fn_0x135394d8(this, r1, r2, r3);  // call  [0x135394d8]
        this = fn_0x1353968c(this, r1, r2, r3);  // call  [0x1353968c]
        // tbz w0, #0x0, 0xb7bfc80  (0xb7bfab8)
    label_0xb7bfabc:
        r8 = (void*)0x378111c;
        rq0 = *(void**)(r8);
        *(void**)(r20) = rq0;
        goto label_0xb7bfc80;
    label_0xb7bfad0:
        // tbz w21, #0x0, 0xb7bfc80  (0xb7bfad0)
        this = fn_0x10101aa0(this, r1, r2, r3);  // call  [0x10101aa0]
        if (this == 0) goto label_0xb7bfc80;
        this = r20;
        this = fn_0xfd98d48(this, r1, r2, r3);  // call  [0xfd98d48]
        // tbz w0, #0x0, 0xb7bfc80  (0xb7bfaec)
        // fmov s0, s8  (0xb7bfaf0)
        this = r20;
        this = fn_0xb7aa8d0(this, r1, r2, r3);  // call  [0xb7aa8d0]
        // fmov s4, #1  (0xb7bfb00)
        rs1 = *(void**)(r19 + 0x41c);
        // fmov s3, w8  (0xb7bfb08)
        rs2 = *(void**)(r19 + 0x420);
        r20 = r19 + 0x41c;
        // fcmpe s1, s2  (0xb7bfb1c)
        // fdiv s5, s4, s3  (0xb7bfb20)
        rs3 = *(void**)(r19 + 0x424);
        // fcsel s6, s2, s1, mi  (0xb7bfb28)
        // csel x8, x9, x8, mi  (0xb7bfb2c)
        // fcmpe s6, s3  (0xb7bfb34)
        // csel x8, x9, x8, mi  (0xb7bfb38)
        r8 = *(uint8_t*)(r19 + 0x948);
        // fcmpe s6, s5  (0xb7bfb44)
        // fcsel s5, s5, s6, mi  (0xb7bfb48)
        // fdiv s4, s4, s5  (0xb7bfb4c)
        if (r8 == 0) goto label_0xb7bfb64;
        // movk w8, #0x3eb3, lsl #0x10  (0xb7bfb58)
        // fmov s5, w8  (0xb7bfb5c)
        // fmul s0, s0, s5  (0xb7bfb60)
    label_0xb7bfb64:
        rs6 = *(void**)(r19 + 0x4cc);
        // fmul s1, s1, s4  (0xb7bfb6c)
        // scvtf s5, w8  (0xb7bfb70)
        // fmul s2, s2, s4  (0xb7bfb74)
        // fmul s3, s3, s4  (0xb7bfb78)
        r1 = sp + 0x20;
        this = r20;
        // fsub s5, s5, s6  (0xb7bfb84)
        rs6 = *(void**)(r19 + 0x428);
        // stp s1, s2, [sp, #0x20]  (0xb7bfb8c)
        // fmul s4, s6, s4  (0xb7bfb90)
        // fmul s0, s0, s5  (0xb7bfb94)
        // stp s3, s4, [sp, #0x28]  (0xb7bfb98)
        this = fn_0xb7ae3a0(this, r1, r2, r3);  // call  [0xb7ae3a0]
        this = r20;
        *(void**)(r19 + 0x41c) = rs0;
        *(void**)(r19 + 0x420) = rs1;
        *(void**)(r19 + 0x424) = rs2;
        *(void**)(r19 + 0x428) = rs3;
        this = fn_0x1353968c(this, r1, r2, r3);  // call  [0x1353968c]
        // tbz w0, #0x0, 0xb7bfbcc  (0xb7bfbb8)
        r8 = (void*)0x378111c;
        rq0 = *(void**)(r8);
        *(void**)(r20) = rq0;
    label_0xb7bfbcc:
        this = *(void**)(r19 + 0x968);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        // cmp this == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7bfc80;
        rs0 = *(void**)(r19 + 0x41c);
        // movk w8, #0x3e59, lsl #0x10  (0xb7bfbf0)
        // movk w9, #0x3f37, lsl #0x10  (0xb7bfbf4)
        rs1 = *(void**)(r19 + 0x420);
        // fmov s2, w8  (0xb7bfbfc)
        // fmov s3, w9  (0xb7bfc00)
        // movk w8, #0x3d93, lsl #0x10  (0xb7bfc08)
        r1 = sp + 0x20;
        this = r20;
        // fmul s0, s0, s2  (0xb7bfc14)
        // fmul s1, s1, s3  (0xb7bfc18)
        // fmov s3, w8  (0xb7bfc1c)
        rs2 = *(void**)(r19 + 0x424);
        // movk w8, #0x3eb3, lsl #0x10  (0xb7bfc28)
        // fadd s0, s0, s1  (0xb7bfc2c)
        // fmul s1, s2, s3  (0xb7bfc30)
        // fadd s0, s0, s1  (0xb7bfc34)
        // fmov s1, w8  (0xb7bfc38)
        // movk w8, #0x3f33, lsl #0x10  (0xb7bfc40)
        // fmul s0, s0, s1  (0xb7bfc44)
        // fmov v1.4s, #1  (0xb7bfc48)
        rv1 = rv0;
        // zip1 v1.4s, v1.4s, v1.4s  (0xb7bfc50)
        rv1 = rv0;
        // fmov s0, w8  (0xb7bfc58)
        *(void**)(sp + 0x20) = rq1;
        this = fn_0xb7ae3a0(this, r1, r2, r3);  // call  [0xb7ae3a0]
        *(void**)(r19 + 0x41c) = rs0;
        this = r20;
        *(void**)(r19 + 0x420) = rs1;
        *(void**)(r19 + 0x424) = rs2;
        *(void**)(r19 + 0x428) = rs3;
        this = fn_0x1353968c(this, r1, r2, r3);  // call  [0x1353968c]
        // tbnz w0, #0x0, 0xb7bfabc  (0xb7bfc7c)
    label_0xb7bfc80:
        r21 = (void*)0x1407f080;
        this = r21;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r22 = *(void**)(r8 + 0x160);
        if (r22 == 0) goto label_0xb7bfce4;
        r8 = *(uint8_t*)(r22);
        if (r8 == 0) goto label_0xb7bfce4;
        r20 = *(void**)(r8 + 0x168);
        if (r20 == 0) goto label_0xb7bfd50;
        r1 = r20 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r8 = *(uint8_t*)(r22);
        *(void**)(sp + 0x20) = r21;
        this = *(void**)(r9 + 0x170);
        *(uint8_t*)(sp + 0x28) = r24;
        // stp x22, x20, [sp, #0x30]  (0xb7bfcd4)
        *(void**)(sp + 0x40) = this;
        if (r8 != 0) goto label_0xb7bfd6c;
        goto label_0xb7bfd04;
    label_0xb7bfce4:
        this = (void*)0x1407f080;
        *(void**)(sp + 0x20) = rzr;
        *(uint8_t*)(sp + 0x28) = rzr;
        // stp xzr, xzr, [sp, #0x38]  (0xb7bfcf4)
        *(void**)(sp + 0x30) = rzr;
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
        r20 = rzr;
    label_0xb7bfd04:
        this = *(void**)(r19 + 0x968);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x20);
        this = (*(void**)r8)(this);  // indirect call
        // cmp this == <complex operand>
        if (/* cond: b.ne */) goto label_0xb7bfd80;
        this = *(void**)(r19 + 0x968);
        // scvtf s0, wzr  (0xb7bfd20)
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x108);
        r8 = sp + 0xc;
        this = (*(void**)r8)(this);  // indirect call
        r8 = *(uint8_t*)(sp + 0x1c);
        if (r8 == 0) goto label_0xb7bfd80;
        r8 = r19 + 0x42c;
        r9 = 0x42c8000000000000;
        *(void**)(r19 + 0x434) = rzr;
        *(void**)(r8) = r9;
        goto label_0xb7bfd80;
    label_0xb7bfd50:
        *(void**)(sp + 0x20) = r21;
        this = *(void**)(r9 + 0x170);
        *(uint8_t*)(sp + 0x28) = r8;
        // stp x22, x20, [sp, #0x30]  (0xb7bfd64)
        *(void**)(sp + 0x40) = this;
    label_0xb7bfd6c:
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x220);
        this = (*(void**)r8)(this);  // indirect call
        // tst x0, #0xfffffffe  (0xb7bfd78)
        if (/* cond: b.eq */) goto label_0xb7bfd04;
    label_0xb7bfd80:
        this = r19 + 0x41c;
        this = fn_0x13538e0c(this, r1, r2, r3);  // call  [0x13538e0c]
        rs2 = *(void**)(r19 + 0x42c);
        rs3 = *(void**)(r19 + 0x408);
        rs0 = *(void**)(r19 + 0x430);
        rs1 = *(void**)(r19 + 0x404);
        *(void**)(r19 + 0x428) = r8;
        // fcmpe s2, s3  (0xb7bfda0)
        // fcsel s2, s2, s3, mi  (0xb7bfda4)
        // fcmpe s0, s1  (0xb7bfda8)
        *(void**)(r19 + 0x42c) = rs2;
        if (/* cond: b.gt */) goto label_0xb7bfdc0;
        // movi d1, #0x0  (0xb7bfdb4)
        // fcmpe s0, #0  (0xb7bfdb8)
        // fcsel s1, s0, s1, gt  (0xb7bfdbc)
    label_0xb7bfdc0:
        *(void**)(r19 + 0x430) = rs1;
        // stp xzr, xzr, [sp, #0x30]  (0xb7bfdc4)
        if (r20 == 0) goto label_0xb7bfe28;
        r1 = r20 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bfdf4;
        r8 = *(void**)(r20);
        this = r20;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r20;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bfdf4:
        r19 = *(void**)(sp + 0x38);
        *(void**)(sp + 0x40) = rzr;
        if (r19 == 0) goto label_0xb7bfe28;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7bfe28;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7bfe28:
        r8 = *(uint8_t*)(sp + 0x28);
        if (r8 == 0) goto label_0xb7bfe38;
        this = *(void**)(sp + 0x20);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7bfe38:
        r8 = *(void**)(r23 + 0x28);
        r9 = *(void**)(fp - 0x28);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7bfe94;
        // ldp x20, x19, [sp, #0xa0]  (0xb7bfe48)
        rd10 = *(void**)(sp + 0x50);
        // ldp x22, x21, [sp, #0x90]  (0xb7bfe50)
        // ldp x24, x23, [sp, #0x80]  (0xb7bfe54)
        // ldp x29, x30, [sp, #0x70]  (0xb7bfe58)
        // ldp d9, d8, [sp, #0x60]  (0xb7bfe5c)
        sp = sp + 0xb0;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9c101c8
// fn_va = 0x9c101c8
// return type (guess): unknown (no ret found)
void* fn_0x9c101c8(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffc0]!  (0x9c101c8)
        // stp x28, x23, [sp, #0x10]  (0x9c101cc)
        // stp x22, x21, [sp, #0x20]  (0x9c101d0)
        // stp x20, x19, [sp, #0x30]  (0x9c101d4)
        // mrs x22, tpidr_el0  (0x9c101e0)
        r8 = *(void**)(r22 + 0x28);
        *(void**)(fp - 0x8) = r8;
        r19 = *(void**)(this + 0x8);
        if (r19 != 0) goto label_0x9c10280;
        r20 = this;
        r21 = r1;
        this = fn_0xe803540(this, r1, r2, r3);  // call  [0xe803540]
        // movi v0.2d, #0x0  (0x9c10204)
        r8 = *(void**)(r21);
        *(void**)(this + 0x28) = rzr;
        r19 = this;
        *(void**)(this) = r8;
        r8 = (void*)0x1407f9b8;
        *(void**)(this + 0x8) = rq0;
        *(void**)(this + 0x18) = rq0;
        // ldarb w8, [x8]  (0x9c10228)
        // tbz w8, #0x0, 0x9c10dd4  (0x9c1022c)
    label_0x9c10230:
        r8 = (void*)0x1407f968;
        // stp x8, x9, [x19, #0x38]  (0x9c10240)
        *(void**)(r19 + 0x48) = r23;
        this = r19 + 0x50;
        r1 = r21;
        this = fn_0x9c20044(this, r1, r2, r3);  // call  [0x9c20044]
        r8 = *(void**)(r21);
        *(void**)(r19 + 0x238) = rzr;
        *(void**)(r19 + 0x240) = r23;
        *(void**)(r19 + 0x230) = r8;
        if (r8 == 0) goto label_0x9c10c44;
        this = *(void**)(r20 + 0x8);
        *(void**)(r19 + 0x248) = r8;
        *(void**)(r20 + 0x8) = r19;
        if (this == 0) goto label_0x9c10280;
        this = fn_0xe803424(this, r1, r2, r3);  // call  [0xe803424]
        r19 = *(void**)(r20 + 0x8);
    label_0x9c10280:
        // nop   (0x9c10280)
        // adr x8, 0x9c10044  (0x9c10284)
        this = r19;
        r21 = sp + 0xd0;
        *(void**)(sp + 0x18) = r8;
        this = fn_0x9c203b0(this, r1, r2, r3);  // call  [0x9c203b0]
        r8 = *(void**)(this + 0x38);
        // cmp r8 == 0x5
        if (/* cond: b.ne */) goto label_0x9c102c8;
        // movi v0.2d, #0x0  (0x9c102a4)
        r8 = rzr;
        *(void**)(sp + 0x100) = rzr;
        // stp q0, q0, [x21, #0x10]  (0x9c102b0)
        *(void**)(r21) = rq0;
        r9 = *(void**)(sp + 0xd8);
        // cmp r9 == rzr
        if (/* cond: b.ne */) goto label_0x9c10374;
        goto label_0x9c10530;
    label_0x9c102c8:
        r20 = this;
        r9 = *(uint8_t*)(r10 + 0x40);
        // cmp r9 == <complex operand>
        r9 = r10 + 0x20;
        if (/* cond: b.ne */) goto label_0x9c102e8;
        r10 = *(void**)(r10 + 0x48);
        goto label_0x9c102f4;
    label_0x9c102e8:
        // ldp x10, x11, [x10, #0x20]  (0x9c102e8)
        // asr x10, x10, #0x2  (0x9c102f0)
    label_0x9c102f4:
        // ldp q1, q0, [x20]  (0x9c102f4)
        this = sp + 0xd0;
        r11 = *(void**)(r20 + 0x20);
        // stp x9, x10, [sp, #0xd0]  (0x9c10300)
        *(void**)(sp + 0x100) = r11;
        // stp q1, q0, [x21, #0x10]  (0x9c10308)
        r9 = *(void**)(r20 + 0x28);
        // stp x9, x8, [sp, #0x108]  (0x9c10310)
        this = fn_0x96b5da0(this, r1, r2, r3);  // call  [0x96b5da0]
        r8 = *(void**)(r20 + 0x38);
        // cmp r8 == 0x5
        if (/* cond: b.ne */) goto label_0x9c10338;
        r8 = rzr;
        r9 = *(void**)(sp + 0xd8);
        // cmp r9 == rzr
        if (/* cond: b.ne */) goto label_0x9c10374;
        goto label_0x9c10530;
    label_0x9c10338:
        // ldp q1, q0, [x20]  (0x9c10338)
        this = fp - 0x50;
        r9 = *(void**)(r20 + 0x20);
        *(void**)(fp - 0x20) = r9;
        r9 = r10 + 0x20;
        // stp q1, q0, [x21, #0x190]  (0x9c10350)
        r10 = *(void**)(r20 + 0x28);
        // stp x9, xzr, [x29, #0xffffffffffffffb0]  (0x9c10358)
        // stp x10, x8, [x29, #0xffffffffffffffe8]  (0x9c1035c)
        this = fn_0x96b5da0(this, r1, r2, r3);  // call  [0x96b5da0]
        r8 = *(void**)(fp - 0x48);
        r9 = *(void**)(sp + 0xd8);
        // cmp r9 == r8
        if (/* cond: b.eq */) goto label_0x9c10530;
    label_0x9c10374:
        r8 = (void*)0x1407f740;
        r21 = *(void**)(r19 + 0x248);
        // ldarb w8, [x8]  (0x9c10380)
        r23 = r19 + 0x230;
        r20 = r19 + 0x50;
        // tbz w8, #0x0, 0x9c10da8  (0x9c1038c)
    label_0x9c10390:
        // ldp x9, x8, [x21, #0x28]  (0x9c10390)
        // lsr x11, x8, #0x3  (0x9c1039c)
        r8 = *(void**)(r10 + 0x72c);
        // and x10, x10, x8  (0x9c103ac)
        r10 = *(void**)(r21 + 0x40);
    label_0x9c103b8:
        r9 = *(void**)(r9);
        // cmp r9 == - 0x1
        if (/* cond: b.eq */) goto label_0x9c10530;
        // madd x9, x9, x11, x10  (0x9c103c4)
        r12 = *(void**)(r9 + 0x8);
        // cmp r12 == r8
        if (/* cond: b.ne */) goto label_0x9c103b8;
        r8 = *(void**)(r21 + 0x48);
        // cmp r9 == r8
        if (/* cond: b.eq */) goto label_0x9c10530;
        r10 = *(void**)(r9 + 0x28);
        r8 = *(void**)(r9 + 0x10);
        // movk w9, #0xc695, lsl #0x10  (0x9c103ec)
        // cmp r10 == r9
        // ccmp x8, #0x0, #0x4, eq  (0x9c103f4)
        if (/* cond: b.eq */) goto label_0x9c10530;
        r9 = sp + 0x18;
        r21 = sp + 0xd0;
        *(uint8_t*)(sp + 0xd0) = rzr;
        *(uint8_t*)(sp + 0xd4) = rzr;
        *(uint8_t*)(sp + 0xd8) = rzr;
        *(uint8_t*)(sp + 0x248) = rzr;
        // stp x9, x21, [sp, #0x20]  (0x9c10414)
        // stp x8, x23, [sp, #0x30]  (0x9c10418)
        *(void**)(sp + 0x40) = rzr;
        this = r19;
        this = fn_0x9c203b0(this, r1, r2, r3);  // call  [0x9c203b0]
        r8 = *(void**)(r19 + 0x40);
        // cmp r8 == 0x5
        if (/* cond: b.ne */) goto label_0x9c10464;
        r8 = *(void**)(r19 + 0x8);
        if (r8 == 0) goto label_0x9c104c8;
        // ldp q0, q1, [x19, #0x10]  (0x9c1043c)
        // cmeq v1.2d, v1.2d, #0x0  (0x9c10440)
        // cmeq v2.2d, v0.2d, #0x0  (0x9c10444)
        // uzp1 v1.4s, v2.4s, v1.4s  (0x9c10448)
        // xtn v1.4h, v1.4s  (0x9c1044c)
        // umaxv h1, v1.4h  (0x9c10450)
        // fmov w9, s1  (0x9c10454)
        // tbnz w9, #0x0, 0x9c104c8  (0x9c10458)
        // fmov x9, d0  (0x9c1045c)
        goto label_0x9c10468;
    label_0x9c10464:
        // ldp x8, x9, [x19, #0x8]  (0x9c10464)
    label_0x9c10468:
        *(void**)(r19 + 0x40) = rzr;
        // ldp x9, x10, [x9, #0x20]  (0x9c1046c)
        // ldp x8, x11, [x8, #0x20]  (0x9c10470)
        // cmp r9 == r8
        if (/* cond: b.lo */) goto label_0x9c10558;
        r9 = *(void**)(r19 + 0x18);
        // ldp x9, x10, [x9, #0x20]  (0x9c10488)
        // cmp r9 == r8
        if (/* cond: b.lo */) goto label_0x9c10578;
    label_0x9c10498:
        r9 = *(void**)(r19 + 0x20);
        // ldp x9, x10, [x9, #0x20]  (0x9c1049c)
        // cmp r9 == r8
        if (/* cond: b.lo */) goto label_0x9c10598;
    label_0x9c104ac:
        r9 = *(void**)(r19 + 0x28);
        // ldp x9, x10, [x9, #0x20]  (0x9c104b0)
        // cmp r9 == r8
        if (/* cond: b.hs */) goto label_0x9c104c8;
    label_0x9c104c0:
        *(void**)(r19 + 0x40) = r8;
    label_0x9c104c8:
        r8 = *(void**)(this + 0x38);
        // cmp r8 == 0x5
        if (/* cond: b.eq */) goto label_0x9c10518;
        if (r23 == 0) goto label_0x9c10518;
        r8 = *(void**)(this);
        // cmp r23 == r8
        if (/* cond: b.eq */) goto label_0x9c105bc;
    label_0x9c104e8:
        r8 = *(void**)(this + 0x8);
        // cmp r23 == r8
        if (/* cond: b.eq */) goto label_0x9c10750;
    label_0x9c104f4:
        r8 = *(void**)(this + 0x10);
        // cmp r23 == r8
        if (/* cond: b.eq */) goto label_0x9c108e4;
    label_0x9c10500:
        r8 = *(void**)(this + 0x18);
        // cmp r23 == r8
        if (/* cond: b.eq */) goto label_0x9c10918;
    label_0x9c1050c:
        r8 = *(void**)(this + 0x20);
        // cmp r23 == r8
        if (/* cond: b.eq */) goto label_0x9c10ab0;
    label_0x9c10518:
        *(void**)(r19 + 0x48) = r8;
        r8 = *(uint8_t*)(sp + 0x248);
        if (r8 == 0) goto label_0x9c10530;
        this = r21 + 0x8;
        this = fn_0x1036e1ec(this, r1, r2, r3);  // call  [0x1036e1ec]
    label_0x9c10530:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0x9c10e74;
        sp = sp + 0x2a0;
        // ldp x20, x19, [sp, #0x30]  (0x9c10544)
        // ldp x22, x21, [sp, #0x20]  (0x9c10548)
        // ldp x28, x23, [sp, #0x10]  (0x9c1054c)
        // ldp x29, x30, [sp], #0x40  (0x9c10550)
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7be9ec
// fn_va = 0xb7be9ec
// return type (guess): unknown (no ret found)
void* fn_0xb7be9ec(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7be9ec)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc50;
        this = r19;
        this = fn_0xb7be24c(this, r1, r2, r3);  // call  [0xb7be24c]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bea0c)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bea14)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc58;
        this = r19;
        this = fn_0xb7be24c(this, r1, r2, r3);  // call  [0xb7be24c]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bea34)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bea3c)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc60;
        this = r19;
        this = fn_0xb7be24c(this, r1, r2, r3);  // call  [0xb7be24c]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bea5c)
        return fn_0x135d37b0(/* tail call */);
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0xb7bea64)
        *(void**)(sp + 0x10) = r19;
        r19 = this - 0xc78;
        this = r19;
        this = fn_0xb7be24c(this, r1, r2, r3);  // call  [0xb7be24c]
        this = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0xb7bea84)
        return fn_0x135d37b0(/* tail call */);
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7a7bc0
// fn_va = 0xb7a7bc0
// return type (guess): unknown (no ret found)
void* fn_0xb7a7bc0(void* this) {
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a58064
// fn_va = 0x9a58064
// return type (guess): unknown (no ret found)
void* fn_0x9a58064(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffd0]!  (0x9a58064)
        *(void**)(sp + 0x10) = r21;
        // stp x20, x19, [sp, #0x20]  (0x9a5806c)
        r20 = r8;
        this = fn_0xe803540(this, r1, r2, r3);  // call  [0xe803540]
        r19 = this;
        r8 = (void*)0x13883af0;
        r21 = this + 0x18;
        // stp xzr, xzr, [x0, #0x8]  (0x9a58090)
        *(void**)(this) = r8;
        this = r21;
        this = fn_0x9a57c44(this, r1, r2, r3);  // call  [0x9a57c44]
        // stp x21, x19, [x20]  (0x9a580a0)
        // ldp x20, x19, [sp, #0x20]  (0x9a580a4)
        r21 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x30  (0x9a580ac)
        return this;
}

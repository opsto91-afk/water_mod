// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d650
// fn_va = 0x8a3d650
// return type (guess): unknown (no ret found)
void* fn_0x8a3d650(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x8a3d650)
        *(void**)(sp + 0x10) = r19;
        this = *(void**)(this + 0x8);
        r19 = r8;
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0xf8);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3d688;
        this = this + 0x8;
        r8 = r19;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3d680)
        return fn_0xe82fbf4(/* tail call */);
    label_0x8a3d688:
        // stp xzr, xzr, [x19]  (0x8a3d688)
        this = r19;
        *(void**)(r19 + 0x10) = rzr;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3d698)
        return fn_0xe82f81c(/* tail call */);
        this = *(void**)(this + 0x8);
        r8 = *(void**)(this);
        r1 = *(void**)(r8 + 0xd8);
        goto *r_indirect;  // indirect branch/tailcall
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x8a3d6b0)
        *(void**)(sp + 0x10) = r19;
        this = *(void**)(this + 0x8);
        r19 = r8;
        r9 = *(void**)(this);
        r9 = *(void**)(r9 + 0x608);
        this = (*(void**)r8)(this);  // indirect call
        rd0 = *(void**)(this);
        *(void**)(r19) = rd0;
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x8a3d6dc)
        return this;
}

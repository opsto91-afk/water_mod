// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3d988
// fn_va = 0x8a3d988
// return type (guess): unknown (no ret found)
void* fn_0x8a3d988(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x8a3d988)
        // stp x20, x19, [sp, #0x10]  (0x8a3d98c)
        r19 = this;
        this = *(void**)(this + 0x8);
        r8 = *(void**)(this);
        r8 = *(void**)(r8 + 0x5d0);
        this = (*(void**)r8)(this);  // indirect call
        if (this == 0) goto label_0x8a3da18;
        this = *(void**)(r19 + 0x8);
        this = fn_0x9c76658(this, r1, r2, r3);  // call  [0x9c76658]
        r8 = *(void**)(r19 + 0x8);
        r20 = this;
        r9 = *(void**)(r8);
        this = r8;
        r9 = *(void**)(r9 + 0x5d0);
        this = (*(void**)r8)(this);  // indirect call
        this = fn_0xb7a34a4(this, r1, r2, r3);  // call  [0xb7a34a4]
        // tbz w20, #0x0, 0x8a3d9fc  (0x8a3d9d0)
        r8 = *(void**)(r19 + 0x8);
        r19 = this;
        r9 = *(void**)(r8);
        this = r8;
        r9 = *(void**)(r9 + 0xd8);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0xb7c8b9c(this, r1, r2, r3);  // call  [0xb7c8b9c]
        goto label_0x8a3da00;
    label_0x8a3d9fc:
        this = fn_0xb7c8e04(this, r1, r2, r3);  // call  [0xb7c8e04]
    label_0x8a3da00:
        // movk w8, #0x3c8e, lsl #0x10  (0x8a3da04)
        // fmov s1, w8  (0x8a3da08)
        // fmul s0, s1, s0  (0x8a3da0c)
        // fmov w8, s0  (0x8a3da10)
        // orr x0, x8, #0x100000000  (0x8a3da14)
    label_0x8a3da18:
        // ldp x20, x19, [sp, #0x10]  (0x8a3da18)
        // ldp x29, x30, [sp], #0x20  (0x8a3da1c)
        return this;
}

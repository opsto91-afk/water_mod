// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7b183c
// fn_va = 0xb7b183c
// return type (guess): unknown (no ret found)
void* fn_0xb7b183c(void* this) {
        // stp xzr, xzr, [sp]  (0xb7b183c)
        if (r19 == 0) goto label_0xb7b18a0;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b186c;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b186c:
        r19 = *(void**)(sp + 0x8);
        *(void**)(sp + 0x10) = rzr;
        if (r19 == 0) goto label_0xb7b18a0;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7b18a0;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7b18a0:
        r8 = *(void**)(r22 + 0x28);
        r9 = *(void**)(sp + 0x18);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7b191c;
        // fmov s0, s8  (0xb7b18b0)
        // ldp x20, x19, [sp, #0x50]  (0xb7b18b4)
        rd8 = *(void**)(sp + 0x20);
        // ldp x22, x21, [sp, #0x40]  (0xb7b18bc)
        // ldp x29, x30, [sp, #0x30]  (0xb7b18c0)
        sp = sp + 0x60;
        return this;
}

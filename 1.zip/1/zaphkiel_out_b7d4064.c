// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0xb7d4064
// fn_va = 0xb7d4064
// return type (guess): unknown (no ret found)
void* fn_0xb7d4064(void* this) {
        // stp x29, x30, [sp, #0x40]  (0xb7d4068)
        // stp x24, x23, [sp, #0x50]  (0xb7d406c)
        // stp x22, x21, [sp, #0x60]  (0xb7d4070)
        // stp x20, x19, [sp, #0x70]  (0xb7d4074)
        fp = sp + 0x40;
        // mrs x21, tpidr_el0  (0xb7d407c)
        r20 = (void*)0x1407f080;
        r8 = *(void**)(r21 + 0x28);
        r19 = this;
        this = r20;
        *(void**)(fp - 0x8) = r8;
        this = fn_0x135d038c(this, r1, r2, r3);  // call  [0x135d038c]
        r22 = *(void**)(r8 + 0x160);
        if (r22 == 0) goto label_0xb7d423c;
        r8 = *(uint8_t*)(r22);
        if (r8 == 0) goto label_0xb7d423c;
        r23 = *(void**)(r8 + 0x168);
        if (r23 == 0) goto label_0xb7d4100;
        r1 = r23 + 0x8;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
        r9 = *(uint8_t*)(r22);
        *(void**)(sp + 0x10) = r20;
        this = *(void**)(r8 + 0x170);
        *(uint8_t*)(sp + 0x18) = r24;
        // stp x22, x23, [sp, #0x20]  (0xb7d40e0)
        *(void**)(sp + 0x30) = this;
        if (r9 != 0) goto label_0xb7d411c;
        r8 = rzr;
        // movk w9, #0xdead, lsl #0x10  (0xb7d40f4)
        *(void**)(r8) = r9;
        goto label_0xb7d411c;
    label_0xb7d4100:
        *(void**)(sp + 0x10) = r20;
        this = *(void**)(r9 + 0x170);
        *(uint8_t*)(sp + 0x18) = r8;
        // stp x22, x23, [sp, #0x20]  (0xb7d4114)
        *(void**)(sp + 0x30) = this;
    label_0xb7d411c:
        r8 = *(void**)(this);
        r9 = *(void**)(r8 + 0x280);
        r8 = sp;
        this = (*(void**)r8)(this);  // indirect call
        // ldp x22, x20, [sp]  (0xb7d412c)
        if (r20 == 0) goto label_0xb7d4144;
        r1 = (void*)0x1407f088;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this == 0) goto label_0xb7d420c;
    label_0xb7d4144:
        r8 = *(void**)(r22 + 0x138);
        r9 = *(void**)(r19 + 0x598);
        // lsl w8, w8, #0x4  (0xb7d414c)
        // cmp r8 == r9
        if (/* cond: b.eq */) goto label_0xb7d416c;
    label_0xb7d4158:
        // cmp r9 == - <complex operand>
        *(void**)(r19 + 0x598) = r8;
        // cset w1, eq  (0xb7d4160)
        this = r19;
        this = fn_0xb7a7fe8(this, r1, r2, r3);  // call  [0xb7a7fe8]
    label_0xb7d416c:
        r19 = *(void**)(sp + 0x28);
        // stp xzr, xzr, [sp, #0x20]  (0xb7d4170)
        if (r19 == 0) goto label_0xb7d41d4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d41a0;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d41a0:
        r19 = *(void**)(sp + 0x28);
        *(void**)(sp + 0x30) = rzr;
        if (r19 == 0) goto label_0xb7d41d4;
        r1 = r19 + 0x8;
        this = 0xffffffffffffffff;
        this = fn_0x88973a0(this, r1, r2, r3);  // call  [0x88973a0]
        if (this != 0) goto label_0xb7d41d4;
        r8 = *(void**)(r19);
        this = r19;
        r8 = *(void**)(r8 + 0x10);
        this = (*(void**)r8)(this);  // indirect call
        this = r19;
        this = fn_0x135d3980(this, r1, r2, r3);  // call  [0x135d3980]
    label_0xb7d41d4:
        r8 = *(uint8_t*)(sp + 0x18);
        if (r8 == 0) goto label_0xb7d41e4;
        this = *(void**)(sp + 0x10);
        this = fn_0x135d03c8(this, r1, r2, r3);  // call  [0x135d03c8]
    label_0xb7d41e4:
        r8 = *(void**)(r21 + 0x28);
        r9 = *(void**)(fp - 0x8);
        // cmp r8 == r9
        if (/* cond: b.ne */) goto label_0xb7d4270;
        // ldp x20, x19, [sp, #0x70]  (0xb7d41f4)
        // ldp x22, x21, [sp, #0x60]  (0xb7d41f8)
        // ldp x24, x23, [sp, #0x50]  (0xb7d41fc)
        // ldp x29, x30, [sp, #0x40]  (0xb7d4200)
        sp = sp + 0x80;
        return this;
}

// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x9a58ebc
// fn_va = 0x9a58ebc
// return type (guess): unknown (no ret found)
void* fn_0x9a58ebc(void* this) {
        // stp x29, x30, [sp, #0xffffffffffffffe0]!  (0x9a58ebc)
        *(void**)(sp + 0x10) = r19;
        r19 = this;
        this = r1;
        this = fn_0xfd94ecc(this, r1, r2, r3);  // call  [0xfd94ecc]
        // tbz w0, #0x0, 0x9a58ee0  (0x9a58ed4)
        *(void**)(r19 + 0x8) = r8;
    label_0x9a58ee0:
        r19 = *(void**)(sp + 0x10);
        // ldp x29, x30, [sp], #0x20  (0x9a58ee4)
        return this;
}

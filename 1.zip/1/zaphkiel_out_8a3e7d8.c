// === Zaphkiel pseudo-C dump ===
// heuristic output — NOT a verified decompilation
#include <stdint.h>

// fn @ 0x8a3e7d8
// fn_va = 0x8a3e7d8
// return type (guess): unknown (no ret found)
void* fn_0x8a3e7d8(void* this, void* r1) {
        *(void**)(sp + 0x40) = rd8;
        // stp x29, x30, [sp, #0x48]  (0x8a3e7e0)
        *(void**)(sp + 0x58) = r21;
        // stp x20, x19, [sp, #0x60]  (0x8a3e7e8)
        fp = sp + 0x48;
        // mrs x21, tpidr_el0  (0x8a3e7f0)
        r20 = r1;
        r8 = *(void**)(r21 + 0x28);
        *(void**)(fp - 0x10) = r8;
        // ldp x8, x19, [x1]  (0x8a3e800)
        // stp x8, x19, [sp]  (0x8a3e804)
        if (r19 == 0) goto label_0x8a3e818;
        r1 = r19 + 0x10;
        this = fn_0x8897370(this, r1, r2, r3);  // call  [0x8897370]
    label_0x8a3e818:
        r8 = *(void**)(r20 + 0x10);
        *(void**)(sp + 0x10) = r8;
        this = sp + 0x18;
        r1 = sp;
        this = fn_0xe82f8c0(this, r1, r2, r3);  // call  [0xe82f8c0]
        this = sp + 0x18;
        this = fn_0xe82f8c4(this, r1, r2, r3);  // call  [0xe82f8c4]
        // tbz w0, #0x0, 0x8a3e864  (0x8a3e834)
        this = sp + 0x18;
        r1 = rzr;
        this = fn_0xfdb3b58(this, r1, r2, r3);  // call  [0xfdb3b58]
        if (this == 0) goto label_0x8a3e864;
        r20 = this;
        this = fn_0xfd828e4(this, r1, r2, r3);  // call  [0xfd828e4]
        // tst w0, #0x1  (0x8a3e854)
        // csel x20, x20, xzr, ne  (0x8a3e858)
        if (r19 != 0) goto label_0x8a3e86c;
        goto label_0x8a3e874;
    label_0x8a3e864:
        r20 = rzr;
        if (r19 == 0) goto label_0x8a3e874;
    label_0x8a3e86c:
        this = r19;
        this = fn_0xe80c714(this, r1, r2, r3);  // call  [0xe80c714]
    label_0x8a3e874:
        if (r20 == 0) goto label_0x8a3e8d0;
        this = r20;
        this = fn_0xfd89a58(this, r1, r2, r3);  // call  [0xfd89a58]
        if (this == 0) goto label_0x8a3e8d0;
        this = r20;
        this = fn_0xfd7fec4(this, r1, r2, r3);  // call  [0xfd7fec4]
        r19 = this;
        this = fn_0xfa4dd9c(this, r1, r2, r3);  // call  [0xfa4dd9c]
        this = r19;
        // fmov s8, s0  (0x8a3e8a0)
        this = fn_0xfa4dd9c(this, r1, r2, r3);  // call  [0xfa4dd9c]
        // fcmpe s8, #0  (0x8a3e8a8)
        // fmov w9, s8  (0x8a3e8ac)
        r10 = 0x100000000;
        // fmov w11, s0  (0x8a3e8b4)
        // csel x8, x10, xzr, gt  (0x8a3e8b8)
        // csel x9, x9, xzr, gt  (0x8a3e8bc)
        // fcmpe s0, #0  (0x8a3e8c0)
        // csel x10, x10, xzr, gt  (0x8a3e8c4)
        // csel x11, x11, xzr, gt  (0x8a3e8c8)
        goto label_0x8a3e8e0;
    label_0x8a3e8d0:
        r8 = rzr;
        r10 = rzr;
        r11 = rzr;
        r9 = rzr;
    label_0x8a3e8e0:
        r12 = *(void**)(r21 + 0x28);
        r13 = *(void**)(fp - 0x10);
        // cmp r12 == r13
        if (/* cond: b.ne */) goto label_0x8a3e938;
        // orr x0, x9, x8  (0x8a3e8f0)
        // orr x1, x11, x10  (0x8a3e8f4)
        // ldp x20, x19, [sp, #0x60]  (0x8a3e8f8)
        r21 = *(void**)(sp + 0x58);
        // ldp x29, x30, [sp, #0x48]  (0x8a3e900)
        rd8 = *(void**)(sp + 0x40);
        sp = sp + 0x70;
        return this;
}

#include "GameBridge.hpp"

#include <android/log.h>

#include <mutex>

// ---------------------------------------------------------------------------
// TODO list (details + code sketches: docs/NEXT_STEPS.md)
//
//  1. readPlayerPose():  hook the per-frame client update -> ClientInstance -> local player ->
//                        rotation (pitch,yaw) and position. Fill `out` and return true.
//  2. camera override:   hook the camera setup function; while cameraOverride(p) is true write
//                        p.pitch / p.yaw (orientation quaternion) and p.x/y/z (camera position)
//                        before calling the original, and restore afterwards.
//  3. (optional) command executor for CameraLink -> /camera /hud /fade commands.
//
// Until then readPlayerPose() returns false (Tools shows "Player pose: NOT connected") and
// the camera override is stored but nothing reads it.
// ---------------------------------------------------------------------------

namespace cm::game {

namespace {
std::mutex g_mu;
bool g_active = false;
Pose g_pose;
}  // namespace

CameraLink& link() {
  static CameraLink l;
  return l;
}

void onEnter() {
  __android_log_print(ANDROID_LOG_INFO, "CinematicMod", "cinematic mode ON (game link %s)",
                      link().connected() ? "connected" : "NOT connected - editor only");
  link().enter();
}

void onExit() {
  __android_log_print(ANDROID_LOG_INFO, "CinematicMod", "cinematic mode OFF");
  setCameraOverride(nullptr);
  link().exit();
}

bool readPlayerPose(Pose& /*out*/) {
  return false;  // TODO (see above)
}

void setCameraOverride(const Pose* pose) {
  std::lock_guard<std::mutex> l(g_mu);
  g_active = pose != nullptr;
  if (pose) g_pose = *pose;
}

bool cameraOverride(Pose& out) {
  std::lock_guard<std::mutex> l(g_mu);
  if (g_active) out = g_pose;
  return g_active;
}

}  // namespace cm::game

// GameBridge.hpp - the ONLY place that talks to Minecraft's own code.
//
// STATUS: stubs. The editor, timeline, segments, transitions and the camera ENGINE all work
// (and are tested); what is missing is connecting them to the game. The hook points are here:
//
//   readPlayerPose()      -> read where the real player is (position + pitch/yaw)      [TODO]
//   setCameraOverride()   -> make the game camera show a pose we computed             [TODO]
//   link()                -> optional /camera /hud /fade commands (needs a command executor)
//
// See docs/NEXT_STEPS.md for how to fill them in.
#pragma once
#include "CameraLink.hpp"
#include "Core.hpp"

namespace cm::game {

CameraLink& link();   // builds /camera /hud /fov_set /fade commands, sends them via the executor
void onEnter();       // cinematic mode switched ON
void onExit();        // cinematic mode switched OFF

// The player's real pose (what Add Key should store). Return false while not implemented.
bool readPlayerPose(Pose& out);

// Playback / scrubbing: show `pose` instead of the player's camera. nullptr = give the camera back.
// The editor calls this every frame while playing. Your camera hook reads it with cameraOverride().
void setCameraOverride(const Pose* pose);
bool cameraOverride(Pose& out);   // for the (future) camera hook: true while an override is active

}  // namespace cm::game

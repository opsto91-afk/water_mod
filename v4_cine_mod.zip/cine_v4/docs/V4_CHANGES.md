# V4 Cine Mod — what changed on top of V3.1

V3.1 ka editor/timeline/engine as-is hai. V4 ne sirf game bridge bhar diya.

## 1. GameBridge.cpp — poora implement (60.4 ke verified signatures)
- Background watcher thread (`init()`) libminecraftpe.so ke load ka wait karta hai (polling /proc/self/maps),
  phir 6 signatures resolve karke 4 hooks lagata hai. Hooks inert hain jab tak camera override na ho.
- `readPlayerPose(Pose&)`: pitch/yaw rotation component se (MC degrees, pitch + = look down, yaw 0 = south).
  Position: render-thread se capture hoti hai (`mCamPos`, har frame); fallback feet+1.62.
  Playback ke waqt (override active) visible camera ka pose hi return hota hai.
- `setCameraOverride()`: game camera is pose pe — orientation quaternion `UpdatePlayerFromCamera` hook se
  (original SKIP — freelook technique), position `RenderLevel` hook se BEFORE original
  (`renderer -> +0x430 -> +0x614` = `mCamPos`). Fade transitions in-game overlay ke saath chalti hain
  (editor khud black rect draw karta hai — kisi executor ki zaroorat nahi).
- Body/jism freeze: playback ke har frame player ka rotation component + head rotation snapshot pe restore
  hota hai; look input body ko ghuma nahi sakta (`LocalPlayerApplyTurnDelta` hook). Override khatam hote hi
  ek baar restore + snapshot clear.
- Crash tracer: FATAL signal (SIGSEGV/SIGBUS/SIGILL/SIGABRT/SIGFPE) pe last stage + fault addr +
  pc/lr/sp log me (`adb logcat -s CinematicMod` ya data-dir/cine_bridge.log).

## 2. Preloader pin fix (latent crash)
V3.1 CMake GIT_TAG **0.2.2** tha; launcher ka bundled preloader ModuleInfo me trailing `onKeybind`
std::function rakhta hai jise 0.2.2 nahi jaanta → registerModule ~32B past read → enable ke kuch seconds
bad game silent death (wahi bug jo water_mod v0.2.x me mila tha). Ab pin = **cc08b40a31471d3e2dedb267f5f17b28da2b0604**
(water_mod aur cine_mod jaisa hi verified commit).

## 3. MyMod.cpp
- `load()`: `cm::game::init(getDataDir())` — watcher start.
- `disable()`: `cm::game::shutdown()` — body restore, hooks unhook, watcher stop, log flush.
- `startPose`: ab `readPlayerPose` se aata hai (fallback 1.62 offset wali default value).
- Module display "V4 Cine Mod"; manifest version 4.0.0. Module id wahi (`cinematic_mod.mode`), folder id wahi (`cinematic_mod`).

## 4. Kya verify nahi hua (device par test zaroori)
- `mCamPos` write BEFORE original RenderLevel — motionblur isi timing pe READ karta hai, isliye reasonable hai.
  Agar position flow na kare (sirf rotation hile), to hook ko original ke AFTER ya kisi later stage pe le jana padega.
- pitch/yaw signs: 60.4 pe flip ho sakte hain (mirror image camera). Symptoms ke saath `quatFromYawPitch` me
  yaw sign ya pitch sign flip — ek line ka badlav.
- `ActorGetHeadRotation` on 60.4 verified signature hai; agar fail ho to head-rotation restore sirf body restore tak simit.
- ClientInstance vtable slot 31 (60.4) — 26.52 pe 32 tha.

## Test sequence (NEXT_STEPS ka "Step 5" plus)
1. Mod on → kurumi/`cine_bridge.log` me `signatures resolved` + `hooks install: ... ok ok ok ok`.
2. `Add Key` kisi jagah se 2 keys (alag POV) → Segment 1 → Play. Camera key1 → key2 flow kare; body freeze; jhatke na lage.
3. `/camera` executor kabhi wired nahi hai — CameraLink disconnected hi rahega (fade overlay kaam karta rahega).
4. Crash aaye to log ka `*** CRASH ... stage=bridge:...` line bhejna.

## Update V4.1 / V4.2 (device feedback)
- V4.1: localPlayer slot auto-probe (31 then 32) with pointer validation; Tools panel shows `Game hooks: ready/NOT ready`.
- Device log showed **only `ClientInstanceUpdate` was missing** (other signatures all resolved). So:
- V4.2: `ClientInstanceUpdate` is now OPTIONAL. The player pointer passed to `UpdatePlayerFromCamera`
  is our primary identity source (no signature, no vtable needed). Required hooks now: UpdatePlayerFromCamera,
  RenderLevel, LocalPlayerApplyTurnDelta. Head-rotation restore stays optional. Camera flow works without the sig.
- If a hand-built `ClientInstanceUpdate` pattern is derived later (Zaphkiel dumps live in /tmp/arena-coding-uploads,
  see zaphkiel_log-*.txt / all_functions.c), it can be dropped back into kSigClientInstanceUpdate.

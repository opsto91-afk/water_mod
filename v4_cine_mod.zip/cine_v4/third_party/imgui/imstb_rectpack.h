// imstb_rectpack.h  (placeholder, added: the original zip did not contain this file)
//
// imgui_draw.cpp unconditionally includes this header. It is intentionally left
// empty so that imstb_truetype.h falls back to its own simple built-in rectangle
// packer. That is enough for the small ASCII font atlas used by this mod.
//
// Optional: replace this file with the official imstb_rectpack.h from the ImGui
// repository (same version as the rest of this folder) for tighter atlas packing.

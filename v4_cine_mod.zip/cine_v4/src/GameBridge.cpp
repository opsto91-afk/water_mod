// GameBridge.cpp - the game-side bridge for V4 (Minecraft 60.4, Android arm64).
//
// What this does
//   Hooks four game functions (all signature-verified against 60.4, adapted from
//   QYCottage/BedrockTools, MIT):
//     ClientInstanceUpdate(client, value)   -> caches the ClientInstance*
//     UpdatePlayerFromCamera(camera, comp, player)
//                                              -> during override: the camera is ours.
//                                                 Original is SKIPPED (like freelook),
//                                                 orientation quaternion written to
//                                                 camera+0x28, body rotation + head
//                                                 rotation restored every frame.
//     LocalPlayerApplyTurnDelta(player, delta)  -> after original: while an override is
//                                                 active the body snapshot is restored,
//                                                 so look input never rotates the body.
//     RenderLevel(renderer, context, view)  -> before original: while an override is
//                                                 active, the camera position Vec3 is
//                                                 written to renderer -> +0x430
//                                                 (LevelRendererPlayer) -> +0x614
//                                                 (mCamPos). Also captured every frame
//                                                 for readPlayerPose() (the true eye pos).
//
//   The local player is fetched through the ClientInstance vtable (index 31 on 60.4 -
//   NEXT_STEPS documented 32 on 26.52). pitch/yaw come from the actor rotation component
//   (first Vec2, MC degrees, pitch + = look down, yaw 0 = south).
//
//   Fade transitions work without any command executor: the editor already draws the
//   black overlay itself (Editor.cpp, fadeAlpha). CameraLink stays unconnected.
//
// What is verified / unverified
//   - Signatures and offsets verified for the user's 60.4 build (via BedrockTools map).
//   - The position write into mCamPos BEFORE the original RenderLevel is the motionblur
//     read-position hypothesis (motionblur reads mCamPos at the same point). If on-device
//     the position does not flow, the next iteration is hooking a later stage.
//   - pitch/yaw sign conventions: MC degrees straight from the rotation component; the
//     quaternion basis (docs/V4_CHANGES.md) matches MC conventions. If the camera comes
//     out mirrored, flip the yaw sign in quatFromYawPitch.
//
// Logging: __android_log_print tag "CinematicMod" (adb logcat -s CinematicMod) AND
//   <data dir>/cine_bridge.log (or /storage/emulated/0/Android/media/org.levimc.launcher/kurumi/cine_bridge.log).
//   A crash tracer writes the last stage + fault address into that log on SIGSEGV/SIGBUS/SIGILL/SIGABRT/SIGFPE.
#include "GameBridge.hpp"

#include <android/log.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <signal.h>
#include <ucontext.h>
#include <unistd.h>

#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

namespace cm::game {

namespace {
using Clock = std::chrono::steady_clock;
constexpr float kDeg2Rad = 0.017453292519943295f;
constexpr float kEyeHeight = 1.62f;  // feet -> eyes (standing). mCamPos capture is preferred when fresh.

constexpr const char* kTag = "CinematicMod";
constexpr const char* kLibName = "libminecraftpe.so";
constexpr const char* kKurumiLog =
    "/storage/emulated/0/Android/media/org.levimc.launcher/kurumi/cine_bridge.log";
constexpr const char* kLogName = "cine_bridge.log";

// ---- offsets (Bedrock 60.4, from QYCottage/BedrockTools sdk/offsets, MIT) -------------
namespace off {
inline constexpr std::size_t Actor_mStateVectorComponent = 0x228;
inline constexpr std::size_t Actor_mRotationComponent = 0x238;
inline constexpr std::size_t Actor_mLevel = 0x1F0;
inline constexpr std::size_t Actor_mDimension = 0x1E0;
inline constexpr std::size_t LevelRenderer_mLevelRendererPlayer = 0x430;
inline constexpr std::size_t LevelRendererPlayer_mCamPos = 0x614;  // Vec3, render-side camera position
inline constexpr std::size_t CameraComponent_mOrientation = 0x28;  // 4 floats = quaternion [x y z w]
inline constexpr std::size_t kVTableClientInstanceGetLocalPlayer = 31;  // 26.52 was 32
}  // namespace off

// ---- signatures (60.4 exact bytes; see docs/V4_CHANGES.md) --------------------------
constexpr std::string_view kSigClientInstanceUpdate =
    "? ? ? FC ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 ? ? ? D1 59 D0 3B D5 ? ? ? 52 F5 03 02 2A";
constexpr std::string_view kSigUpdatePlayerFromCamera =
    "? ? ? D1 ? ? ? FD ? ? ? A9 ? ? ? F9 ? ? ? A9 ? ? ? A9 ? ? ? 91 54 D0 3B D5 ? ? ? 52";
constexpr std::string_view kSigRenderLevel =
    "? ? ? D1 ? ? ? FD ? ? ? 6D ? ? ? 6D ? ? ? 6D ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 57 D0 3B D5";
constexpr std::string_view kSigLocalPlayerApplyTurnDelta =
    "? ? ? D1 ? ? ? FD ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 56 D0 3B D5 F3 03 00 AA F4 03 01 AA ? ? ? F9 ? ? ? F8 ? ? ? F9 ? ? ? F9";
constexpr std::string_view kSigActorGetHeadRotation =
    "? ? ? F9 ? ? ? 52 00 E4 00 2F ? ? ? 72 ? ? ? A9 08 01 0B CB ? ? ? D3 ? ? ? 51 0C 01 0A 8A ? ? ? B9 6B 0D 0C 8B ? ? ? F9 ? ? ? F9 ? ? ? B1 ? ? ? 54 8B 15 0B 8B ? ? ? B9 BF 01 0A 6B ? ? ? 54 ? ? ? F9 7F 01 09 EB ? ? ? 54 ? ? ? F9 ? ? ? B4 ? ? ? A9 ? ? ? D3 8C 01 0A CB 7F 0D 8C EB ? ? ? 54 ? ? ? F8 ? ? ? B4 ? ? ? 92 ? ? ? 12 ? ? ? 92 ? ? ? B8 ? ? ? 32 48 01 08 4A 1F 01 0B 6B ? ? ? 54 ? ? ? D3 ? ? ? F9 01 E4 00 2F";
constexpr std::string_view kSigActorSetHeadRotation =
    "? ? ? F9 ? ? ? 52 ? ? ? 72 ? ? ? A9 08 01 0B CB ? ? ? D3 ? ? ? 51 0C 01 0A 8A ? ? ? B9 6B 0D 0C 8B ? ? ? F9 ? ? ? F9 ? ? ? B1 ? ? ? 54 8B 15 0B 8B ? ? ? B9 BF 01 0A 6B ? ? ? 54 ? ? ? F9 7F 01 09 EB ? ? ? 54 ? ? ? F9 ? ? ? B4 ? ? ? A9 ? ? ? D3 8C 01 0A CB 7F 0D 8C EB ? ? ? 54 ? ? ? F8 ? ? ? B4 ? ? ? 92 ? ? ? 12 ? ? ? 92 ? ? ? B8 ? ? ? 32 48 01 08 4A 1F 01 0B 6B ? ? ? 54 ? ? ? D3 ? ? ? F9 ? ? ? 92 ? ? ? F8 ? ? ? B4 ? ? ? 92 ? ? ? 92 08 0D 09 8B ? ? ? 2D C0 03 5F D6";

struct Resolved {
    uintptr_t clientInstanceUpdate = 0;
    uintptr_t updatePlayerFromCamera = 0;
    uintptr_t renderLevel = 0;
    uintptr_t localPlayerApplyTurnDelta = 0;
    uintptr_t actorGetHeadRotation = 0;
    uintptr_t actorSetHeadRotation = 0;
};
Resolved g_resolved;

// ---- file log + crash tracer ---------------------------------------------------------
struct LoggerState {
    int fd = -1;
    std::string path;
    std::mutex mu;
};
LoggerState g_log;

void flog(const std::string& s);  // fwd

namespace crash {

int g_fd = -1;
uintptr_t g_libBase = 0;
uintptr_t g_libEnd = 0;
uintptr_t g_selfBase = 0;
char g_stage[128] = "bridge:init";
struct sigaction g_old[NSIG];
const int kSigs[] = {SIGSEGV, SIGBUS, SIGILL, SIGABRT, SIGFPE};

void setStage(const char* s) {
    std::strncpy(g_stage, s, sizeof g_stage - 1);
    g_stage[sizeof g_stage - 1] = 0;
}
void put(const char* s) { if (g_fd >= 0) (void)!::write(g_fd, s, std::strlen(s)); }
void putHex(uint64_t v) {
    char b[19] = "0x0000000000000000";
    for (int i = 17; i >= 2; --i, v >>= 4) b[i] = "0123456789abcdef"[v & 0xF];
    put(b);
}
void putAddr(uint64_t a) {
    putHex(a);
    if (g_libBase && a >= g_libBase && a < g_libEnd) { put(" [libminecraftpe.so+"); putHex(a - g_libBase); put("]"); }
    else if (g_selfBase && a - g_selfBase < 0x1000000) { put(" [cinematic_mod.so+"); putHex(a - g_selfBase); put("]"); }
}
void handler(int sig, siginfo_t* si, void* uc) {
    put("\n*** CRASH signal="); putHex((uint64_t)sig);
    put(" code="); putHex((uint64_t)si->si_code);
    put(" fault_addr="); putAddr((uint64_t)si->si_addr);
#if defined(__aarch64__)
    auto* c = static_cast<ucontext_t*>(uc);
    put("\n    pc="); putAddr(c->uc_mcontext.pc);
    put("\n    lr="); putAddr(c->uc_mcontext.regs[30]);
    put("\n    sp="); putHex(c->uc_mcontext.sp);
#else
    (void)uc;
#endif
    put("\n    stage="); put(g_stage); put("\n");
    if (g_fd >= 0) ::fsync(g_fd);
    if (sig > 0 && sig < NSIG) sigaction(sig, &g_old[sig], nullptr);  // hand back to Android's handler
}
void install() {
    static bool done = false;
    if (done) return;
    done = true;
    Dl_info info{};
    if (dladdr(reinterpret_cast<void*>(&install), &info) && info.dli_fbase) g_selfBase = (uintptr_t)info.dli_fbase;
    struct sigaction sa{};
    sa.sa_sigaction = handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    for (int sig : kSigs) sigaction(sig, &sa, &g_old[sig]);
}
void setLib(uintptr_t base, uint64_t size) { g_libBase = base; g_libEnd = base + size; }
void setFd(int fd) { g_fd = fd; }

}  // namespace crash

void flog(const std::string& s) {
    std::lock_guard<std::mutex> lk(g_log.mu);
    if (g_log.fd >= 0) {
        char ts[16] = "--:--:--";
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        if (localtime_r(&t, &tmv)) std::strftime(ts, sizeof ts, "%H:%M:%S", &tmv);
        std::string line = std::string(ts) + " " + s + "\n";
        (void)!::write(g_log.fd, line.data(), line.size());
        ::fsync(g_log.fd);
    }
    __android_log_print(ANDROID_LOG_INFO, kTag, "%s", s.c_str());
}

struct LibMap { uintptr_t base = 0; uint64_t size = 0; };

bool findLib(LibMap& out) {
    FILE* f = std::fopen("/proc/self/maps", "r");
    if (!f) return false;
    char line[1024];
    bool found = false;
    uintptr_t lo = 0, hi = 0;
    while (std::fgets(line, sizeof line, f)) {
        if (!std::strstr(line, kLibName)) continue;
        unsigned long a = 0, b = 0, off_ = 0;
        char perms[8] = {};
        if (std::sscanf(line, "%lx-%lx %7s %lx", &a, &b, perms, &off_) != 4) continue;
        if (!found) {
            if (off_ != 0) continue;
            lo = a;
            hi = b;
            found = true;
        } else if (b > hi) {
            hi = b;
        }
    }
    std::fclose(f);
    if (!found) return false;
    out.base = lo;
    out.size = hi - lo;
    return true;
}

std::atomic<void*> g_clientInstance{nullptr};

bool resolveSignatures() {
    const std::string lib(kLibName);
    const std::vector<std::string> patterns = {
        std::string(kSigClientInstanceUpdate),
        std::string(kSigUpdatePlayerFromCamera),
        std::string(kSigRenderLevel),
        std::string(kSigLocalPlayerApplyTurnDelta),
        std::string(kSigActorGetHeadRotation),
        std::string(kSigActorSetHeadRotation),
    };
    const auto found = pl::memory::resolveSignatures(patterns, lib.c_str());
    auto get = [&](std::string_view p) -> uintptr_t {
        const auto it = found.find(std::string(p));
        return it == found.end() ? 0 : it->second;
    };
    g_resolved.clientInstanceUpdate = get(kSigClientInstanceUpdate);
    g_resolved.updatePlayerFromCamera = get(kSigUpdatePlayerFromCamera);
    g_resolved.renderLevel = get(kSigRenderLevel);
    g_resolved.localPlayerApplyTurnDelta = get(kSigLocalPlayerApplyTurnDelta);
    g_resolved.actorGetHeadRotation = get(kSigActorGetHeadRotation);
    g_resolved.actorSetHeadRotation = get(kSigActorSetHeadRotation);
    return g_resolved.clientInstanceUpdate && g_resolved.updatePlayerFromCamera &&
           g_resolved.renderLevel && g_resolved.localPlayerApplyTurnDelta &&
           g_resolved.actorGetHeadRotation && g_resolved.actorSetHeadRotation;
}

void logMissing() {
    auto report = [](const char* name, uintptr_t v) { if (!v) flog(std::string("  missing: ") + name); };
    report("ClientInstanceUpdate", g_resolved.clientInstanceUpdate);
    report("UpdatePlayerFromCamera", g_resolved.updatePlayerFromCamera);
    report("RenderLevel", g_resolved.renderLevel);
    report("LocalPlayerApplyTurnDelta", g_resolved.localPlayerApplyTurnDelta);
    report("ActorGetHeadRotation", g_resolved.actorGetHeadRotation);
    report("ActorSetHeadRotation", g_resolved.actorSetHeadRotation);
}

void* localPlayer() {
    auto* client = g_clientInstance.load(std::memory_order_acquire);
    if (!client) return nullptr;
    void** table = *reinterpret_cast<void***>(client);
    if (!table) return nullptr;
    using Fn = void* (*)(void*);
    auto fn = reinterpret_cast<Fn>(table[off::kVTableClientInstanceGetLocalPlayer]);
    return fn ? fn(client) : nullptr;
}

void* rotationComponent(void* player) {
    if (!player) return nullptr;
    return *reinterpret_cast<void**>(static_cast<char*>(player) + off::Actor_mRotationComponent);
}
void* stateVectorComponent(void* player) {
    if (!player) return nullptr;
    return *reinterpret_cast<void**>(static_cast<char*>(player) + off::Actor_mStateVectorComponent);
}
void* actorLevel(void* player) {
    if (!player) return nullptr;
    return *reinterpret_cast<void**>(static_cast<char*>(player) + off::Actor_mLevel);
}
void* actorDimension(void* player) {
    if (!player) return nullptr;
    return *reinterpret_cast<void**>(static_cast<char*>(player) + off::Actor_mDimension);
}

struct Vec2 {
    float x = 0.f, y = 0.f;
};

using HeadGetFn = Vec2 (*)(void*);
using HeadSetFn = void (*)(void*, float, float);

Vec2 getHeadRotation(void* player) {
    if (!g_resolved.actorGetHeadRotation) return {};
    return reinterpret_cast<HeadGetFn>(g_resolved.actorGetHeadRotation)(player);
}
void setHeadRotation(void* player, const Vec2& v) {
    if (!g_resolved.actorSetHeadRotation) return;
    reinterpret_cast<HeadSetFn>(g_resolved.actorSetHeadRotation)(player, v.x, v.y);
}

// ---- shared state ------------------------------------------------------------------
struct BodySnapshot {
    void* player = nullptr;
    void* level = nullptr;
    void* dimension = nullptr;
    std::array<float, 4> rotation{};  // rotationComponent first 4 floats
    std::array<float, 2> head{};      // ActorGetHeadRotation
    bool valid = false;
};

struct CameraState {
    Pose pose{};
    bool active = false;        // an override is currently requested
    std::array<float, 3> camPos{};
    bool camPosFresh = false;
    Clock::time_point camPosAt{};
    BodySnapshot body;
};
CameraState g_cam;
std::mutex g_mu;

bool sameEntity(const BodySnapshot& b, void* player) {
    return player && b.player == player && b.level == actorLevel(player) && b.dimension == actorDimension(player);
}

// must hold g_mu
void saveBodyLocked(void* player) {
    BodySnapshot& b = g_cam.body;
    void* rot = rotationComponent(player);
    if (!rot) { b.valid = false; return; }
    b.player = player;
    b.level = actorLevel(player);
    b.dimension = actorDimension(player);
    std::memcpy(b.rotation.data(), rot, sizeof b.rotation);
    const Vec2 head = getHeadRotation(player);
    b.head = {head.x, head.y};
    b.valid = true;
}

// must hold g_mu; safe to call any time
void restoreBodyLocked() {
    BodySnapshot& b = g_cam.body;
    if (!b.valid) return;
    if (void* rot = rotationComponent(b.player)) {
        std::memcpy(rot, b.rotation.data(), sizeof b.rotation);
    }
    setHeadRotation(b.player, {b.head[0], b.head[1]});
    b.valid = false;
}

// body frozen for the whole override window: called every frame
// must hold g_mu
void maintainBodyLocked(void* player) {
    if (g_cam.body.valid) {
        if (sameEntity(g_cam.body, player)) {
            // write the snapshot back (game may have shifted it from look input)
            if (void* rot = rotationComponent(player)) {
                std::memcpy(rot, g_cam.body.rotation.data(), sizeof g_cam.body.rotation);
            }
            setHeadRotation(player, {g_cam.body.head[0], g_cam.body.head[1]});
            return;
        }
        // different player (level reload): re-snapshot
        g_cam.body.valid = false;
    }
    saveBodyLocked(player);
}

// ---- orientation math -----------------------------------------------------------------
struct Vec3 {
    float x, y, z;
};
struct Quat {
    float x, y, z, w;
};
Vec3 cross_(const Vec3& a, const Vec3& b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}

// Pose (pitch + = look down, yaw 0 = south) -> MC camera quaternion.
// forward = (-sin y cos p, -sin p, cos y cos p); right = (-cos y, 0, -sin y);
// up = right x forward; matrix columns (right, up, -forward) -> quaternion.
Quat quatFromYawPitch(float yawDeg, float pitchDeg) {
    const float y = yawDeg * kDeg2Rad;
    const float p = pitchDeg * kDeg2Rad;
    const float sy = std::sin(y), cy = std::cos(y);
    const float sp = std::sin(p), cp = std::cos(p);
    const Vec3 right{-cy, 0.f, -sy};
    const Vec3 forward{-sy * cp, -sp, cy * cp};
    const Vec3 up = cross_(right, forward);
    const float m00 = right.x, m01 = up.x, m02 = -forward.x;
    const float m10 = right.y, m11 = up.y, m12 = -forward.y;
    const float m20 = right.z, m21 = up.z, m22 = -forward.z;
    Quat q{};
    const float tr = m00 + m11 + m22;
    if (tr > 0.f) {
        const float s = std::sqrt(tr + 1.f) * 2.f;
        q.w = 0.25f * s; q.x = (m21 - m12) / s; q.y = (m02 - m20) / s; q.z = (m10 - m01) / s;
    } else if (m00 > m11 && m00 > m22) {
        const float s = std::sqrt(1.f + m00 - m11 - m22) * 2.f;
        q.w = (m21 - m12) / s; q.x = 0.25f * s; q.y = (m01 + m10) / s; q.z = (m02 + m20) / s;
    } else if (m11 > m22) {
        const float s = std::sqrt(1.f + m11 - m00 - m22) * 2.f;
        q.w = (m02 - m20) / s; q.x = (m01 + m10) / s; q.y = 0.25f * s; q.z = (m12 + m21) / s;
    } else {
        const float s = std::sqrt(1.f + m22 - m00 - m11) * 2.f;
        q.w = (m10 - m01) / s; q.x = (m02 + m20) / s; q.y = (m12 + m21) / s; q.z = 0.25f * s;
    }
    const float len = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
    if (len > 1e-6f) { q.x /= len; q.y /= len; q.z /= len; q.w /= len; }
    return q;
}

// ---- frame hooks -----------------------------------------------------------------------
using ClientInstanceUpdateFn = void* (*)(void*, bool);
using UpdatePlayerFromCameraFn = void (*)(void*, void*, void*);
using RenderLevelFn = void (*)(void*, void*, void*);
using TurnDeltaFn = void (*)(void*, Vec2*);
ClientInstanceUpdateFn g_origClientUpdate = nullptr;
UpdatePlayerFromCameraFn g_origUpdatePlayer = nullptr;
RenderLevelFn g_origRenderLevel = nullptr;
TurnDeltaFn g_origTurnDelta = nullptr;
std::atomic<bool> g_hooksInstalled{false};

void* clientUpdateDetour(void* clientInstance, bool value) {
    if (clientInstance) g_clientInstance.store(clientInstance, std::memory_order_release);
    return g_origClientUpdate ? g_origClientUpdate(clientInstance, value) : nullptr;
}

void updatePlayerDetour(void* camera, void* component, void* player) {
    Pose p;
    bool over = false;
    void* lp = nullptr;
    {
        std::lock_guard<std::mutex> lk(g_mu);
        over = g_cam.active;
        if (over) p = g_cam.pose;
    }
    if (over) {
        lp = localPlayer();
        if (lp && player == lp) {
            crash::setStage("bridge:updatePlayer:override");
            std::lock_guard<std::mutex> lk(g_mu);
            maintainBodyLocked(player);
            if (camera) {
                const Quat q = quatFromYawPitch(p.yaw, p.pitch);
                std::memcpy(static_cast<char*>(camera) + off::CameraComponent_mOrientation, &q, sizeof q);
            }
            // Player rotation is authoritative for the body; the camera is ours. Skip the original.
            return;
        }
    }
    // not overriding (or not the local player): hand back the camera/body, then run the original.
    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (!over) restoreBodyLocked();
    }
    crash::setStage("bridge:updatePlayer:passthrough");
    if (g_origUpdatePlayer) g_origUpdatePlayer(camera, component, player);
}

void turnDeltaDetour(void* player, Vec2* delta) {
    crash::setStage("bridge:turnDelta");
    if (g_origTurnDelta) g_origTurnDelta(player, delta);
    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (g_cam.active && player && g_cam.body.valid && sameEntity(g_cam.body, player)) {
            if (void* rot = rotationComponent(player)) {
                std::memcpy(rot, g_cam.body.rotation.data(), sizeof g_cam.body.rotation);
            }
        }
    }
}

void renderLevelDetour(void* renderer, void* context, void* view) {
    crash::setStage("bridge:renderLevel");
    void* playerRenderer = nullptr;
    if (renderer) playerRenderer = *reinterpret_cast<void**>(static_cast<char*>(renderer) + off::LevelRenderer_mLevelRendererPlayer);
    if (playerRenderer) {
        std::lock_guard<std::mutex> lk(g_mu);
        // capture the current eye position (fresh every frame while not overriding)
        std::memcpy(g_cam.camPos.data(), static_cast<char*>(playerRenderer) + off::LevelRendererPlayer_mCamPos, sizeof g_cam.camPos);
        g_cam.camPosAt = Clock::now();
        if (g_cam.active) {
            const std::array<float, 3> eye = {g_cam.pose.x, g_cam.pose.y, g_cam.pose.z};
            std::memcpy(static_cast<char*>(playerRenderer) + off::LevelRendererPlayer_mCamPos, eye.data(), sizeof eye);
            g_cam.camPosFresh = false;  // our own write; don't feed it back as "real"
        } else {
            g_cam.camPosFresh = true;   // game-written eye position is valid now
        }
    }
    if (g_origRenderLevel) g_origRenderLevel(renderer, context, view);
}

// ---- lifecycle ---------------------------------------------------------------------------
std::atomic<bool> g_stop{false};
std::atomic<bool> g_started{false};
std::thread g_thread;

void unhookAll() {
    crash::setStage("bridge:unhook");
    if (g_origClientUpdate) {
        pl::memory::unhook(reinterpret_cast<void*>(g_resolved.clientInstanceUpdate), reinterpret_cast<void*>(clientUpdateDetour));
        g_origClientUpdate = nullptr;
    }
    if (g_origUpdatePlayer) {
        pl::memory::unhook(reinterpret_cast<void*>(g_resolved.updatePlayerFromCamera), reinterpret_cast<void*>(updatePlayerDetour));
        g_origUpdatePlayer = nullptr;
    }
    if (g_origRenderLevel) {
        pl::memory::unhook(reinterpret_cast<void*>(g_resolved.renderLevel), reinterpret_cast<void*>(renderLevelDetour));
        g_origRenderLevel = nullptr;
    }
    if (g_origTurnDelta) {
        pl::memory::unhook(reinterpret_cast<void*>(g_resolved.localPlayerApplyTurnDelta), reinterpret_cast<void*>(turnDeltaDetour));
        g_origTurnDelta = nullptr;
    }
    g_hooksInstalled.store(false);
    flog("hooks removed");
}

void watchLoop() {
    for (int attempt = 0; attempt < 240; ++attempt) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        if (g_stop.load(std::memory_order_relaxed)) return;
        LibMap lib;
        if (!findLib(lib)) {
            if (attempt == 0) flog("waiting for libminecraftpe.so ...");
            continue;
        }
        crash::setLib(lib.base, lib.size);
        char buf[160];
        std::snprintf(buf, sizeof buf, "libminecraftpe.so found, base=0x%llx - resolving signatures",
                      static_cast<unsigned long long>(lib.base));
        flog(buf);
        crash::setStage("bridge:resolve");
        if (!resolveSignatures()) {
            flog("SIGNATURE RESOLUTION FAILED - game hooks NOT installed (editor works, camera stays with the player). Missing:");
            logMissing();
            return;
        }
        flog("signatures resolved (local player via ClientInstance vtable[31])");
        crash::setStage("bridge:hooks");
        const bool r1 = pl::memory::hook(reinterpret_cast<void*>(g_resolved.clientInstanceUpdate),
                                         reinterpret_cast<void*>(clientUpdateDetour),
                                         reinterpret_cast<void**>(&g_origClientUpdate)) == 0;
        const bool r2 = pl::memory::hook(reinterpret_cast<void*>(g_resolved.updatePlayerFromCamera),
                                         reinterpret_cast<void*>(updatePlayerDetour),
                                         reinterpret_cast<void**>(&g_origUpdatePlayer)) == 0;
        const bool r3 = pl::memory::hook(reinterpret_cast<void*>(g_resolved.renderLevel),
                                         reinterpret_cast<void*>(renderLevelDetour),
                                         reinterpret_cast<void**>(&g_origRenderLevel)) == 0;
        const bool r4 = pl::memory::hook(reinterpret_cast<void*>(g_resolved.localPlayerApplyTurnDelta),
                                         reinterpret_cast<void*>(turnDeltaDetour),
                                         reinterpret_cast<void**>(&g_origTurnDelta)) == 0;
        flog(std::string("hooks install: ClientInstanceUpdate=") + (r1 ? "ok" : "FAILED") +
             " UpdatePlayerFromCamera=" + (r2 ? "ok" : "FAILED") +
             " RenderLevel=" + (r3 ? "ok" : "FAILED") +
             " LocalPlayerApplyTurnDelta=" + (r4 ? "ok" : "FAILED"));
        g_hooksInstalled.store(r1 && r2 && r3 && r4);
        crash::setStage("bridge:ready");
        return;
    }
    flog("gave up waiting for libminecraftpe.so (game hooks not installed)");
}

}  // namespace

CameraLink& link() {
    static CameraLink l;
    return l;
}

void init(const std::filesystem::path& dataDir) {
    if (g_started.exchange(true)) return;
    std::error_code ec;
    std::filesystem::create_directories(dataDir, ec);
    const std::string fileLog = (dataDir / kLogName).string();
    for (const std::string& p : {std::string(kKurumiLog), fileLog}) {
        const int fd = ::open(p.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd >= 0) { g_log.fd = fd; g_log.path = p; break; }
    }
    crash::setFd(g_log.fd);
    crash::install();
    flog("---- V4 bridge init  log: " + (g_log.path.empty() ? std::string("(android log only)") : g_log.path));
    g_stop.store(false);
    g_thread = std::thread(watchLoop);
}

void shutdown() {
    g_stop.store(true);
    if (g_thread.joinable()) g_thread.join();
    {
        std::lock_guard<std::mutex> lk(g_mu);
        g_cam.active = false;
        restoreBodyLocked();
    }
    unhookAll();
    flog("bridge shutdown");
    if (g_log.fd >= 0) { ::fsync(g_log.fd); ::close(g_log.fd); g_log.fd = -1; }
}

void onEnter() {
    __android_log_print(ANDROID_LOG_INFO, kTag, "cinematic mode ON (game link %s)",
                        link().connected() ? "connected" : "NOT connected - camera hooks");
    flog(std::string("cinematic mode ON (hooks ") + (g_hooksInstalled.load() ? "installed" : "not ready yet") + ")");
    link().enter();
}

void onExit() {
    flog("cinematic mode OFF");
    setCameraOverride(nullptr);
    link().exit();
}

bool readPlayerPose(Pose& out) {
    // While an override is active, the editor should sample the camera (the visible POV),
    // not the frozen body.
    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (g_cam.active) {
            out = g_cam.pose;
            out.fov = 70.f;
            return true;
        }
    }
    void* client = g_clientInstance.load(std::memory_order_acquire);
    void* player = client ? localPlayer() : nullptr;
    if (!player) return false;
    bool rotOk = false;
    if (void* rot = rotationComponent(player)) {
        float two[2];
        std::memcpy(two, rot, sizeof two);
        out.pitch = two[0];
        out.yaw = two[1];  // MC degrees; pitch + = look down; yaw 0 = south
        rotOk = true;
    }
    bool posOk = false;
    std::array<float, 3> eye{};
    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (g_cam.camPosFresh && g_cam.camPosAt + std::chrono::seconds(2) > Clock::now()) {
            eye = g_cam.camPos;
            posOk = true;
        }
    }
    if (!posOk) {
        if (void* svc = stateVectorComponent(player)) {
            std::memcpy(eye.data(), svc, sizeof eye);
            eye[1] += kEyeHeight;  // feet -> eye height
            posOk = true;
        }
    }
    if (posOk) {
        out.x = eye[0];
        out.y = eye[1];
        out.z = eye[2];
    }
    out.fov = 70.f;
    return rotOk && posOk;
}

void setCameraOverride(const Pose* pose) {
    std::lock_guard<std::mutex> lk(g_mu);
    g_cam.active = pose != nullptr;
    if (pose) g_cam.pose = *pose;
}

bool cameraOverride(Pose& out) {
    std::lock_guard<std::mutex> lk(g_mu);
    if (g_cam.active) out = g_cam.pose;
    return g_cam.active;
}

}  // namespace cm::game

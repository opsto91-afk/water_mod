// GameBridge.hpp - the ONLY place that talks to Minecraft's own code.
//
// V4 (built for Minecraft 60.4, Android arm64): the hooks are IMPLEMENTED.
//   init()      -> starts a background watcher; once libminecraftpe.so is loaded, the
//                  signatures are resolved and the hooks are installed (inert until
//                  an override is set). Call once at load().
//   shutdown()  -> removes the hooks, restores the body, stops the watcher. Call at disable().
//   readPlayerPose()    -> true once the game is readable; position is the EYE position
//                          (render camera, else feet + 1.62), pitch/yaw in degrees.
//   setCameraOverride() -> playback/scrub: while set, the camera renders this pose.
//                          nullptr gives the camera back and restores the body once.
//   cameraOverride()    -> for the hooks: true while an override is active.
//   hooksReady()        -> true once all game hooks are installed (for the Tools status line).
//
// See docs/V4_CHANGES.md and docs/NEXT_STEPS.md for the conventions and what to
// sign-flip if the camera comes out mirrored on device.
#pragma once
#include <filesystem>

#include "CameraLink.hpp"
#include "Core.hpp"

namespace cm::game {

CameraLink& link();   // builds /camera /hud /fov_set /fade commands, sends them via the executor
void onEnter();       // cinematic mode switched ON
void onExit();        // cinematic mode switched OFF

// Lifecycle (called by the mod entry):
void init(const std::filesystem::path& dataDir);  // start the watcher thread (once)
void shutdown();                                  // unhook + restore + stop (disable time)

// The player's real pose (what Add Key should store). False until the game is readable.
bool readPlayerPose(Pose& out);

// Playback / scrubbing: show `pose` instead of the player's camera. nullptr = give the camera back.
// The editor calls this every frame while playing. The camera hooks read it with cameraOverride().
void setCameraOverride(const Pose* pose);
bool cameraOverride(Pose& out);   // true while an override is active
bool hooksReady();                // true once all game hooks are installed

}  // namespace cm::game

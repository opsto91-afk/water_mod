# Third-party references & code

The mod itself is original. The game-side bridge (src/GameBridge.cpp) is built directly against
layout information and hook patterns verified from an open-source project:

## QYCottage/BedrockTools — Leviathan (MIT License, (c) 2026 RadiantByte)
https://github.com/QYCottage/BedrockTools

Used (offsets, byte-signature patterns, hook points, per-frame restore technique):
  * `SignatureId::ClientInstanceUpdate`, `UpdatePlayerFromCamera`, `RenderLevel`,
    `LocalPlayerApplyTurnDelta`, `ActorGetHeadRotation`, `ActorSetHeadRotation`
    (src/core/memory/Signatures.cpp)
  * Offsets: Actor::mLevel 0x1F0, Actor::mDimension 0x1E0, mStateVectorComponent 0x228,
    mActorRotationComponent 0x238, LevelRenderer::mLevelRendererPlayer 0x430,
    LevelRendererPlayer::mCamPos 0x614, CameraComponent::mOrientation 0x28
  * `VTable::ClientInstanceGetLocalPlayer` index (31 on 60.4)
  * The freelook technique: skip the camera-sync original, write the orientation
    quaternion at camera+0x28, restore the player's rotation component + head
    rotation every frame.
  * The motionblur technique: renderer -> +0x430 -> +0x614 Vec3 camera position,
    captured / overridden inside RenderLevel.

Copyright (c) 2026 RadiantByte. MIT License — see https://github.com/QYCottage/BedrockTools/blob/master/LICENSE

## ImGui (third_party/imgui) — MIT, Omar Cornut and contributors.
## LeviLauncher preloader-android (LiteLDev/preloader-android) — Apache-2.0, LiteLDev.
## OpenJML / Pojav Controls Fixed (Craftandoof) — referenced for controls approach (no code copied).
## Do a Barrel Roll (theaddonn/MrPokeG) — GPL-3.0, referenced for layout ideas only (no code copied).
